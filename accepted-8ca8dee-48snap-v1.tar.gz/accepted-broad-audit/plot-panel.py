import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
for kind in ['run','pass']:
    cases=[json.loads(p.read_text()) for p in sorted((root/'cases').glob('A*.json'))]
    cases=[c for c in cases if c['result']['kind']==kind]
    fig,axes=plt.subplots(6,4,figsize=(20,22))
    for ax,c in zip(axes.flat,cases):
        r=c['result'];a=c['actors'];fs=r['frames'];xy=np.array([f['agents'] for f in fs]).reshape(-1,22,3)
        for actor in a:
            i=actor['idx']; color='#829bbb' if actor['team']=='D' else '#b7a59b'
            ax.plot(xy[:,i,0],xy[:,i,1],c=color,lw=.6,alpha=.7)
            ax.scatter(xy[0,i,0],xy[0,i,1],c=color,s=10)
        who=r['stats'].get('receiver') or r['stats'].get('rusher')
        idx=next((a['idx'] for a in a if a['id']==who),0)
        if who:
            sel=np.array([f['carrier']==idx for f in fs]);path=xy[sel,idx,:2]
            if len(path):
                ax.plot(path[:,0],path[:,1],c='#a72b2b',lw=2)
                ax.scatter(path[::10,0],path[::10,1],c=np.arange(len(path))[::10],cmap='plasma',s=12)
        for e in r['events']:
            if e['type'] in ['handoff','catch','carrier_contact','touchdown'] and 'pos' in e:
                ax.scatter(e['pos']['x'],e['pos']['y'],marker='x',s=28,c='black')
        ax.axvline(35,c='black',lw=.6);ax.axvline(45,c='black',lw=.5,ls=':')
        ax.set_xlim((22,66) if kind=='run' else (20,111));ax.set_ylim(0,160/3);ax.set_aspect('equal',adjustable='box')
        ax.tick_params(labelsize=7)
        ax.set_title(f"{c['caseId']} {c['matchup']}\n{c['concept']} {r['outcome']} {r['offenseYards']:.1f}yd / {r['duration']:.2f}s",fontsize=9)
    fig.suptitle(f'Accepted 8ca8dee: all 24 {kind} plays, all-player native paths\nOffense brown, defense blue, actual receiver/rusher possession red; time markers every .5s. Descriptive paths, not automatic faults.',fontsize=13)
    fig.tight_layout(rect=[0,0,1,.96]);fig.savefig(root/f'{kind}-panel.png',dpi=130);plt.close(fig)
