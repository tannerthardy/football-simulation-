# Accepted-build full-game checkpoint

Four games ran once on accepted `70b4db6a3ef53acc1a0e90cd055f1087205daa30`, seeds701–704. All completed. No runtime source or settings changed.

Open `index.html` for each standalone full-telemetry film. Native stable IDs are G1–G4 plus the one-based log entry (e.g. G1-P003), not an ordinal within the filtered panel. Every film contains its own matchup; placeholder seed slots support shared cohort IDs and do not indicate additional games.

`accepted/<fixture>/game.json.gz` is the complete native saved result, full telemetry and passive contact observations. `summary.json` has context and artifact hashes. `plays.jsonl`/`observations.jsonl` are append-only recovery prefixes; the archives retain both these and the complete raw gzip for exact verification. `batch-ledger.json` and `launcher-receipt.json` preserve attempt/completeness/cost/source information.

`report/play-index.{json,csv}` inventories every log entry. `report/audit-panel.json` defines the shared outcome-blind48-snap sample and a separately labeled diagnostic tail. Nobody should select replacement plays after watching outcomes.

This is diagnostic exposure across four generated-roster games, not an NFL population estimate, a new baseline or a paired comparison against older builds. Native recorded positions are quantized to0.1yard/0.1second; full numeric telemetry is sampled and rounded. Recorded facing is not gaze. Unrecorded requests and rejected alternatives remain unknown. Two-point tries have passive observations but no native film; see the inventory. Impulse-report counts are not distinct collisions or football defects.

Audit assignment -> acquired cue -> request -> achieved response -> next responsibility. Preserve legitimate opposing wins. Rank repeated mechanisms before proposing engine changes. No new games are required to inspect this packet.

For standalone saved-data reporting after extracting all archives, change into the extracted directory and run `node evidence/accepted-game-audit-report.mjs .`. Its frozen input manifests are included at their original relative paths. This command does not import the engine.

Remote retention uses dedicated orphan evidence branch codex/accepted-games-70b4db6-evidence-v1. See the outer artifact README/receipt and PR129 for verified immutable commit and downloads. This branch contains data only and must never be merged into develop.
