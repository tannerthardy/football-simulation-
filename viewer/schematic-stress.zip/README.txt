SCHEMATIC STRESS FILM ROOM

Open schematic-stress.html in Chrome, Edge or Firefox. The file contains every
recorded trajectory and telemetry layer; no server or network is required.

Seven saved native 11-on-11 clips:
SS-02-written: stationary split-zone slice versus Wide-9.
SS-04-written: Counter into Under/spill, actual five rush/front roles.
SS-06-written: Bunch Mesh with only one crosser; incomplete concept install.
SS-08-written: static quad-diamond quick-outs, NOT screen or presnap motion.
SS-10-written: third & 27 inside zone, actual three rush/eight cover.
PA-SHOT-baseline / PA-SHOT-current: saved protector-read comparison.

Select players and layers to inspect the recorded state. Body facing is not
measured eye gaze. Native stress clips lack recorded trait ratings; the viewer
says Unrecorded and uses saved physical mass/height. No plays were resimulated
for this export. Reduced moving-slice witnesses stay in the raw repository
packet; they have no invented credited yards or full-game result.

Use Copy play reference to report a clip, exact source and timestamp.
The existing Export video controls save a selected time range as WebM where
the browser supports canvas recording. All displayed gains are pre-penalty.
Sources and input/output hashes are in source-pins.json and embedded metadata.
