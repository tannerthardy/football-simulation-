GRIDIRON FILM ROOM

Open film-room.html in a browser. It contains all play data and works offline.
828 clips across 6 games, with stable play IDs and filters for concept, front, coverage and formation.
Source: c9d21a3bba0ac0e3cc8c27925f4f5b8b27dde76ddd893a9b84fcad0f33e084ec
Branch: claude/engine-priorities

The replay.template.html source is an empty template; use this populated file.
