GRIDIRON FILM ROOM

Unzip this archive and open film-room.html in your browser.

862 recorded clips across six games (seeds 7-12), 27 concepts.
Engine source SHA-256: 622c45f18386aad28e724d8745933626a1f4e49adf1410fc687cfddb517a1218
Branch: claude/engine-priorities

Use Copy play reference when reporting a problem: game/clip IDs alone can
change when the physics changes later game paths.
Player ticks are body facing, not vision. Inspect player shows weight and
approximate speed from the recorded path. Pitch release/catch are separate.

Physics is still NOT READY for certification. Read
docs/reviews/snap-mesh-pull-and-nfl-movement.md in the repository.
