GRIDIRON FILM ROOM

Unzip this archive and open film-room.html in your browser.

858 recorded clips across six games (seeds 7-12), 27 concepts.
Engine source SHA-256: 6368ce73ec217e52860d34533d9de102b028725b23688735c5f0b58aace472c5
Branch: claude/engine-priorities

Use Copy play reference when reporting a problem: game/clip IDs alone can
change when the physics changes later game paths.

Physics is still NOT READY for certification. Read
docs/reviews/contact-height-press-and-physics-readiness.md in the repository.
