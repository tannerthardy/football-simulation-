Gridiron Film Room

Open film-room.html in Chrome, Safari, Firefox or Edge.
No Node installation or server is needed for playback.

767 clips from six games, seeds 7-12, with 27 concepts.
Choose an offensive concept, then click Watch selection.
Auto-next stays within your selected clips. Loop selection repeats them.
Use Hide filters for more viewing room.

The simulation snapshot uses engine commit d76cb9b (2026-10-08).
Generate fresh film after engine changes with:
  npm run replay -- 7 --games 6 --doc
