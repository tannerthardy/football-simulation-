Gridiron film room

Open film-room.html locally in a browser. 870 clips, six games (seeds 7-12), 27 concepts.
Engine source SHA-256: e6f1cea4f7c3d2d1a5660c00b31d12cef68a8e1c73d6574931053e7937b5ab57
Physics is NOT READY; see docs/reviews/nfl-reference-and-support-integration.md in the repository.
Copied play references include the film source version. Old play IDs belong to their original film version.
