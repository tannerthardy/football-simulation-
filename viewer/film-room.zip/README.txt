GRIDIRON FILM ROOM

Unzip and open film-room.html in a browser.
821 simulated clips, 27 concepts, six games (seeds 7-12).
Film source version: f77b289aa2406e999cdb41ab399139ef68561de68267c10776c584be104a311e

Use concept/front/coverage filters and Watch selection.
Each clip has an ID. Copy play reference includes version and timestamp.
Pressure filter: defender within two yards before throw, sack or scramble.
QB sensed pressure is a separate perception flag.

Source branch: claude/engine-priorities
Repository: https://github.com/tannerthardy/football-simulation-
