GRIDIRON FILM ROOM

Open film-room.html in a browser. It contains all play data and works offline.
808 clips across 6 games, with stable play IDs and filters for concept, front, coverage and formation.
Source: 0bf4abc5bfdd385a7dd4231305adfab8fed4c6af5c9d64ad92cc4ac1f7bafd64
Branch: claude/engine-priorities

The replay.template.html source is an empty template; use this populated file.
