GRIDIRON FILM ROOM

Extract this ZIP and open film-room.html in a browser. All data is included; the HTML works offline.

812 filmed plays, 27 concepts, 6 games (seeds 7–12).
Engine source SHA-256: 192b8d9644146584c6d9315cb1795b3a74e41451d8074703593513b4addf8f97

Use Group plays by and filters to compare concepts, fronts, coverage and results. Search for a stable ID such as G1-P078. Copy play reference includes the film version and timestamp; include it when reporting a problem. IDs identify plays within this export.
