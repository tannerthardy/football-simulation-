GRIDIRON FILM ROOM — physics development, NOT READY

Unzip both files and open film-room.html in a browser. The HTML contains the
plays; replay.template.html is only the developer template.

845 filmed plays, 6 games (seeds 7–12), 27 concepts.
Engine source SHA-256: e0ecd30f2c6c160f463f1fbbdeef599b0956587ec61f0e74ab24a222e3041a18
Branch: claude/engine-priorities

Group/filter by concept, family, front, coverage or game. Watch a selection,
use next/previous, and inspect player weight and recorded-path speed.
Body-facing ticks are not eye direction. Copy play reference includes the film
version, play ID and timestamp so a report can be recreated.

IDs change their contents when the engine regenerates games. Previous user
observations are preserved in the repository at
 data/reviews/physics-world/shared-actuation/owner-film-observations.json.

Current handoff: docs/reviews/shared-actuation-and-physics-transfer.md.
Force/work consistency improved, but football hand-fighting convergence and
run-contact/coverage/pursuit realism remain unresolved. This film is evidence
for development, not a claim that the physics has earned its readiness OK.
