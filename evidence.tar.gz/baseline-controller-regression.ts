import { CENTER_Y } from '../src/core/field.js';
import { Rng } from '../src/core/rng.js';
import { generateTeam, pickDefense, pickOffense } from '../src/league/team.js';
import { RUN_BY_ID } from '../src/playbook/concepts.js';
import { COVERAGE_BY_ID, FRONT_BY_ID } from '../src/playbook/defense.js';
import { FORMATION_BY_ID } from '../src/playbook/formations.js';
import { RunBlocker } from '../src/sim/behaviors/blocking.js';
import { PlaySim } from '../src/sim/playsim.js';

const formation = FORMATION_BY_ID.ace_11;
const offense = generateTeam(new Rng(31), 'O', 'O', { strength: .55 });
const defense = generateTeam(new Rng(32), 'D', 'D', { strength: .55 });

/** Synthetic decision encounter with actual perception latency. The advancing
 * snapshot records changed reality; the blocker can still receive the older
 * picture. No native continuation or useful block is awarded by this fixture.
 */
function stage(work = true, known: boolean | undefined = true) {
  const sim = new PlaySim({
    offense: pickOffense(offense, formation.personnel), defense: pickDefense(defense, 'base43'),
    offCall: { formation, flip: false, kind: 'run', run: RUN_BY_ID.iz_strong, label: 'work reference' },
    defCall: { personnel: 'base43', front: FRONT_BY_ID.over, coverage: COVERAGE_BY_ID.cover3,
      pressure: null, label: 'Over' }, los: 40, ballY: CENTER_Y, firstDownX: 50, seed: 3,
  });
  for (const b of sim.agents) {
    b.body.pos = { x: 80 + b.idx * 2, y: CENTER_Y };
    b.body.vel = { x: 0, y: 0 };
    if (b.team === 'O') b.behavior = { kind: 'fixture-unassigned', update: () => ({ vel: { x: 0, y: 0 } }) };
  }
  const a = sim.slot('C')!, qb = sim.slot('QB')!, rb = sim.slot('RB')!;
  a.body.pos = { x: 40, y: CENTER_Y };
  qb.body.pos = { x: 45, y: CENTER_Y + 4 };
  rb.body.pos = { x: 36, y: CENTER_Y };
  if (work) {
    sim.slot('DE_W')!.body.pos = { x: 41.8, y: CENTER_Y - 1.5 };
    sim.slot('DE_S')!.body.pos = { x: 41.8, y: CENTER_Y + 1.5 };
  }
  const controller = new RunBlocker({ kind: 'drive', target: null, drive: { x: 1, y: 0 } });
  a.behavior = controller;
  sim.t = 2;
  const record = () => sim.perception.record(sim.agents, known === undefined ? undefined : known ? qb.idx : null);
  for (let i = 0; i < 24; i++) record();
  return { sim, a, qb, rb, controller, record };
}

const rows=[];
for(const side of [-1,1]){
 const f=stage();f.rb.body.pos={x:45,y:CENTER_Y+side*5};f.sim.ball={kind:'held',carrier:f.rb};f.sim.t+=.05;f.sim.perception.record(f.sim.agents,f.rb.idx);
 const acquired={qb:f.sim.see(f.a,f.qb),rb:f.sim.see(f.a,f.rb)};
 const command=f.controller.update(f.a,f.sim);rows.push({hiddenSide:side,acquired,target:f.controller.target?.slot,command});
}
console.log(JSON.stringify({schema:'actual-controller-hidden-motion-contract',synthetic:true,rows,invariant:JSON.stringify(rows[0].command)===JSON.stringify(rows[1].command)&&rows[0].target===rows[1].target}));
