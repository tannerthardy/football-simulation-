"""Reduce frozen paired evidence only; no simulator or new observations."""
import gzip,json,hashlib,pathlib,math
p=pathlib.Path(__file__).parent
read=lambda n:json.load(gzip.open(p/n/'trace.json.gz'))
base={};candidate={};receipts={};pairs=[]
for kind in ['native','fresh']:
 for arm,target in [('baseline',base),('candidate',candidate)]:
  name=arm+'-'+kind;x=read(name);receipts[name]=x['receipt'];target.update({r['id']:r for r in x['rows']})
for name,a in base.items():
 b=candidate[name];assert a['inputSha256']==b['inputSha256'];assert a['initial']==b['initial'];assert len(a['frames'])==len(b['frames'])
 frames=list(zip(a['frames'],b['frames']))
 for x,y in frames:assert x['t']==y['t']
 def first(key):
  f=next(((x,y)for x,y in frames if x[key]!=y[key]),None)
  if f is None:return None
  x,y=f
  if key=='rng':return {'t':x['t']}
  i=next(i for i in range(22)if x[key][i]!=y[key][i]);c=next(c for c in b['calls']if c['t']==y['t']and c['a']==i)
  return {'t':x['t'],'actor':i,'slot':b['initial'][i]['slot'],'baseline':x[key][i],'candidate':y[key][i],'workPicture':c.get('workPicture')}
 def intervals(row):
  out={}
  for f in row['frames']:
   for e in f['afterReps']:out.setdefault(str((e['b'],e['d'])),[]).append(f['t'])
  return out
 def traffic(row):return[{'t':f['t'],**c}for f in row['frames']for c in f['report']['contacts']if c['impulse']>0 and c['i']<11 and c['j']<11]
 def contactevents(row):return[e for e in row['events']if e['type']in ['carrier_contact','tackle_wrap','tackle_break']]
 used={}
 for c in b['calls']:
  if c.get('workPicture'):used.setdefault(str(c['a']),{'slot':b['initial'][c['a']]['slot'],'firstAt':c['t'],'firstPicture':c['workPicture']})
 row={'id':name,'inputSha256':a['inputSha256'],'baselineSource':a['source'],'candidateSource':b['source'],'phase':[a['phase'],b['phase']],'endTime':[a['endTime'],b['endTime']],'outcome':[a['outcome'],b['outcome']],'gain':[a['gain'],b['gain']],'firstContact':[a['firstContact'],b['firstContact']],'firstRawDifference':first('raw'),'firstFinalDifference':first('final'),'firstAchievedDifference':first('after'),'firstRngDifference':first('rng'),'runnerIdentical':all(x['after'][6]==y['after'][6]for x,y in frames),'contactEventsIdentical':contactevents(a)==contactevents(b),'eventsIdentical':a['events']==b['events'],'loadedIntervalMembershipIdentical':intervals(a)==intervals(b),'loadedForceRecordsIdentical':all(x['afterReps']==y['afterReps']for x,y in frames),'positiveTeammateImpulses':[traffic(a),traffic(b)],'workReferenceConsumers':used,'removedEvents':[e for e in a['events']if e not in b['events']],'addedEvents':[e for e in b['events']if e not in a['events']]}
 assert row['runnerIdentical'] and row['contactEventsIdentical'] and row['loadedIntervalMembershipIdentical']
 assert row['firstRngDifference'] is None
 assert len(row['positiveTeammateImpulses'][0])==len(row['positiveTeammateImpulses'][1])
 assert all(math.isfinite(v)for r in [a,b]for f in r['frames']for bod in f['after']for v in [*bod['pos'].values(),*bod['vel'].values()])
 pairs.append(row)
result={'schema':'blocker-work-paired-review-v1','qualification':'Four bounded paired encounters, selected for information correction and preservation. Not yardage improvement or whole-run-game certification. Final source ac0c6df; original three pairs use compatible2b56869 (only optional absent-age policy differs; production PerceptionBuffer always supplies finite age). F01 uses exact final source. Two live inputs per arm remain censored at5s.','receipts':receipts,'nativeCollectorSeconds':sum(r['elapsedSeconds']for r in receipts.values()),'pairs':pairs}
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pairs':len(pairs),'collectorSeconds':result['nativeCollectorSeconds'],'finalFreshWorkConsumers':list(pairs[-1]['workReferenceConsumers'].keys())}))
