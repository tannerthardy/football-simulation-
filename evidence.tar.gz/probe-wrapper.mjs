import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {RunBlocker} from './src/sim/behaviors/blocking.ts';
import {previewFreeMovement} from './src/physics/movement-preview.ts';
import {sourceVersion} from './scripts/source-version.ts';
const trace=JSON.parse(gunzipSync(readFileSync('../b03-native/trace.json.gz'))),r=trace.rows[0];
const input=JSON.parse(gunzipSync(readFileSync('inputs-12.json.gz'))).rows.find(x=>x.id==='B03');
const output=[];
for(const t of [1.05,1.25,1.5,1.75,2,2.25,2.5,2.75,2.9,3]){
 const f=r.frames.find(x=>Math.abs(x.t-t)<1e-8),call=r.calls.find(c=>c.a===4&&c.t===f.t);
 const body=structuredClone(f.before[4]),seen=structuredClone(call.read.seen),targetBody=f.before[15];
 const strike=body.profile.radius+targetBody.profile.radius+.1+input.setup.offense.LG.measurables.armIn/36*.45;
 const planner={climbRead:null},actor={body,pos:body.pos,profile:body.profile,mind:{decisionInterval:.2}};
 const sim={t,offCall:input.setup.offCall,offAlign:{strongSign:-1},world:{handContact:'center'},trace:{data:null},see(){return seen;}};
 const intent=RunBlocker.prototype.plannedClimb.call(planner,actor,sim,{idx:15},strike);
 const path=previewFreeMovement(body,intent,t,26,'center');
 const scored=path.map(s=>({...s,gap:Math.hypot(s.pos.x-seen.pos.x-seen.vel.x*s.t,s.pos.y-seen.pos.y-seen.vel.y*s.t)-strike}));
 const withinDeadline=scored.filter(s=>t+s.t<2.9+1e-7),first=scored.find(s=>s.gap<=0)??null,best=scored.reduce((a,b)=>a.gap<b.gap?a:b),overlaps=[];
 for(let i=0;i<11;i++)if(i!==4){
  const other=f.before[i],radius=body.profile.radius+other.profile.radius;
  const min=path.reduce((a,b)=>Math.hypot(b.pos.x-other.pos.x,b.pos.y-other.pos.y)<Math.hypot(a.pos.x-other.pos.x,a.pos.y-other.pos.y)?b:a);
  if(Math.hypot(min.pos.x-other.pos.x,min.pos.y-other.pos.y)<radius+.15)overlaps.push({slot:r.initial[i].slot,t:min.t,margin:Math.hypot(min.pos.x-other.pos.x,min.pos.y-other.pos.y)-radius});
 }
 output.push({t,body:{pos:body.pos,vel:body.vel},seen,observedRearClearance:call.read.clearanceX-body.pos.x-body.profile.radius,routeIndex:call.after.pullIdx,raw:f.raw[4],final:f.final[4],strike,plan:planner.climbRead,intent,firstForecastStrike:first,bestForecast:best,bestBeforeRunnerContact:withinDeadline.length?withinDeadline.reduce((a,b)=>a.gap<b.gap?a:b):null,staticTeammateScreen:overlaps,path:scored});
}
writeFileSync('../wrapper-preview.json',JSON.stringify({schema:'wrapper-consumed-cue-preview-v1',source:sourceVersion(),qualification:'No native rollout; existing plannedClimb on saved acquired picture. Free, unloaded, constant-picture forecast; not block feasibility or future clearance. Fixed observed strong sign from installed Buck strong alignment. Static teammate screen is analyst-only truth, never a proposed input.',rows:output},null,2)+'\n');
for(const x of output)console.log(JSON.stringify({t:x.t,attainable:x.plan.attainable,first:x.firstForecastStrike&&x.t+x.firstForecastStrike.t,bestBefore:x.bestBeforeRunnerContact?.gap,command:x.intent.vel,overlaps:x.staticTeammateScreen}));
