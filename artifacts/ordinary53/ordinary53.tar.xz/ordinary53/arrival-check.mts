import {readFileSync,writeFileSync} from 'node:fs';
import {derivePhysical} from '../../src/players/physical.js';
import {sprintTime,timeToReachRequested} from '../../src/physics/reach.js';
import {stepBody} from '../../src/physics/kinematics.js';
import {readSavedPlay,restoreSetup} from '../../scripts/diag/saved-play.js';
const saved=readSavedPlay('out/ordinary53/G1-P007/play.bin'),profile=derivePhysical(restoreSetup(saved.setup).offense.QB);
const taps=JSON.parse(readFileSync('out/ordinary53/G1-P007/qb-evaluations.json','utf8')),trace=JSON.parse(readFileSync('out/ordinary53/G1-P007/selected-trace.json','utf8'));
const margins=JSON.parse(readFileSync('out/ordinary53/G1-P007/lane-comparison.json','utf8'));
const results=[];
for(const r of taps.rows.filter(r=>r.method==='shouldScramble')){
 if(profile.vmax!==r.actor.vmax)throw Error('Profile mismatch');
 const state=trace.steps.find(s=>s.stepStart===r.t).start.body;const record=margins.find(m=>m.t===r.t);const lanes=[];
 for(const lane of record.lanes){const target={x:Math.max(state.position.x+4,r.actor.los+1),y:state.position.y+lane.dy};
  const dx=target.x-state.position.x,dy=target.y-state.position.y,dist=Math.hypot(dx,dy);
  const optimisticFull=sprintTime(dist,0,profile.vmax,profile.tau);const requested=timeToReachRequested({pos:state.position,vel:state.velocity,profile,speedScale:1},target,0,{speed:.8,effort:1});
  const body={pos:{...state.position},vel:{...state.velocity},facing:Math.atan2(dy,dx),profile,energy:state.energy};let elapsed=0;
  const heading={x:dx/dist,y:dy/dist};
  while(elapsed<5&&((body.pos.x-state.position.x)*heading.x+(body.pos.y-state.position.y)*heading.y)<dist){stepBody(body,{vel:{x:heading.x*profile.vmax*.8,y:heading.y*profile.vmax*.8}},.01);elapsed+=.01;}
  lanes.push({...lane,distance:dist,optimisticFreshAlignedFullEffortArrival:optimisticFull,requestedAlignedEstimate:requested,freeAlignedMotorArrival:elapsed,fullEffortLiveMargin:lane.myT+lane.live.margin-optimisticFull,fullEffortPictureMargin:lane.myT+lane.alreadyConsumedEstimate.margin-optimisticFull});
 }
 results.push({t:r.t,profile:{vmax:profile.vmax,tau:profile.tau},start:state,lanes});
}
writeFileSync('out/ordinary53/G1-P007/arrival-comparison.json',JSON.stringify({question:'Is own constant-speed arrival consistent with own finite acceleration? No defender reaction treatment or football result rerun.',assumptions:'Fresh aligned full-effort scalar sprint is optimistic; free held-.8 motor includes energy and traction, excludes collisions/support and decisions. Existing defender arrival estimates are held, not realized future contact. Native QB starts at rest.',results},null,2));
for(const r of results)console.log(r.t,r.profile,r.lanes.map(l=>({dy:l.dy,naive:l.myT,full:l.optimisticFreshAlignedFullEffortArrival,requested:l.requestedAlignedEstimate,motor:l.freeAlignedMotorArrival,liveMargin:l.fullEffortLiveMargin,pictureMargin:l.fullEffortPictureMargin})));
