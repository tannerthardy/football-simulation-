import {readFileSync,writeFileSync} from 'node:fs';
import {readSavedPlay,restoreSetup,bytesHash} from '../../scripts/diag/saved-play.js';
import {engineSettings} from '../../scripts/scorecard/provenance.js';
const sample=JSON.parse(readFileSync('out/ordinary53/sample.json','utf8'));const xs=[];
for(const e of sample.entries){const s=readSavedPlay(`out/ordinary53/${e.id}/play.bin`),p=restoreSetup(s.setup);xs.push({id:e.id,seed:typeof p.seed==='number'?p.seed:{...p.seed},inputSha256:s.setupSha256,offense:s.context.offense,actors:s.original.initial.actors,wind:p.wind});}
const actual=sample.identity.settings,defaults=engineSettings({});
writeFileSync('out/ordinary53/input-summary.json',JSON.stringify({settingsSha256:bytesHash(Buffer.from(JSON.stringify(actual))),overrides:Object.keys(actual).filter(k=>actual[k]!==defaults[k]),inputs:xs},null,2));
console.log(xs.map(({actors,...e})=>e));
