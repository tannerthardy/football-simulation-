import {writeFileSync,mkdirSync} from 'node:fs';
import {copySaved,readSavedPlay} from '../../scripts/diag/saved-play.js';
import {originalFilm} from '../../scripts/diag/capture-game-play.js';
mkdirSync('out/ordinary53/clips',{recursive:true});
for(const [id,from,to,actor] of [['G1-P004',.9,2.55,2],['G1-P007',2.8,5.9,0]] as const){
 const saved=readSavedPlay(`out/ordinary53/${id}/play.bin`),s=copySaved(saved);
 s.film.replay!.frames=s.film.replay!.frames.filter(f=>f.t>=from&&f.t<=to);
 const t=s.film.replay!.telemetry!;t.frames=t.frames.filter(f=>f.t>=from&&f.t<=to);t.decisions=t.decisions.filter(f=>f.t>=from&&f.t<=to);
 // Presentation-only excerpt; full native inputs/results remain unchanged beside this clip.
 let html=originalFilm(s);html=html.replace('</body>',`<script>document.getElementById('inspect-player').value='${actor}';document.getElementById('inspect-player').dispatchEvent(new Event('change'));</script></body>`);
 writeFileSync(`out/ordinary53/clips/${id}.html`,html);
}
