# Ordinary seed53: six-play diagnosis packet

Start with review.md, then owner-handoff.md. This is research on accepted source
50b80062815716b902438f9a7fa227535a255ea0, not a policy patch or merge request.

Two short clips are in clips/G1-P004.html and clips/G1-P007.html, with WebM copies.
The HTML uses the existing replay viewer with the actor selected; Copy reference
and Export clip still work. All six original films, exact constructors and the
pre-detector first pass remain alongside the notes. Do not relabel these as the
older#265 or historical18 cohort.

## Unpack and verify

Unpack ordinary53.tar.xz under an isolated checkout's ignored out/ directory.
Verify every file against ordinary53/manifest.json (SHA256 of exact bytes).
Preserve the notes' uncertainty. Detector nominations were inspected only after
first-pass.json was saved and hashed; its SHA256 is in first-pass.sha256.

## Reproduce only selected evidence, without a new game prefix

Use a separate worktree at exact source50b80062815716b902438f9a7fa227535a255ea0,
Node22.23.3 and npm ci. The code has no pending runtime dependency. Raw diagnostic
scripts in this packet import the checked-out source; they are not engine edits.
From the checkout root with the packet under out/ordinary53:

```sh
node --import tsx scripts/diag/command-trace.ts --capture out/ordinary53/G1-P007/play.bin --actor O:QB --from 2.8 --to 3.65 --out out/reproduced-qb-trace.json
node --import tsx out/ordinary53/lane-check.mts
node --import tsx out/ordinary53/arrival-check.mts
```

The trace command independently checks complete original/plain/traced execution
and source/settings/runtime/lockfile. All lane diagnostics use saved already-
consumed observations or bounded free-body mechanics, not a new game or hidden
future reaction. The optimistic aligned full-effort scalar bound is deliberately
more generous than the held0.8 request. Neither guarantees a future football
contact or decides whether throwing/remaining in the pocket would be better.

capture.mts is retained as the actual collection recipe, not an instruction to
recollect this sample. It captured only the declared first six eligible plays;
three matched six-step prefixes checked observer and recording neutrality.
No full-game scorecard/suite rerun was needed. Existing engine, settings, metrics,
viewer, detectors, historical files and other workers were not changed.
