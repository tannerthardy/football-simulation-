import {readSavedPlay,restoreSetup} from '../../scripts/diag/saved-play.js';
for(const p of ['G1-P004','G1-P007']){const s=readSavedPlay(`out/ordinary53/${p}/play.bin`);const setup=restoreSetup(s.setup);console.log(p,'QB archetype',setup.offense.QB.archetype,'call',s.context,'play seed',typeof setup.seed==='number'?setup.seed:{...setup.seed});}
