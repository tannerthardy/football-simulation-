from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw
import json,io
root=Path('out/ordinary53').resolve();log=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1500,'height':1100});page.on('pageerror',lambda e:log.append(str(e)))
 for folder in sorted(root.glob('G*')):
  film=json.loads((folder/'film.json').read_text());ts=film['replay']['frames'];lo=ts[0]['t'];hi=ts[-1]['t']
  page.goto('http://127.0.0.1:8765/'+folder.name+'/original.html');page.wait_for_selector('#field');page.wait_for_timeout(200)
  times=sorted(set([0,1,2,min(3,hi),min(4,hi),hi]))
  sheet=Image.new('RGB',(1200,275*((len(times)+1)//2)), 'white');draw=ImageDraw.Draw(sheet)
  for i,t in enumerate(times):
   page.locator('#scrub').evaluate('(e,v)=>{e.value=v;e.dispatchEvent(new Event("input"))}',round((t-lo)/(hi-lo)*1000));page.wait_for_timeout(90)
   im=Image.open(io.BytesIO(page.locator('#field').screenshot()));im.thumbnail((598,250));x=(i%2)*600;y=(i//2)*275;sheet.paste(im,(x,y+22));draw.text((x+10,y+3),folder.name+' '+str(round(t,2))+'s',fill='black')
  sheet.save(folder/'first-pass-view.png')
 b.close()
(root/'viewer-check.json').write_text(json.dumps({'browser':'Chromium','errors':log,'selection':'all six in official order, no scout scores'},indent=2))
