import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {readSavedPlay,runRestoredPlay,executionIdentity,firstDifference,bytesHash} from '../../scripts/diag/saved-play.js';
const root='out/ordinary53',sample=JSON.parse(readFileSync(root+'/sample.json','utf8')),results=[];
const start=performance.now();
if(firstDifference(sample.identity,executionIdentity()))throw Error('Source/settings/runtime changed');
for(const e of sample.entries){
 const saved=readSavedPlay(`${root}/${e.id}/play.bin`);if(saved.setupSha256!==e.inputSha256)throw Error('Input mismatch');
 const path=`${root}/${e.id}/${e.id==='G1-P004'?'rt-trace':'selected-trace'}.json`;
 let proof;
 if(existsSync(path)){const t=JSON.parse(readFileSync(path,'utf8'));if(Object.values(t.verification).slice(0,3).some(v=>v!==null))throw Error('Existing restoration receipt mismatch');proof='reused existing exact original/plain/traced receipt';}
 else{const restored=runRestoredPlay(saved);if(restored.difference)throw Error(JSON.stringify(restored.difference));proof='complete native result/initialization/replay restored exactly';}
 results.push({play:e.id,inputSha256:saved.setupSha256,proof});
}
const a=JSON.parse(readFileSync(root+'/G1-P007/arrival-comparison.json','utf8'));
for(const r of a.results){if(r.start.velocity.x!==0||r.start.velocity.y!==0)throw Error('Not stationary');if(r.lanes.filter(l=>l.live.margin>.35).length!==4)throw Error('Native lane count');if(r.lanes.some(l=>l.fullEffortLiveMargin>.35||l.fullEffortPictureMargin>.35))throw Error('Finite-acceleration comparison');if(r.lanes.some(l=>Math.abs(l.requestedAlignedEstimate-l.freeAlignedMotorArrival)>.02))throw Error('Motor consistency');}
if(bytesHash(readFileSync(root+'/first-pass.json'))!=='0d4749742ad8892048ecceefeb8df9cbefb693bd0887a32d38293346f888b68f')throw Error('First pass changed');
writeFileSync(root+'/verification.json',JSON.stringify({results,arithmeticAndMotorChecks:'pass',firstPassUnchanged:true,identityUnchanged:true,seconds:(performance.now()-start)/1000},null,2));console.log(JSON.stringify(results));
