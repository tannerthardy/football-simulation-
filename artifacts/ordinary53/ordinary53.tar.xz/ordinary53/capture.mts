import {mkdirSync,writeFileSync} from 'node:fs';
import {serialize} from 'node:v8';
import {Rng} from '../../src/core/rng.js';
import {Game} from '../../src/game/game.js';
import {generateTeam} from '../../src/league/team.js';
import {composeHooks} from '../../scripts/scorecard/hooks.js';
import {weirdObserver,uninstallPreSnapCapture} from '../../scripts/scorecard/weird/observe.js';
import {captureSetup,copySaved,executionIdentity,initialState,bytesHash,firstDifference} from '../../scripts/diag/saved-play.js';
import {originalFilm} from '../../scripts/diag/capture-game-play.js';
const out='out/ordinary53', identity=executionIdentity(), start=performance.now();
const eligible=p=>(p.kind==='run'||p.kind==='pass')&&!p.nullified;
function run(observe,record=true,fixedSteps=null){
 const rng=new Rng(53), before={...rng},home=generateTeam(rng,'Ironmen','IRN',{strength:.55}),afterHome={...rng},away=generateTeam(rng,'Comets','COM',{strength:.55});
 const recipe={seed:53,leagueSampler:false,before,afterHome,afterAway:{...rng},home:home.abbr,away:away.abbr,gameInputSha256:bytesHash(serialize({home,away,seed:53}))};
 const captures=[];let pending;
 const scout=observe?weirdObserver({idPrefix:'',game:1,cap:Infinity}):null;
 const capture={playSetup(setup,context){pending=context.kind==='scrimmage'?{setup:captureSetup(setup),context:copySaved(context)}:null;if(pending)captures.push(pending);},playResult(sim){const c=pending;if(!c)return;c.initial=initialState(sim);const orig=sim.run.bind(sim);sim.run=()=>{const r=orig();c.result=copySaved(r);return r;};}};
 const game=new Game(home,away,{seed:53,record,recordLevel:'full',hooks:observe?composeHooks(capture,scout.hooks):undefined});
 game.kickoffToStart();let steps=0;
 while(steps<(fixedSteps??20)&&!game.state.over){game.step();steps++;if(fixedSteps===null&&game.result().log.filter(eligible).length>=6)break;}
 const result=game.result(), alerts=scout?.finish(result);uninstallPreSnapCapture();return {result,steps,captures,alerts,recipe};
}
const on=run(true),off=run(false,true,on.steps),noRecord=run(false,false,on.steps);
const diff=firstDifference(off.result,on.result);
const strip=r=>({...r,log:r.log.map(({replay,...p})=>p)});
const recordingDiff=firstDifference(strip(off.result),strip(noRecord.result));
writeFileSync(out+'/neutrality.json',JSON.stringify({identity,steps:on.steps,observerDifference:diff,recordingDifference:recordingDiff,seconds:(performance.now()-start)/1000},null,2));
if(diff||recordingDiff)throw Error('Neutrality failed; see retained differences');
writeFileSync(out+'/sealed-detectors.json',JSON.stringify(on.alerts,null,2));
const selected=on.result.log.filter(eligible).slice(0,6), ledger=on.result.log.map(p=>({index:p.index,id:`G1-P${String(p.index+1).padStart(3,'0')}`,kind:p.kind,nullified:!!p.nullified,selected:selected.includes(p),reason:selected.includes(p)?'eligible completed scrimmage':p.nullified?'nullified':p.kind==='run'||p.kind==='pass'?'beyond selected cohort':'not scrimmage'}));
const entries=[];
for(const p of selected){const c=on.captures.find(c=>c.context.index===p.index);const id=`G1-P${String(p.index+1).padStart(3,'0')}`;if(!c?.result||!p.replay)throw Error('Missing selected constructor/replay; do not replace');
 const saved={format:'constructor-play-v1',identity,game:{seed:53,steps:on.steps,complete:on.result.log.length===0,playId:id},context:c.context,setup:c.setup,setupSha256:bytesHash(c.setup),original:{initial:c.initial,result:c.result,replay:copySaved(p.replay)},film:copySaved(p)};
 mkdirSync(out+'/'+id,{recursive:true});writeFileSync(out+'/'+id+'/play.bin',serialize(saved));writeFileSync(out+'/'+id+'/original.html',originalFilm(saved));writeFileSync(out+'/'+id+'/film.json',JSON.stringify(p));
 entries.push({id,inputSha256:saved.setupSha256,call:p.call,defense:p.defense,kind:p.kind,outcome:p.outcome,yards:p.yards,actors:c.initial.actors});}
writeFileSync(out+'/sample.json',JSON.stringify({identity,recipe:on.recipe,steps:on.steps,undersized:entries.length<6,ledger,entries},null,2));
console.log(JSON.stringify({plays:entries.map(({actors,...p})=>p),steps:on.steps,neutrality:'exact',seconds:(performance.now()-start)/1000}));
