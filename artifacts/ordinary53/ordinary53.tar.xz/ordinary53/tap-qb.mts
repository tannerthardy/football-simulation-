import {writeFileSync} from 'node:fs';
import {QBMind} from '../../src/sim/qbmind.js';
import {QBPass} from '../../src/sim/behaviors/qb.js';
import {readSavedPlay,runRestoredPlay,copySaved} from '../../scripts/diag/saved-play.js';
const rows=[];const estimates=[];const estimate=(QBMind.prototype as any).estimate;(QBMind.prototype as any).estimate=function(d){const p=estimate.call(this,d);if(this.sim.t>=2.8&&this.sim.t<=3.65)estimates.push({t:this.sim.t,slot:d.slot,idx:d.idx,p:copySaved(p),memoryAt:this.memory.get(d)?.t});return p;};const proto=QBPass.prototype as any;
for(const method of ['evaluate','pressure','shouldScramble']){
 const orig=proto[method];proto[method]=function(...args){const [a,sim]=args;const result=orig.apply(this,args);if(sim.t>=2.8&&sim.t<=3.65)rows.push({t:sim.t,method,readIdx:this.readIdx,readSlot:this.reads[this.readIdx]?.slot,clock:this.clock,setAt:this.setAt,snapAt:this.snapAt,drop:this.drop,receiver:method==='evaluate'?args[2].slot:undefined,urgency:method==='evaluate'?args[3]:undefined,panic:method==='shouldScramble'?args[2]:undefined,result:result?.target?{P:result.P,intRisk:result.intRisk,value:result.value,depth:result.depth,target:result.target.slot,point:result.point,T:result.T}:method==='pressure'?{time:result.time,agent:result.agent?.slot}:result,
 defenders:method==='shouldScramble'?sim.defense.map(d=>({idx:d.idx,slot:d.slot,playerId:d.player.id,pos:{...d.pos},vel:{...d.vel},profile:{...d.profile},speedScale:d.speedScale,isDown:d.isDown(sim.t),engaged:!!d.engagement})):undefined,actor:method==='shouldScramble'?{pos:{...a.pos},vmax:a.profile.vmax,mobility:{forty:a.player.measurables.forty,elusiveness:a.r('elusiveness')},los:sim.los}:undefined});return result;};
}
const saved=readSavedPlay('out/ordinary53/G1-P007/play.bin');const restored=runRestoredPlay(saved);
if(restored.difference)throw Error(JSON.stringify(restored.difference));
writeFileSync('out/ordinary53/G1-P007/qb-evaluations.json',JSON.stringify({completeExecutionDifference:restored.difference,rows,estimates},null,2));
console.log(rows.map(r=>({t:r.t,method:r.method,read:r.readSlot,P:r.result?.P,risk:r.result?.intRisk,result:typeof r.result==='boolean'?r.result:r.method==='pressure'?r.result:undefined})));
