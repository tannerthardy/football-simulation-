import {readFileSync,writeFileSync} from 'node:fs';
import {timeToReach} from '../../src/physics/reach.js';
const j=JSON.parse(readFileSync('out/ordinary53/G1-P007/qb-evaluations.json','utf8'));
const results=[];
for(const row of j.rows.filter(r=>r.method==='shouldScramble')){
 const {pos,vmax,los}=row.actor;
 const estimates=new Map(j.estimates.filter(e=>e.t===row.t).map(e=>[e.idx,e]));
 const lanes=[];
 for(const dy of [-4,-2,0,2,4]){
  const q={x:Math.max(pos.x+4,los+1),y:Math.max(1,Math.min(52.33333333333,pos.y+dy))};
  const myT=Math.hypot(q.x-pos.x,q.y-pos.y)/(vmax*.8);const ds=row.defenders.filter(d=>!d.isDown);
  function calc(view){const times=ds.map(d=>{const est=estimates.get(d.idx);const p=view&&est?est.p:d;return {slot:d.slot,tt:timeToReach({pos:p.pos,vel:p.vel,profile:d.profile,speedScale:d.speedScale},q,1)+(d.engaged?.5:0),known:!!est};});times.sort((a,b)=>a.tt-b.tt);return {margin:times[0].tt-myT,limiter:times[0].slot};}
  lanes.push({dy,myT,live:calc(false),alreadyConsumedEstimate:calc(true)});
 }
 results.push({t:row.t,nativeChoice:row.result,lanes,liveOpen:lanes.filter(l=>l.live.margin>.35).length,estimateOpen:lanes.filter(l=>l.alreadyConsumedEstimate.margin>.35).length,coverage:estimates.size,
  deltas:row.defenders.filter(d=>estimates.has(d.idx)).map(d=>({slot:d.slot,memoryAt:estimates.get(d.idx).memoryAt,age:row.t-estimates.get(d.idx).memoryAt,distance:Math.hypot(d.pos.x-estimates.get(d.idx).p.pos.x,d.pos.y-estimates.get(d.idx).p.pos.y)}))});
}
writeFileSync('out/ordinary53/G1-P007/lane-comparison.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results));
