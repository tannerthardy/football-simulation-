from playwright.sync_api import sync_playwright
from pathlib import Path
import json
out=Path('out/ordinary53').resolve();results=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1500,'height':1100},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 for id in ['G1-P004','G1-P007']:
  page.goto('http://127.0.0.1:8765/clips/'+id+'.html');page.wait_for_timeout(300)
  page.locator('#copy-reference').click();ref=page.locator('#play-reference').input_value()
  with page.expect_download(timeout=20000) as d:page.locator('#export-video').click()
  d.value.save_as(str(out/'clips'/(id+'.webm')))
  results.append({'id':id,'reference':ref,'html':'clips/'+id+'.html','video':'clips/'+id+'.webm','bytes':(out/'clips'/(id+'.webm')).stat().st_size})
 b.close()
(out/'clip-check.json').write_text(json.dumps({'results':results,'pageErrors':errors},indent=2));print(json.dumps(results))
