from pathlib import Path
import re, html
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

root = Path(__file__).resolve().parent
source = (root / 'TECHNICAL-PLAN.md').read_text()
font_root = Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('PlanSans', str(font_root / 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('PlanSans-Bold', str(font_root / 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('PlanSans', normal='PlanSans', bold='PlanSans-Bold', italic='PlanSans', boldItalic='PlanSans-Bold')

def inline(text, pdf=False):
    result = html.escape(text, quote=False)
    result = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>' if pdf else r'<strong>\1</strong>', result)
    def link(match):
        url = match.group(0)
        # Keep sentence punctuation outside links.
        suffix = ''
        while url and url[-1] in '.,;':
            suffix = url[-1] + suffix
            url = url[:-1]
        tag = 'link' if pdf else 'a'
        return f'<{tag} href="{url}">{url}</{tag}>' + suffix
    return re.sub(r'https://[^\s<>]+', link, result)

blocks = []
lines = source.splitlines()
i = 0
while i < len(lines):
    line = lines[i].strip()
    if not line:
        i += 1
        continue
    if line.startswith('#'):
        level = len(line) - len(line.lstrip('#'))
        blocks.append(('heading', level, line[level:].strip()))
        i += 1
    elif line.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].strip().startswith('|'):
            cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r'[-: ]+', c or '-') for c in cells):
                rows.append(cells)
            i += 1
        blocks.append(('table', rows))
    elif line.startswith('- ') or re.match(r'^\d+\.\s', line):
        marker = '•' if line.startswith('- ') else line.split('.', 1)[0] + '.'
        body = line[2:] if line.startswith('- ') else re.sub(r'^\d+\.\s+', '', line)
        blocks.append(('item', marker, body))
        i += 1
    else:
        para = [line]
        i += 1
        while i < len(lines) and lines[i].strip() and not lines[i].lstrip().startswith(('#', '|', '- ')) and not re.match(r'^\d+\.\s', lines[i].strip()):
            para.append(lines[i].strip())
            i += 1
        blocks.append(('paragraph', ' '.join(para)))

toc, rendered = [], []
for n, block in enumerate(blocks):
    kind = block[0]
    if kind == 'heading':
        _, level, text = block
        anchor = f'section-{n}'
        rendered.append(f'<h{level} id="{anchor}">{inline(text)}</h{level}>')
        if level == 2:
            toc.append(f'<li><a href="#{anchor}">{html.escape(text)}</a></li>')
    elif kind == 'table':
        rows = block[1]
        rendered.append('<div class="table"><table>')
        for row_number, row in enumerate(rows):
            tag = 'th' if row_number == 0 else 'td'
            rendered.append('<tr>' + ''.join(f'<{tag}>{inline(c)}</{tag}>' for c in row) + '</tr>')
        rendered.append('</table></div>')
    elif kind == 'item':
        rendered.append(f'<p class="item"><span>{block[1]}</span> {inline(block[2])}</p>')
    else:
        rendered.append(f'<p>{inline(block[1])}</p>')
css = '''
:root {color-scheme:light}
* {box-sizing:border-box}
body {margin:0;background:#f3f5f8;color:#182334;font:16px/1.6 system-ui,sans-serif}
main {max-width:1100px;margin:28px auto;background:white;padding:48px 56px;box-shadow:0 2px 14px #172a4020}
h1 {font-size:32px;line-height:1.2;color:#102f4d}
h2 {font-size:24px;line-height:1.3;border-bottom:2px solid #dfe7ef;padding-bottom:10px;margin-top:44px;scroll-margin-top:20px}
h3 {font-size:19px;line-height:1.4;margin-top:25px}
p {margin:12px 0}
a {color:#185b9c;overflow-wrap:anywhere}
nav {background:#edf3f8;border:1px solid #d4e0ec;padding:18px 24px;margin:28px 0}
nav ol {columns:2;padding-left:22px;margin:8px 0;font-size:14px}
nav li {break-inside:avoid;margin:5px 0}
.item {padding-left:22px;text-indent:-17px}
.table {overflow-x:auto}
table {border-collapse:collapse;width:100%;font-size:14px;line-height:1.45;margin:16px 0}
td,th {border:1px solid #d4dfe9;padding:10px 12px;vertical-align:top;text-align:left}
th {background:#173a58;color:white}
tr:nth-child(even) {background:#f4f7fa}
@media print {body{background:white;font-size:10pt}main{max-width:none;box-shadow:none;margin:0;padding:0}nav{display:none}h2,h3{break-after:avoid}table{font-size:8pt}tr{break-inside:avoid}a{color:#182334} }
@media(max-width:700px){main{margin:0;padding:24px 18px}nav ol{columns:1}h1{font-size:26px}}
'''
page = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Gridiron Engine — next-week technical plan</title><style>'+css+'</style><body><main>'
page += rendered[0] + '<nav><strong>Plan contents</strong><ol>' + ''.join(toc) + '</ol></nav>' + ''.join(rendered[1:]) + '</main></body></html>'
(root / 'TECHNICAL-PLAN.html').write_text(page)

styles = {
    'p': ParagraphStyle('p', fontName='PlanSans', fontSize=9.3, leading=13.7, spaceAfter=7, splitLongWords=True),
    'h1': ParagraphStyle('h1', fontName='PlanSans-Bold', fontSize=21, leading=26, textColor=colors.HexColor('#123551'), spaceAfter=16, keepWithNext=True),
    'h2': ParagraphStyle('h2', fontName='PlanSans-Bold', fontSize=13.5, leading=18, textColor=colors.HexColor('#123551'), spaceBefore=15, spaceAfter=8, keepWithNext=True),
    'h3': ParagraphStyle('h3', fontName='PlanSans-Bold', fontSize=10.5, leading=15, spaceBefore=10, spaceAfter=6, keepWithNext=True),
    'item': ParagraphStyle('item', fontName='PlanSans', fontSize=9.3, leading=13.7, leftIndent=14, firstLineIndent=0, bulletIndent=0, bulletFontName='PlanSans', spaceAfter=5),
    'cell': ParagraphStyle('cell', fontName='PlanSans', fontSize=8.1, leading=11.4, splitLongWords=True),
    'th': ParagraphStyle('th', fontName='PlanSans-Bold', fontSize=8.1, leading=11.4, textColor=colors.white),
}
width, height = A4
available = width - 84
story = []
for block in blocks:
    if block[0] == 'heading':
        level = min(3, block[1])
        story.append(Paragraph(inline(block[2], True), styles[f'h{level}']))
    elif block[0] == 'paragraph':
        story.append(Paragraph(inline(block[1], True), styles['p']))
    elif block[0] == 'item':
        story.append(Paragraph(inline(block[2], True), styles['item'], bulletText=block[1]))
    else:
        rows = block[1]
        count = len(rows[0])
        ratios = [0.19, 0.40, 0.41] if count == 3 else [0.15, 0.19, 0.28, 0.38] if count == 4 else [1/count]*count
        data = [[Paragraph(inline(c, True), styles['th'] if j == 0 else styles['cell']) for c in row] for j, row in enumerate(rows)]
        table = LongTable(data, colWidths=[available*r for r in ratios], repeatRows=1, hAlign='LEFT', splitByRow=1)
        table.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,0),colors.HexColor('#173a58')),
            ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f1f5f8')]),
            ('GRID',(0,0),(-1,-1),.4,colors.HexColor('#cfdae4')),
            ('VALIGN',(0,0),(-1,-1),'TOP'),
            ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
            ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
        ]))
        story.extend([table, Spacer(1,9)])

def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('PlanSans', 7)
    canvas.setFillColor(colors.HexColor('#52687a'))
    canvas.drawString(42, 27, 'Gridiron Engine · Technical execution plan · Oct 26–Nov 1, 2026')
    canvas.drawRightString(width-42, 27, str(doc.page))
    canvas.restoreState()

doc = SimpleDocTemplate(str(root/'TECHNICAL-PLAN.pdf'), pagesize=A4, rightMargin=42, leftMargin=42, topMargin=40, bottomMargin=43, title='Gridiron Engine — technical execution plan', author='Project audit planning review')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print('Rendered HTML and PDF from the complete Markdown plan.')
