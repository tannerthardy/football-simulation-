# Integration: Correct the few misleading diagnostic claims

Paste the following brief into **Integration**. It has not been sent automatically.

---

Suggested branch: tools/F1-audit-diagnostic-clarifications.
Suggested title: [F1] Qualify movement evidence and separate demonstrated causes.

Repository: tannerthardy/football-simulation-. Fetch current develop and record its SHA; read AGENTS.md, docs/PLAN.md, docs/GAPS.md and CLAUDE.md. The audit experiments used c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0; last checked develop ccdb69cba81e07c578f607ff1bf8ce0efe2edc68 changes documentation only. Verify current behavior before fixing it.

Use an isolated branch, one focused PR into develop, and the supported Node version. Preserve existing work and coordinate shared-source edits with the current owning lane. Use focused checks first, followed by the existing plan's applicable verification tier; do not invent another mandatory campaign. Keep raw output in ignored out/. No merge, unrelated cleanup, new framework or default-off feature flag. Do not change approved priorities, metric targets or historical evidence. If the issue is already fixed, verify that and stop.

Documentation-only follow-up. Correct the few statements that could send implementation agents toward the wrong fix; do not write another master plan or create a new workboard.

In docs/KNOWN_PROBLEMS.md TKL-4, qualify the claims “braking is not the cause” based on sim DB deceleration p90 6.6 versus NFL 5.6, and “turn capability is not the problem” based on NFL extreme orientation rates. The former is a p90 of per-player-play maximum filtered scalar speed loss, including contact—not lateral cutting capacity, braking timing or maximum hard-plant capability. The latter compares provider orientation/extrema with profile limits, which cannot establish physiological capacity. Preserve the dated values and source context as historical measurements; remove the unsupported inference.

Keep distinct:
- Native P002 free sweep: ordinary motor plus recorded commands reproduces the path; doubled yaw barely changes it. Capacity realism remains unresolved.
- Native P019 blocked LB_W: engagement asks him to face his blocker. Turning his torso toward the runner mostly changes appearance, not movement.
- Contact acquisition: drawing a dive as a dot can mislead, but a better drawing does not establish that the acquired hold was geometrically valid.
- VIEW-1 already exists and the viewer already copies selected player, film identity and timestamp. Do not describe those as absent.

Use exact experimental pin c4a03f6 and distinguish selected-case diagnoses from population conclusions. Do not imply all overruns or facing-away cases share one cause. Briefly connect to existing gap entries without changing ranked priorities or closure targets.

Done: a short documentation diff with source links/anchors checked. No games, engine edits, refreshed statistical bands or blanket assertion that physical capacities are correct/incorrect.

