# Measurin: Fix the mechanics guard's false success

Paste the following brief into **Measurin**. It has not been sent automatically.

---

Suggested branch: tools/F1-mechanics-guard-validity.
Suggested title: [F1] Missing mechanics evidence cannot pass the guard.

Repository: tannerthardy/football-simulation-. Fetch current develop and record its SHA; read AGENTS.md, docs/PLAN.md, docs/GAPS.md and CLAUDE.md. The audit experiments used c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0; last checked develop ccdb69cba81e07c578f607ff1bf8ce0efe2edc68 changes documentation only. Verify current behavior before fixing it.

Use an isolated branch, one focused PR into develop, and the supported Node version. Preserve existing work and coordinate shared-source edits with the current owning lane. Use focused checks first, followed by the existing plan's applicable verification tier; do not invent another mandatory campaign. Keep raw output in ignored out/. No merge, unrelated cleanup, new framework or default-off feature flag. Do not change approved priorities, metric targets or historical evidence. If the issue is already fixed, verify that and stop.

Problem: scripts/mechanics/compare.py can print “Guard: 12/12 matched metrics still match” and exit 0 when simulated metrics are empty. The row() function records marks only for sufficiently populated comparisons. The guard subtracts “off” and incompatible-pressure entries from the total, so missing, insufficient, unknown or never-evaluated metrics can count as successes.

Deliver the smallest guard/report correction. Every guarded metric must resolve to a clearly qualified state. Preserve the existing distinction between an acceptable comparison, a warning, a measured mismatch and evidence that cannot be evaluated; don't silently redefine existing threshold policy. Missing/insufficient/unknown/operator-incompatible evidence must never certify preservation and must give a non-success result when a guard requires that evidence. Descriptive reporting without a guard should remain usable.

Checks: empty metrics; one omitted guarded metric; below-minimum sample; incompatible operator; guarded name not evaluated by the report; a real adequate match; a real mismatch. Use tiny saved/synthetic inputs and focused offline tests—no simulated campaign is needed to reproduce this bug. Existing pressure compatibility work is already present; extend it instead of replacing the tool.

Done: show the old false success, new explicit unavailable result, and unchanged legitimate-match behavior in the PR. No simulator changes. This is a new narrow defect, not a request to redo earlier scorecard-provenance work.

