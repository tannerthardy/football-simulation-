# Do-It-All! — make tackle acquisition physically coherent

Prepared next-work brief; not automatically sent to its chat.

Branch: defense/G10-tackle-acquisition-geometry.
Problem: TKL-5 / QB-3. Priority: high. Effort: medium-to-hard; the first deliverable is bounded acquisition correctness.

Repository: tannerthardy/football-simulation-. Read current AGENTS.md, CLAUDE.md, docs/PLAN.md, docs/GAPS.md and the named problem before starting. Fetch develop and record its full SHA; the preparation check saw 2f7ac93c270812869f19779fc2f5659d53e94080. These are subsequent development/research assignments, not review or merge chores. Preserve current work and use a separate named branch. State exact accepted versus pending dependencies; never label a pending composition as accepted trunk. Coordinate the actual shared interface with its owner, preserve source-qualified counterexamples, use the existing verification tiers, and keep raw artifacts in ignored out/. No target/band changes or broad parameter tuning are implied.

The INFO-1 work is now PR #260, head b956e3d6. Its possession interpretation, ball-rally continuation and split-threat cap are distinct behavior changes; retain their controls when testing any eventual composition. This new task owns contact admission, coordinated with Defense/Main Engine. It does not redo possession or #256's engaged work-off.

PhysicalProfile.reach is center-to-hand horizontal reach. Arm strike/handoff use reach + target radius, while standing tackle adds both radii, lunge/dive add further margins, and grasp retention can grow from acquisition distance. A dive currently creates a hold before its body has traversed the distance. The solver can then faithfully pull through a contact that should not yet exist.

First record the actual geometry contract for the existing reduced body: actor origin, target landmark, pose, available extension, physical acquisition time and retained extension. Implement the smallest coherent correction across the tackle branches it affects. A lunge/dive extension must arise from represented movement/pose before a hold becomes active. Probability of technique success applies within a genuine opportunity, not as a substitute for one. Avoid giving repeated independent success draws merely because an attempted dive spans several ticks.

Acceptance cases: reachable standing contact; outside-envelope standing miss; a dive that physically reaches and acquires; a receding runner the diver cannot reach; a grip that transmits then slips; assist/rear variants; QB and non-QB targets. Reconcile the admitted contact with the retained grasp length. Check affected arrival/stopping consumers for shared radius assumptions without silently retuning their football policy.

Use one current ordinary-game long-hold witness and opposing legitimate dive. Preserve a prefix with equal bodies/requests/RNG at the intervention point. The old audit P048 is historical evidence, not a fixture recreated by its ordinal. Removing its hold prevented a fall but changed a completion into a sack; final yardage cannot certify geometry.

Done: a narrow acquisition contract/repair with finite-motion evidence and legitimate dives preserved. A gate that eliminates all dives, an arbitrary replacement distance bonus, or a new anatomical solver is not a successful first delivery. If full cross-branch adoption exceeds one slice, publish the bounded geometry and verified first repair with the precise remaining gap.

