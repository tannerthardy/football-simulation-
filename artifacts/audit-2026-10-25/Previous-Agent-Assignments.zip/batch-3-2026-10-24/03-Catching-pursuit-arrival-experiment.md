# Catching And Defensive Pursuit — discriminate prediction error from redirect cost

Prepared next-work brief; not automatically sent to its chat.

Branch: defense/G1-pursuit-arrival-comparison.
Problem: TKL-2. Effort: small-to-medium experiment; a resulting policy change is evidence-gated.

Repository: tannerthardy/football-simulation-. Read current AGENTS.md, CLAUDE.md, docs/PLAN.md, docs/GAPS.md and the named problem before starting. Fetch develop and record its full SHA; the preparation check saw 2f7ac93c270812869f19779fc2f5659d53e94080. These are subsequent development/research assignments, not review or merge chores. Preserve current work and use a separate named branch. State exact accepted versus pending dependencies; never label a pending composition as accepted trunk. Coordinate the actual shared interface with its owner, preserve source-qualified counterexamples, use the existing verification tiers, and keep raw artifacts in ignored out/. No target/band changes or broad parameter tuning are implied.

PR #259, head06bf5ef7, already supplies estimated-feasible/fallback status, candidate samples, raw/applied requests and current ordinary P002/P012 captures. Do not redo that instrumentation or re-prove its summary. Its useful next question is whether the 1.8→2.8-second candidate switch asks for a bad arrival, reflects legitimate redirection cost, or predicts a runner path poorly.

Freeze the full native SS bodies and actually consumed forecast inputs at the two adjacent P002 decisions (4.25 and4.30 on that pinned source). Preserve full support/spin/motor history, source/settings and elapsed-time conventions. Compare the original request and the two recorded candidate requests through the existing unchanged World/movement-preview mechanism. Keep predicted runner motion separate from the later recorded runner motion; recorded future motion is diagnostic truth, never a player input.

Measure capture/arrival error at the stated horizon/radius, velocity direction, speed lost and resulting miss side. Apply an applicable necessary reach bound, but do not mistake a sufficient controller failure for proof the target is unreachable. A miss under one seek policy does not establish an impossible optimal arrival.

Retain aligned/head-on, faster crossing, transverse momentum, close gathering and escaping/fallback controls. Use #259's successful P012 as a native negative control. If a request or predictor correction is justified, compare one bounded alternative on frozen independent cases before adoption. Faster yaw, automatic stop-first and a .8s horizon already failed to rescue the historical case; repeated blind tuning is not the task.

Provide Measurin with the exact baseline/treatment traces, objective clocks, actor identities and complete case manifest. Agree the concrete export/reproduction handoff early so it can run in another workspace. A bare local path or inaccessible hash is not a delivered fixture.

Done: an experiment that rules out a competing explanation and identifies the next smallest justified correction; where the correction survives opposing controls, a scoped implementation. Preserve adverse and inactive transfer. Coordinate common.ts with INFO-1's supplied-target exclusion; changing contact or physical capacities belongs to its owner.

