# Run Game — test whether nearby help is actually useful

Prepared next-work brief; not automatically sent to its chat.

Branch: run/G2-observed-helper-usefulness.
Scope: a bounded role-specific adaptation experiment, beginning with a native witness. Effort: medium.

Repository: tannerthardy/football-simulation-. Read current AGENTS.md, CLAUDE.md, docs/PLAN.md, docs/GAPS.md and the named problem before starting. Fetch develop and record its full SHA; the preparation check saw 2f7ac93c270812869f19779fc2f5659d53e94080. These are subsequent development/research assignments, not review or merge chores. Preserve current work and use a separate named branch. State exact accepted versus pending dependencies; never label a pending composition as accepted trunk. Coordinate the actual shared interface with its owner, preserve source-qualified counterexamples, use the existing verification tiers, and keep raw artifacts in ignored out/. No target/band changes or broad parameter tuning are implied.

PR #258, head40c77d14, corrects first-threat eligibility and the selected job's downstream revalidation. It deliberately keeps the nearer-teammate veto, and its quick/CI cards retain adverse explosive-run outcomes. Preserve both facts. This task is not a demand to restore aggregate YPC or discard correct finite information.

Question: does a lead/climbing blocker skip a real threat because a teammate is momentarily nearer, even though the acquired teammate picture shows that he is down, recovering, departing or unable to arrive? Conversely, can a nearby body still screen or recover usefully? The audit's helper-predicate panel only changed synthetic choices; native physical benefit was unproved.

Find one reproducible ordinary witness and one legitimate-help control. Trace the acquired teammate/defender/runner cues, original responsibility, exact helper veto, target/action lifetime, physical opportunity and first emitted difference. A retained cache or different selected target is insufficient proof. Reuse exact constructor capture and command tracing.

Compare current policy with the smallest local interpretation of useful help. Use existing acquired pose/motion and the existing decision interval. Preserve uncertain help as uncertain; do not consult live engagement/support or future paths. Keep original-threat, force/cutback, distant-distraction and useful co-moving-helper controls. A down body may still obstruct; a recovering teammate may still become useful.

This is an experiment before a production policy expansion. Measure actual arrival, leverage/contact or prevented threat, and the cost of abandoning the original defender. Use a second formation/front or mirrored active case as transfer, selected before choosing a winning variant. Preserve failures and inactive controls as such.

Done: a demonstrated native usefulness defect plus a bounded correction surviving opposing cases, or a supported finding that the current teammate priority is adequate. Do not add a general utility chooser or a coaching exception tied to a particular play ID. If no real opportunity exists in the nominated clip, close that hypothesis and stop rather than manufacturing one.

