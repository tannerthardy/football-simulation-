# Integration — turn film scouts into a useful review queue

Prepared next-work brief; not automatically sent to its chat.

Branch: tools/F1-film-scout-review-queue.
Problem: PERF-5 / VIEW-1. Effort: small-to-medium. Tools only.

Repository: tannerthardy/football-simulation-. Read current AGENTS.md, CLAUDE.md, docs/PLAN.md, docs/GAPS.md and the named problem before starting. Fetch develop and record its full SHA; the preparation check saw 2f7ac93c270812869f19779fc2f5659d53e94080. These are subsequent development/research assignments, not review or merge chores. Preserve current work and use a separate named branch. State exact accepted versus pending dependencies; never label a pending composition as accepted trunk. Coordinate the actual shared interface with its owner, preserve source-qualified counterexamples, use the existing verification tiers, and keep raw artifacts in ignored out/. No target/band changes or broad parameter tuning are implied.

PERF-4 has produced reporting PR #257. The next F1 step in current GAPS is detector precision. Reuse #243's detector output, the current viewer's player/version/time reference, ordinary-play capture and existing notes. This is a development assignment, not an integration/review gate.

Prepare a small frozen sample from already recorded evidence: around twelve flagged episodes stratified across detector types and six unflagged control windows. Keep the sampling recipe, eligible population, seed and denominators. It is a development sample, not a population-recall estimate.

Create a portable index/report using the existing film format. Each entry identifies source/settings/input, play, stable actor, interval, detector and its claimed concern, with a link/reference to the exact replay and capture/trace command where available. Include observed responsibility, raw versus final request, contact/support and opportunity context when recorded. Unknown fields remain unknown. The existing Copy reference feature already includes player/version/time; build on it.

Complete an agent first pass: mechanism-supported defect, legitimate football/physical constraint, or unresolved. Keep the reason and competing explanation, not just a checkbox. Include contact-owned facing, valid coverage turn, a stale cache never consumed and a far-side player without a reachable useful intervention as opposing examples where available. Agents must not infer contact absence or intent from dots alone.

Give Tanner only the concise ambiguous shortlist and short clips needed for his football judgment. Save his optional labels through the existing notes/report convention. Summarize reviewed true/false/uncertain counts by detector with small-sample limits; unreviewed alerts are not errors and uncertain labels are not successes. Include unflagged controls to expose blind spots without claiming a reliable recall estimate from six cases.

Done: a reproducible compact queue that makes an existing detector useful or establishes why it wastes time. No new detector families, automatic football grades, engine tuning to suppress alerts or standalone visualization application. Preserve all sampled outcomes and choose the next tool change from the observed review bottleneck.

