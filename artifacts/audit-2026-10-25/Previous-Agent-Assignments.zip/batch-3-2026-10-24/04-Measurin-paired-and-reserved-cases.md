# Measurin — complete treatment evidence and independent pursuit transfer

Prepared next-work brief; not automatically sent to its chat.

Branch: tools/F1-pursuit-treatment-evidence.
Effort: small-to-medium; use the existing panel.

Repository: tannerthardy/football-simulation-. Read current AGENTS.md, CLAUDE.md, docs/PLAN.md, docs/GAPS.md and the named problem before starting. Fetch develop and record its full SHA; the preparation check saw 2f7ac93c270812869f19779fc2f5659d53e94080. These are subsequent development/research assignments, not review or merge chores. Preserve current work and use a separate named branch. State exact accepted versus pending dependencies; never label a pending composition as accepted trunk. Coordinate the actual shared interface with its owner, preserve source-qualified counterexamples, use the existing verification tiers, and keep raw artifacts in ignored out/. No target/band changes or broad parameter tuning are implied.

The previous deliverable exists: #255 is the turning operator; dependent branch tools/F1-pursuit-movement-panel at b7e12948 contains the actor-window panel. Its #255 handoff records six complete reference cases, six missing treatment cases, and no controller-improvement claim. Do not rebuild that report. The reference cases came from current P012 rather than the initially missing historical nominations; keep those identities honest.

Complete the causal evidence loop with Catching's next arrival/steering experiment. Obtain a portable trace export or complete regeneration command against an explicit source/settings/input identity. Use its actual P002 and P012 captures; do not relabel P012 actors/windows as the P002 SS. Extend the manifest under a new declared selection/version when adding cases, while preserving the original six-case selection.

Before inspecting treatment outcomes, nominate two independent active transfer situations (for example a faster crossing and a stop/reversal or sideline escape), using existing captured inputs where possible. Keep successful gathering, coverage turn and contact/fall controls. A treatment that never executes on a case is an inactivity control, not evidence of useful transfer.

Run existing native and tracking-style operators over the baseline/treatment trajectories. Join actual prediction horizon/status/slack and objective times when recorded; otherwise retain unavailable fields. Report entry velocity, body and travel change, speed loss, transverse carry, first useful redirection, actual approach/arrival error and contact exposure. Preserve missing/rejected/partial trials in counts.

Explicitly distinguish a policy's intended changed requests from observer-induced mismatches, and fixed-input continuations from new whole-game exposures. A reduced final gain caused by another player's fumble is not evidence of better selected-pursuer execution.

Done: the existing table populated with actual paired treatments and preselected active transfer, with favorable/adverse/inactive/missing outcomes visible. Supply a short mechanism conclusion; do not fit a physical capacity or choose a new NFL target. Baseline capture and reserved-case selection can proceed while the controller owner develops its treatment.

