# Small, high-value audit follow-ups

Prepared October 23, 2026. These are proposed chat assignments, not delivered messages or amendments to the approved plan. The session can read existing chats but has no send-to-chat tool. Chat names below match the inspected titles.

| Order | Chat | Deliverable | Scope |
|---|---|---|---|
| Start | Measurin | Mechanics guard cannot pass missing evidence | Small offline tooling repair |
| Start | Do-It-All! | Target and held aim remain one coherent action | Small code change; careful run/coverage review |
| Start | Run Game | Equivalent lineup mappings ignore property insertion order | Small-to-medium construction/experiment repair |
| Alongside | Integration | Correct unsupported braking/yaw diagnostic claims | Short docs-only pass |
| Next | Catching And Defensive Pursuit | Selected-player command-stage trace | Moderate tooling slice; sequence playsim.ts edits |

Use the current coordinator's ownership and merge process. These chat assignments do not displace Claude's existing football lanes. Check open PRs before starting another in the same chat. Physics Sim need not be redirected into a cheap-win batch. CEO of Football can review the resulting claims without creating another broad research assignment.

The five individual briefs contain source locations, evidence, scope, opposing controls and completion criteria. They do not depend on access to the audit's local filesystem. Exact native fixtures and raw traces are optional context available in the full audit archive; a seed/play number alone must not be presented as an exact native reproduction.

The bigger possession-belief correction, contact-geometry redesign, capacity calibration and generalized intelligence framework are deliberately outside this batch. Their impact may be large, but their tradeoffs do not qualify as quick, low-risk repairs.

