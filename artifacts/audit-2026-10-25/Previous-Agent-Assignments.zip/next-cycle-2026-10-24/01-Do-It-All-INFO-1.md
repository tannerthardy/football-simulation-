# Do-It-All! — continue the possession-awareness repair

Paste-ready development brief. This message has not been sent to the chat automatically.

Fetch current develop and read AGENTS.md, CLAUDE.md, docs/PLAN.md and docs/GAPS.md. Record the exact source/settings used. This brief assigns development work; it does not assign review or merging. Coordinate shared functions with their current lane owner. Keep one bounded deliverable, use focused evidence first and the existing verification tiers, and retain adverse results. Raw output stays in ignored out/. Preserve existing workers' changes and historical source pins. If this slice is already implemented, verify it and move to the remaining stated question rather than duplicating it.

Continue the INFO-1 assignment already given after #251. Own the narrow possession slice with Main Engine/Coverage coordination; Run Game owns the separate #238 blocker gate in this batch.

Trace both routes together: onBallCaught's global replacement with Pursuit and the legacy pursueIfLive/coverage route selecting sim.carrier. The audit's native SS experiment showed either isolated correction could be bypassed by the other. Reproduce baseline, each isolated intervention and the combined intervention on one exact current input. An old G1-P002 ordinal alone is not that input.

Implement the smallest shared acquired-possession rule for these two consumers. Preserve legitimate anticipation from available ball-flight or football cues; a blanket requirement to wait for carrying=true can be wrong. Ball physics and official possession continue to use authoritative state.

Acceptance: fixed available evidence plus different hidden holder state gives the same migrated decision; newly acquired catch cues produce a timely response; credible pre-catch anticipation remains possible; fake handoffs, previously read runs, bobbles/incompletions and late acquisition have explicit opposing controls. Preserve existing commitment timing unless a separate defect is demonstrated. Use command attribution and first useful motion, then report downstream outcomes with limitations.

Done: a bounded information-boundary repair with a current reproducible witness and one unfamiliar/mirrored active transfer case. Avoid extending this into a whole-engine perception or decision rewrite.

