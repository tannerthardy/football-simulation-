# Integration — make the scorecard's uncertainty language honest

Paste-ready development brief. This message has not been sent to the chat automatically.

Fetch current develop and read AGENTS.md, CLAUDE.md, docs/PLAN.md and docs/GAPS.md. Record the exact source/settings used. This brief assigns development work; it does not assign review or merging. Coordinate shared functions with their current lane owner. Keep one bounded deliverable, use focused evidence first and the existing verification tiers, and retain adverse results. Raw output stays in ignored out/. Preserve existing workers' changes and historical source pins. If this slice is already implemented, verify it and move to the remaining stated question rather than duplicating it.

Your documentation follow-up is #248. The next development task is PERF-4: presentation of uncertainty and rare-event exposure. Own the report-formatting slice; coordinate the interface with Measurin. This is not a merge/coordinator assignment.

Inspect current scripts/scorecard/run.ts and the existing reporting helpers. Where still present, replace “noise” for an interval including zero with “not resolved by this sample,” and “Biggest real moves” with wording such as “Largest estimated changes.” Preserve thresholds, bootstrap calculations and statistical policy.

Show available numerator/denominator counts beside rare-event rates and their intervals. For example, 17/17 made field goals is an observed 100%, not proof of a certain success rate. Preserve the existing interval calculation while making exposure and limitations visible. Read counts from actual stored evidence; never reconstruct an integer numerator from a rounded percentage. Missing legacy counts remain explicitly unavailable.

Use tiny offline fixtures and compatible saved cards: all-success rare event, one failure, zero exposure, missing legacy counts, a resolved difference and an interval spanning zero. Preserve current provenance/compatibility handling and all numeric metric/interval values.

Acceptance: reporting text/counts become more informative; the same saved card retains identical underlying numeric results; incompatible/missing evidence remains qualified. Do not change NFL bands, replace the interval method or generate another game campaign for this formatting task.

Done: one small reporting PR with before/after examples and focused offline checks. If the wording/counts are already correct on current develop, document that and stop this slice.

