# Catching And Defensive Pursuit — expose pursuit prediction feasibility

Paste-ready development brief. This message has not been sent to the chat automatically.

Fetch current develop and read AGENTS.md, CLAUDE.md, docs/PLAN.md and docs/GAPS.md. Record the exact source/settings used. This brief assigns development work; it does not assign review or merging. Coordinate shared functions with their current lane owner. Keep one bounded deliverable, use focused evidence first and the existing verification tiers, and retain adverse results. Raw output stays in ignored out/. Preserve existing workers' changes and historical source pins. If this slice is already implemented, verify it and move to the remaining stated question rather than duplicating it.

The command trace and exact ordinary-play capture have produced #250/#254. Use them to resolve a movement question. Coordinate reach/pursuit interfaces with Defense; Do-It-All! owns the possession-transition slice.

The first deliverable is the TKL-2 prediction contract. timeToReach is approximate, and interceptPoint returns a feasible interception and its least-bad fallback in the same shape. Expose whether a candidate met the estimator's test, its prediction horizon, estimated arrival time/slack and forecast assumptions. “Estimator says feasible” must not be labelled physically guaranteed. Preserve existing point selection and steering for this first slice.

Make the result inspectable in the existing selected-player diagnostic path without extra perception reads, controller evaluations, random draws or prediction steps. Use a normal-game capture to show one pursuit overrun and a useful pursuit control. Identify whether the point changes, a modifier changes the request, or the body fails to realize it in time. Separate body facing from actual travel.

Controls: aligned/head-on approach, transverse momentum, escaping/faster crossing, fallback with no estimated feasible candidate, and close gathering that bypasses the intercept planner. The audit's isolated reach-bound violation did not establish the cause of its native P002 sweep; do not repeat that causal leap.

Done: explicit, honestly named status and a replayable first-divergence diagnosis for one ordinary pursuit. Any subsequent forecast/steering correction is a separate bounded continuation, tested against the frozen opposing cases. Keep physical capacities fixed during that comparison.

