# Run Game — correct the first-threat blocker’s hidden-state gate

Paste-ready development brief. This message has not been sent to the chat automatically.

Fetch current develop and read AGENTS.md, CLAUDE.md, docs/PLAN.md and docs/GAPS.md. Record the exact source/settings used. This brief assigns development work; it does not assign review or merging. Coordinate shared functions with their current lane owner. Keep one bounded deliverable, use focused evidence first and the existing verification tiers, and retain adverse results. Raw output stays in ignored out/. Preserve existing workers' changes and historical source pins. If this slice is already implemented, verify it and move to the remaining stated question rather than duplicating it.

The lineup and offline-data-CI tasks have produced #252/#253. The next task is the blocker part of INFO-1, distinct from Do-It-All!'s possession paths. Coordinate blocking.ts with the Run/Main Engine owner.

In RunBlocker.rereadThreat (introduced by #238), candidate eligibility can inspect the opponent's real engagement and isDown state even though target geometry uses delayed pictures. Reproduce the leak by holding the blocker's acquired evidence fixed while changing only an unseen opponent's support/contact state. Trace the first changed candidate/target/request, not just final yards.

Replace only the unjustified authoritative eligibility decisions with already available acquired evidence and legitimate own-contact knowledge. Use observed pose/position/motion or exposed contact information according to their actual meaning. Treat unavailable knowledge as unknown; proximity alone must not become proof of engagement. Once a changed state is acquired, permit the existing selector/cadence to respond.

Preserve #251's target/action lifetime, the current runner-threat scoring, installed assignment priorities and valid teamwork. The ignored helper-velocity opportunity and a broader adaptation policy are separate follow-ups.

Acceptance: hidden-only changes do not alter this decision; acquired down/unavailability cues can alter it at the existing read; valid nearby help and cutback/original-threat controls remain; no extra look at true holder identity is introduced. Demonstrate at least one physical continuation where the selected request is consumed. Do not label a target change itself a football improvement.

Done: one narrow input-provenance repair and opposing controls, with a clear list of any remaining live-state reads. No selection-policy expansion is required.

