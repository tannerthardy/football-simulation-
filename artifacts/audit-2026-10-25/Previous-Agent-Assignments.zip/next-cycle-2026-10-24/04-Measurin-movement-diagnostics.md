# Measurin — measure the movement failures in the actual pursuit cases

Paste-ready development brief. This message has not been sent to the chat automatically.

Fetch current develop and read AGENTS.md, CLAUDE.md, docs/PLAN.md and docs/GAPS.md. Record the exact source/settings used. This brief assigns development work; it does not assign review or merging. Coordinate shared functions with their current lane owner. Keep one bounded deliverable, use focused evidence first and the existing verification tiers, and retain adverse results. Raw output stays in ignored out/. Preserve existing workers' changes and historical source pins. If this slice is already implemented, verify it and move to the remaining stated question rather than duplicating it.

The turning-operator repair has produced #255. Apply the improved measurements to the pursuit work rather than starting another broad NFL-capacity audit. Coordinate a small output contract with Catching/Defense; they own controller and physics changes.

Reuse the existing movement-task and measurement helpers. Select a small frozen case set: a free overrun, a useful intercept, a stop/redirect, a valid coverage turn, a contact-owned torso turn and a contact/fall. Prefer existing saved inputs and traces; record the source of every case. Unknown contact/support state stays unknown.

For each actor/window report actual elapsed time, entry velocity, body rotation and travel-direction change separately, speed loss, velocity remaining across the desired direction, and closest approach/arrival error where an actual objective is recorded. Include the raw/applied request and prediction status when supplied by the trace; do not infer a player's intention from a trajectory.

Where native resolution and tracking-style filtered/sampled measurements differ, show both with explicit definitions. Preserve failed/rejected measurements in the appropriate exposure counts. Use current #255 operators where suitable and reuse the existing movement-task panel rather than building a second evaluation framework.

Acceptance: an unchanged saved case gives identical metrics; a body-only turn is distinguished from travel redirection; a known stop/turn fixture has the expected direction and timing; a paired controller intervention can be evaluated without relying only on final yards. Keep the selected case list and windows fixed before comparing treatments.

Done: one compact, reusable diagnostic table/command serving the current pursuit experiment. No new NFL download, hard physiological limit, capacity retune or new aggregate target is required.

