# Catching And Defensive Pursuit: Expose who changed one player's command

Paste the following brief into **Catching And Defensive Pursuit**. It has not been sent automatically.

---

Queue after the lineup-construction edit or coordinate a nonoverlapping shared-file handoff.
Suggested branch: tools/F1-selective-command-trace.
Suggested title: [F1] Trace decision owner and command rewrites for a selected player.

Repository: tannerthardy/football-simulation-. Fetch current develop and record its SHA; read AGENTS.md, docs/PLAN.md, docs/GAPS.md and CLAUDE.md. The audit experiments used c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0; last checked develop ccdb69cba81e07c578f607ff1bf8ce0efe2edc68 changes documentation only. Verify current behavior before fixing it.

Use an isolated branch, one focused PR into develop, and the supported Node version. Preserve existing work and coordinate shared-source edits with the current owning lane. Use focused checks first, followed by the existing plan's applicable verification tier; do not invent another mandatory campaign. Keep raw output in ignored out/. No merge, unrelated cleanup, new framework or default-off feature flag. Do not change approved priorities, metric targets or historical evidence. If the issue is already fixed, verify that and stop.

This is the slightly larger follow-up, not a request to fix pursuit, tackling or all replay infrastructure.

Deliver a selectable actor/time-window trace using values already computed in the normal execution. Record step-start and endpoint time, stable actor identity, behavior/target at decision time, raw command, materially changed commands after containment/open-to-ball/engagement/tackle bond/spacing/snap guard, final command and endpoint behavior/body/contact state. Record consumed observation timestamps only where already available; do not add perception calls to explain a decision.

The audit found a concrete attribution trap: at a catch, an old coverage controller generates a command, then the catch replaces behavior with Pursuit before the replay records it. Endpoint behavior is not proof Pursuit authored that command. Similarly engagement can replace a runnerward facing request with blocker-facing while preserving much of the velocity.

Relevant chain: src/sim/playsim.ts, approximately lines 943–1047 at the audit pin. A passive audit prototype observed these stages without changing the entire packed native replay. Use its design if supplied, but do not ship globalThis audit hooks or a permanent all-player JSON dump as the production interface.

Checks: observer off/on complete execution equality on a selected native play; correct ownership across a catch; an engagement-facing rewrite; a legitimate unchanged/free command. No extra random draws, decision evaluations or physics steps. Keep output disabled/absent by default as optional diagnostic recording, not a feature-flagged football mechanism.

Done: one reproducible command producing a short selected-player trace that lets an agent locate the first controller responsible. Preserve lightweight replay operation. Do not build a general state serializer, visualization application or universal brain.

This chat's recent scorecard work is useful background, but this assignment is not an extension of special-teams metrics.

