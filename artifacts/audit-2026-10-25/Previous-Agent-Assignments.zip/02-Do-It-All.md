# Do-It-All!: Stop new targets inheriting old targets' actions

Paste the following brief into **Do-It-All!**. It has not been sent automatically.

---

Suggested branch: coverage/G3-target-action-lifetime.
Suggested title: [G3] Keep target changes coherent with held aiming actions.

Repository: tannerthardy/football-simulation-. Fetch current develop and record its SHA; read AGENTS.md, docs/PLAN.md, docs/GAPS.md and CLAUDE.md. The audit experiments used c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0; last checked develop ccdb69cba81e07c578f607ff1bf8ce0efe2edc68 changes documentation only. Verify current behavior before fixing it.

Use an isolated branch, one focused PR into develop, and the supported Node version. Preserve existing work and coordinate shared-source edits with the current owning lane. Use focused checks first, followed by the existing plan's applicable verification tier; do not invent another mandatory campaign. Keep raw output in ignored out/. No merge, unrelated cleanup, new framework or default-off feature flag. Do not change approved priorities, metric targets or historical evidence. If the issue is already fixed, verify that and stop.

Own this one shared repair; obtain run/coverage review for their consumers rather than splitting the same primitive into two patches.

Problem: SnapMind.aim(job, desired, t), src/sim/mind.ts, retains a position by job string until its deadline. Investigated callers are RunBlocker’s “block-fit” in behaviors/blocking.ts and ZoneCoverage’s “zone-drive” in behaviors/defense.ts. Either can select target B while receiving the held point for A, sometimes combining B’s velocity with A’s position. There are eight aim callsites, not just these two: inspect the others for compatibility, but do not migrate them without evidence.

The audit reproduced real command/body effects in native P093 F and P095 FS. In P095, target X→Z retained the old goal and emitted lateral velocity −7.165 yd/s; invalidation emitted +6.401. Final yards did not change. Four other plays computed stale goals that a later planned-climb branch ignored; P029 retained a cache without calling it. Don't equate retained memory with an executed error.

Deliver a coherent transition: either preserve target and held goal together through commitment, or invalidate the old action when existing policy allows a target change. Preserve normal same-target reaction cadence. A target-key-only cache can resurrect obsolete state on A→B→A; use action generation/explicit invalidation or demonstrate equivalent semantics.

Checks: changed target before expiry; same target; expiry; A→B→A; both investigated roles; a branch that never consumes the cache. Assert the emitted action/command, not just private cache contents. Reuse exact audit fixtures if available; otherwise construct and label a minimal witness—old play numbers alone are not reproducible inputs.

Done: the action consistently belongs to its selected target, with no new decision scheduler, instantaneous universal reactions or promise of improved aggregate yards. This is a small implementation with meaningful transition review.

