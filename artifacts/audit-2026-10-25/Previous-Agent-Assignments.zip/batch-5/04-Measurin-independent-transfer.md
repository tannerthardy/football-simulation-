# Measurin — finish the reserved live-policy experiment

Prepared task brief. It has not been sent automatically to the chat.

Branch: tools/F1-reserved-pursuit-transfer. Audit: A15/A18, existing measurement code only unless a demonstrated defect requires a bounded correction. Effort: small-to-medium.

## Verify this brief before implementing

Independently check this plan against the exact current code and saved evidence. In your first substantive update, give: **confirmed details; corrections to the plan; unresolved details and the smallest deciding experiment**. Verify source/dependency SHA, actual function signatures and callers, units/coordinate origins, controller/World clock, actor IDs from machine records, and whether the stated cause is really reproduced. A review comment or this brief is a claim to test, not technical truth. Correct routine details and continue within the goal; do not pause for Tanner to approve every implementation choice. Ask the owning agent only for a concrete missing interface/artifact. If the hypothesis fails, preserve the negative result instead of forcing a patch.

Use current AGENTS/CLAUDE/PLAN/GAPS. Work on the named isolated branch, protect existing workers, keep accepted and pending dependencies explicit, and follow existing lane ownership and verification tiers. Raw traces belong in ignored out/ and the useful conclusion in the PR, not a new Git-tracked receipt system. Read the technical plan in this package. These are development/research jobs, not review or merge chores.

## Availability is no longer the blocker

#267's published headba880a1b and comment6382953852 now deliver the actual on-by-default implementation, activation definition, exact commands and a nonvacuous witness. The P038 SS/P117 FS reserved cases have no completed independent results visible in the handoff read for this plan. Verify that status before repeating work; if already completed, publish the conclusion rather than rerun it.

## Technical work

1. Preserve the reserved selections and source-qualified inputs. Read actual playerId/team/slot/index tuples from files: prior handwritten catcher IDs were corrected on #255/#267. Never relabel an ordinal or change the window after seeing treatment.
2. Use the existing saved-play and movement-window tools to run baseline and live #267 policy, retaining strict observer-off/on equality within each arm and expected cross-source differences explicitly. Keep pending #264 contact and #260 possession changes out of this single-factor comparison.
3. Confirm active reduced-effort interception with actual emitted speed/effort and recorded estimate request fields, not the existence of new metadata. Distinguish a changed own request on matched body/picture from a later difference inherited from other actors. A queried candidate with the same chosen point is point-inactive, not a second transfer success.
4. Report finite forecast-point error versus actual runner approach, physical contact/load versus acquisition, body/travel change, and exposure/missing data using the existing panel. Reaching a sampled point is not finishing a tackle.
5. If final outcomes differ through randomness, inspect the already consumed probability/draw where practical without rerunning it. Separate geometry-driven threshold changes from draw reassignment. Do not force common outcomes or claim a whole-play paired-RNG counterfactual.

## Completion

Deliver the two reserved live results as active/inactive, favorable/adverse/unchanged, with their first consequential difference and source/case identities. A small sample may narrow a claim; it cannot prove a league improvement. Reuse #263/#267's portable bundle instead of rebuilding a panel or launching another NFL/scorecard campaign. If no active transfer occurs, say so and identify the exposure reason. Hand Integration a short watchable pair only when the mechanical story is established; do not create another artifact-access loop.

