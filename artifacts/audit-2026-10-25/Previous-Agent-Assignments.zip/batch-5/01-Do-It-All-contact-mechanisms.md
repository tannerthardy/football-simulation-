# Do-It-All! — separate admission, retained span and grip control

Prepared task brief. It has not been sent automatically to the chat.

Branch: defense/G10-contact-mechanism-separation. Audit: A07; keep A14 physics-law changes separate. First delivery: medium; pose extension may require a second bounded slice.

## Verify this brief before implementing

Independently check this plan against the exact current code and saved evidence. In your first substantive update, give: **confirmed details; corrections to the plan; unresolved details and the smallest deciding experiment**. Verify source/dependency SHA, actual function signatures and callers, units/coordinate origins, controller/World clock, actor IDs from machine records, and whether the stated cause is really reproduced. A review comment or this brief is a claim to test, not technical truth. Correct routine details and continue within the goal; do not pause for Tanner to approve every implementation choice. Ask the owning agent only for a concrete missing interface/artifact. If the hypothesis fails, preserve the negative result instead of forcing a patch.

Use current AGENTS/CLAUDE/PLAN/GAPS. Work on the named isolated branch, protect existing workers, keep accepted and pending dependencies explicit, and follow existing lane ownership and verification tiers. Raw traces belong in ignored out/ and the useful conclusion in the PR, not a new Git-tracked receipt system. Read the technical plan in this package. These are development/research jobs, not review or merge chores.

## Evidence that changes the task

PR264 at6eb21c86 proposes a soundly motivated standing/blocked admission correction, but also changes lunge/dive opportunity, retained reach/ground and quality. The coordinator's6380890578 comment requests a split/rework. Its approximate anatomy and quality numbers also require verification. Your6382181174 follow-up rejects the simple arrival-radius hypothesis: P013 CB_S reaches, acquires and transmits a hold before slipping; neither radius treatment improves finishing. Do not rerun that failed tuning path.

## Technical work

1. Build a unit/landmark table for PhysicalProfile.reach, body center, target body surface, World.graspPoint, GraspJoint.reach/ground/hold, contactQuality arguments, and grip/control/capacity. Check whether distances are body-center or represented attachment-point distances at every consumer. Keep point-ball reach distinct from receiver-body distance.
2. Preserve the valid standing/blocked double-radius correction as a separately testable treatment. In a diagnostic branch, isolate the effects of admission, retained span and quality; avoid using an all-in-one changed ending as attribution.
3. For an identical genuinely acquired hold, copy full bodies/support, attachment/joint state, intended commands and consumed execution values. Compare retained-span versus quality treatments. Log transmitted load, slipping/break reason, body/attachment separation, grip, control, capacity and World time. A low wrap-control estimate need not automatically mean weak hand grip; verify what the equations intend before changing either.
4. Check the dive/ground representation. physical.ts's1.33×height comment describes standing catch height; it does not itself validate a horizontal center-of-mass-to-fingertip distance. Derive any layout/pivot allowance from explicit body dimensions and represented pose/motion. Do not count body translation twice or turn a possible future pose into immediate contact.
5. If a revised landmark moves, its velocity and force/work meaning must agree with the solver's existing point/Jacobian. Coordinate that narrow boundary with Physics. This task does not authorize silently enabling patch hand physics or adding a detailed skeleton.

## Acceptance and stopping

Keep standing in/out-of-range, restricted arm, reached-and-slipped P013, successful P012, a finite reachable dive, a receding miss and target-change retirement. An initial grasp is not proof of transmitted load. Repeated ticks cannot reroll one committed attempt. Check whether decision-sample-only admission misses a short opportunity; label that unresolved sampling rather than enlarging the radius to hide it.

Deliver the verified geometry/quality contract and smallest supported repair, with separate mechanism evidence. Preserve legitimate failures and adverse results. Do not restore a remote hold, force NFL averages, or claim all long contacts anatomically impossible. #260/#256/#267 remain explicit independent dependencies until a specified composition is tested.

