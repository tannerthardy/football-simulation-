# Integration — finish the usable film-to-agent loop

Prepared task brief. It has not been sent automatically to the chat.

Branch: tools/F1-actionable-film-queue. Audit: A03/A04/A10. Effort: small-to-medium; complete current work before another platform feature.

## Verify this brief before implementing

Independently check this plan against the exact current code and saved evidence. In your first substantive update, give: **confirmed details; corrections to the plan; unresolved details and the smallest deciding experiment**. Verify source/dependency SHA, actual function signatures and callers, units/coordinate origins, controller/World clock, actor IDs from machine records, and whether the stated cause is really reproduced. A review comment or this brief is a claim to test, not technical truth. Correct routine details and continue within the goal; do not pause for Tanner to approve every implementation choice. Ask the owning agent only for a concrete missing interface/artifact. If the hypothesis fails, preserve the negative result instead of forcing a patch.

Use current AGENTS/CLAUDE/PLAN/GAPS. Work on the named isolated branch, protect existing workers, keep accepted and pending dependencies explicit, and follow existing lane ownership and verification tiers. Raw traces belong in ignored out/ and the useful conclusion in the PR, not a new Git-tracked receipt system. Read the technical plan in this package. These are development/research jobs, not review or merge chores.

## Current state

#265's paired producer is now merged at a64146a3, into accepted30a1f491. It supplies eight episodes across seven plays with exact saved inputs and traces. Its own description says the #262 queue-side manifest/notes integration and stricter first-pass adjudication were unfinished. All eight football concerns remain unresolved, with P006 Y2.6–3.85 and P007 RG3.6–4.15 nominated for whether useful release is possible. This is a functioning producer, not yet the completed diagnosis loop.

## Technical work

Join those exact recordings to the existing queue/notes consumer. Verify source/settings/input/player/interval identity and support relocation. Deliver an accessible portable bundle and exact regeneration command; a private out/ path or hash without fetchable bytes is not delivery. Preserve the old18-entry historical sample as unavailable rather than relabelling it.

For P006 Y and P007 RG, record the actually entered behavior, installed responsibility, raw request, engagement rewrite, actual load/support, runner/threat geometry and any feasible alternative. Use already consumed observations; do not call a controller or perception again to manufacture an explanation. Distinguish preserving a useful block from holding an obsolete job; seeing a free defender elsewhere proves neither.

Complete an agent first pass using the matched evidence. Label mechanism-supported defect, legitimate constraint, or the exact unresolved football tradeoff. A label must cite the interval and recorded facts; do not invent intent. Preserve early approach/contact controls from the same source. A short causal probe can establish whether a claimed alternative was physically possible, coordinated with Run/Defense; production policy remains theirs.

Give Tanner at most two short, playable ambiguous clips with a concrete question and the competing explanations. Include side-by-side request/achieved motion where already supported by the viewer. His judgment should resolve football meaning, not compensate for missing files.

## Completion

One self-contained index/film/input/trace/notes bundle that another workspace can open and use, plus updated per-scout confirmed/legitimate/uncertain counts with small-sample limits. Uncertainty is acceptable when the question is explicit and the film is available. Do not add detectors, an automatic football grade, a standalone app or another unjoined sampling format. The operational success is a shorter path from a flagged clip to a supported diagnosis, not a larger event count.

