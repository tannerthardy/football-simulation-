# Catching And Defensive Pursuit — research and prototype the first disciplined adaptation

Prepared task brief. It has not been sent automatically to the chat.

Branch: coverage/G3-COV7-alley-option-pilot. Audit: A08/A19; current PLAN's named first adaptation test. Effort: medium research/fixtures first, then a bounded role-local prototype.

## Verify this brief before implementing

Independently check this plan against the exact current code and saved evidence. In your first substantive update, give: **confirmed details; corrections to the plan; unresolved details and the smallest deciding experiment**. Verify source/dependency SHA, actual function signatures and callers, units/coordinate origins, controller/World clock, actor IDs from machine records, and whether the stated cause is really reproduced. A review comment or this brief is a claim to test, not technical truth. Correct routine details and continue within the goal; do not pause for Tanner to approve every implementation choice. Ask the owning agent only for a concrete missing interface/artifact. If the hypothesis fails, preserve the negative result instead of forcing a patch.

Use current AGENTS/CLAUDE/PLAN/GAPS. Work on the named isolated branch, protect existing workers, keep accepted and pending dependencies explicit, and follow existing lane ownership and verification tiers. Raw traces belong in ignored out/ and the useful conclusion in the PR, not a new Git-tracked receipt system. Read the technical plan in this package. These are development/research jobs, not review or merge chores.

## Why this is next

#267 implements the effort/request contract. Its CI YAC8.15→8.03 with change interval-1.27…+.99 is not a general YAC improvement. Its adverse P002 touchdown includes a changed consumed execution draw; do not tune motion parameters to recover that ending. The audit's promised decision-layer checkpoint now needs an actual opportunity-versus-duty experiment.

## Phase A: verify football and engine support

Read COV-7, ManCoverage.coverMan/blockingSupport, PASS_FIRST, installed force/alley roles, existing CoverageJudgment and #260's acquired possession/recognized-flight contract. Verify the corner is an alley player, not force, and identify the exact acquired run/block/possession cues. The audit P029 is historical; capture the complete current input before using its labels.

Write a short coaching-supported decision account: when maintaining man protects a live pass threat, when capped alley support helps, and when an emergency chase is justified. Identify which cues a player can actually distinguish. Verify whether a real HB pass, stalk-then-release and delayed route can be installed with current legal ball/route/blocking rules. Unsupported cases stay unsupported; do not call a nonactivating ordinary pass a deception-cost test.

## Phase B: discriminating fixtures and local prototype

Create one run benefit case and at least one active deception/retained-threat cost case with comparable early acquired cues. Hidden offensive call/result must not choose the response. Cases with identical consumed evidence must remain behaviorally identical until new evidence arrives, apart from explicitly fixed own traits/call.

Compare: retain man; temporarily execute the installed capped alley fit; chase. Keep the primary receiver responsibility and a way to reacquire it. Use existing recognition/read/commitment cadence; add no second generic decision clock. Preserve force/cutback constraints. Reuse current per-role abstractions and target/action lifetime; no universal utility chooser is required for the pilot.

Measure cue→choice→first useful motion, support arrival/leverage, abandoned pass window, ability/time to recover the primary and physical execution. A reduced run gain alone is not success. A plausible misread can have a real cost; no policy is expected to win indistinguishable run/pass prefixes perfectly.

## Deliverable and boundary

First deliver verified coaching logic, support inventory and replayable active benefit/cost fixtures. Only then implement one smallest role-local policy if warranted. Preserve #260's acquired-information semantics on an explicitly identified dependency; no hidden holder or future-route access. Coordinate with Coverage/Defense and the current COV-6 owner. This starts the research phase specified by Tanner and PLAN; it does not authorize a shared brain or a production policy unsupported by its opposing case.

