# Run Game — trace the C/RG-to-Mike responsibility chain

Prepared task brief. It has not been sent automatically to the chat.

Branch: run/G2-combo-handoff-access. Audit: A08/A09/A12 responsibility and installation; local native investigation. Effort: medium.

## Verify this brief before implementing

Independently check this plan against the exact current code and saved evidence. In your first substantive update, give: **confirmed details; corrections to the plan; unresolved details and the smallest deciding experiment**. Verify source/dependency SHA, actual function signatures and callers, units/coordinate origins, controller/World clock, actor IDs from machine records, and whether the stated cause is really reproduced. A review comment or this brief is a claim to test, not technical truth. Correct routine details and continue within the goal; do not pause for Tanner to approve every implementation choice. Ask the owning agent only for a concrete missing interface/artifact. If the hypothesis fails, preserve the negative result instead of forcing a patch.

Use current AGENTS/CLAUDE/PLAN/GAPS. Work on the named isolated branch, protect existing workers, keep accepted and pending dependencies explicit, and follow existing lane ownership and verification tiers. Raw traces belong in ignored out/ and the useful conclusion in the PR, not a new Git-tracked receipt system. Read the technical plan in this package. These are development/research jobs, not review or merge chores.

## Starting evidence

Close the sampled helper and backside-crack hypotheses from #261/#266. In #266's ordinary P003, the wide Z/LB_W responsibility did not cause demonstrated lost perimeter access. LB_M actually tackles the runner from the separately installed C/RG combination responsibility. This is a nominated opportunity to investigate, not a proven late release. Use the captured input43107b5708f2df79cb14b4281a765e6247a701ecfa0d04bc55b5cd10576024e3 on its recorded source, then qualify a current-source reproduction.

## Technical work

1. Recover the actual installed combination: who starts on DT_S, who owns the next LB_M responsibility, what permits release, and what each partner knows. Verify role names from the data, not roster labels.
2. Trace C and RG across pre-decision combo preparation, each entered update, plan/target/action changes, raw/final requests and physical load. Trace LB_M/runner pictures and real contact timing. Distinguish a planned transfer from the actor actually issuing it.
3. Find the earliest causal bottleneck: recognition/cadence, shared-plan effective time, keeper/collector ownership, target cache, approach capability, or a legitimate requirement to retain the first defender. The audit's P064 update-order effect is a precedent to test, not an explanation to assume here.
4. Compare a minimal transfer using only evidence available at that time against keeping the double. Preserve reacting players and physical costs. A forced earlier release may be used for attribution, clearly labelled; it is not deployable policy unless the player had the relevant cue.
5. If a shared mutation reaches an already-updated partner, define that exchange's effective tick or a small explicit transaction. Do not rewrite the entire scheduler. If the installed responsibility itself is wrong, repair that supported installation rather than inventing a nearest-defender policy.

## Acceptance and opposing controls

Show the first changed responsibility/request and useful physical consequence. Releasing earlier must be tested against the cost of letting DT_S penetrate; merely getting nearer to Mike is insufficient. Include a legitimate stay-on-double case and a mirror or different front with the same installation meaning. Preserve #251 lifetime and #258 acquired eligibility, and do not reintroduce private engagement/support reads for remote decisions.

No patch is required if neither blocker could safely affect Mike before arrival. In that case close this case precisely and nominate one supported RUN-12 contact/approach question with an existing witness. Pending #256/#264 can affect loaded contact; do not compensate their unresolved law/retention behavior with a release heuristic. Final result: a small justified ownership/release correction, or a clear limit on that hypothesis.

