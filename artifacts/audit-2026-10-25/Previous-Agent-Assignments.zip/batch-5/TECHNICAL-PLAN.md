# Technical plan: turn the audit repairs into believable football

Prepared for Tanner from the deep audit and current GitHub work. This is a proposed next-work package and verification request, not an amendment to the approved repository plan or a claim that pending PRs are accepted.

## 1. Current source and what has actually changed

Latest verified develop during preparation: **50b80062815716b902438f9a7fa227535a255ea0**. It advanced first to30a1f491 through #265/#266 (paired-scout tools/documentation), then to50b80062 through **#267 request-budget consistency**, which is now merged and changes reach/common pursuit code. #264 contact geometry, #260 possession and #256 work-off remain separate pending mechanisms at this snapshot. Fetch again before implementation; an older source-qualified capture is not automatically a current-source reproduction.

The big audit's primary conclusion still holds: preserve role-specific football logic and repair demonstrated information/action/execution interfaces. It did not prove that all higher-level decision problems disappear afterward. Its checkpoint called for returning to the adaptation question after bounded repairs. This cycle does that through COV-7 research and active opposing situations.

Important current results:

| Evidence | Supported conclusion | What it does not establish |
|---|---|---|
| #251 target/action lifetime and #258 acquired blocker eligibility are accepted | Real shared consistency defects have bounded repairs | Target-selection quality, every installed block's information purity, or universal intelligence |
| #261 helper and #266 backside-crack investigations | No demonstrated missed feasible help or installation violation in the nominated windows | All helper priorities/backside assignments are correct; a patch must be manufactured |
| #263 and accepted #267 | Full-effort arrival planning disagreed with reduced-effort native pursuit; #267 models the emitted budget | Solved YAC or a guaranteed physical interception. CI YAC8.15→8.03 has change interval-1.27…+.99 |
| Pending #264 | Remote admission and inconsistent reach meanings require correction | One unchanged scalar span adequately represents standing, layout, retained hold and wrap/control |
| Approach follow-up on #264 | The inspected failure reaches and loads a hold, then slips; tested radius changes do not fix it | All approach selection is sound, or all slips are a grip defect |
| #262/#265 | A queue plus matching ordinary captures now exists | Useful precision/football adjudication is finished. #265's notes/queue integration and first pass were explicitly unfinished |
| #255/panel and #267 handoffs | The operator, actual treatment and activation recipe are available | Reserved P038/P117 independent results are complete merely because data was delivered |

## 2. The objective for this cycle

Converge on three football questions:

1. Can a player acquire and retain a tackle through coherent represented geometry, with legitimate misses and slips?
2. Does the installed C/RG combination give the offense a feasible way to account for the Mike, and is the responsibility actually transferred/executed?
3. Can a corner conditionally help against a run while retaining a meaningful cost for abandoning a live receiver?

Measurin supplies independent pursuit evidence; Integration completes the film-to-diagnosis loop. Success is an explained and repaired mechanism, or a closed hypothesis with its real limitation. It is not another collection of helpers or a matching aggregate score.

## 3. Mandatory independent verification at task start

Every agent receives the following request in its individual brief:

**Before implementing, verify this plan against actual current code and saved evidence. Report confirmed details, corrections to the plan, and unresolved details with the smallest deciding experiment. Correct routine implementation details and continue within the goal. Do not implement a premise simply because the audit, coordinator, or this plan says it.**

Verify:

- Accepted/dependent SHAs and source/settings/runtime identity; what changed since the supplied witness.
- Actual function signatures, call order, caches and responsibility ownership, including later consumers that could undo a local correction.
- Units and origins: yards/seconds/radians; center versus surface/attachment distances; interval-start versus physical endpoint time.
- Actor identity from recorded playerId/team/slot/index tuples. Prior handwritten catcher labels were corrected; file data is authoritative.
- Native restoration and observer neutrality where reused; cross-treatment differences are expected and must not be disguised as failed restoration.
- Which observation/action value was actually consumed and propagated into a command. Retained state, computed-but-overridden values, selected actions and physical results are different evidence levels.

The update can be a short PR/status paragraph. No new tracked ledger, approval ceremony, broad suite rerun or blanket game campaign is required. Ask an owner for a specific missing artifact/interface when necessary. A failed hypothesis changes the plan; it does not justify tuning until a preferred result appears.

## 4. Work package T1 — contact opportunity, retained hold and control

**Owner: Do-It-All!, with Defense/Main Engine/Physics at their existing boundaries.** Audit A07. Medium first slice; pose representation may be a later, harder slice.

### Architecture to verify

Treat these as distinct meanings that must agree geometrically, not necessarily one identical scalar:

- body collision representation;
- hand contact opportunity at a particular pose/time;
- retained attachment span after acquisition;
- grip force capacity and body-wrap/control quality;
- planning regions used for gathering and interception.

Map PhysicalProfile.reach, tackleReach, tackle-window contactQuality, GraspJoint.reach/ground/hold and World.graspPoint. World can use a represented foot/attachment point rather than the target's bare center. Verify the point and its velocity/load Jacobian before declaring a center-distance formula sufficient everywhere.

The new quality call in #264 uses contactQuality(distance, torso, tackleReach(...)). The helper normalizes distance against a body/arm interval. Verify each argument's intended domain and what quantity its output represents. The coordinator reports a substantial quality change at extended contact; neither the old nor the new number is an external football calibration. In particular, distinguish weak wrap control from weak hand grip before using one number for both.

The 1.33×height comment at physical.ts154 concerns standing catch height. It is not itself a validated horizontal center-of-mass-to-fingertip distance. Any laid-out/pivot geometry needs explicit dimensions, reference points and finite pose/body movement.

### Experiment and implementation sequence

1. Preserve the soundly motivated standing/blocked admission repair as an isolated mechanism. Inventory its exact consumers and radius conventions.
2. On an already genuinely acquired contact, isolate retained-span and quality changes using identical full bodies, joints, commands and consumed execution state. Record load, grip/control/capacity, attachment/body distances, slip/break condition, support and World time.
3. Reproduce the reached-and-slipped P013 and successful P012 controls. Keep the failed radius treatments closed unless new evidence identifies a different mechanism.
4. If representation is inadequate, propose one minimal explicit layout/pivot/attachment model. Its geometry, point velocity and force/work interpretation must agree. Actual translation cannot be counted again as a reach bonus, and a future pose cannot grant current contact.
5. Check the 50ms acquisition sampling boundary. A contact possible only between samples is a timing/representation limit, not permission for a wider scalar radius. A substep-aware correction needs the owning physics interface and evidence before expansion.

**Acceptance:** reachable standing and finite diving contacts, unreachable recession, restricted arms, assists/rear contact, transmitted-load-then-slip, possession/attempt retirement, and no repeated success roll per attempt. Preserve a legitimate offensive escape. Diagnose the first changed mechanism; final points/YPC do not decide geometry.

**Stop:** no evidence supports the proposed quality/pose change; an extra constant is restoring old outcomes; or the task becomes an anatomical/World rewrite. Deliver the bounded valid correction and exact missing mechanism instead.

## 5. Work package T2 — C/RG combination to Mike access

**Owner: Run Game.** Audit A08/A09/A12. Medium; native causal investigation with a small repair only if earned.

#266's next factual lead is the current P003 C/RG→LB_M access chain. It is better grounded than revisiting a wide receiver far from the actual tackle. Preserve the two prior negative findings.

Technical sequence:

1. Verify the installation: DT_S first level, named keeper/collector, next-level LB_M responsibility and release conditions. A roster position is not proof of an installed role.
2. Trace pre-decision combo preparation, each actor's entered update, effective plan target/action epoch, observations, raw/final request, actual contact/load and runner/Mike arrival.
3. Identify the earliest bottleneck: recognition/commitment, stale target, shared plan after a partner already decided, physical approach, or a legitimate need to keep the double. The audit's P064 order sensitivity is a hypothesis template, not an assumed cause.
4. Compare retaining the double with a minimal evidence-available transfer. Measure whether the first defender becomes dangerous when released; getting closer to Mike alone is insufficient. A forced transfer can isolate opportunity but cannot become policy without an available cue.
5. If exchange timing is causal, define a local effective tick/transaction. If installation is causal, repair that supported family. Do not replace the engine scheduler or turn blockers into nearest-threat chasers.

**Acceptance:** first responsibility/request difference and useful physical consequence, with a legitimate keep-the-double control and one supported mirror/front transfer. Keep #251/#258 and own-contact versus remote-knowledge boundaries intact. Pending work-off/geometry can affect physical retention; do not compensate unresolved contact with a release heuristic.

**Stop:** neither blocker can safely affect Mike in time, or the call legitimately loses this matchup. Close that case and nominate one supported current RUN-12 witness rather than widening the search until a patch is found.

## 6. Work package T3 — COV-7 disciplined adaptation research/pilot

**Owner: Catching And Defensive Pursuit, coordinated with Coverage/Defense.** Audit A08/A19 and the approved PLAN's named first adaptation test. Medium research/fixtures, followed by an evidence-gated local prototype.

This is the return to Tanner's original intelligence question. Keep the existing brains and test whether a corner can choose a useful temporary contribution without losing his primary duty.

### Research and representability first

Verify current ManCoverage.coverMan/blockingSupport, PASS_FIRST, installed alley/force jobs, existing CoverageJudgment and acquired possession/flight semantics. Read the coaching basis for cue reliability and responsibility. Verify that intended HB-pass, stalk-release and delayed-route controls can actually execute legal football in this engine. An unsupported trick play cannot certify safety; an ordinary pass where the option never activates is only an inactivity control.

### Small decision design

The options are retain man, temporary capped alley support, and emergency chase. Retain the original receiver responsibility and a reacquisition path. Use existing recognition and read/commitment cadence; do not stack another generic delay. Preserve force/cutback duties and the installed cap.

Cases with identical consumed evidence must have the same response until later evidence distinguishes them, with own call/traits fixed. A credible deception is allowed to fool the player. The goal is a defensible risk/cost tradeoff, not perfect run/pass discrimination.

Compare one real support opportunity with at least one active abandonment-cost situation and a valid discipline case. Track cue availability→choice→request→first useful motion, support leverage, pass window/cost, reacquisition and body/contact execution. Keep the original action as a candidate, and preserve action lifetime across option changes.

**First deliverable:** coaching-supported decision account, supported/unsupported scenario inventory and exact active benefit/cost fixtures. Only then implement one smallest role-local option if supported. #260 is a named dependency when its interpretation is used; it must not be silently described as accepted. This is the research phase required by PLAN, not authorization for a shared decision scheduler.

**Stop:** benefit depends on hidden call/holder knowledge, no active cost case exists, the same cues are magically distinguished, or physical execution invalidates the claimed opportunity. Identify that missing evidence/mechanism before enlarging the architecture.

## 7. Work packages T4/T5 — independent evidence and usable film

### T4: Measurin — reserved live-policy transfer

Do not restart measurement infrastructure. #267's actual implementation and activation recipe are delivered. Verify whether P038 SS/P117 FS results already exist; if so publish them. Otherwise complete the preselected independent cases using the existing panel and portable constructors.

Keep baseline and live treatment identity separate, verify active reduced-effort requests nonvacuously, and distinguish the first changed own request on matched body/picture from inherited later context. Report actual runner approach/contact as well as forecast-point arrival. If finishing changes with different execution draws, classify the actual consumed probabilities/draws without rerolling or claiming a whole-play paired-randomness result.

**Completion:** favorable/adverse/unchanged/inactive/missing outcomes and first causal limits for the reserved cases. No new panel, capacity fit, NFL target or automatic scorecard campaign.

### T5: Integration — complete #265's diagnosis loop

Join the eight exact paired recordings to #262 notes/index, with source/settings/input/actor/interval verification and an accessible portable bundle. Keep the historical18-entry queue unavailable rather than relabelling it.

For P006 Y and P007 RG, establish actual owner/rewrite/load and whether useful release is achievable. State mechanism-supported defect, legitimate constraint or the precise unresolved football question. A nearby free defender or an unusual torso is insufficient. Give Tanner at most two short playable ambiguous clips, their competing explanations and the exact question his eyes should answer.

**Completion:** another workspace can fetch/open the same film and generate its trace; the first pass cites actual context; notes and small-sample counts remain honest. No new detector families, standalone app or automated football grade.

## 8. Dependencies and sequencing

| Work | Can start from | Actual dependency | Not a prerequisite |
|---|---|---|---|
| T1 geometry/retention | Exact current source plus separately named #264 treatment | Known point/pose/quality semantics and contact owner | Universal brain; desired YPC |
| T2 combo access | Accepted P003 capture/source | Installation, allowed cues and safe release opportunity | All G5 physics perfect; new helper policy |
| T3 adaptation research | Coaching + current coverage code | Representable active deception/cost and acquired-information semantics for runtime claims | Common chooser; global latency rewrite |
| T4 transfer | Delivered #267 source/inputs | Actual activation and correctly qualified source composition | Another measurement framework |
| T5 film loop | Accepted paired producer/index | Fetchable matching bytes and actual context | More detectors or a new UI application |

Prepare research/data now. Keep normally three football implementation lanes and explicit shared ownership. Pairing pending behavior changes is a distinct identified experiment after their individual mechanisms are understood; importing every pending branch is not a neutral baseline. Use a small decisive composed case before a broad campaign. The existing coordinator retains merging; no merge chores are assigned here.

## 9. Position of the original A01–A21 roadmap

| Audit package | Current disposition |
|---|---|
| A01 evidence validity | Guard/CI/report repairs delivered; keep their contracts |
| A02 gap evidence | Existing source-qualified entries only; no new workboard |
| A03 film scouts | T5 finishes usability; precision remains a measured question |
| A04 command trace | Delivered; preserve owner/clock/provenance semantics |
| A05 knowledge | #258 accepted; #260 remains a bounded pending interpretation, not full vision/attention validation |
| A06 movement/turn transitions | Accepted #267 addresses effort consistency; coverage toggles, forecast and steering remain separate |
| A07 contact geometry | T1; admission, pose, retention and control require explicit verification |
| A08 adaptation | Prior helper hypothesis weakened/closed; named COV-7 research is T3 |
| A09 shared architecture | #251 earned action lifetime; common chooser remains conditional |
| A10 causal experiments | Capture/restaging delivered; use them to make football progress |
| A11 traits/lineup | Lineup identity delivered; leadBlock execution truthfulness remains a later cheap verified slice |
| A12 installation | T2 verifies a real installed responsibility; broader supported families remain bounded future work |
| A13 protection family | Later; assignment preparation need not await every physics repair |
| A14 angular law | Retain the bounded correctness issue; it is not the proven cause of the selected turns/slips |
| A15 measurement | Reuse #255/panel; T4 supplies active independent evidence; capacity remains unresolved |
| A16 performance | Same-workload optimizations only; avoid multiplying speculative previews |
| A17 RNG | Canonical construction accepted; actor/purpose isolation is conditional. #267's draw shift is a real comparison limit, not proof of biased randomness |
| A18 adversarial tests | Active opposing cases now; broad exploit search later |
| A19 attention/communication | Use existing cadence/provenance; richer cognition requires a residual demonstrated need |
| A20 expansion | Wider features/league remain outside this cycle |
| A21 learned/anatomical expansion | Parked; one reduced pose/point question is not authority for a full solver/program |

The next checkpoint asks whether a real mechanism improved across its opposing case, whether the player kept/retired an understandable duty, and whether Tanner received a shorter useful film decision. If these local systems cannot express the same necessary tradeoff across roles after their inputs/execution are sound, that earns reconsideration of the common decision architecture. Merely accumulating more conditional code does not.

