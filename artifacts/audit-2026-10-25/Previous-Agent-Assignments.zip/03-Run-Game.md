# Run Game: Make equivalent lineup inputs produce the same experiment

Paste the following brief into **Run Game**. It has not been sent automatically.

---

Suggested branch: tools/F1-stable-lineup-order.
Suggested title: [F1] Canonicalize lineup construction for reproducible experiments.

Repository: tannerthardy/football-simulation-. Fetch current develop and record its SHA; read AGENTS.md, docs/PLAN.md, docs/GAPS.md and CLAUDE.md. The audit experiments used c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0; last checked develop ccdb69cba81e07c578f607ff1bf8ce0efe2edc68 changes documentation only. Verify current behavior before fixing it.

Use an isolated branch, one focused PR into develop, and the supported Node version. Preserve existing work and coordinate shared-source edits with the current owning lane. Use focused checks first, followed by the existing plan's applicable verification tier; do not invent another mandatory campaign. Keep raw output in ignored out/. No merge, unrelated cleanup, new framework or default-off feature flag. Do not change approved priorities, metric targets or historical evidence. If the issue is already fixed, verify that and stop.

This is an experiment-identity task despite this chat’s name. Do not change run-fit or blocking policy.

Problem: PlaySim constructs actors from Object.entries(setup.offense/defense) in src/sim/playsim.ts. The same slot→player mapping in a different insertion order changes initialization and random-consumer order. In 18 audit paired comparisons across Inside Zone/Hitches and three seeds, all reordered inputs developed different physical trajectories. A first-cause example changed RG’s overset draw and initial request with only offense record order reversed. Canonicalized controls were identical. Exact identical-serialization determinism already works; no distributional bias was demonstrated.

Deliver one declared stable slot ordering at the common construction/input boundary. Reuse the project's actual slot conventions. Preserve normal caller ordering where possible; do not alphabetically sort just because it is convenient. Handle optional slots without dropping/reassigning players; reject unsupported identities explicitly if required by the existing contract. Keep actual personnel and call differences meaningful.

Checks compare by stable player/slot identity: ordinary, offense-reversed, defense-reversed, both-reversed inputs; at least a run and pass; unchanged repeated input; a true player substitution. Compare initialization, raw requests, events and a short physical continuation. Report any intentional change to standard callers separately from invariance under meaningless reordering.

Stop if this expands into a whole-engine RNG rewrite. Stable per-event random streams are a different task. The goal is that object property order is not an accidental football variable.

Coordinate with the later command-trace job before either edits playsim.ts. Done: a small normalization contract and demonstrated invariance, with ordinary execution changes honestly disclosed.

