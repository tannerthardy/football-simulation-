# Do-It-All! — make the approach reach a genuine tackle opportunity

Paste-ready subsequent work. No external chat was messaged automatically.

Branch: defense/G10-reachable-tackle-approach. Priority: high after the bounded geometry candidate. Effort: medium; begin with one approach family.

Read current AGENTS.md, CLAUDE.md, PLAN/GAPS and the named problem. Fetch develop and record its full SHA; preparation observed cac9e1000b27e9222d47a23db6ebdf65eaac25f9. This is the next development/research task, not a review/merge assignment. Use the named isolated branch, preserve existing work, state exact accepted versus pending dependencies, and coordinate the specific shared interface with its owner. Use the smallest discriminating evidence first, then existing verification tiers. Raw artifacts stay in ignored out/. Retain failed treatments and opposing controls. No arbitrary parameter/band changes or general decision framework are implied.

#264 (6eb21c86) proposes physically bounded grasp admission and finite dive acquisition. It is still pending; do not label it accepted source. Its contact/retention geometry, changed ordinary QB ending and strongly adverse card are explicit evidence. Its32-step/29-play prefix has zero acquired dive holds. That is a selection/arrival question to test, not a reason to restore remote holds.

First compare the free pursuit/gather stopping and arrival regions with the actual center-to-hand + target-surface opportunity declared by #264. Current policy radii still use both body radii plus fractions of own reach. Reaching one of those regions is not necessarily reaching an admissible hand contact.

Take one exact ordinary failed finish and one successful reachable contact. Trace observed target, actually requested approach, physical separation/relative velocity, available own arm, admission boundary and first real contact opportunity. Compare a minimal approach using the real contact span against the current policy through unchanged World. Start with free pursuit/gather; leave blocked technique and point-ball catch geometry with their owners.

If earlier lunge/dive selection is necessary, base the decision on acquired motion and a demonstrated finite reachable opportunity. Test the attempted body motion against a receding runner and a runner whose actual slowing creates a chance. Neither repeated success rolls nor an unrepresented limb extension can make contact exist. A failed dive and its fall/recovery cost must remain possible.

Acceptance: an actually reachable approach can enter the real envelope and transmit a legitimate hold; an unreachable runner remains unreachable; front/side/rear and successful gather controls survive. Separate the request change from the acquisition change at the first differing interval. Preserve #264's seeded finite dive and slip controls. Do not require old final-yardage/engagement outcomes.

Coordinate common.ts/request budget with Catching, who owns the effort-consistent estimator. Begin with separate geometry/effort arms before any composition, preserving #260/#256 when actually present. Done: one mechanically supported approach correction or a localized finding that the remaining representation cannot express the opportunity. No global pursuit rewrite, capacity retune or anatomy expansion.

