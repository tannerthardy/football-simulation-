# Run Game — resolve the remaining backside-crack assignment

Paste-ready subsequent work. No external chat was messaged automatically.

Branch: run/G2-backside-crack-responsibility. Problem: RUN-12 leftovers. Effort: small-to-medium, football evidence dependent.

Read current AGENTS.md, CLAUDE.md, PLAN/GAPS and the named problem. Fetch develop and record its full SHA; preparation observed cac9e1000b27e9222d47a23db6ebdf65eaac25f9. This is the next development/research task, not a review/merge assignment. Use the named isolated branch, preserve existing work, state exact accepted versus pending dependencies, and coordinate the specific shared interface with its owner. Use the smallest discriminating evidence first, then existing verification tiers. Raw artifacts stay in ignored out/. Retain failed treatments and opposing controls. No arbitrary parameter/band changes or general decision framework are implied.

#261 (d63db47f) is merged and found no missed feasible work in the nominated helper windows. Keep its negative finding and nearer-teammate policy. Do not reopen the same search or force an adaptation change because the synthetic audit panel changed targets.

Move to the existing RUN-12 backside-crack question. The historical note says a playside-only trial reduced backside box stalks14→8 but was not adopted. That is a lead, not proof that every backside crack is wrong: cracks, reverses, cutback support and concept-specific exchanges can be legitimate.

Recover one current ordinary case where a receiver cracks into the box from the back side. Identify the installed concept, receiver role, run direction, intended defender, release/assignment rule and retained perimeter or cutback threat. Establish whether the assignment contradicts that installation or merely looks surprising. Use football/coaching evidence for the rule; do not fit a field-side threshold to one clip.

If a defect is demonstrated, repair the assignment/eligibility condition for the supported concept family. Preserve legitimate playside crack, a valid backside/cutback assignment, mirrors, actual motion and detached/inline role differences. Do not silently turn a named stalk into a new arc/insert concept.

Acceptance: exact case reproduction; first incorrect assignment/command; corrected ordinary finite execution; active opposing and mirrored controls; unchanged helper/target-lifetime/acquired-eligibility contracts. Show what defender/threat the receiver protects before and after, not just lower rush yards. If the existing crack is valid football or no failed assignment is established, close that hypothesis and report the next supported RUN-12 witness.

Coordinate blocking/installation ownership with Run/Main Engine. Contact retention and #256's work-off belong to their existing owners. Done: a small concept-supported responsibility correction, or a defensible negative finding. No new general blocker adaptation policy or arbitrary playside-only rule.

