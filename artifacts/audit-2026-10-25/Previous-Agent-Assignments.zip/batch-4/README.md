# Next work after #261–#264

Prepared from current GitHub evidence. develop was cac9e1000b27e9222d47a23db6ebdf65eaac25f9. Read current GAPS, PR261–264 bodies and relevant comments/portable handoffs, plus current pursuit source. Production code and approved plans are unchanged by this preparation.

## What the results change

- #261 is a supported sampled negative finding: retain the helper priority. No demonstrated missed feasible opportunity was found. Run Game should move on to a named RUN-12 leftover.
- #263 isolates a real effort contract mismatch: full-effort scalar prediction versus .84184 native effort in the example. Its attribution reaches the forecast point but does not prove runner contact. The next actual repair is estimate/request consistency, with active transfer.
- #262 implements a queue but has zero matched recordings for its historical sample; all18 entries remain uncertain. The next useful tools deliverable is the matching recording, not more queues.
- #264 proposes finite contact admission and bounded hold geometry, remains pending, and reports strongly adverse finishing. Its policy arrival distances remain distinct from actual reach. The next experiment must inspect real contact opportunity without restoring remote holds.
- #260 possession and #256 engaged work-off remain separate pending work. Their eventual compositions must be identified explicitly. #255 measurement tooling is also open. These statuses are evidence of availability, not implementation endorsements.

## Tasks

| Chat | Work | Completion |
|---|---|---|
| Catching And Defensive Pursuit | Effort-consistent interception | Estimator uses the actual request budget; useful/opposing native evidence |
| Do-It-All! | Approach within physical tackle reach | Finite approach produces real opportunities; unreachable misses remain |
| Run Game | RUN-12 backside-crack responsibility | Correct a demonstrated concept/assignment mismatch or close it honestly |
| Integration | Matched scout/replay/capture production | Six usable clips with actual context and portable reproduction |
| Measurin | Independent active transfer | Locked unfamiliar cases; actual treatment and honest benefit/adverse limits |

Catching owns movement-budget consistency; Do-It-All owns contact-span semantics. They coordinate one shared approach interface and isolate the two factors before composing them. Run Game leaves the helper predicate alone. Integration repairs evidence delivery. Measurin supplies independent activation/transfer evidence.

These are bounded development jobs. Review/merge chores and broad new test campaigns are not assignments. Pending parent dependencies remain named; an existing worker's branch is never reset or silently imported as accepted trunk. Current lane limits and research/adoption boundaries remain in effect.

