# Measurin — independently test active pursuit transfer with the existing panel

Paste-ready subsequent work. No external chat was messaged automatically.

Branch: tools/F1-pursuit-active-transfer. Effort: small-to-medium measurement/experiment support.

Read current AGENTS.md, CLAUDE.md, PLAN/GAPS and the named problem. Fetch develop and record its full SHA; preparation observed cac9e1000b27e9222d47a23db6ebdf65eaac25f9. This is the next development/research task, not a review/merge assignment. Use the named isolated branch, preserve existing work, state exact accepted versus pending dependencies, and coordinate the specific shared interface with its owner. Use the smallest discriminating evidence first, then existing verification tiers. Raw artifacts stay in ignored out/. Retain failed treatments and opposing controls. No arbitrary parameter/band changes or general decision framework are implied.

The #263 fixture/export is now delivered and merged. It already runs the published b7e12948 movement-window panel:44 expected responses,41 complete,3 intentionally inactive gather arms missing, plus one filtered-operator rejection. Do not repeat the old claim that treatment data is wholly absent or rebuild the panel. The remaining gap is independent active native transfer of an actual effort-consistent policy.

Freeze at least two unfamiliar native pursuit cases before examining Catching's new treatment: one fast crossing/escaping case and one stop/reversal or sideline case. Use existing source-pinned capture tools and record exact actor, observation window, source/settings/input and activation condition. Preserve the P012 gather and coverage/contact controls as inactivity/opposing controls, not generalization wins.

Obtain the actual baseline/treatment traces from Catching's effort-consistent implementation. Keep isolated held/re-seek responses separate from live reacting full-play continuations. Report estimator budget versus emitted effort, time/slack, sampled versus biased/shaded goal, actual approach/arrival error, body versus travel change, speed loss and real contact exposure. A point-radius entry is not a tackle, and later yardage/fumble changes can come from another player.

Use the current native/tracking-style operators and complete-case/unknown rules. Verify that the treatment really executes in each claimed active transfer. Keep missing/rejected/partial trials in the manifest. Report adverse, unchanged and beneficial intermediate effects without selecting windows after seeing outcomes.

Done: a compact independent transfer table and a supported conclusion on scope. If the policy has no active independent transfer or only reaches forecast points that miss the runner, state that clearly. The verdict can narrow or reject the treatment; capacity fitting and new NFL targets are outside this slice.

Use the portable input parts/reproduction instructions on #263 and existing panel code rather than a new workspace-specific pipeline. Coordinate interface fields with Catching; Do-It-All's contact-span treatment is a separate factor until an explicitly pinned composition is tested.

