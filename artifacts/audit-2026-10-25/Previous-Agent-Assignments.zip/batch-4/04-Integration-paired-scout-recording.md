# Integration — deliver film alerts with the recordings needed to judge them

Paste-ready subsequent work. No external chat was messaged automatically.

Branch: tools/F1-paired-scout-recording. Problem: PERF-5 / VIEW-1. Effort: small-to-medium tooling slice.

Read current AGENTS.md, CLAUDE.md, PLAN/GAPS and the named problem. Fetch develop and record its full SHA; preparation observed cac9e1000b27e9222d47a23db6ebdf65eaac25f9. This is the next development/research task, not a review/merge assignment. Use the named isolated branch, preserve existing work, state exact accepted versus pending dependencies, and coordinate the specific shared interface with its owner. Use the smallest discriminating evidence first, then existing verification tiers. Raw artifacts stay in ignored out/. Retain failed treatments and opposing controls. No arbitrary parameter/band changes or general decision framework are implied.

#262 (e71be0dd) is merged. Its queue consumer is implemented, but all12 sampled alerts and6 control windows remain uncertain because the historical scorecard artifact has no matched replay/trace. Tanner's shortlist is empty. Another index or detector category will not resolve that missing producer-side evidence.

Close the alert-to-recording join. Inspect the requests for already-recorded material first. If the historical recordings are absent, preserve that historical queue as unavailable and use one new short ordinary source-pinned recording with existing scouts and exact constructor capture together. A seed/play label alone must not be called a historical restoration.

Persist matching source/settings/input, official play identity, stable actor, interval and scout event alongside the existing replay and a constructor input from which selected traces can be regenerated. Compose existing observer hooks without extra perception/RNG/physics evaluations. Save a small bounded set of episodes and controls; do not retain a permanent all-player telemetry campaign.

Create one portable bundle using existing standalone film, Copy reference, command trace and queue formats. A second workspace must be able to unpack it, verify identities, open the same replay and generate its selected trace without private paths or an inaccessible hash. Keep bytes/checksums in ignored output or an existing accessible artifact channel, not Git raw dumps.

Acceptance: at least six source-matched playable episodes spanning several existing scouts, plus legitimate controls; agent first-pass classifications based on actual context; a concise shortlist only where football judgment remains unresolved. Flag unknowns honestly. Show observer-off/on equality for the recorded source. Keep the old18 historical dispositions unchanged; new cases are a new declared sample, not fresh labels for the lost cohort.

Done: usable clips and evidence, not merely technically working sampling. Precision remains descriptive with small labelled samples; unreviewed/uncertain alerts are not confirmed defects. No automatic football grade, new viewer application or engine tuning to erase alerts.

