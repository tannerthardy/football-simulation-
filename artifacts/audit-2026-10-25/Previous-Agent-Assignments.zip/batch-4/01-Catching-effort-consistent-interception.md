# Catching And Defensive Pursuit — make interception estimates match requested effort

Paste-ready subsequent work. No external chat was messaged automatically.

Branch: defense/G1-effort-consistent-interception. Priority: highest direct pursuit repair. Effort: small-to-medium implementation plus active transfer.

Read current AGENTS.md, CLAUDE.md, PLAN/GAPS and the named problem. Fetch develop and record its full SHA; preparation observed cac9e1000b27e9222d47a23db6ebdf65eaac25f9. This is the next development/research task, not a review/merge assignment. Use the named isolated branch, preserve existing work, state exact accepted versus pending dependencies, and coordinate the specific shared interface with its owner. Use the smallest discriminating evidence first, then existing verification tiers. Raw artifacts stay in ignored out/. Retain failed treatments and opposing controls. No arbitrary parameter/band changes or general decision framework are implied.

#263 (cb7c1d89) is merged and establishes a concrete request/estimate mismatch. Both native P002 decisions use full-effort scalar arrival estimates while chase actually requests .84184 effort /7.830yd/s rather than its full9.301yd/s request. An isolated effort-attribution arm reaches the late forecast point, but not the recorded runner. Forecast error and transverse redirection remain separate. Reuse the delivered checksum-verified fixture and controls, not another duplicate audit.

Implement an interception estimate based on the request that will actually execute: its effort/speed budget and applicable movement assumptions. Determine how effort affects both desired velocity and available propulsion; reducing vmax alone is not automatically the correct physical model. Preserve deliberate distant-pursuit work-rate behavior rather than giving every defender full effort. Close gathering, existing cadence, time-bias/leverage, around-body navigation and contact retain their own semantics.

Keep the chosen sampled interception separate from the later biased/shaded steering point. If the latter was not checked, label it not-evaluated rather than inheriting a feasibility certificate. No estimate is a physical guarantee. Preserve fallback status when no sampled candidate passes the model.

Acceptance: estimator and emitted request agree on effort/budget; full-effort controls retain appropriate behavior; the near/far effort boundary has explicit cases; close gather remains a bypass; transverse/faster-crossing/escaping cases retain failures honestly. Compare actual finite World response and capture/arrival error, not just returned times. Test at least two fresh active native transfers selected before choosing a preferred treatment. Final gain or forecast-point arrival alone cannot certify a useful tackle.

Do-It-All owns approach-to-contact span under TKL-5. Agree one shared request/geometry interface; isolate effort and contact-span treatments before testing their composition. Preserve INFO-1's acquired-target exclusion. Done: a narrow consistent planning/execution contract and source-qualified native evidence, with no global yaw/brake/speed boost or persistence timer.

