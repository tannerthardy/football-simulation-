import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Rng} from '../../src/core/rng.js';
import {PlaySim} from '../../src/sim/playsim.js';
import {ScoutingReport} from '../../src/sim/recognition.js';
import {CoverageScouting} from '../../src/sim/qbmind.js';
const evidence=process.env.AUDIT_ARCHITECTURE_DIR??'/workspace/audit-deep/evidence/architecture';
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
function revive(_k:string,v:any):any{if(v?.__type){const{__type,...p}=v;if(__type==='Map')return new Map(v.entries);if(__type==='Set')return new Set(v.entries);const c:any={Rng,ScoutingReport,CoverageScouting}[__type];if(c)return Object.assign(Object.create(c.prototype),p);}if(v?.__number)return Number(v.__number);return v;}
function run(mode:string){
 const setup=JSON.parse(readFileSync(`${evidence}/G1-P019-setup.json`,'utf8'),revive);const sim=new PlaySim(setup),target=sim.slot('LB_W')!;
 const frames:any[]=[];let fork:string|null=null;const oldStep=sim.world.step.bind(sim.world),oldTick=sim.tick.bind(sim);let raw:any;
 const wrapped=new WeakSet();
 sim.tick=()=>{const b=target.behavior as any;if(!wrapped.has(b)){wrapped.add(b);const update=b.update.bind(b);b.update=(...args:any[])=>{const cmd=update(...args);if(args[0]===target)raw=structuredClone(cmd);return cmd;};}oldTick();};
 sim.world.step=(intents:any,dt:number)=>{
  let applied:any=null;const initial=structuredClone(intents[target.idx]);
  const active=sim.t>=4.05-1e-7&&sim.t<4.45-1e-7&&!!target.engagement;
  if(active){fork??=hash({t:sim.t,bodies:sim.agents.map(a=>a.body),intents,rng:sim.rng,events:sim.events});
   if(mode==='pursuit-facing'){intents[target.idx]={...intents[target.idx],facing:raw.facing??Math.atan2(raw.vel.y,raw.vel.x)};applied=intents[target.idx].facing;}
   if(mode==='no-hand-force')for(const j of sim.world.joints)if(j.kind==='hands'&&(j.a===target.body||j.b===target.body)){j.push=j.hold=j.steer=0;}
  }
  const pre={pos:{...target.pos},vel:{...target.vel},facing:target.facing};
  const r=oldStep(intents,dt);const c=sim.carrier;
  if(sim.t>=3.75&&sim.t<=4.9)frames.push({t:sim.t,raw,initial,final:structuredClone(intents[target.idx]),applied,pre,post:{pos:{...target.pos},vel:{...target.vel},facing:target.facing,state:target.body.support?.state},engagement:target.engagement?{blocker:target.engagement.blocker.slot,control:target.engagement.control,win:target.engagement.win}:null,runner:c?{slot:c.slot,pos:{...c.pos},gap:Math.hypot(c.pos.x-target.pos.x,c.pos.y-target.pos.y),facingError:Math.abs(Math.atan2(Math.sin(Math.atan2(c.pos.y-target.pos.y,c.pos.x-target.pos.x)-target.facing),Math.cos(Math.atan2(c.pos.y-target.pos.y,c.pos.x-target.pos.x)-target.facing)))}:null,hands:sim.world.joints.filter((j:any)=>j.kind==='hands'&&(j.a===target.body||j.b===target.body)).map((j:any)=>({normalForce:j.normalForce,tangentForce:j.tangentForce,extension:j.extension}))});
  return r;
 };
 const result=sim.run();return {mode,fork,frames,result:{outcome:result.outcome,yards:result.yards,duration:result.duration,events:result.events}};
}
const rows=['native','pursuit-facing','no-hand-force'].map(run);const native=JSON.parse(readFileSync(`${evidence}/ordinary-census.json`,'utf8')).plays.find((x:any)=>x.id==='G1-P019');
const neutral=JSON.stringify(rows[0].result)===JSON.stringify(native.result);const equalPrefixes=rows.slice(1).map(r=>({mode:r.mode,equal:r.fork===rows[0].fork}));
writeFileSync('out/forensic-contact/blocked-facing.json',JSON.stringify({neutral,equalPrefixes,note:'Native P019 LB_W. At4.05–4.40 under engagement, pursuit-facing changes only final desired facing to raw pursue command direction (other fields/physics retained). No-hand-force preserves all commands and engagement but zeros hand force capacities touching LB; torso contacts remain. Neither is proposed fix. Tests which mechanism creates away-facing posture.',rows}));
console.log(JSON.stringify({neutral,equalPrefixes,rows:rows.map(r=>({mode:r.mode,result:{outcome:r.result.outcome,yards:r.result.yards},frames:r.frames.filter(f=>[4.05,4.25,4.4,4.5].some(t=>Math.abs(t-f.t)<1e-6))}))},null,2));
