import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Rng} from '../../src/core/rng.js';
import {PlaySim} from '../../src/sim/playsim.js';
import {ScoutingReport} from '../../src/sim/recognition.js';
import {CoverageScouting} from '../../src/sim/qbmind.js';
const evidence=process.env.AUDIT_ARCHITECTURE_DIR??'/workspace/audit-deep/evidence/architecture';
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
function revive(_k:string,v:any):any{if(v?.__type){const{__type,...p}=v;if(__type==='Map')return new Map(v.entries);if(__type==='Set')return new Set(v.entries);const c:any={Rng,ScoutingReport,CoverageScouting}[__type];if(c)return Object.assign(Object.create(c.prototype),p);}if(v?.__number)return Number(v.__number);return v;}
function run(removeTarget:string|null){
 const setup=JSON.parse(readFileSync(`${evidence}/G1-P048-setup.json`,'utf8'),revive);
 const sim=new PlaySim(setup);const frames:any[]=[];let intervention:any=null;const before:Record<string,string>={};const seen=new WeakSet();const contacts:any[]=[];
 const nativeTick=sim.tick.bind(sim);
 sim.tick=()=>{
  nativeTick();
  for(const j of sim.world.joints)if(j.kind==='grasp'&&j.origin==='dive'&&!seen.has(j)){
   seen.add(j);const holder=sim.agents.find(a=>a.body===j.a)!,target=sim.agents.find(a=>a.body===j.b)!;
   const token=`${holder.slot}->${target.slot}`;
   before[token]=hash({t:sim.t,bodies:sim.agents.map(a=>a.body),intents:sim.intents,rng:sim.rng,events:sim.events});
   contacts.push({token,t:sim.t,worldTime:sim.world.time,hash:before[token],distance:Math.hypot(j.a.pos.x-j.b.pos.x,j.a.pos.y-j.b.pos.y),reach:j.reach});
   if(token===removeTarget&&!intervention){
    intervention=contacts.at(-1);
    sim.world.joints=sim.world.joints.filter(x=>x!==j);
    const b=sim.bond!;b.tacklers=b.tacklers.filter(a=>a!==holder);b.holds?.delete(holder);b.grip?.delete(holder);b.control?.delete(holder);b.execution?.delete(holder);if(b.tacklers.length===0)sim.bond=null;
   }
  }
  frames.push({t:sim.t,worldTime:sim.world.time,ball:sim.ball.kind,carrier:sim.carrier?.slot,throwAt:sim.throwAt,agents:sim.agents.filter(a=>['QB','DE_W','SS','Y'].includes(a.slot)).map(a=>({slot:a.slot,pos:{...a.pos},vel:{...a.vel},facing:a.facing,support:structuredClone(a.body.support)})),intents:sim.agents.filter(a=>['QB','DE_W','SS','Y'].includes(a.slot)).map(a=>({slot:a.slot,...structuredClone(sim.intents[a.idx])})),events:sim.events.filter(e=>Math.abs(e.t-(sim.t-sim.dt))<1e-5)});
 };
 const result=sim.run();return {removeTarget,intervention,contacts,frames,result:{outcome:result.outcome,yards:result.yards,duration:result.duration,events:result.events}};
}
const rows=[run(null),run('DE_W->QB'),run('SS->Y')];
const native=JSON.parse(readFileSync(`${evidence}/ordinary-census.json`,'utf8')).plays.find((p:any)=>p.id==='G1-P048');
const neutral=JSON.stringify(rows[0].result)===JSON.stringify(native.result);
const prefixEqual=rows.slice(1).map(r=>({target:r.removeTarget,identical:rows[0].contacts.find((c:any)=>c.token===r.removeTarget)?.hash===r.intervention?.hash}));
writeFileSync('out/forensic-contact/native-dive.json',JSON.stringify({sha:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',neutral,prefixEqual,note:'Remove only selected just-created dive grip/bond membership after native tryTackles has consumed its RNG and queued the original dive. No RNG changed at intervention; subsequent replanning remains live and can diverge. Immediate force/support comparison is causal; final yardage is not assigned solely to grip.',rows}));
console.log(JSON.stringify({neutral,prefixEqual,rows:rows.map(r=>({removeTarget:r.removeTarget,intervention:r.intervention,result:r.result,falls:r.frames.flatMap(f=>f.agents.filter((a:any)=>a.support?.state==='falling'&&(a.slot==='QB'||a.slot==='Y')).map((a:any)=>({t:f.t,slot:a.slot,cause:a.support.cause,carrier:f.carrier,ball:f.ball,throwAt:f.throwAt}))).slice(0,12)}))},null,2));
