import {writeFileSync} from 'node:fs';
import {stage} from './acquisition.js';
const rows=[];
for(const defender of ['FS','DE_S','DT_S'])for(const speed of [3,5,7])for(const sep of [1.7,2.5,4])for(const hold of [true,false])rows.push(stage('QB',1,0,'dive',hold,speed,sep,defender));
writeFileSync('out/forensic-contact/dives.json',JSON.stringify({description:'Bounded 27-cell geometry/control panel, paired hold/remove-hold with successful dive execution forced. No inference of frequency.',rows},null,2));
console.log(JSON.stringify(rows.filter(r=>r.fallAt!==null).map(({defenderSlot,speed,separating,keepHold,fallAt,outcome,gap,layoutProxy})=>({defenderSlot,speed,separating,keepHold,fallAt,outcome,gap,layoutProxy})),null,2));
