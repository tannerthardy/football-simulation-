import {writeFileSync} from 'node:fs';
import {redirect,approachTackle} from '../../src/lab/scenarios.js';
import {World} from '../../src/physics/world.js';
const proto=World.prototype as any, originalPair=proto.pairImpulse,originalStep=proto.step;
let stats:any;
proto.pairImpulse=function(...a:any[]) {
 const [i,j,x,y,,kind,,,ai=0,aj=0]=a,b=this.bodies[i],c=this.bodies[j];
 const m=(c.pos.x-b.pos.x)*y-(c.pos.y-b.pos.y)*x+ai+aj;
 const f=originalPair.apply(this,a);if(stats){stats.net[kind]=(stats.net[kind]??0)+m*f;stats.tick[kind]=(stats.tick[kind]??0)+m*f;}return f;
};
proto.step=function(...args:any[]){if(stats)stats.tick={};const r=originalStep.apply(this,args);if(stats){stats.steps++;for(const [k,v]of Object.entries(stats.tick)){stats.absTicks[k]=(stats.absTicks[k]??0)+Math.abs(v as number);}stats.maxResidual=Math.max(stats.maxResidual,Math.abs(r.work.residual));stats.maxSpin=Math.max(stats.maxSpin,...this.bodies.map((b:any)=>Math.abs(b.spin??0)));stats.contactTicks+=r.contacts.length>0?1:0;}return r;};
const rows=[];
for(const mode of ['center','patch'] as const)for(const substeps of [12,48])for(const seed of [3,7,11])for(const side of [-1,1] as const)for(const rusherPower of [.7,1.4]) {
 stats={net:{},tick:{},absTicks:{},steps:0,maxResidual:0,maxSpin:0,contactTicks:0};
 const result=redirect({seed,side,rusherPower,handContact:mode,substeps,maxT:3});const {tick,...measure}=stats;rows.push({kind:'redirect',mode,substeps,seed,side,rusherPower,result,measure});
}
for(const mode of ['center','patch'] as const)for(const substeps of [12,48])for(const side of [-1,1] as const)for(const bearing of [0,90,180]){
 stats={net:{},tick:{},absTicks:{},steps:0,maxResidual:0,maxSpin:0,contactTicks:0};
 const result=approachTackle({seed:7,side,bearing,speed:6,handContact:mode,substeps,maxT:3});const {tick,...measure}=stats;rows.push({kind:'tackle',mode,substeps,seed:7,side,bearing,result,measure});
}
proto.pairImpulse=originalPair;proto.step=originalStep;
writeFileSync('out/forensic-contact/law-transfer.json',JSON.stringify({sha:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',note:'Contact mode is a bundled physical intervention, not only missing torque. Same fixture/controller/seed. 48 steps is convergence comparison, not truth. Native current defaults otherwise retained.',rows},null,2));
console.log('rows',rows.length);
