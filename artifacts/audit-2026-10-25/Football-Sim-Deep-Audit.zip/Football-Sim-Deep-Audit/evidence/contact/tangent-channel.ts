import {writeFileSync} from 'node:fs';
import {World} from '../../src/physics/world.js';
import {supportParams} from '../../src/physics/support.js';
import type {Body} from '../../src/physics/kinematics.js';
const proto=World.prototype as any, jointRows=proto.jointRows;
let mode:'native'|'tangent-coupled'='native';
proto.jointRows=function(...args:any[]){const rows=jointRows.apply(this,args);if(mode==='tangent-coupled')for(const r of rows){if(r.joint.kind!=='hands')continue;const a=this.bodies[r.i],b=this.bodies[r.j],D=(b.pos.x-a.pos.x)*r.nx+(b.pos.y-a.pos.y)*r.ny,rad=a.profile.radius+b.profile.radius;r.ri=D*a.profile.radius/rad;r.rj=D*b.profile.radius/rad;r.mt=1/(1/a.profile.massKg+1/b.profile.massKg+r.ri*r.ri/supportParams(a.profile).yawInertia+r.rj*r.rj/supportParams(b.profile).yawInertia);}return rows;};
const body=(mass:number,x:number):Body=>({pos:{x,y:0},vel:{x:0,y:0},facing:x===0?0:Math.PI,spin:0,energy:1,profile:{massKg:mass,radius:.3,reach:1,heightYd:2.05,vmax:9,tau:1.3,brake:6,lateral:6,turnRate:8,backpedal:.6,shuffle:.55,maxCatchHeight:3,reactReach:2.6,reactionTime:.25,power:mass,balance:.5,stepSpeed:3.4,getUp:.9}});
const rows=[];
for(const requestedMode of ['native','tangent-coupled']as const)for(const substeps of [12,48])for(const side of [-1,1])for(const free of [false,true]){
 mode=requestedMode;const bs=[body(100,0),body(80,.9)],w=new World(bs,{substeps});if(free){bs[0].vel={x:.7,y:0};bs[1].vel={x:.7,y:side*2};}
 w.joints.push({kind:'hands',a:bs[0],b:bs[1],extension:.9,push:0,hold:0,steer:100});
 const intents=free?bs.map(()=>({vel:{x:0,y:0},free:true})):[{vel:{x:0,y:side*1.5},facing:0,push:1,posture:.7},{vel:{x:0,y:0},facing:Math.PI,push:1,posture:.7}];
 const frames=[];for(let k=0;k<(free?1:10);k++){const r=w.step(intents,.05);frames.push({t:w.time,bodies:structuredClone(bs),energyResidual:r.work.residual,groundYawImpulse:r.groundYawImpulse,groundImpulse:r.groundImpulse});}
 rows.push({requestedMode,substeps,side,free,frames});
}
proto.jointRows=jointRows;
writeFileSync('out/forensic-contact/tangent-channel.json',JSON.stringify({note:'Single-channel diagnostic surrogate: add common-point tangential angular Jacobian and effective mass to hand rows only, retaining all center defaults, normal laws, constraints, movement, requests, and ground yaw. Not a production candidate: full finite-force midpoint/angular transport is not implemented. Grounded scenario has no normal hand force or torso contacts; passive case is control.',rows}));
console.log(rows.filter(r=>r.side===1).map(r=>({mode:r.requestedMode,substeps:r.substeps,free:r.free,end:r.frames.at(-1)?.bodies.map(b=>({pos:b.pos,vel:b.vel,facing:b.facing,spin:b.spin,state:b.support?.state})),maxResidual:Math.max(...r.frames.map(f=>Math.abs(f.energyResidual)))})));
