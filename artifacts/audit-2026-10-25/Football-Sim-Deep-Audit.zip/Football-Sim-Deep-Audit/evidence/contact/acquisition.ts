import {writeFileSync} from 'node:fs';
import {Rng} from '../../src/core/rng.js';
import {CENTER_Y} from '../../src/core/field.js';
import {generateTeam,pickOffense,pickDefense} from '../../src/league/team.js';
import {RUN_BY_ID,PASS_BY_ID} from '../../src/playbook/concepts.js';
import {COVERAGE_BY_ID,FRONT_BY_ID} from '../../src/playbook/defense.js';
import {FORMATION_BY_ID} from '../../src/playbook/formations.js';
import {PlaySim} from '../../src/sim/playsim.js';
import {tryTackles} from '../../src/sim/tackle.js';
export function stage(carrierSlot:string,side:number, facing:number, gapKind:string, keepHold:boolean, speed=6, separating=4, defenderSlot='FS') {
 const sim=new PlaySim({offense:pickOffense(generateTeam(new Rng(19),'O','O'),'11'),defense:pickDefense(generateTeam(new Rng(20),'D','D'),'nickel'),offCall:{formation:FORMATION_BY_ID.gun_doubles_11,flip:side<0,kind:'pass',pass:PASS_BY_ID.four_verts,label:'acquisition'},defCall:{personnel:'nickel',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:'acquisition'},los:40,ballY:CENTER_Y,firstDownX:50,seed:83});
 const c=sim.slot(carrierSlot)!,d=sim.slot(defenderSlot)!;
 for(const a of sim.agents){a.body.pos={x:5+Math.floor(a.idx/12)*2,y:2+a.idx%12*4};a.body.vel={x:0,y:0};a.downUntil=99;a.behavior={kind:'idle',update:()=>({vel:{x:0,y:0}})} as any;}
 c.downUntil=d.downUntil=-1;sim.t=sim.world.time=2;sim.scrambled=true;sim.ball={kind:'held',carrier:c};
 const body=c.profile.radius+d.profile.radius, arms=body+d.profile.reach,range=arms+.45;
 const gap=gapKind==='dive'?range+.15:gapKind==='outside'?range+.35:gapKind==='lunge'?arms+.2:gapKind==='form'?body+.02:arms-.02;
 d.body.pos={x:50,y:CENTER_Y}; d.body.vel={x:side*(speed-separating),y:0};d.body.facing=facing;
 c.body.pos={x:50+side*gap,y:CENTER_Y};c.body.vel={x:side*speed,y:0};c.body.facing=side>0?0:Math.PI;
 c.behavior={kind:'carrier',update:()=>({vel:{x:side*speed,y:0},facing:side>0?0:Math.PI})} as any;
 d.behavior={kind:'idle',update:()=>({vel:{x:side*(speed-separating),y:0},facing})} as any;
 sim.intents=sim.agents.map(a=>({vel:{...a.vel},facing:a.facing}));
 for(let k=0;k<24;k++){const lag=(23-k)*sim.dt;sim.perception.record(sim.agents.map(a=>({pos:{x:a.pos.x-a.vel.x*lag,y:a.pos.y-a.vel.y*lag},vel:a.vel,facing:a.facing,pose:'up' as const})),c.idx);}
 const rolls:number[]=[];
 sim.rng.chance=(p:number)=>{rolls.push(p);return gapKind==='dive';};
 sim.rng.normal=()=>0;
 const before=[{...c.pos},{...d.pos}];tryTackles(sim);
 const j=sim.world.joints.find(j=>j.kind==='grasp') as any;
 const acquired=j?{origin:j.origin,reach:j.reach,hold:j.hold,legs:j.legs,capacity:j.capacity,distance:Math.hypot(c.pos.x-d.pos.x,c.pos.y-d.pos.y),states:[c.body.support?.state,d.body.support?.state],positionsUnchanged:JSON.stringify(before)===JSON.stringify([{...c.pos},{...d.pos}])}:null;
 if(!keepHold){sim.world.joints=[];sim.bond=null;}
 d.nextTackleAt=99;
 const frames=[];const start=sim.t;let fallAt:number|null=null;
 for(let k=0;k<16&&sim.phase==='live';k++) {sim.tick();if(c.body.support?.state!=='up'&&fallAt===null)fallAt=sim.t-start;frames.push({t:sim.t-start,c:{pos:{...c.pos},vel:{...c.vel},state:c.body.support?.state,cause:c.body.support?.cause},d:{pos:{...d.pos},vel:{...d.vel},state:d.body.support?.state,cause:d.body.support?.cause},distance:Math.hypot(c.pos.x-d.pos.x,c.pos.y-d.pos.y),joint:j?{broken:j.broken,force:j.force}:null,bodyContacts:sim.lastStep?.contacts.filter(x=>(x.i===c.idx&&x.j===d.idx)||(x.j===c.idx&&x.i===d.idx)).length??0});}
 return {carrierSlot,side,facing,gapKind,keepHold,speed,separating,defenderSlot,body,arms,range,gap,heights:[d.profile.heightYd,c.profile.heightYd],layoutProxy:.71*d.profile.heightYd+.25*c.profile.heightYd,rolls,acquired,fallAt,outcome:sim.outcome,frames};
}
if(import.meta.url === `file://${process.argv[1]}`) {
const rows=[];
for(const slot of ['QB','RB','Z'])for(const side of [-1,1])for(const kind of ['dive','lunge','reach','form','outside'])for(const keep of [true,false])rows.push(stage(slot,side,side>0?0:Math.PI,kind,keep));
for(const facing of [0,Math.PI/2,Math.PI])rows.push(stage('RB',1,facing,'reach',true));
writeFileSync('out/forensic-contact/acquisition.json',JSON.stringify({sha:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',note:'Geometry/physics intervention, not probability estimate: technique and fumble draws forced successful/non-fumble; same dive request retained in no-hold arm, only freshly acquired hold and bond removed. Other defenders parked. All initial feet and later carrier request identical within each pair.',rows},null,2));
console.log(JSON.stringify(rows.map(({carrierSlot,side,facing,gapKind,keepHold,gap,layoutProxy,acquired,fallAt,outcome})=>({carrierSlot,side,facing,gapKind,keepHold,gap,layoutProxy,acquired,fallAt,outcome})),null,2));

}
