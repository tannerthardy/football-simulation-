# Gridiron Engine: a candid review and the way forward

**Prepared for Tanner · October 23, 2026**  
**Audited build:** `develop@c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0`, including PR #245, merged at 1:53 p.m. Phoenix time. The remote still pointed to this commit at the final verification. This is a consulting review and proposed direction; it does not amend the approved operating plan.

## 1. My verdict

**Your complaint is valid. The project repeatedly produces players who execute an instruction after its football purpose has changed. But a wholesale “smarter players” rewrite would be the wrong response.**

The engine already contains delayed perception, run/pass beliefs, anticipation, finite decision cadence, stable errors, coverage help judgments, carrier alternatives, movement forecasts, and new blocker threat reassessment. The missing piece is consistency: each subsystem still answers basic questions differently. What do I actually know? What responsibility am I protecting? When has that responsibility changed? What useful alternative can this body execute? What did a later movement/contact system do to my request?

That is the central architectural problem. **The project has many intelligent components without a reliable common contract connecting them.** More football rules will still be necessary. The opportunity is to stop rebuilding the same knowledge, commitment, threat, and handoff logic inside every new football rule.

The other central problem is the development feedback loop. The written philosophy is already unusually good: mechanism before averages, acquired information, common physics, first wrong action, opposing controls, ordinary film. Yet agents can still satisfy local tests, produce plausible explanations, and miss obvious football. Your eyes remain too important because the tools identify symptoms more reliably than they establish why a player acted or whether a better action was possible.

My recommendation is a measured architectural consolidation, attached to current football problems:

1. Make evidence trustworthy and current.
2. Make player knowledge and the stages between choice and movement inspectable.
3. Prove one shared responsibility-and-opportunity decision on a narrow role.
4. Extend it only after it preserves disciplined football on unfamiliar cases.
5. Make player traits and concept installations behave like the experimental controls the eventual product promises.

There is substantial progress here, especially in the last two days. There is also substantial unfinished work. Neither “everything is hopeless” nor “the tests pass, so keep adding mechanisms” is supported.

## 2. What I actually reviewed and tested

The environment initially contained the October 8 branch, which would have produced a seriously misleading audit. I fetched the actual trunk, created an isolated checkout, reviewed current plans and known problems, examined recent Git history and 100 recent PR records, and divided the technical inspection across architecture, evaluation, physics/product scope, development history, and external decision-model research. The old integration queue and historical experimental branches were treated as history, not current authority. Some requested chat-history reads did not return; the chronology is grounded in repository records and PR evidence rather than presumed chat contents.

Fresh work on the pinned current build:

| Check | Result | What it establishes |
|---|---|---|
| Core TypeScript tests | **3,197 passed**, 283 files | Existing production assertions pass; not a realism certificate |
| Integration tests | **9 passed**, 5 files | Existing integrated contracts pass |
| Python data/extraction tests | **215 passed** | Existing data assertions pass |
| Typecheck and build | Both pass | Type/build integrity |
| Current scorecards | **12 games, 1,597 official scrimmage records**, two seeds, four generated leagues | A fresh bounded picture of current outcomes and automated film flags |
| Recorded film | One additional seed-7 film-room game, 125 filmed plays | Replay artifact and selected trajectory inspection; not an expert review of every play |
| Information experiments | Four synthetic information-contract probes | Three hidden-state pairs change decisions despite unchanged pictures; one catch-handler trace shows global controller replacement |
| Evaluator failure experiment | Empty metrics still report 12/12 guards matching | Confirmed false assurance in a diagnostic tool |
| Trait experiment | Four complete Power/Counter executions | Extreme `leadBlock` changes have no execution effect with lineup fixed |
| Contact-law experiment | Four tiny two-body steps | Current angular-momentum defect survives finer stepping |

No production source, defaults, tests, branches, or repository plan were changed. Diagnostic scripts and raw output remain outside tracked source. The paused anatomical research suite was not rerun. I did not re-extract all raw NFL tracking or certify every legal rule, every controller, or all possible matchups. Findings distinguish fresh reproduction, prior measured evidence, code-level risk, and proposed design.

Detailed technical appendices: [architecture](architecture-audit.md), [evaluation](validation-audit.md), [physics and product](physics-product-audit.md), [history](history-audit.md), and [decision research](decision-research.md). The actionable work packages are in [ROADMAP.md](ROADMAP.md).

## 3. Progress is real—and the latest work changes the diagnosis

October 22 already addressed several problems that an uninformed consultant would recommend fixing: one trunk, one ranked gap list, smaller tests, fewer active lanes, mechanism evidence over statistical vetoes, and realistic mechanisms enabled by default. Preserve that correction. Do not restore the old machinery of extensive integration receipts and repeated broad campaigns.

Recent progress is particularly persuasive where it identifies a wrong intermediate action:

| Recent work | Demonstrated improvement | What remains unresolved |
|---|---|---|
| [#238: first-threat reread](https://github.com/tannerthardy/football-simulation-/pull/238) | A lead/climber can leave an irrelevant assigned defender for a more immediate threat; the filmed fullback now takes the Mike | Still narrow; a broad receiver version abandoned corners and was rejected; a hidden-state dependency remains |
| [#239: puller approach](https://github.com/tannerthardy/football-simulation-/pull/239) | Removes feed-forward that made a guard retreat after a penetrating end; assigned-target contacts 55→66 in 132 restaged pullers | Targets reaching the runner unblocked were 35→36; contact count is not successful protection |
| [#240–241: defensive turning](https://github.com/tannerthardy/football-simulation-/pull/240) | Repairs five controller causes and default facing that outran actual travel | Explicit coverage-mode toggles still cause too many sharp turns; COV-6 is already next for Coverage |
| [#237: motion](https://github.com/tannerthardy/football-simulation-/pull/237) | Motion paths stop running through teammates and the quarterback | Some longer valid motions exceed the 5.5-second planning limit and are dropped |
| [#245: inline ends](https://github.com/tannerthardy/football-simulation-/pull/245) | Gives inline TE/H first-level blockers the base/strike preparation of OL; early falls 21→3 in 151 restaged runs | Own first step/zone track and some contact questions remain; yardage moves both ways |
| [#243: film scouts](https://github.com/tannerthardy/football-simulation-/pull/243) | Five read-only detectors now nominate exact plays/times; recovered 14 of 19 selected development examples | This is not population recall or precision; many alerts remain unreviewed |
| [#204: allocation optimization](https://github.com/tannerthardy/football-simulation-/pull/204) | Measured speed savings with exact execution preserved | Several-fold throughput improvement is still required for a rich matchup laboratory |

The inline-TE repair is a model for future work: **the technique follows the job and geometry, not simply the position label.** The rejected receiver retargeting is equally instructive: unrestricted “go make a play” can destroy the useful assignment.

The earlier physics and integration work was not all wasted. It found conservation problems, corrected accounting, established deterministic traces, and prevented unsupported mechanisms from silently becoming production. But some research chains accumulated expensive local proofs with little demonstrated ordinary-football benefit. Preserve those references; stop treating further refinement as automatically valuable.

This is roughly two weeks of substantial engine development across difficult, coupled problems. Expecting mature football already would be unreasonable. Expecting the same failure family to become cheaper to diagnose each time is reasonable. I cannot infer labor hours or wasted money from PR counts; the criticism is about demonstrated return and recurring structure, not effort or motives.

### Progress, regression, or unresolved interaction?

| Evidence | Honest classification | Development consequence |
|---|---|---|
| Historical #164/#165 candidates failed combined native contracts and were reverted | Demonstrated rejected composition; those changes are not the current default | Preserve the counterexamples when revisiting the ideas |
| Realistic line splits/snap mechanisms raised sacks during #210 promotion | Interaction exposed; not proof that realistic splits were a bug | Diagnose protection, as subsequent G5 work did; do not restore unrealistic spacing to recover an average |
| #237 collision-free paths now cause some called motions to be dropped by the time limit | New capability loss/tradeoff, explicitly recorded as ALN-4 | Fix planning/calling time semantics; collision removal alone did not complete motion support |
| #238's new first-threat policy still responds to hidden availability | Reproduced information-contract defect in a current improvement | Repair its input boundary; do not declare the whole adaptation idea failed |
| #245 changes restaged gains in both directions while sharply reducing early TE falls | Valid local repair with unresolved downstream effects; yardage alone does not prove regression | Examine whether prior full-speed impacts supplied accidental displacement |
| COV-6 turning and QB-3 dives remain on current trunk | Confirmed unresolved mechanisms, not established new regressions from today's final commit | Keep the cause and source pin distinct from the date someone noticed the symptom |

This distinction matters: calling every bad play a regression hides progress, while calling every adverse result a newly exposed gap can excuse a bad model. Both require a supported behavioral comparison.

## 4. Where the current football stands

These are fresh diagnostic samples using the current scorecard definitions. They are **not matched before/after estimates** against the older GAPS table. Rosters, defaults and accounting have changed; some reference bands also changed. Six games per seed give broad uncertainty, and repeated teams within leagues limit generalization.

| Measure | Seed 7, six games | Seed 8, six games | Reading |
|---|---:|---:|---|
| Points per team-game | 38.08 | 38.00 | Offense remains too productive in these samples |
| Rush yards/carry | 4.93 | 4.88 | The old 10+ YPC description does not describe these current cohorts |
| Stuff rate | 21.1% | 23.6% | Plenty of failed runs coexist with explosives |
| Runs of 10+ yards | 14.4% | 13.1% | Explosive frequency remains a concern |
| Runs of 20+ that reach 40 | **4/11** | **8/10** | The deep tail is unresolved; the first seed alone was misleading |
| Pass yards/attempt | 9.54 | 9.33 | Consistently high in both samples |
| YAC/reception | 7.70 | 7.26 | Catch approach, pursuit and finish remain important |
| Interception rate | 5.4% | 4.9% | High alongside explosive passing: an unhealthy distribution, not simply easy offense |
| Sack rate | 8.1% | 6.7% | No reason to diagnose all pass problems as “too little pressure” |
| Completion rate | 60.2% | 60.4% | Lower completion and large successful gains coexist |
| Failed defender tackle opportunities/play | .15 | .16 | Internal definition; do not substitute the unmatched PFF band |
| Accepted penalties/team-game | 3.92 | 4.25 | Total alone hides missing/excess foul types; the old 2.5–4 target was invalid |

The right takeaway is distributional. A nearly plausible run average can hide a mixture of failed runs and failures to stop the rare breakout; these samples do not establish a clearly excessive stuff rate against the current sourced band. Passing here combines ordinary-range sack rates with high interceptions and high YAC. Different mechanisms can compensate in a total. An “OK” total is not evidence that its parts are credible.

The second seed changed an important conclusion: four of eleven breakouts reaching 40 looked close to the old rough comparison band; eight of ten did not. Across these two small samples it is twelve of twenty-one. Do not declare long-run pursuit solved. Study how the next defender becomes available, recognizes the runner, selects an angle, gathers, and finishes.

The new detectors found zero pre-snap teammate contacts in both the seed-7 scorecard and its separate film-room game, consistent with the recent motion repair. They also flagged many apparent bad actions. In seed 7, the “stuck blocker” rule fired on 163 of 262 eligible run plays. **That is an alert rate, not a 62% decision-error rate.**

In the recorded G1-P142, Z follows his corner far from the interior tackle. The detector sees a free interior defender near the runner. The trajectory plot shows why “switch and help” is not established: the receiver is on the other side of the play, far beyond any useful rescue path in the remaining time. In G1-P031, the center continues with a defender far from the runner; that is a useful review candidate, but a late snapshot still does not establish when a better reachable option existed. G1-P060 shows a defensive end turned away during a scramble, with the recorded requested facing also away: a request investigation is justified. G1-P017 supplies an ordinary catch/contact/tackle comparison. These selected cases illustrate diagnosis, not prevalence.

![Selected current-trunk trajectories](film-examples.png)

The [interactive current replay](current-film.html) preserves the film IDs. The plot shows body orientation, not gaze; it cannot establish perception, applied force, or intent by itself.

## 5. The recurring problems underneath the symptoms

### A. Responsibility is often represented as a target or landmark, without a common lifecycle

A football instruction has a purpose, a current implementation, and conditions for continuing or changing it. Those are not interchangeable. A force defender's purpose is to keep the ball from escaping outside; his current landmark is one way to do it. A climber's purpose is to keep a dangerous second-level player from the runner; his initial target is a hypothesis about who that will be.

The engine has role-specific versions of this reasoning, but not a uniform contract. Assignment changes, coverage techniques, run-fit gates, blocker coordination, possession transitions and emergency pursuit each preserve or discard responsibility differently. This is why related failures recur under new positions or concepts.

Source inspection supports this as an architectural diagnosis, not merely a complaint about file size: `Behavior.update` receives the whole simulation and returns a movement command, without requiring a purpose, evidence for switching, or responsibility-retirement condition. Some paths can mutate other players' assignments immediately. The architecture appendix traces these interfaces and distinguishes untested update-order risk from reproduced defects.

### B. Delayed positions do not guarantee believable knowledge

We reproduced three synthetic hidden-state dependencies and traced one global event transition, all relevant to the project's stronger acquired-information model:

| Same delivered pictures; change only… | Observed decision effect |
|---|---|
| The authoritative ball holder, QB→RB | Pursuit changes from no request to a running request, despite the supplied RB picture showing no possession |
| The global handoff timestamp | Run/pass belief changes from uncertain to strongly run |
| Invoke the global catch handler | All 11 defenders switch to pursuit without a personal observation query |
| Mike's hidden current support state | The new first-threat blocker switches target even though his picture still shows Mike up |

These do not measure frequency or yardage damage in games. They prove a class of information dependency that “we call `sim.see`” does not prevent. Identity, eligibility, and event admission can leak truth before the delayed-position read.

The fix is not to give everyone less information indiscriminately. Known calls, self-balance, tactile contact, communication and visual memory are legitimate channels. Define them. New policy functions should receive typed observations and self-state rather than unrestricted live opponent objects. Physics and officials still use authoritative state. Then test **same knowledge, same decision**, followed by a cue-reveal test proving the player can respond when the evidence arrives.

See [the reproducible witness](evidence/information-boundary.ts) and [results](evidence/information-boundary.json); relevant production paths include [defensive pursuit](https://github.com/tannerthardy/football-simulation-/blob/c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0/src/sim/behaviors/defense.ts), [recognition](https://github.com/tannerthardy/football-simulation-/blob/c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0/src/sim/recognition.ts), and [assignment transitions](https://github.com/tannerthardy/football-simulation-/blob/c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0/src/sim/assign.ts).

### C. A good choice can be changed before the body executes it

The current tick includes behavior choice, coverage containment, turn adjustment, engagement, tackle-bond adjustment, teammate spacing, snap guarding, and finally physics. Several layers can alter the request. Existing telemetry records useful intentions and bodies, but not a general explanation of each transformation or each rejected alternative.

This creates repeated diagnosis errors: a policy is blamed for a request that contact/spacing changed; physics is blamed for a deliberately impossible requested turn; an assigned blocker appears to refuse a climb when his partner has actually fallen. Add a selective command-stage trace before inventing another intelligence mechanism. Record the selected purpose, the request entering/leaving each relevant stage, and the constraint that changed it. Observe already computed values; do not rerun decision functions to explain them.

Also trace the complete latency chain: evidence becomes available → acquired picture → belief update → decision beat → technique transition → first useful motion. Plausible local delays can accumulate into an implausibly late player. This is a hypothesis to measure, not a reason to zero all reaction times.

### D. Some visible stupidity is geometry or presentation

The current QB-3 diagnosis is strong: the scrambling quarterback is not choosing to fall. A dive can acquire a leg outside the modeled plausible reach and trip him. The viewer then draws the diver as a ground dot, obscuring the contact story. A mental-model rewrite cannot fix that.

The common reach contract must connect standing reach, lunge, finite dive motion, body landmarks, target ankle position, contact acquisition and held extension. A probability roll may govern technique success **within an available physical opportunity**; it must not create contact at impossible range. The trial that removes every dive is not a complete solution. Preserve reachable diving tackles and their cost.

Presentation is part of the audit loop. A simple extended body/reach/contact overlay and a clear distinction between asked-for and achieved motion can prevent wasted investigation. This is a scientific instrument, not cosmetic polish.

### E. The physics law and its numerical solver are different problems

We freshly reproduced the known center-hand angular-momentum defect. A passive two-body step changed total planar angular momentum by about −0.902 kg·yd²/s with no ground impulse or torso contact. Increasing substeps from 12 to 48 did not remove it, while energy accounting residuals remained near rounding error. The experimental common-point path conserved angular momentum in that isolated case.

This does **not** authorize enabling the experimental stack: its transfer failures and costs remain unresolved. It does establish that a green energy ledger and finer stepping can coexist with a wrong force application law. Repair the smallest causal law/geometry defect; do not keep paying for refinement of the wrong abstraction. Conversely, do not abandon common physics merely because it is hard. Shared physical constraints are essential to credible unfamiliar matchups.

### F. Some player controls do not mean what the eventual product needs them to mean

The `leadBlock` rating affects FB/H-back suitability, but has no execution consumer. In the audit, setting offensive `leadBlock` from 1 to 99 with the lineup fixed left complete Power and Counter replay, bodies and RNG identical. Suitability changed substantially. That is a concrete mismatch between selection and technique, not a theory about why all blocks fail.

There are also large position-dependent trait offsets caused by omitted ratings falling to a low tier. Prior roster audits already identified related issues; another broad survey is less valuable than resolving a narrow slice. Establish a trait-to-mechanism contract: selection, perception, choice, execution, development, or presentation. An unused public skill should be explicitly deferred or removed, not given an arbitrary success bonus just so it does something.

For the user's intended experiments, a smart/slow player and a fast/inexperienced player must fail for different intelligible reasons. Test intermediate responses under fixed calls and selected lineups. Do not demand that every single stochastic play improve monotonically with a rating.

### G. The measuring tools can create confidence they have not earned

The reproduced mechanics-guard defect is unambiguous: zero simulated metrics still printed “12/12 matched metrics still match” and exited successfully. Missing evidence must be unavailable, not a pass. This is a small repair with high value.

Other issues are subtler. “Noise” for an interval containing zero does not establish no effect. “Biggest real moves” overstates exploratory 90% intervals across many metrics and splits. In the first fresh card, 17/17 field goals and 48/48 extra points produce bootstrap intervals of 100–100%; those describe the observed resampling support, not certainty about future kick success. Counts must remain visible.

Python measurement tests currently do not run in the new CI workflow. Collector validity is also different from whether a football statistic lies outside a descriptive band. A broken collector should be an infrastructure failure; an out-of-band football result should remain diagnostic.

## 6. The mental model I would build

**Preserve the instruction's purpose, adapt its execution, and require evidence before abandoning a live duty.** That is the principle behind disciplined improvisation.

Use a small, shared decision envelope around existing behaviors:

| Layer | Player's question | Stored/produced information |
|---|---|---|
| Responsibility | What danger or opportunity am I responsible for? | Primary duty, partner convention, protected space/threat, retirement conditions |
| Personal picture | What do I know, remember, doubt or need to look at? | Acquired cues, age, uncertainty, possession hypothesis, self/contact state |
| Alternatives | What useful actions are available to me now? | Continue, adjust technique, help, exchange, recover, emergency intervention |
| Evaluation | Can I get there; what do I leave exposed? | Reachable contribution, time, abandoned risk, teammate availability, confidence |
| Commitment | Is the new evidence strong enough to change course? | Held option, next read, switching margin, interrupt/termination reason |
| Execution | What can my body actually do? | Technique request, downstream changes, achieved motion/contact and feedback |

This can be ordinary TypeScript with a few records and pure functions. It does not require a large class hierarchy, full-world optimization, or a language model controlling every tick.

The current coached action remains a candidate. Candidate sets should be small and role-specific. Reevaluate at existing decision cadence or a meaningful acquired event; steer continuously between choices. Actual forces and contact must obey the physical model, but a player can attempt an action he mistakenly believes is reachable. Physically possible fouls can also be chosen or committed accidentally, with discipline, detection and enforcement modeled; legality is not a magical ban on an illegal attempt. Football responsibilities are priorities with an explicit cost of violation, not universal prohibitions: a player can make an aggressive judgment, misread the situation, or accept risk in an emergency. Unknown teammate help cannot count as guaranteed coverage.

Consider the climbing guard. His assigned linebacker drifts away; a second defender closes on the runner. He should estimate who can threaten the runner before the play develops, whom he can reach or obstruct, whether another teammate has usable leverage, and whether the original linebacker can still close a cutback. Switch when the alternative clearly matters more, then commit enough to execute. The same logic must say **stay** when the old threat remains dangerous or the new one is unreachable.

For an edge defender, making a play can mean denying the bounce so a teammate tackles. For a deep defender, it can mean keeping a credible vertical capped while resisting the temptation to chase a short route. For a receiver, it can mean altering a release to leverage while preserving the quarterback's timing and window. Better intelligence should sometimes produce less visible activity.

This approach has established technical precedents: temporally extended actions with initiation/termination conditions in the [options framework](https://www.sciencedirect.com/science/article/pii/S0004370299000521), and separation of goals, steering and locomotion in [Reynolds's character-control work](https://www.red3d.com/cwr/papers/1999/gdc99steer.html). They support design structure, not a football reward formula. Coach-authored examples of [force/cutback responsibility](https://blogs.usafootball.com/blog/866/use-these-drills-to-apply-force-and-cutback-rules-to-fit-any-defense) and [release adaptation within route timing](https://blogs.usafootball.com/blog/7237/coaching-the-wide-receiver-2nd-level-slot-releases) support constrained expression; neither is a universal NFL rule.

### The first pilot

Use free climbing/lead blockers, building on #238. First remove the reproduced hidden eligibility dependency and add a decision explanation. Then compare the existing distance/closing heuristic with a bounded reachable-threat assessment. Keep stalk, kick/trap, contact capacities and unrelated physics outside this first policy change.

Design paired cases before coding: harmless old target versus cutback threat; nearby candidate approaching versus receding; teammate nearby and effective versus nearby but unable to help; visible fall versus hidden fall; small advantage versus decisive advantage; early versus late cue; slow powerful versus fast light blocker. Reserve a formation/concept and fresh inputs for transfer.

Success means fewer independently judged dominated choices, fewer missed feasible opportunities, no increased unjustified abandonment, no hidden-state dependence, sensible commitment, and transfer without new formation-specific exceptions. More switches, blocks, or yards is not the acceptance criterion. If two plausible attempts fail, re-diagnose; the apparent decision problem may be an execution limit.

After success, transfer the same small contract to fit-versus-rally and coverage technique transitions. Shared concepts should emerge from working examples. Do not generalize every controller in advance.

### Individual expression

Keep coherent, persistent variation. Let processing affect when evidence is consumed; recognition affect interpretation; anticipation affect priors and forecasts; discipline/aggression affect perceived risk; technique affect the available repertoire and its control; composure affect degradation under workload. A player can confidently make a plausible wrong read. Do not add independent per-frame randomness or a generic “chance to make the correct decision.”

Tracking constrains movement and outcomes but does not uniquely reveal intentions, effort, gaze, or instructions. [NFL's tracking description](https://operations.nfl.com/gameday/technology/nfl-next-gen-stats) describes the observable system; [inverse-learning research](https://proceedings.mlr.press/v139/kim21c.html) illustrates why latent objectives need additional assumptions. Use coaching sources, controlled scenarios and uncertainty alongside tracking. Explicitly label engineering heuristics as heuristics.

## 7. How agents should catch the obvious problems

Build on the detectors that just landed. The next improvement is an explanation packet and a disciplined review loop, not another broad dashboard.

Every cycle should use three small feeds: selected high-value alerts, independently selected ordinary plays, and opposing controls from the affected mechanism. The ordinary sample estimates prevalence and finds blind spots; the alert sample concentrates diagnosis; the controls protect legitimate football. Keep those denominators separate.

An agent's packet should contain the clip, first suspect time, actual responsibility, consumed cue and age, current belief, chosen/rejected action, request stages, achieved motion, and one competing explanation. Unknown fields stay unknown. The agent then proposes the smallest intervention that distinguishes explanations. It should not jump from “looks bad” to a threshold patch.

Your role becomes high-value adjudication: “clearly wrong,” “plausible,” or “uncertain,” with a first wrong moment and a short football explanation. Most metadata is automatic. A starting review of roughly 8–12 clips per cycle is a workload proposal, not a statistically sufficient sample. Ask for source research or another reviewer when the scheme judgment exceeds your confidence. Preserve disagreement rather than converting it into forced certainty.

Measure an opportunity chain for one behavior at a time: **feasible opportunity → available cue → acquired cue → justified choice → feasible request → achieved execution → useful team contribution.** A play that ends before a response is possible is censored, not automatically failed. Maintaining leverage can be useful without earning a tackle statistic. An offline omniscient reviewer can nominate an opportunity; the player must still decide using his own knowledge.

Evaluate scouts on reviewed alerts and ordinary clips, with an untouched labeled segment. Report valid alerts, false alarms, uncertainty and missed categories. The 14/19 development-example hit count is useful, but cannot establish general recall. Never optimize the engine to make detector counts vanish: standing still or abandoning a sound responsibility can fool a weak detector.

Useful process measures at review are agent-first discoveries, repeated failure families, time from clip to isolated cause, escaped regressions on new cases, and your minutes per resolved question. Test count, rule count, PR volume, and prettier averages are poor substitutes.

## 8. Other strategic changes that matter

**Separate mechanism, execution, and calling experiments.** Whole games test composition, fatigue, rules and play calling. Short matched situations test a local decision. Existing collectors already do useful restaging; consolidate a small reusable native-prefix/intervention runner. Do not start with a universal state serializer. Named RNG forks already exist, but shared draw order can still turn unrelated later contacts into different outcomes. A bounded event/actor stream migration may help later; it is a semantic change, not a free determinism fix.

**Make supported concepts explicit.** The playbook already has relative receiver roles and some defensive installation guards. It still needs clear structural needs, actual-lineup selection, and protection-call families. Distinguish illegal/unrepresentable installations from valid but weak tactics. Do not silently invent a fallback and call it the requested concept. Mirror, hash, personnel and formation transformations should preserve declared responsibilities where supported.

**Build the experiment product before the management product.** A valuable near-term milestone is: select a supported concept and player profile, watch a believable rep, inspect why the player acted, alter one meaningful trait, and observe an understandable effect. That directly serves the user's goal and exposes model defects earlier than a season UI would.

**Make rendering an instrument.** Show planted/turning/down states, actual contact points, reach, intent versus motion, and perception uncertainty where helpful. A dot-only ankle tackle or visually misleading slide can waste both human and agent effort. Avoid decorative animation that hides wrong mechanics.

**Use a bounded physics research budget.** Require a law defect or repeated football failure, the simplest intervention, an opposing control, a useful transfer measure, and incremental production cost. Keep anatomical feet/soles paused unless a simpler model cannot express a demonstrated need. Known conservation errors deserve narrow work even if averages look good; speculative detail does not.

**Treat speed as an experimental-capacity problem.** The first current card collected six games in 87.5 seconds with four workers; mean per-game elapsed time was 46.9 seconds under concurrent audit work. Those are observed elapsed timings, not clean CPU benchmarks. The existing five-second target is a several-fold improvement. Continue exact-execution allocation wins, profile production paths, cache compatible evidence, and make selective tracing cheap. Any coarser physics approximation needs explicit law/behavior tolerances.

**Keep an honest capability boundary.** Special teams currently use a hybrid reduced model, so kick-coverage scheme experiments are not equivalent to scrimmage experiments. Protection calls, broader modern concepts, and league development are separate capabilities. “No meta to abuse” should mean no known universal implementation exploit without a represented counter or contextual cost; real personnel mismatches and strong tactics should remain strong.

**Use learning later, in bounded roles.** Per-tick LLM players would inherit the same bad observations/actions and add cost and nondeterminism. Tracking imitation alone encounters unfamiliar states created by the learner, a standard sequential-learning problem described in [DAgger](https://proceedings.mlr.press/v15/ross11a.html). Self-play can discover counters but also simulator loopholes; [multi-agent tool-use research](https://arxiv.org/abs/1909.07528) illustrates both. Initially use learning and language models offline for scouting, adversarial case generation, source research, and bounded candidate evaluators. They are tools, not substitutes for a valid simulator.

## 9. Process changes: firm evidence without rebuilding bureaucracy

Keep the October 22 plan's small loops, lane ownership and default-on bias for supported corrections. Update its acceptance language at the next review: a plausible mechanism with an unresolved material cost is not automatically correct merely because the cost has not been traced to a conventional code bug. A bad abstraction, bad proxy, missing prerequisite, or composition tradeoff can matter too.

A concise PR needs four things: the mechanism claim; the same-input intermediate change; the strongest opposing control; and the unresolved cost or next discriminator. An adverse aggregate is not an automatic veto. An unexplained material loss is not automatically another lane's problem. “Inconclusive” must remain a usable outcome.

The GAPS table and the “Current” numerical section still point to an October 22 build. Other subsections describe today's repairs. Give the ranked list a clearly dated evidence link and mechanism exit condition; do not keep copying giant tables into many documents. The old tackle and penalty closure bands should be reviewed because their definitions were unqualified. Preserve historical evidence with its pin.

Retire experimental flags and old-path test pins at their scheduled review, preserving distinct contracts. The project has already announced this transition; a large flag inventory is not by itself proof that the new plan was ignored. Avoid another repository cleanup project. Most of the large documentation footprint is reference material, not disposable receipts.

## 10. What I would do next

The [roadmap](ROADMAP.md) contains work packages, owners, dependencies, effort ranges, acceptance and stopping criteria. My recommended first decisions are:

1. **Immediately repair false assurance:** empty guards, misleading statistical labels, missing fast data CI, and stale status/targets.
2. **Continue the current COV-6 and QB-3 diagnoses:** stable coverage technique and coherent dive acquisition address demonstrated failures; do not globally slow turning or ban diving.
3. **Attach one decision/command trace to that work:** make the next bad clip cheaper to explain.
4. **Pilot responsible adaptation on free lead/climb blockers:** first enforce knowledge boundaries, then compare reachable alternatives and obligation cost.
5. **Audit trait and installation promises with interventions:** close a narrow slice of the existing roster findings, not another broad survey.

The decisive change in thinking is to define progress as **a reusable, explainable football correction that survives its opposite case and a new situation**. Your film judgments are valuable precisely because they expose failures the averages miss. The engineering goal is to turn those judgments into a system that finds, explains and tests the same class of failure before you have to notice it again.
