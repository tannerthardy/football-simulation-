# Reproduce the audit checks

Repository: https://github.com/tannerthardy/football-simulation-  
Commit: `c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0`  
Runtime: Node 22.23.3. Use an isolated checkout. None of the following requires changing production source.

```sh
npm ci --no-audit --no-fund
npm test -- --maxWorkers=4 --reporter=json --outputFile=out/audit/core-tests.json
npm run test:integration -- --reporter=json --outputFile=out/audit/integration-tests.json
python3 -m unittest discover -s test -p 'test_*.py'
npm run typecheck
npm run build
npm run scorecard -- --tier quick --seed 7 --workers 4 --out out/audit/current-scorecard.json --md out/audit/current-scorecard.md
npm run scorecard -- --tier quick --seed 8 --workers 4 --out out/audit/current-scorecard-seed8.json --md out/audit/current-scorecard-seed8.md
```

Copy `information-boundary.ts` to `out/audit/` in the checkout:

```sh
node --import tsx out/audit/information-boundary.ts
```

Copy `hand-law.ts` and `leadblock.ts` to `out/consultant-physics/`:

```sh
node --import tsx out/consultant-physics/hand-law.ts
node --import tsx out/consultant-physics/leadblock.ts
```

The empty-metrics witness uses the supplied synthetic input, not a simulation:

```sh
python3 -I scripts/mechanics/compare.py --sim /path/to/evidence/empty-mechanics.json --guard data/reviews/mechanics/guard.json --out out/audit/empty-mechanics-report.md
```

On the audited source, that last command exits 0 and prints `Guard: 12/12 matched metrics still match.` despite no simulated metrics. That is the defect, not an expected future behavior to preserve.

The film uses the existing film-room setup: root Rng(7), sequential Ironmen/Comets generation at strength .55, game seed 7. The audit recorded light replay and attached the read-only weirdness observer in one run. Ordinary reproduction uses `npm run replay -- 7 --games 1 --doc` and `npm run weird -- 7 --games 1`; those are two runs with the same game setup. Scorecard game IDs are a different cohort and must not be substituted for film IDs.

The test artifacts show 3,197 core assertions and 9 integration assertions passing, plus 215 Python tests in the log. `manifest.json` records source, runtime and file checksums. Elapsed timings were collected under some concurrent audit work and are not clean throughput benchmarks.
