# Scorecard

Commit `c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0` · 6 games per arm over 2 leagues · seed 8 · 2026-10-23

Rendering measurement SHA256: `b717e89fe59dfb91f3123ec281168448f6d830d6d4cea27f1f41d1ac35e32b85`. Tables use this checkout's metric definitions; producer metadata below is preserved.

Read this as a diagnosis. A band says where our football looks unrealistic; it does not decide whether a mechanism is correct. A stat that moves the wrong way usually points at another mechanism to fix next. Ranges are 90% intervals from resampling whole games; "moved" means the interval excludes zero. A dash means an unavailable measurement or no eligible denominator.

## Timing and provenance

Per-game ms is elapsed time around simulateGame only; it excludes roster generation, record/probe work and worker startup. Sums of worker elapsed times are not collection wall time or CPU time.

**producer**: commit `c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0`; Node: v22.23.3; probes: missedBy, weird.

Workers requested: 4; peak concurrent worker processes: 4.

Collection elapsed: 94.6 s. CPU time: not collected in scorecard records.

- current: 53.2 s elapsed per game; worker processes: 4
- current film weirdness detectors: 640 ms per game, 1.2% of the elapsed time (inside it, not extra)
- engineSha256: 3e0bdcf720c1ba1df51848b48c6faece48e0860b43e956de1ad6ef372540f7a1
- measurementSha256: b717e89fe59dfb91f3123ec281168448f6d830d6d4cea27f1f41d1ac35e32b85
- lockfileSha256: cee32ba14d404c05dff4e8e3b4506bc1ea1e1afbfd40b35461511e7ff8fdb98f
- platform: linux
- arch: x64
- cpuModel: AMD EPYC 9V74 80-Core Processor
- cpuQuotaCores: 4
- execution: node --import tsx
- current resolved engine switches: `{"AGAP_ALIGN":true,"ANCHOR_SPLIT":true,"ARM_PRESS":true,"BACK_BLOCK":true,"BLOCKED_REACH":true,"BOX_ALIGN":true,"CF_FLOW":null,"CLIMB_INTERCEPT":true,"CLIMB_PLAN":true,"COVER_CALL":true,"DEEP_NO_FORCE":false,"DEF_ALIGN":true,"DEF_GETOFF":1,"DEF_PACKAGE":true,"DEUCE":true,"DL_ANCHOR":true,"DL_CHASE":true,"DL_FIGHT":false,"DL_FLATTEN":true,"DL_FLATTEN_WON":true,"DL_FLOW":true,"DL_HANDS":false,"DL_SQUEEZE":true,"FLOW_READ":true,"FLOW_RELEASE":true,"FORCE_BOUNCE":true,"FRONT_ALIGN":true,"FRONT_MENU":true,"FRONT_STRENGTH":true,"GAIT_STEP":0,"GRIP_HOLD":true,"GROUNDING_FACTS":true,"HAND_FIGHT":false,"HAND_MOTOR":false,"HOLD_LEVERAGE":true,"HOLD_SUBSTEPS":0,"IN_STRIDE_CATCH":false,"KEEPER_TORSO":true,"LB_LANDMARK":true,"LB_PLAN":true,"LEG_BRACE":false,"LEVER_FACING":true,"LIVE_AIM":true,"LIVE_GAPS":true,"MOTION":true,"MOTION_CHECK":true,"OL_SPLITS":true,"OL_STAGGER":true,"PAD_LEVERAGE":true,"PASS_FEEL":true,"PASS_FIRST":true,"PASS_KICK":true,"PASS_SINK":false,"PRESSURE_CALL":true,"PULL_CUE":false,"PULL_EARLY":true,"PULL_PLAN":false,"PULL_READ":true,"PULL_STEP":false,"PURSUE_AROUND":true,"REACH_CONTACT":false,"READ_EYES":true,"READ_RISK_TRACE":false,"ROUTE_CLEAR":true,"RUN_ANCHOR":true,"RUN_CONTACT_COMPONENTS":true,"RUN_CONTACT_TRACK":false,"RUN_FEEL":true,"RUN_HANDS":false,"RUN_READ":false,"RUN_READ_TURN":false,"SAFETY_TEMPO":true,"SCRAPE":true,"SHED_PHYSICAL":true,"SHED_PURSUE":true,"SHELL_SHOW":true,"SHORT_PACKAGE":true,"SNAP_REACT":true,"STALK_CLAIM":true,"STALK_CUSHION":true,"STRETCH_MESH":true,"STRETCH_REACH":true,"TACKLE_ROLL":false,"TACKLE_TOUCH":false,"THREAT_READ":true,"TIP_AWAY":true,"WRAP_BIND":false,"WR_ALIGN":true,"ZONE_FLOW":true}`


## Metrics

| Metric | Sim | 90% range | NFL band | vs band |
| --- | --- | --- | --- | --- |
| Points / team-game | 38.00 | 30.50 to 44.67 | 21–23.5 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Scrimmage plays / team-game | 66.25 | 64.50 to 68.00 | 61–65 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Total yards / team-game | 421.43 | 325.59 to 528.65 | 320–345 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Pass rate (dropbacks / plays) | 67.4% | 64.0% to 70.6% | 54.43–66.33% (data/reviews/nflverse/reference.json#teamSeasons[].dropbackShare.percent (team-season p10–p90; 2dp)) | HIGH |
| Completion % | 60.4% | 55.3% to 64.4% | 60.59–68.09% (data/reviews/nflverse/reference.json#teamSeasonRanges.completion (team-season p10–p90; 2dp)) | LOW |
| Yards / attempt | 9.33 | 7.70 to 10.96 | 6.35–7.89 (data/reviews/nflverse/reference.json#teamSeasons[]: completionYards.mean * completion.count / throws (team-season p10–p90; 2dp)) | HIGH |
| Sack rate (per dropback) | 6.7% | 4.8% to 8.1% | 4.61–9.36% (data/reviews/nflverse/reference.json#teamSeasonRanges.sackPerDropback (team-season p10–p90; 2dp)) | OK |
| INT rate | 4.9% | 3.6% to 6.2% | 1.47–3.15% (data/reviews/nflverse/reference.json#teamSeasonRanges.interception (team-season p10–p90; 2dp)) | HIGH |
| Pass TD rate | 9.1% | 6.6% to 11.4% | 4–4.8% (unsourced: legacy scorecard estimate; no committed TD/attempt team-season range) | HIGH |
| 20+ yd completions / att | 13.3% | 9.8% to 16.7% | 6.66–11.08% (data/reviews/nflverse/reference.json#teamSeasonRanges.twentyYardCompletionPerThrow (team-season p10–p90; 2dp)) | HIGH |
| aDOT | 8.94 | 8.32 to 9.47 | 7.5–8.5 (unsourced: legacy scorecard estimate; reference throwAirYards includes throwaways excluded here) | HIGH |
| YAC / reception | 7.26 | 5.99 to 8.33 | 4.53–5.91 (data/reviews/nflverse/reference.json#teamSeasonRanges.meanCompletedYAC (team-season p10–p90; 2dp)) | HIGH |
| Time to throw (s) | 2.57 | 2.52 to 2.62 | 2.7–2.9 (unsourced: legacy scorecard estimate; no committed time-to-throw distribution) | LOW |
| Scramble rate | 8.4% | 6.7% to 9.9% | 2.18–7.32% (data/reviews/nflverse/reference.json#teamSeasonRanges.scramblePerDropback (team-season p10–p90; 2dp)) | HIGH |
| Separation at catch point (yd) | 3.22 | 3.11 to 3.32 | 2.8–3.2 (unsourced: NGS 2022–24; no committed cohort or team-season aggregate) | HIGH |
| Rush yards / carry | 4.88 | 3.39 to 6.82 | 3.7–4.83 (data/reviews/nflverse/reference.json#teamSeasons[].designedRun.yards.mean (team-season p10–p90; 2dp)) | HIGH |
| Run stuff rate (<=0) | 23.6% | 20.5% to 26.5% | 15.89–23.54% (data/reviews/nflverse/reference.json#teamSeasonRanges.stuffPerDesignedRun (team-season p10–p90; 2dp)) | HIGH |
| 10+ yd runs | 13.1% | 7.8% to 19.6% | 7.58–12.87% (data/reviews/nflverse/reference.json#teamSeasons[].designedRun.explosive.percent (team-season p10–p90; 2dp)) | HIGH |
| Runs of 20+ that reach 40 | 80.0% | 70.0% to 100.0% | 25–35% (unsourced: PR #190, BDB 2022; no committed team-season distribution) | HIGH |
| Yards before contact (runs) | 1.44 | 0.95 to 2.00 | 1.5–2.3 (unsourced: legacy scorecard estimate; NFL cohort and contact definition unverified) | LOW |
| Missed + broken tackles / play | 0.25 | 0.20 to 0.30 | 0.11–0.16 (unsourced: PFF, definition unknown) | HIGH |
| Failed tackle opportunities / play (unique defenders) | 0.16 | 0.12 to 0.20 | internal: unique failed defenders per official play; no NFL comparison band |  |
| 3rd-down conversion | 36.9% | 30.8% to 43.2% | 37–41% (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | LOW |
| FG % | 94.7% | 83.3% to 100.0% | 83–87% (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| XP % | 98.0% | 94.6% to 100.0% | 94–97% (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Fumbles lost / team-game | 0.42 | 0.17 to 0.58 | 0.4–0.7 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | OK |
| Punts / team-game | 5.42 | 4.33 to 6.92 | 3.5–4.5 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Accepted penalties / team-game | 4.25 | 3.42 to 4.92 | internal: accepted count, no qualified total band; compare types under docs/NFL_RULES.md |  |
| FG 18–29 yd % | 100.0% | 100.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| FG 30–39 yd % | 80.0% | 50.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| FG 40–49 yd % | 100.0% | 100.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| FG 50+ yd % | 100.0% | 100.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt gross average (box yards) | 46.86 | 45.69 to 47.83 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt net field-position average | 40.09 | 37.00 to 43.12 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Kickoff return average (recorded yards) | 25.47 | 23.52 to 27.42 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt return average (recorded yards) | 11.53 | 9.11 to 13.27 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Kickoff touchback % (regular kicks) | 29.4% | 26.7% to 32.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt touchback % | 3.1% | 0.0% to 6.2% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Fourth-down go % (outside Q4 last 2:30) | 8.0% | 3.0% to 13.8% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Fourth-down conversion % (all official attempts) | 28.6% | 0.0% to 57.1% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Two-point attempts / TD (retries once) | 12.5% | 7.5% to 18.6% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Drives / team-game (logged offensive possessions) | 15.83 | 14.67 to 17.00 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Offensive points / drive (including Try) | 2.25 | 1.67 to 2.82 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Red-zone TD % (box trips) | 66.7% | 58.3% to 77.8% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Turnovers / team-game (box) | 2.33 | 1.75 to 3.00 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Missed tackles by DL / play | 0.04 | 0.02 to 0.05 | internal |  |
| Missed tackles by LB / play | 0.02 | 0.01 to 0.02 | internal |  |
| Missed tackles by CB / play | 0.03 | 0.02 to 0.03 | internal |  |
| Missed tackles by S / play | 0.01 | 0.00 to 0.01 | internal |  |
| Pre-snap teammate contact: plays with one or more (% of plays with pre-snap staging) | 0.0% | 0.0% to 0.0% | internal |  |
| Pre-snap teammate contact: events per 100 plays with pre-snap staging | 0.0 | 0.0 to 0.0 | internal |  |
| Pre-snap teammate contact with no motion called (control, expect 0): events per 100 plays with staging and no motion | 0.0 | 0.0 to 0.0 | internal |  |
| Pre-snap contact involving the motion man (% of pre-snap contact events) | — | — to — | internal |  |
| Defender turned from a nearby runner: plays with one or more (% of plays with a runner) | 13.6% | 11.7% to 15.5% | internal |  |
| Defender turned from a nearby runner: events per 100 plays with a runner | 17.6 | 13.7 to 22.3 | internal |  |
| Blocker on a man out of the play: plays with one or more (% of run plays with a runner) | 71.1% | 69.6% to 73.2% | internal |  |
| Blocker on a man out of the play: events per 100 run plays with a runner | 145.3 | 140.4 to 150.8 | internal |  |
| OL facing own backfield and moving back (% of OL frames) | 3.8% | 3.3% to 4.3% | internal |  |
| OL backpedaling facing own backfield: plays with one or more (% of plays) | 68.1% | 64.7% to 71.4% | internal |  |
| OL backpedaling facing own backfield: events per 100 plays | 124.7 | 114.1 to 136.0 | internal |  |
| Sharp turns with no speed loss (candidate; % of 60°+ turns) | 4.0% | 2.9% to 5.0% | internal |  |
| Sliding through a cut (candidate): events per 100 plays | 8.2 | 5.5 to 10.7 | internal |  |
| Accepted penalties / team-game: block_in_back | 0.25 | 0.00 to 0.50 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: false_start | 0.83 | 0.33 to 1.50 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: holding | 1.17 | 0.50 to 1.92 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: illegal_contact | 0.83 | 0.67 to 1.00 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: intentional_grounding | 0.25 | 0.08 to 0.42 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: neutral_zone_infraction | 0.42 | 0.17 to 0.67 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: offside | 0.33 | 0.00 to 0.67 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: roughing_passer | 0.17 | 0.00 to 0.33 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |

## Watch these first

Read the clips, not the averages: each line is a place in a simulated game that a rule flagged. A rule says where to look, never what number is right, and several of its constants are chosen, not sourced (docs/VALIDATION.md). Ids with an `sc<seed>/` prefix are this run's own games, not the film room's: the full list is in the events file next to the saved card, and `npm run weird -- <seed>` plays the film-room games so its ids match `npm run replay`.

**Pre-snap teammate contact**: 0 events in 6 games

- none

**Defender turned away from a nearby runner**: 98 events in 6 games

- sc8/G2-P095 @ 2.45 s: DE_W facing 170° from the runner (RB) at 2.9 yd for 1.30 s; asked for 173°
- sc8/G1-P112 @ 1.75 s: DE_W facing 125° from the runner (RB) at 2.4 yd for 1.15 s; asked for 125°
- sc8/G5-P019 @ 2.35 s: DE_W facing 124° from the runner (RB) at 2.6 yd for 1.00 s; asked for 127°

**Blocker on a man who is out of the play**: 372 events in 6 games

- sc8/G6-P040 @ 1.40 s: Z (stalk) on CB_S, 22.7 yd from the runner and moving away at 5.6 yd/s, while NB is free 1 yd from the runner, for 3.05 s
- sc8/G2-P152 @ 2.70 s: LG (climb) on LB_M, 21.2 yd from the runner and moving away at 1.9 yd/s, while FS is free 0.5 yd from the runner, for 2.20 s
- sc8/G4-P014 @ 2.75 s: RG (run-block) on LB_W, 6.6 yd from the runner and moving away at 0.8 yd/s, while LB_M is free 1.1 yd from the runner, for 2.20 s

**Lineman backpedaling while facing his own backfield**: 991 events in 6 games

- sc8/G6-P018 @ 1.70 s: LG facing 154° from downfield, moving back at 4.3 yd/s for 2.55 s (pass play)
- sc8/G4-P030 @ 1.25 s: RT facing 139° from downfield, moving back at 4.7 yd/s for 2.00 s (pass play)
- sc8/G5-P170 @ 1.75 s: LT facing 141° from downfield, moving back at 4.7 yd/s for 2.00 s (pass play)

**Sliding through a cut (candidate)**: 65 events in 6 games

- sc8/G1-P053 @ 4.20 s: RB turned 65° from 4.7 yd/s keeping 92% of his speed through the whole cut (NFL p90 for the role 90%); asked for a 30° turn
- sc8/G1-P091 @ 4.80 s: Y turned 61° from 3.6 yd/s keeping 97% of his speed through the whole cut (NFL p90 for the role 82%); asked for a 47° turn [play nullified by a penalty]
- sc8/G5-P062 @ 2.20 s: NB turned 61° from 3.5 yd/s keeping 89% of his speed through the whole cut (NFL p90 for the role 85%); asked for a 5° turn

