# Scorecard

Commit `c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0` · 6 games per arm over 2 leagues · seed 7 · 2026-10-23

Rendering measurement SHA256: `b717e89fe59dfb91f3123ec281168448f6d830d6d4cea27f1f41d1ac35e32b85`. Tables use this checkout's metric definitions; producer metadata below is preserved.

Read this as a diagnosis. A band says where our football looks unrealistic; it does not decide whether a mechanism is correct. A stat that moves the wrong way usually points at another mechanism to fix next. Ranges are 90% intervals from resampling whole games; "moved" means the interval excludes zero. A dash means an unavailable measurement or no eligible denominator.

## Timing and provenance

Per-game ms is elapsed time around simulateGame only; it excludes roster generation, record/probe work and worker startup. Sums of worker elapsed times are not collection wall time or CPU time.

**producer**: commit `c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0`; Node: v22.23.3; probes: missedBy, weird.

Workers requested: 4; peak concurrent worker processes: 4.

Collection elapsed: 87.5 s. CPU time: not collected in scorecard records.

- current: 46.9 s elapsed per game; worker processes: 4
- current film weirdness detectors: 569 ms per game, 1.2% of the elapsed time (inside it, not extra)
- engineSha256: 3e0bdcf720c1ba1df51848b48c6faece48e0860b43e956de1ad6ef372540f7a1
- measurementSha256: b717e89fe59dfb91f3123ec281168448f6d830d6d4cea27f1f41d1ac35e32b85
- lockfileSha256: cee32ba14d404c05dff4e8e3b4506bc1ea1e1afbfd40b35461511e7ff8fdb98f
- platform: linux
- arch: x64
- cpuModel: AMD EPYC 9V74 80-Core Processor
- cpuQuotaCores: 4
- execution: node --import tsx
- current resolved engine switches: `{"AGAP_ALIGN":true,"ANCHOR_SPLIT":true,"ARM_PRESS":true,"BACK_BLOCK":true,"BLOCKED_REACH":true,"BOX_ALIGN":true,"CF_FLOW":null,"CLIMB_INTERCEPT":true,"CLIMB_PLAN":true,"COVER_CALL":true,"DEEP_NO_FORCE":false,"DEF_ALIGN":true,"DEF_GETOFF":1,"DEF_PACKAGE":true,"DEUCE":true,"DL_ANCHOR":true,"DL_CHASE":true,"DL_FIGHT":false,"DL_FLATTEN":true,"DL_FLATTEN_WON":true,"DL_FLOW":true,"DL_HANDS":false,"DL_SQUEEZE":true,"FLOW_READ":true,"FLOW_RELEASE":true,"FORCE_BOUNCE":true,"FRONT_ALIGN":true,"FRONT_MENU":true,"FRONT_STRENGTH":true,"GAIT_STEP":0,"GRIP_HOLD":true,"GROUNDING_FACTS":true,"HAND_FIGHT":false,"HAND_MOTOR":false,"HOLD_LEVERAGE":true,"HOLD_SUBSTEPS":0,"IN_STRIDE_CATCH":false,"KEEPER_TORSO":true,"LB_LANDMARK":true,"LB_PLAN":true,"LEG_BRACE":false,"LEVER_FACING":true,"LIVE_AIM":true,"LIVE_GAPS":true,"MOTION":true,"MOTION_CHECK":true,"OL_SPLITS":true,"OL_STAGGER":true,"PAD_LEVERAGE":true,"PASS_FEEL":true,"PASS_FIRST":true,"PASS_KICK":true,"PASS_SINK":false,"PRESSURE_CALL":true,"PULL_CUE":false,"PULL_EARLY":true,"PULL_PLAN":false,"PULL_READ":true,"PULL_STEP":false,"PURSUE_AROUND":true,"REACH_CONTACT":false,"READ_EYES":true,"READ_RISK_TRACE":false,"ROUTE_CLEAR":true,"RUN_ANCHOR":true,"RUN_CONTACT_COMPONENTS":true,"RUN_CONTACT_TRACK":false,"RUN_FEEL":true,"RUN_HANDS":false,"RUN_READ":false,"RUN_READ_TURN":false,"SAFETY_TEMPO":true,"SCRAPE":true,"SHED_PHYSICAL":true,"SHED_PURSUE":true,"SHELL_SHOW":true,"SHORT_PACKAGE":true,"SNAP_REACT":true,"STALK_CLAIM":true,"STALK_CUSHION":true,"STRETCH_MESH":true,"STRETCH_REACH":true,"TACKLE_ROLL":false,"TACKLE_TOUCH":false,"THREAT_READ":true,"TIP_AWAY":true,"WRAP_BIND":false,"WR_ALIGN":true,"ZONE_FLOW":true}`


## Metrics

| Metric | Sim | 90% range | NFL band | vs band |
| --- | --- | --- | --- | --- |
| Points / team-game | 38.08 | 30.75 to 45.50 | 21–23.5 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Scrimmage plays / team-game | 66.83 | 65.50 to 68.17 | 61–65 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Total yards / team-game | 427.83 | 379.85 to 475.58 | 320–345 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Pass rate (dropbacks / plays) | 66.3% | 62.4% to 70.6% | 54.43–66.33% (data/reviews/nflverse/reference.json#teamSeasons[].dropbackShare.percent (team-season p10–p90; 2dp)) | HIGH |
| Completion % | 60.2% | 55.5% to 64.3% | 60.59–68.09% (data/reviews/nflverse/reference.json#teamSeasonRanges.completion (team-season p10–p90; 2dp)) | LOW |
| Yards / attempt | 9.54 | 8.07 to 11.02 | 6.35–7.89 (data/reviews/nflverse/reference.json#teamSeasons[]: completionYards.mean * completion.count / throws (team-season p10–p90; 2dp)) | HIGH |
| Sack rate (per dropback) | 8.1% | 7.0% to 9.2% | 4.61–9.36% (data/reviews/nflverse/reference.json#teamSeasonRanges.sackPerDropback (team-season p10–p90; 2dp)) | OK |
| INT rate | 5.4% | 4.0% to 6.6% | 1.47–3.15% (data/reviews/nflverse/reference.json#teamSeasonRanges.interception (team-season p10–p90; 2dp)) | HIGH |
| Pass TD rate | 8.5% | 6.3% to 10.7% | 4–4.8% (unsourced: legacy scorecard estimate; no committed TD/attempt team-season range) | HIGH |
| 20+ yd completions / att | 14.8% | 11.7% to 17.9% | 6.66–11.08% (data/reviews/nflverse/reference.json#teamSeasonRanges.twentyYardCompletionPerThrow (team-season p10–p90; 2dp)) | HIGH |
| aDOT | 9.10 | 8.46 to 9.64 | 7.5–8.5 (unsourced: legacy scorecard estimate; reference throwAirYards includes throwaways excluded here) | HIGH |
| YAC / reception | 7.70 | 5.97 to 9.27 | 4.53–5.91 (data/reviews/nflverse/reference.json#teamSeasonRanges.meanCompletedYAC (team-season p10–p90; 2dp)) | HIGH |
| Time to throw (s) | 2.63 | 2.57 to 2.69 | 2.7–2.9 (unsourced: legacy scorecard estimate; no committed time-to-throw distribution) | LOW |
| Scramble rate | 7.7% | 5.3% to 9.6% | 2.18–7.32% (data/reviews/nflverse/reference.json#teamSeasonRanges.scramblePerDropback (team-season p10–p90; 2dp)) | HIGH |
| Separation at catch point (yd) | 3.43 | 3.18 to 3.72 | 2.8–3.2 (unsourced: NGS 2022–24; no committed cohort or team-season aggregate) | HIGH |
| Rush yards / carry | 4.93 | 3.93 to 5.93 | 3.7–4.83 (data/reviews/nflverse/reference.json#teamSeasons[].designedRun.yards.mean (team-season p10–p90; 2dp)) | HIGH |
| Run stuff rate (<=0) | 21.1% | 19.9% to 22.4% | 15.89–23.54% (data/reviews/nflverse/reference.json#teamSeasonRanges.stuffPerDesignedRun (team-season p10–p90; 2dp)) | OK |
| 10+ yd runs | 14.4% | 12.7% to 15.8% | 7.58–12.87% (data/reviews/nflverse/reference.json#teamSeasons[].designedRun.explosive.percent (team-season p10–p90; 2dp)) | HIGH |
| Runs of 20+ that reach 40 | 36.4% | 14.3% to 50.0% | 25–35% (unsourced: PR #190, BDB 2022; no committed team-season distribution) | HIGH |
| Yards before contact (runs) | 1.14 | 0.97 to 1.28 | 1.5–2.3 (unsourced: legacy scorecard estimate; NFL cohort and contact definition unverified) | LOW |
| Missed + broken tackles / play | 0.24 | 0.22 to 0.26 | 0.11–0.16 (unsourced: PFF, definition unknown) | HIGH |
| Failed tackle opportunities / play (unique defenders) | 0.15 | 0.14 to 0.16 | internal: unique failed defenders per official play; no NFL comparison band |  |
| 3rd-down conversion | 37.9% | 35.5% to 40.6% | 37–41% (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | OK |
| FG % | 100.0% | 100.0% to 100.0% | 83–87% (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| XP % | 100.0% | 100.0% to 100.0% | 94–97% (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Fumbles lost / team-game | 0.75 | 0.42 to 1.17 | 0.4–0.7 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Punts / team-game | 5.75 | 5.25 to 6.33 | 3.5–4.5 (unsourced: legacy scorecard estimate; waits on M1 game-layer.json) | HIGH |
| Accepted penalties / team-game | 3.92 | 3.17 to 4.75 | internal: accepted count, no qualified total band; compare types under docs/NFL_RULES.md |  |
| FG 18–29 yd % | 100.0% | 100.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| FG 30–39 yd % | 100.0% | 100.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| FG 40–49 yd % | 100.0% | 100.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| FG 50+ yd % | 100.0% | 100.0% to 100.0% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt gross average (box yards) | 47.78 | 46.18 to 49.58 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt net field-position average | 42.66 | 38.45 to 46.24 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Kickoff return average (recorded yards) | 26.12 | 24.06 to 28.20 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt return average (recorded yards) | 11.48 | 7.36 to 15.69 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Kickoff touchback % (regular kicks) | 23.3% | 17.3% to 28.2% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Punt touchback % | 2.9% | 0.0% to 5.4% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Fourth-down go % (outside Q4 last 2:30) | 6.6% | 4.2% to 8.9% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Fourth-down conversion % (all official attempts) | 20.0% | 0.0% to 36.4% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Two-point attempts / TD (retries once) | 14.3% | 8.8% to 18.5% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Drives / team-game (logged offensive possessions) | 16.42 | 15.67 to 17.33 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Offensive points / drive (including Try) | 2.24 | 1.90 to 2.55 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Red-zone TD % (box trips) | 61.4% | 54.8% to 70.6% | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Turnovers / team-game (box) | 2.75 | 2.00 to 3.42 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Missed tackles by DL / play | 0.02 | 0.01 to 0.03 | internal |  |
| Missed tackles by LB / play | 0.03 | 0.02 to 0.04 | internal |  |
| Missed tackles by CB / play | 0.02 | 0.02 to 0.03 | internal |  |
| Missed tackles by S / play | 0.01 | 0.01 to 0.01 | internal |  |
| Pre-snap teammate contact: plays with one or more (% of plays with pre-snap staging) | 0.0% | 0.0% to 0.0% | internal |  |
| Pre-snap teammate contact: events per 100 plays with pre-snap staging | 0.0 | 0.0 to 0.0 | internal |  |
| Pre-snap teammate contact with no motion called (control, expect 0): events per 100 plays with staging and no motion | 0.0 | 0.0 to 0.0 | internal |  |
| Pre-snap contact involving the motion man (% of pre-snap contact events) | — | — to — | internal |  |
| Defender turned from a nearby runner: plays with one or more (% of plays with a runner) | 10.5% | 8.4% to 12.5% | internal |  |
| Defender turned from a nearby runner: events per 100 plays with a runner | 12.2 | 9.8 to 14.6 | internal |  |
| Blocker on a man out of the play: plays with one or more (% of run plays with a runner) | 62.2% | 56.3% to 69.4% | internal |  |
| Blocker on a man out of the play: events per 100 run plays with a runner | 124.4 | 104.3 to 147.1 | internal |  |
| OL facing own backfield and moving back (% of OL frames) | 3.3% | 2.8% to 4.0% | internal |  |
| OL backpedaling facing own backfield: plays with one or more (% of plays) | 64.8% | 59.8% to 70.5% | internal |  |
| OL backpedaling facing own backfield: events per 100 plays | 114.3 | 102.2 to 130.6 | internal |  |
| Sharp turns with no speed loss (candidate; % of 60°+ turns) | 5.1% | 4.5% to 5.8% | internal |  |
| Sliding through a cut (candidate): events per 100 plays | 10.3 | 9.1 to 11.6 | internal |  |
| Accepted penalties / team-game: block_in_back | 0.17 | 0.00 to 0.50 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: false_start | 0.50 | 0.17 to 0.92 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: holding | 1.67 | 1.25 to 2.08 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: illegal_contact | 0.58 | 0.25 to 0.92 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: illegal_touching | 0.08 | 0.00 to 0.25 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: intentional_grounding | 0.25 | 0.08 to 0.42 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: neutral_zone_infraction | 0.17 | 0.00 to 0.33 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: offside | 0.33 | 0.17 to 0.50 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |
| Accepted penalties / team-game: roughing_passer | 0.17 | 0.00 to 0.33 | internal: no band yet; NFL ranges in data/reviews/nflverse/game-layer.json |  |

## Watch these first

Read the clips, not the averages: each line is a place in a simulated game that a rule flagged. A rule says where to look, never what number is right, and several of its constants are chosen, not sourced (docs/VALIDATION.md). Ids with an `sc<seed>/` prefix are this run's own games, not the film room's: the full list is in the events file next to the saved card, and `npm run weird -- <seed>` plays the film-room games so its ids match `npm run replay`.

**Pre-snap teammate contact**: 0 events in 6 games

- none

**Defender turned away from a nearby runner**: 69 events in 6 games

- sc7/G2-P059 @ 2.65 s: DE_W facing 171° from the runner (RB) at 2.1 yd for 1.40 s; asked for 171°
- sc7/G1-P029 @ 2.15 s: DE_W facing 180° from the runner (RB) at 1.1 yd for 1.35 s; asked for 178°
- sc7/G4-P160 @ 3.85 s: DE_S facing 128° from the runner (QB) at 2.4 yd for 1.30 s; asked for 130°

**Blocker on a man who is out of the play**: 326 events in 6 games

- sc7/G2-P076 @ 3.45 s: Z (stalk) on CB_S, 52.1 yd from the runner and moving away at 3.6 yd/s, while LB_M is free 0.7 yd from the runner, for 3.35 s
- sc7/G2-P076 @ 3.45 s: X (stalk) on CB_W, 13.1 yd from the runner and moving away at 4.6 yd/s, while LB_M is free 3.4 yd from the runner, for 2.10 s
- sc7/G5-P022 @ 1.75 s: LG (run-block) on DT_W, 6.5 yd from the runner and moving away at 0.7 yd/s, while LB_W is free 0.6 yd from the runner, for 1.50 s

**Lineman backpedaling while facing his own backfield**: 917 events in 6 games

- sc7/G6-P088 @ 1.50 s: RG facing 150° from downfield, moving back at 4.5 yd/s for 2.25 s (pass play)
- sc7/G5-P152 @ 1.75 s: RT facing 138° from downfield, moving back at 4.4 yd/s for 2.15 s (pass play)
- sc7/G5-P171 @ 1.45 s: LG facing 146° from downfield, moving back at 4.4 yd/s for 2.10 s (pass play)

**Sliding through a cut (candidate)**: 83 events in 6 games

- sc7/G6-P049 @ 4.30 s: H turned 60° from 3.9 yd/s keeping 100% of his speed through the whole cut (NFL p90 for the role 76%); asked for a 7° turn
- sc7/G6-P067 @ 2.50 s: Z turned 64° from 4.1 yd/s keeping 90% of his speed through the whole cut (NFL p90 for the role 81%); asked for a 8° turn
- sc7/G2-P098 @ 2.50 s: Y turned 68° from 3.3 yd/s keeping 100% of his speed through the whole cut (NFL p90 for the role 82%); asked for a 113° turn

