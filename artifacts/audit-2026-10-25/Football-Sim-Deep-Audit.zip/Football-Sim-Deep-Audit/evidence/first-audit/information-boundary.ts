import { HASH_LEFT_Y, CENTER_Y } from '../../src/core/field.ts';
import { Rng } from '../../src/core/rng.ts';
import { generateTeam, pickDefense, pickOffense } from '../../src/league/team.ts';
import { PASS_BY_ID, RUN_BY_ID } from '../../src/playbook/concepts.ts';
import { COVERAGE_BY_ID, FRONT_BY_ID } from '../../src/playbook/defense.ts';
import { FORMATION_BY_ID } from '../../src/playbook/formations.ts';
import { PlaySim } from '../../src/sim/playsim.ts';
import { pursueIfLive } from '../../src/sim/behaviors/defense.ts';
import { Recognition } from '../../src/sim/recognition.ts';
import { onBallCaught } from '../../src/sim/assign.ts';
import { RunBlocker } from '../../src/sim/behaviors/blocking.ts';

const home = generateTeam(new Rng(31), 'Home', 'HOM', { strength: .6 });
const away = generateTeam(new Rng(32), 'Away', 'AWY', { strength: .6 });
const formation = FORMATION_BY_ID.ace_12;
function setup() {
 const sim = new PlaySim({ offense: pickOffense(home, formation.personnel), defense: pickDefense(away, 'base43'),
  offCall: { formation, flip: false, kind: 'pass', pass: PASS_BY_ID.hitches, label: 'audit-boundary' },
  defCall: { personnel: 'base43', front: FRONT_BY_ID.over, coverage: COVERAGE_BY_ID.cover3, pressure: null, zoneStyle: 'match', label: 'c3' },
  los: 40, ballY: HASH_LEFT_Y, firstDownX: 50, seed: 77 });
 const d = sim.slot('DE_W')!;
 d.body.pos = {x: 43, y: HASH_LEFT_Y - 4}; d.body.vel = {x: 0, y: 0};
 d.readAt = 0; d.snapReadyAt = 0;
 const rb = sim.slot('RB')!;
 const pictures = new Map(sim.agents.map(a => [a, {pos: {...a.pos}, vel: {...a.vel}, stance: null, facing: a.facing, carrying: a === sim.qb, age: .25}]));
 pictures.set(rb, {...pictures.get(rb)!, pos: {x: 44, y: HASH_LEFT_Y}, vel: {x: 4, y: 0}, carrying: false});
 let queries = 0;
 sim.see = (_observer, target) => { queries++; return structuredClone(pictures.get(target)!); };
 sim.t = 1.5;
 return {sim,d,rb,pictures,queries:()=>queries};
}
function pursuit(holder: 'QB'|'RB') {
 const {sim,d,rb,pictures} = setup();
 sim.ball = {kind: 'held', carrier: holder === 'QB' ? sim.qb : rb};
 return {holder, pictures: [...pictures].map(([a,p])=>[a.slot,p]), command: pursueIfLive(sim,d)};
}
function recognition(handoffAt: number) {
 const {sim,d,pictures} = setup();
 sim.handoffAt = handoffAt;
 const recognition = new Recognition(d,sim,0);
 recognition.update(d,sim);
 return {handoffAt, probability: recognition.pPass(), read: recognition.read,
  pictures: [...pictures].map(([a,p])=>[a.slot,p])};
}
function caught() {
 const {sim,rb,queries} = setup();
 const before = sim.defense.map(a=>a.behavior.kind);
 const priorQueries = queries();
 onBallCaught(sim,rb);
 return {before,after:sim.defense.map(a=>a.behavior.kind),observationQueries:queries()-priorQueries};
}
function firstThreat(hiddenDown: boolean) {
 const sim = new PlaySim({ offense: pickOffense(home, '21'), defense: pickDefense(away, 'base43'),
  offCall: { formation: FORMATION_BY_ID.i_pro_21, flip: false, kind: 'run', run: RUN_BY_ID.iz_strong, label: 'audit-first-threat' },
  defCall: { personnel: 'base43', front: FRONT_BY_ID.over, coverage: COVERAGE_BY_ID.cover3, pressure: null, label: 'c3' },
  los: 40, ballY: CENTER_Y, firstDownX: 50, seed: 7 });
 for (const a of sim.agents) { a.body.pos = {x:80+a.idx*2,y:4}; a.body.vel = {x:0,y:0}; }
 const fb=sim.slot('F')!,rb=sim.slot('RB')!,fs=sim.slot('FS')!,mike=sim.slot('LB_M')!;
 rb.body.pos={x:37,y:CENTER_Y};fb.body.pos={x:40.5,y:CENTER_Y+.4};fs.body.pos={x:47,y:CENTER_Y+1};mike.body.pos={x:41.5,y:CENTER_Y};
 sim.qb.body.pos={x:34,y:CENTER_Y+3};
 const pictures = new Map(sim.agents.map(a=>[a,{pos:{...a.pos},vel:{...a.vel},facing:a.facing,stance:null,pose:'up' as const,age:.2,carrying:a===rb}]));
 pictures.get(rb)!.vel={x:5,y:0};pictures.get(fs)!.vel={x:1,y:0};pictures.get(mike)!.vel={x:-2,y:0};
 sim.see=(_observer,target)=>structuredClone(pictures.get(target)!);
 if(hiddenDown) mike.body.support!.state='down';
 const lead=new RunBlocker({kind:'lead',target:fs,drive:{x:1,y:0}});fb.behavior=lead;sim.t=1.8;
 lead.update(fb,sim);
 return {target:lead.target?.slot,pictures:[...pictures].map(([a,p])=>[a.slot,p])};
}
const p0=pursuit('QB'),p1=pursuit('RB'),r0=recognition(-1),r1=recognition(.5);
const f0=firstThreat(false),f1=firstThreat(true);
console.log(JSON.stringify({source:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',fixture:'rosters 31/32; pursuit/recognition: seed 77 ace12 hitches vs cover3; first-threat: seed 7 i_pro21 inside zone vs cover3',
 pursuit:{sameSuppliedPictures:JSON.stringify(p0.pictures)===JSON.stringify(p1.pictures),qb:p0.command,rb:p1.command},
 recognition:{sameSuppliedPictures:JSON.stringify(r0.pictures)===JSON.stringify(r1.pictures),withoutHandoff:{p:r0.probability,read:r0.read},withHandoff:{p:r1.probability,read:r1.read}},
 catchTransition:caught(),
 firstThreat:{sameSuppliedPictures:JSON.stringify(f0.pictures)===JSON.stringify(f1.pictures),liveUpTarget:f0.target,hiddenDownTarget:f1.target}},null,2));
