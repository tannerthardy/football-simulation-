# Gridiron Engine: implementation roadmap

**Proposed for review, October 23, 2026.** Based on `develop@c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0`. Read [the review](REVIEW.md) for the evidence and diagnosis. These packages are proposals, not new assignments or changes to PLAN/GAPS. Preserve the existing coordinator and current lane agreements.

## 1. The outcome this plan is designed to deliver

The next milestone should be an **accountable football experiment**. Tanner can choose a supported concept and player profile, watch a believable rep, inspect what a player knew and why he acted, change one meaningful input, and see an understandable response. That is the useful foundation for both a simulator and a later management game.

Do not define success as “all numbers in NFL bands,” “all defenders get to the ball,” or “no surprising plays.” Define it as credible decisions and execution across the supported matchup space, with plausible failures and observable counters.

Five milestones organize the work:

| Milestone | Demonstration required | What it does not claim |
|---|---|---|
| M0: trustworthy evidence | Missing measurements cannot pass; current build/defaults and evidence are unmistakable; data checks run in CI | Engine realism |
| M1: explainable ordinary failures | A flagged player's knowledge, responsibility, request changes and execution can be inspected without a bespoke collector | Every reason is a correct reason |
| M2: disciplined adaptation | A narrow shared decision contract improves unfamiliar opportunity cases while preserving stay-with-assignment controls | General intelligence or universal policy replacement |
| M3: credible matchup experiments | Traits, selected lineups, supported concepts and opponent responses have understandable causal effects | Full NFL calibration or every formation/concept |
| M4: broader football product | Expand protection, calls, special teams and league only after lower layers and throughput support them | A date-certain finished simulator |

## 2. Cost, value and priority

Effort estimates are **focused engineering effort for a competent owner using agents, plus review**. They are not elapsed agent runtime or delivery guarantees. Research findings, coupling and data access can dominate the coding. Parallel work reduces elapsed time only when the shared interfaces remain stable. Do not sum every row into a promised project duration.

| ID | Work package | Existing base to reuse | Effort estimate | Value / difficulty | Priority |
|---|---|---|---|---|---|
| A01 | Repair evidence validity and wording | Mechanics guard, scorecard, Python tests | 0.5–2 days | Very high / easy | Immediate |
| A02 | Refresh current gap evidence and closure definitions | PLAN, GAPS, KNOWN_PROBLEMS | 0.5–1 day at review | High / easy | Immediate |
| A03 | Evaluate and use film scouts | #243 detectors, film IDs, `--expect` | 1–3 days initial setup | Very high / easy–moderate | Immediate |
| A04 | Selective decision and command-stage trace | Existing telemetry and observers | 3–7 days for one path | Very high / moderate | Next |
| A05 | Enforce player knowledge at a narrow policy boundary | `see`, perception buffer, acquired run-fit inputs | 3–7 days first slice; 3–6 weeks staged migration | Foundational / moderate–hard | Next |
| A06 | Stabilize coverage technique transitions | COV-6, SnapMind, coverage techniques | 3–7 days initial correction | Very high / moderate | Current coverage priority |
| A07 | Coherent dive/reach/acquisition | QB-3, existing grasp/support geometry | 3–10 days first slice | Very high / moderate–hard | Next defense/physics priority |
| A08 | Responsibility/opportunity pilot | #238 lead/climb reread, movement forecasts | 1–3 weeks including transfer | Very high / hard | After A04/A05 |
| A09 | Generalize to fit/rally and coverage | RunFit, CoverageJudgment | 2–4 weeks in stages | High / hard | Only after A08 |
| A10 | Reusable short causal experiments | Current restaging/native-prefix collectors | 3–7 days first two consumers | High / moderate | Supports A06–A08 |
| A11 | Trait and actual-lineup contracts | Existing roster audit, generator/selector | 3–7 days narrow slice | Very high for product / moderate | Alongside M2 |
| A12 | Small concept-installation family and transformations | Relative roles, call-integrity, structure | 1–2 weeks first family | High / moderate–hard | M3 |
| A13 | Real protection call and exchange family | G9, generic protection coordinator | 2–4 weeks initial supported family | Necessary / hard | After G5 boundary stable |
| A14 | Bounded common-point hand-law repair | Existing PHY-001 witnesses and experimental reference | 1–3 weeks initial investigation/review | Necessary / hard, transfer risk | Bounded physics slot |
| A15 | Measurement versions, missingness and holdouts | Shared NFL/sim operators, future exam plan | 2–5 days first slice | High / moderate | Before new calibration claims |
| A16 | Same-workload performance program | #204/#206/#218 profiles and optimizations | 2–5 days per targeted improvement; larger target uncertain | High / moderate to very hard | Continuous small budget |
| A17 | Bounded RNG isolation | Existing named forks, state/RNG traces | 1–3 weeks per bounded migration | Conditional / hard | Only if A10 insufficient |
| A18 | Adversarial matchup and exploit search | Supported scenario/call tools | 2–4 weeks after M3 | High later / hard | Later |
| A19 | Richer attention, memory and communication | Perception, eyes/keys, team conventions | 3–6 weeks staged first expansion | Potentially high / hard | Evidence-triggered |
| A20 | Full special teams, wider concepts and league | Hybrid game layer, current playbook/team model | Multi-month combined program | Necessary for end state / very hard | After M3 and speed |
| A21 | Full learned policies or anatomical solver expansion | Preserved research | Open-ended research | Unproved immediate return / very hard | Park unless a narrow need earns it |

The best inexpensive work is A01–A04, plus a small trait-effect inventory within A11. The central architectural bet is A08, supported by A05 and A10. The expensive work most likely to be unavoidable is consistent information/coordination, real protection and concept installation, common contact geometry/laws, and conditional validation across players. A full learned 22-player brain is not currently necessary.

## 3. Sequence without opening six new workstreams

Use cycles, consistent with the current plan. The ranges below are planning budgets, not dates. Keep approximately three implementation lanes active unless Tanner deliberately adds another; the consulting audit's parallel readers are not a model for unrestricted shared-code implementation.

### Review and cycle 0: make the next decision trustworthy

**Tools:** A01 and A02, followed by A03. **Coverage:** continue already prioritized COV-6 diagnosis. **Defense/physics:** stage the QB-3 reach contract and its opposing reachable-dive case. Keep other candidate work with its existing owner/disposition. Do not merge held research to tidy the queue.

Exit: current source/evidence linked, false-pass guard fixed, collector validity visible, first short scout packet produced, and one precise question each for coverage and dive work. This should take a few focused days, not a large planning phase.

### Cycle 1: make failures explainable and repair demonstrated causes

Tools provides A04/A10 only to the two active football fixes. Coverage corrects selected mode transitions under A06. Defense/physics aligns reach/acquisition under A07. Instrumentation and behavior changes should be independently reviewable so a trace does not create the apparent improvement.

Exit: a real bad clip can be classified as acquisition, choice, command interference, or body/contact execution; the corresponding repair survives an opposing case and a small unfamiliar case. Keep currently valid hip flips and diving opportunities. Resolve uncertainty instead of automatically expanding games.

### Cycle 2: test the architectural bet

One lane owns A08 free lead/climb adaptation; tools supports the observation/experiment boundary, not a separate general platform. Use a lane slot freed by completed work. Another lane may close one A11 trait/lineup semantic issue. No mass controller migration yet.

Exit: the pilot beats the current policy on a predeclared reviewed transfer set without unjustified abandonment, hidden information, unexplained extra switches, or large runtime cost. If it does not, preserve the evidence and revise the hypothesis. A reasonable first budget is one to three engineering weeks, including evaluation.

### Cycle 3: earn generality

Transfer the same decision envelope to one second role under A09; use the user's fit-versus-rally complaint or COV-6 technique stability depending on remaining evidence. Start a small supported concept/trait experiment surface under A11/A12. Schedule A14 as a bounded law correction, with current football transfer controls rather than the whole old experimental stack.

Exit: two roles share a useful contract with fewer duplicated lifecycle rules; a user can make one meaningful player/concept intervention and understand the intermediate response. Failure to transfer is a reason to narrow the abstraction, not add more generic layers.

### Later cycles: broaden only after evidence and cost permit it

A13 protection calls and exchanges, wider A12 installation contracts, A15 data validity and independent transfer, A16 throughput, then A18 exploit search. A19 expands sensing only for specific deceptive/occluded/communication failures. A20 features get separate capability milestones. Do not promise management realism from credible scrimmage alone.

## 4. Implementation briefs for the highest-value work

### A01 — Make absent evidence impossible to certify

**Owner:** tools. **Dependencies:** none. **Starting files:** `scripts/mechanics/compare.py`, `scripts/scorecard/run.ts`, `.github/workflows/tests.yml`, `.github/workflows/scorecard.yml`.

Deliver explicit guard states: qualified match, qualified change, insufficient sample, missing metric, incompatible operator. Only a qualified match counts toward a “matches” total. Reuse the audit's empty-summary witness. Replace “noise” with “not resolved in this sample,” and “real moves” with “exploratory signals.” Surface numerator/denominator for rare rates. Treat all-success bootstrap ranges as conditional resampling summaries, not certainty about future rates.

Add fast offline Python tests to CI and relevant data/script path triggers. Separate collector/schema/comparison failure from a diagnostic football result. Preserve the rule that a bad NFL average does not automatically fail a PR.

**Acceptance:** empty and absent guarded metrics cannot print 12/12 match; adequate matching input still qualifies; insufficient/incompatible states are visible; normal football outputs and RNG are unchanged; tests run without raw downloads. Documentation wording needs only appropriate checks, not games. A meaningful observer or collector change uses existing neutrality controls.

**Risk/stop:** do not turn this into a new statistical framework. A very large rewrite is unnecessary to fix false assurance.

### A02 — Give each gap a current, meaningful exit condition

**Owner:** coordinator at review, tools prepares the concrete update. **Dependencies:** current source and evidence links.

Replace ambiguous “now” labels with a dated source/measurement pin. Distinguish merged mechanism, open candidate, partial repair and demonstrated gap closure. Keep historical tables explicitly historical. Review G1's unmatched tackle band and G6's invalid old penalty total; do not silently substitute a different benchmark as an approved goal.

For G1, use conditional opportunity stages plus distribution tails. For G3, distinguish acquisition/closing before catch, attainable arrival, and post-catch finish. For G2, separate formation/crease, assignment, first contact and breakout containment. Each exit condition should state what valid opposing football must survive.

**Acceptance:** a new agent can identify current trunk, active owner, exact evidence and next question from one entry. Plan/priority changes remain review decisions. No new live workboard or duplicate evidence archive.

### A03 — Turn existing scouts into a useful review service

**Owner:** tools, with rotating football-lane reviewer. **Dependencies:** #243 is already merged.

Sample uncapped alerts before worst-event truncation when assessing precision. Also draw ordinary plays independently. For each reviewed event store source/input identity, actor, first suspect time, selection method, verdict and uncertainty. Most metadata is automatic. Use the existing replay IDs; scorecard and film-room cohorts are different and their IDs must not be conflated.

Begin with 8–12 short clips for Tanner per cycle only after agents have triaged them. Include clear successes and false alarms, such as a far receiver unable to rescue an interior threat, a defender correctly retaining force, and a corner legitimately turning to run with a vertical. Review the existing slide rule as a candidate category, not biomechanical truth.

**Acceptance:** each nomination explains the visible concern and whether traces are needed; independent reviewed alerts produce useful/false/uncertain rates; an ordinary sample exposes at least the ability to record unflagged errors. Do not promise a recall percentage without labels for the relevant population. Preserve a small untouched label set for the next detector revision.

**Risk/stop:** if a detector generates more work than it saves, narrow its purpose or leave it as an exploratory query. Never tune player behavior directly against an alert count.

### A04 — Explain the first wrong request

**Owner:** tools plus the affected controller owner. **Dependencies:** one selected real failure.

Record a short buffer for selected actors: installed duty; current target/option; consumed observation and age; held belief; raw technique request; coverage/turn/contact/bond/spacing modifications; final request; achieved movement; and the stage's already-computed reason. Do not fabricate reasons after seeing the outcome. Reuse existing telemetry and flush selectively.

**Acceptance:** instrumentation on/off preserves native bodies, results and RNG; a coverage-turn witness and one contact/spacing witness can be localized to the right stage without a new collector; a counterexample where the original request was valid is correctly classified. Unknown rejected alternatives remain unknown until the policy records them.

**Cost gate:** measure overhead on the actual path. Trace only relevant actors/windows; store raw output in ignored artifacts. A large permanent trace of every player every tick is not required.

### A05 — Enforce personal knowledge before adding smarter policy

**Owner:** shared decision-interface owner, coordinated with defense/run/coverage. **Dependencies:** A04 helps diagnosis; tests can begin immediately.

Introduce a narrow immutable policy input: known instruction, self body/contact state, observed opponents/teammates, and acquired events. Start with first-threat eligibility and possession admission. Physics/legal state remains authoritative. Legitimate tactile and communicated facts receive explicit channels; teammate state does not become perfect knowledge merely because it is friendly.

Use the audit's four synthetic witnesses as starting points. For each, hold instruction, supplied observations, mind and random state fixed; alter hidden current location, possession, opponent assignment, down/recovery or engagement. The decision must stay fixed until a legitimate new cue is supplied. Then reveal the cue and show timely response. Test fake handoffs, unseen catches, loose balls and recovery, not just the happy path.

**Acceptance:** no hidden eligibility gate in migrated policies; no players permanently stuck after a real phase change; repeated old pictures do not add confidence; policy code cannot access live opponent state through an escape hatch. Characterize the behavioral change rather than claiming this migration is trajectory-neutral.

**Risk/stop:** removing existing omniscience can expose late acquisition. Fix the acquisition contract deliberately; do not compensate by making everyone sprint faster or instantly revealing everything. Migrate consumers gradually.

### A06 — Stable coverage technique, without dulling athletic ability

**Owner:** coverage; this matches the recorded COV-6 priority. **Dependencies:** current yaw diagnostics, optionally A04.

Count transitions among square/QB-facing/hips-open/turn-and-run/carry-across and identify the first repeated toggle. Distinguish a changing receiver threat from oscillation caused by thresholds and fresh steering. Preserve the assigned responsibility through a technique change. Reuse existing cadence/commitment rather than adding unrelated timers.

**Acceptance:** fewer unsupported rapid toggles on matched ordinary reps; legitimate fast hip flips and deep turn/run survive; hidden/counterfactual cues cannot change the decision; body turn limits and capacities stay fixed during controller work. Validate the meaning and cohort of provider orientation before making a biomechanical claim. Report request and achieved turn separately.

**Risk/stop:** a global turn-speed nerf that merely hides repeated contradictory commands fails the intended contract. If the command is stable and the body still behaves incoherently, hand the specific execution witness to physics.

### A07 — Reachable diving tackles that can be understood on film

**Owner:** defense with physics sign-off. **Dependencies:** agreed geometry/units.

Specify body reference points, standing reach, lunge travel, dive trajectory, target limb location, acquisition time, and maximum held extension. An action may attempt contact; the physical geometry determines whether contact is available. Preserve stochastic technique variation only within a valid opportunity.

Create reachable, unreachable, receding and sideways/mirrored controls. Include the filed QB-3 clips and a back/receiver, so a QB-only patch cannot pass. Add a minimal reach/contact visualization showing the diver and actual attachment rather than only a distant ground dot.

**Acceptance:** no instantaneous hold outside reachable geometry; at least one justified reachable dive remains possible and carries a real miss/recovery cost; post-acquisition force and release remain coherent; no awarded tackle. Explain changes to missed/broken tackle accounting without tuning them to the PFF band.

**Risk/stop:** a gate eliminating all dives indicates overlapping or inconsistent action envelopes, not a completed fix. Avoid importing full anatomical gait to solve a simple acquisition inconsistency.

### A08 — Prove responsible adaptation on one role

**Owner:** run, using a shared decision contract reviewed by defense/coverage. **Dependencies:** A04/A05 and a small A10 runner.

Scope: free climbing linemen and lead backs. Preserve unrelated stalk, kick/trap, hand physics and capacities. Represent original purpose, acquired runner, current threat, useful alternatives, obligation cost, switching margin, and termination/interrupt evidence. Compare current `rereadThreat` with a small attainable-interception/threat-time assessment. Reuse trustworthy movement forecasts; do not treat a free-motion preview as a contact oracle.

Candidate actions can be continue, adjust fit, collect a new threat or recover. Do not make every player solve every job. Avoid a weighted “football IQ” score whose terms cannot be inspected. If a score is used, expose each meaningful term and use independently reviewed scenario orderings; a threshold is an engineering approximation, not a measured coaching law.

**Predeclared paired cases:**

| Change one fact | Desired distinction |
|---|---|
| Old defender harmless / on cutback path | Leave versus retain |
| New threat closing / moving away | Threat time beats proximity |
| Teammate nearby and capable / nearby but blocked or retreating | Usable help beats distance |
| Visible fall / same hidden fall | Acquisition matters |
| Clear advantage / tiny changing advantage | Switch versus stable commitment |
| Candidate reachable / impossible before play ends | Help versus no futile chase |
| Correct cue / deceptive early cue | Fallible read without play-call oracle |
| Strong slow / light fast / smart late versus quick wrong read | Distinct causal strengths and failures |

Reserve a formation/concept, mirrored inputs and fresh players for transfer. Establish baseline disagreement and choose the minimum worthwhile improvement before viewing candidate transfer results. Do not invent a universal acceptable error rate in advance of defining the cases.

“Impossible before play ends” is an offline evaluation label. The player estimates threat and interception time from acquired motion and his own body; he must not know the future whistle or recorded ending. Likewise, an attempted action may fail because he misjudged reach, and physically possible fouls remain possible with discipline and enforcement. The physical engine constrains what actually occurs.

**Acceptance:** reduced clearly dominated choices and missed feasible opportunities; preserved essential duties; no hidden information; no unbounded target flapping; positive transfer with no special per-play exceptions; measured cost within a predeclared budget. Final gains may move either way if the decision/physics is coherent.

**Kill/revise:** two unsuccessful mechanism attempts; new formation-specific exceptions needed to pass transfer; improvement comes from privileged state; extra complexity explains no additional cases; or the supposed helpful alternative is physically unreachable. Report the failed hypothesis, not just another patch.

### A09 — Earn a common architecture across roles

**Owner:** next affected lane, shared interface owner preserves semantics. **Dependencies:** A08 succeeds.

Transfer to one second role: run-fit versus rally, or coverage responsibility versus help/technique. Keep role-specific options. Reuse only genuinely common pieces: observation identity, purpose, evidence for departure, feasible alternatives, commitment and trace. For run support, preserve force, cutback and roof exposure. For coverage, preserve uncapped verticals and uncertain teammate help.

**Acceptance:** a shared interface supports two different football purposes; less duplicated lifecycle logic; retained opposing wins and unfamiliar inputs; no framework-specific formation exceptions. If responsibilities need different semantics, keep them explicit rather than forcing a universal utility function.

### A10 — Short causal experiments before whole games

**Owner:** tools with one lane as first consumer. **Dependencies:** reuse existing collectors.

Build one reusable path for immutable roster/call/input identity, native prefix to a named event, optional narrow intervention, passive trace, local measures, and explicit end/censor state. Start with two existing cases; do not write a universal serializer. Preserve acquisition history rather than teleporting a player into an invalid fixture without labeling it synthetic.

**Acceptance:** native unmodified repeat matches; instrumentation is neutral; one intervention changes only its intended input before downstream consequences; failure is distinguishable from censored/unobserved. Whole games remain for composition and distribution transfer. A same seed is never described as a paired sequence after the games diverge.

**Risk/stop:** do not replay hundreds of prefixes or fresh rosters to answer a local command question. A10 should save work on A06–A08 immediately or be narrowed.

## 5. The next layer: making the simulator a credible experimental tool

### A11 — Traits and actual selected players

Build a small machine-readable map from every exposed trait to its intended channel and consumers. Begin with `leadBlock`, missing-versus-zero physical measurements, and one positional default/familiarity issue from the existing roster audit. Fix or explicitly defer each meaning. Ensure the playcaller and scheme-fit logic use the actual selected lineup rather than an unrelated best roster player or all roster OL.

Use fixed-lineup interventions to verify execution channels and fresh-generation/selection tests for generator changes. A better recognition trait should alter cue-to-action delay or interpretation, not maximum speed. A better lead technique should alter an identifiable fit/selection/control action, not award a block. Preserve correlations and physical tradeoffs; do not require every final play result to improve.

Exit for the first slice: each control in the declared initial archetype panel has a truthful meaning, a demonstrable intended channel, and a stated limitation. Other exposed traits are mapped as implemented, selection-only, uncertain or deferred. Broader validation is a later M3 milestone, not part of the 3–7-day estimate. This is essential before making archetype-vs-scheme claims beyond the tested panel.

### A12/A13 — Concepts, installations and protection

Declare a supported family first. Express required eligible roles, alignment/spacing, route timing, blocking/protection responsibilities and motion consequences. Return an explicit reason for unrepresentable combinations. Allow valid but tactically poor calls to fail for football reasons. Test mirrors, hashes, personnel substitutions and formation changes that the family claims to support.

For protection, install one recognizable slide/BOB-style family, Mike identification and back scan/exchange conventions using pre-snap information and acquired threats. Challenge bluff pressure, overload, twist and a teammate losing leverage. A free rusher can be correct if the call sacrifices him or nobody can recover; the acceptance criterion is the reason, not zero free rushers or a target sack rate.

Exit: a reviewer can explain who owns each danger, when ownership transfers, and why a supported matchup wins or loses. Do not claim every concept works from every formation by silently filling absent roles.

### A14 — Correct contact law without importing the research stack

Take the current production angular-momentum witness and the relevant historical common-point failure controls. Isolate the minimal law correction, with proper force point, reaction torque, work and shared budgets. Temporal refinement tests law integration; it does not replace the law contract. Review current loaded football contacts and useful opposing cases before adoption.

Exit: the reproduced conservation defect is repaired, historical blockers are explicitly resolved or remain excluded, current relevant contacts preserve coherent behavior, and incremental production cost is measured. A local experimental table alone is not promotion evidence. If ordinary-football impact is unknown, measure a bounded representative exposure rather than launching a general solver project.

### A15 — Data validity and independent tests

Version measurement semantics per family, not only pressure. Preserve missing/imputed samples so derivative/contact windows cannot silently treat carried-forward coordinates as valid. First census actual missingness; do not assert material bias without it. Reprocess saved common-format plays where possible rather than redownloading everything.

Preserve 2026 weeks 10–18 as the planned future rushing exam. Predeclare any new passing/special-teams queries before looking at those weeks. A future holdout does not replace today's small independent transfer set. Once a set influences tuning, it becomes development evidence; reserve another for the next claim.

Exit: incompatible operators and invalid exposure cannot certify agreement; coverage/missingness and population scope remain visible; learning from inspected data is labeled honestly.

### A16/A17 — Faster experiments with honest randomness

Profile the actual supported production workload and report CPU, elapsed, workers, source and completed work separately. Start with exact-execution allocation/storage wins, expensive observer work, and reuse of compatible outputs. Do not lower physics resolution and call the resulting changed game “the same workload” without behavior/law tolerances.

Only pursue actor/subsystem/event-indexed RNG isolation if shared draw shifts still prevent important diagnoses after A10. Named forks already exist; preserve purposeful correlations and document semantic changes. Same random numbers cannot make divergent causal states equivalent. Retain both old/new source identities and replay validity during migration.

Exit: a useful experiment is cheaper for the same meaning and completed workload. The five-second target remains a measured engineering goal, not an excuse to suppress physics or skip observations.

## 6. Long-term research and expansion

**A18, exploit scouting:** run supported concept/archetype matchups with fixed budgets, independent seeds and known counters. Search for strategies that win across implausibly broad conditions. Classify each as legitimate mismatch, missing counter/cost, bad information, movement exploit, contact exploit, or measurement error. A counter must operate through represented football; no equal-win-rate balancing. Use adversarial search as a bug finder before a teacher.

**A19, attention/communication:** add explicit key, glance, memory, uncertainty and communicated-intent channels when deceptive plays or failed exchanges demonstrate the need. Keep total cue-to-action timing measurable. Body facing is not gaze, and a sophisticated vision cone is not automatically more accurate. A coarse, testable sensing model may be enough for many roles.

**A20, broader football:** treat full kick coverage/returns, expanded screens/RPOs/short yardage, coaching familiarity, roster evolution and league rules as separate vertical slices. Each needs an honest supported-capability boundary and its own causal tests. Start management features after controlled experiments work and simulation speed supports the workload.

**A21, learned policy/extra anatomy:** retain research but require a concrete failure that the existing abstraction cannot express, a credible source of supervision or objective, a bounded action/observation space, an opposing control and a production cost budget. Per-tick LLMs, full 22-player reinforcement learning and anatomical feet are not prerequisites for M2/M3. Do not fund them merely because “intelligence” or “physics” sounds fundamental.

## 7. Review rules and the user's role

Use this small decision record for material behavior work:

1. **Claim:** the specific wrong mechanism and what replaces it.
2. **Evidence:** the same-input intermediate change and strongest opposing control.
3. **Limits:** material adverse or unknown effects, including changed random histories.
4. **Decision:** adopt within supported scope, revise, wait on a named dependency, or park with a next discriminating question.

This is not a mandatory multi-page worksheet. Reuse compatible evidence. No automatic 2→8→16→32→games staircase. A new check needs a decision it could change. A failed attempt counts as useful information when it narrows the cause; two failed attempts mean re-diagnose.

The coordinator owns priority and shared-boundary decisions. Football lanes own coaching semantics; tools owns observation/evaluation integrity; physics owns law and execution constraints. A shared decision-interface owner prevents each lane inventing its own meaning of possession, threat, commitment and handoff. Keep that role narrow—it should resolve interfaces, not become a bottleneck for every local fix.

Tanner should primarily judge ambiguous football clips and choose product priorities. Agents should gather source evidence, trace causal stages, build opposing cases and propose the smallest repair. Where Tanner is unsure, record uncertainty and seek coaching evidence or an independent review. Do not force him to become the specification for every football situation.

At each review, inspect a few outcome measures for the development process: agent-first recurring defects found; ordinary unseen regressions; alert usefulness; time from clip to isolated cause; recurrence of the same defect family; and Tanner minutes per resolved decision. Use those to see whether the workflow is improving, not to create incentives for more tickets or fewer honest uncertainties.

## 8. The first assignments I would hand out

These are ready-to-scope briefs for the next review, not automatic dispatches:

**Tools:** “Repair the empty-mechanics false pass, distinguish collector validity from football diagnostics, run fast Python data checks in CI, and prepare a current evidence link for the gap review. Preserve games. Then instrument one COV-6 request chain using existing telemetry.”

**Coverage:** “On the current build, identify the dominant COV-6 technique toggle. Preserve physical turn capacity, fix the chosen request/transition, and prove a legitimate vertical turn/run and an unfamiliar counterexample. Use one causal trace before another broad campaign.”

**Defense/physics:** “Define one coherent standing/lunge/dive acquisition geometry for QB-3. Preserve a reachable dive and its miss/recovery cost; eliminate impossible immediate holds. Include a non-QB control and a visual contact explanation.”

**Next freed lane, run:** “Build on #238. First remove hidden eligibility dependence. Then test whether a small responsibility-and-reachable-threat policy improves free lead/climb decisions while retaining cutback/ownership duties. Reserve unfamiliar cases before tuning. Do not extend to all stalks or alter contact capacities.”

If these assignments succeed, the project will have more than a few repaired clips: it will have a cheaper way to discover causes and the first evidence that a shared decision model can generalize. That is the condition for committing to the larger architectural work.
