import {World,type Intent} from '../../src/physics/world.js';
import {supportParams} from '../../src/physics/support.js';
import type {Body} from '../../src/physics/kinematics.js';
const body=(mass:number,x:number):Body=>({pos:{x,y:0},vel:{x:.7,y:0},facing:0,spin:0,energy:1,profile:{massKg:mass,radius:.3,reach:1,heightYd:2.05,vmax:9,tau:1.3,brake:6,lateral:6,turnRate:8,backpedal:.6,shuffle:.55,maxCatchHeight:3,reactReach:2.6,reactionTime:.25,power:mass,balance:.5,stepSpeed:3.4,getUp:.9}});
const angular=(bs:Body[])=>bs.reduce((s,b)=>s+b.profile.massKg*(b.pos.x*b.vel.y-b.pos.y*b.vel.x)+supportParams(b.profile).yawInertia*(b.spin??0),0);
const rows=[];
for(const handContact of ['center','patch'] as const) for(const substeps of [12,48]) {
 const bs=[body(100,0),body(80,.9)];bs[1].vel.y=2;
 const w=new World(bs,{handContact,substeps}),before=angular(bs);w.joints.push({kind:'hands',a:bs[0],b:bs[1],extension:.9,push:0,hold:0,steer:20});
 const r=w.step(bs.map(()=>({vel:{x:0,y:0},free:true})),.05);
 rows.push({handContact,substeps,angularChange:angular(bs)-before,planarEnergyResidual:r.work.residual,groundImpulse:r.groundImpulse,groundYawImpulse:r.groundYawImpulse,contacts:r.contacts.length,handWork:r.work.hands});
}
console.log(JSON.stringify({sha:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',description:'Existing hand-angular-transfer test body shape, free two-body passive steering, .05 s; no ground or torso contact',rows},null,2));
