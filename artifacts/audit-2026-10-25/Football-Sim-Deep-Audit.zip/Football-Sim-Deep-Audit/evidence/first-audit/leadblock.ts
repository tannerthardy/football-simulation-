import { createHash } from 'node:crypto';
import { Rng } from '../../src/core/rng.js';
import { HASH_LEFT_Y } from '../../src/core/field.js';
import { generateTeam,pickDefense,pickOffense } from '../../src/league/team.js';
import { RUN_BY_ID,PASS_BY_ID } from '../../src/playbook/concepts.js';
import { COVERAGE_BY_ID,FRONT_BY_ID } from '../../src/playbook/defense.js';
import { FORMATION_BY_ID } from '../../src/playbook/formations.js';
import { PlaySim,type PlaySetup } from '../../src/sim/playsim.js';
const hash=(x:unknown)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const rng=new Rng(8675309),o=generateTeam(rng,'Audit O','AUDO',{strength:.55}),d=generateTeam(rng,'Audit D','AUDD',{strength:.55});
const offense=pickOffense(o,'21'),defense=pickDefense(d,'base43');
const results=[];
for(const concept of ['power','counter']) {
 const arms=[];
 for(const rating of [1,99]) {
  const own=structuredClone(offense); for(const p of Object.values(own)) p.ratings.leadBlock=rating;
  const setup:PlaySetup={offense:own,defense:structuredClone(defense),offCall:{formation:FORMATION_BY_ID.i_pro_21,flip:false,kind:'run',run:RUN_BY_ID[concept],label:concept},defCall:{personnel:'base43',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:'cover3'},los:35,ballY:HASH_LEFT_Y,firstDownX:45,seed:42,record:true,recordLevel:'full',audibles:false};
  const sim=new PlaySim(setup);const r=sim.run();
  arms.push({rating,hash:hash({r,bodies:sim.agents.map(a=>a.body),rng:sim.rng}),outcome:r.outcome,yards:r.yards,seconds:r.duration});
 }
 results.push({concept,arms,identical:arms[0].hash===arms[1].hash});
}
console.log(JSON.stringify({sha:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',description:'Fixed selected lineups; all offensive leadBlock ratings set to 1 or 99; no re-selection; two complete plays in each arm',results},null,2));
