# Sim vs NFL mechanisms (c4a03f6)

NFL 2022: Big Data Bowl 2025: 2022 regular season weeks 1,2,3,4,5,6,7,8,9 (all 22 players) (5462 runs, 9713 dropbacks).  
NFL 2017 (replication): Big Data Bowl 2019: 2017 regular season weeks 1-6, 91 games (all 22 players; carrier and target inferred).  
NFL 2021 (replication): Big Data Bowl 2023: 2021 regular season weeks 1,2,3,4,5,6,7,8 (dropbacks, tracking to just after the throw).  
NFL 2023 (replication): Big Data Bowl 2026: 2023 regular season weeks 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18 (ball in the air, selected players).  
Sim: audit: intentionally empty synthetic sim, no simulation executed (0 runs, 0 dropbacks).

Values are median [25th, 75th percentile] 90th percentile; rates are shares.
Shift and tail: sim median and 90th percentile minus the 2022 NFL's, in 2022 NFL interquartile ranges.
Pressure operators: NFL `legacy/unspecified`, sim `None`. Different versions are not compared.

## Movement (every player, every play)

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| move.max_accel.DB | 4.24 [3.43, 5.05] 5.88 | 4.53 [3.54, 6.89] 9.74 | 3.95 [3.16, 4.88] 5.71 | - | n=0 | | | too few |
| move.max_accel.DL | 3.73 [3.07, 4.42] 5.05 | 6.64 [4.03, 9.21] 10.68 | 3.99 [3.33, 4.75] 5.33 | - | n=0 | | | too few |
| move.max_accel.LB | 4.42 [3.65, 5.25] 5.91 | 5.15 [3.85, 8.22] 10.29 | 4.48 [3.67, 5.33] 5.96 | - | n=0 | | | too few |
| move.max_accel.OL | 3.11 [2.54, 3.72] 4.37 | 7.12 [5.34, 8.47] 9.64 | 2.94 [2.48, 3.54] 4.18 | - | n=0 | | | too few |
| move.max_accel.QB | 3.84 [3.12, 4.75] 5.73 | 8.06 [4.47, 9.76] 10.70 | 3.79 [3.12, 4.51] 5.59 | - | n=0 | | | too few |
| move.max_accel.RB | 5.02 [4.18, 5.81] 6.56 | 9.90 [7.45, 11.39] 12.37 | 4.87 [3.92, 5.76] 6.52 | - | n=0 | | | too few |
| move.max_accel.TE | 4.75 [3.78, 5.62] 6.27 | 7.96 [4.48, 10.64] 11.88 | 5.13 [4.37, 5.83] 6.37 | - | n=0 | | | too few |
| move.max_accel.WR | 5.55 [4.62, 6.25] 6.82 | 11.05 [9.36, 12.03] 12.88 | 5.76 [5.11, 6.37] 6.90 | - | n=0 | | | too few |
| move.max_decel.DB | 3.12 [2.09, 4.37] 5.56 | 3.15 [2.18, 4.34] 5.48 | 1.67 [0.62, 3.11] 4.66 | - | n=0 | | | too few |
| move.max_decel.DL | 2.79 [2.09, 3.67] 4.51 | 3.63 [2.79, 4.49] 5.41 | 2.57 [1.79, 3.46] 4.41 | - | n=0 | | | too few |
| move.max_decel.LB | 3.39 [2.48, 4.46] 5.52 | 3.57 [2.60, 4.55] 5.63 | 2.65 [1.45, 3.92] 5.04 | - | n=0 | | | too few |
| move.max_decel.OL | 2.53 [1.93, 3.16] 3.86 | 3.39 [2.78, 4.13] 4.87 | 2.18 [1.52, 2.88] 3.64 | - | n=0 | | | too few |
| move.max_decel.QB | 2.92 [2.17, 3.75] 4.58 | 3.34 [2.58, 4.35] 5.13 | 3.08 [2.17, 3.94] 4.90 | - | n=0 | | | too few |
| move.max_decel.RB | 3.60 [2.69, 4.53] 5.50 | 3.86 [3.02, 4.88] 5.93 | 2.06 [1.04, 3.19] 4.42 | - | n=0 | | | too few |
| move.max_decel.TE | 3.19 [2.34, 4.25] 5.27 | 3.41 [2.57, 4.37] 5.31 | 2.01 [0.84, 3.54] 5.00 | - | n=0 | | | too few |
| move.max_decel.WR | 3.60 [2.59, 4.68] 5.82 | 3.64 [2.74, 4.70] 5.82 | 1.88 [0.62, 3.93] 5.78 | - | n=0 | | | too few |
| move.max_speed.DB | 5.49 [4.37, 6.61] 7.70 | 5.38 [4.37, 6.52] 7.57 | 5.15 [4.07, 6.37] 7.46 | - | n=0 | | | too few |
| move.max_speed.DL | 4.07 [3.25, 5.06] 6.02 | 4.37 [3.58, 5.22] 6.02 | 3.90 [3.16, 4.76] 5.59 | - | n=0 | | | too few |
| move.max_speed.LB | 5.06 [4.03, 6.13] 7.16 | 4.98 [4.03, 6.01] 7.04 | 4.74 [3.90, 5.62] 6.54 | - | n=0 | | | too few |
| move.max_speed.OL | 3.26 [2.61, 4.03] 4.81 | 3.61 [3.05, 4.26] 4.96 | 3.01 [2.46, 3.54] 4.07 | - | n=0 | | | too few |
| move.max_speed.QB | 3.54 [2.51, 4.60] 5.52 | 4.03 [3.09, 4.61] 5.15 | 3.01 [2.50, 4.53] 6.29 | - | n=0 | | | too few |
| move.max_speed.RB | 5.64 [4.70, 6.66] 7.57 | 5.49 [4.70, 6.43] 7.46 | 5.53 [4.27, 6.58] 7.32 | - | n=0 | | | too few |
| move.max_speed.TE | 5.27 [4.00, 6.58] 7.50 | 5.10 [3.91, 6.37] 7.29 | 6.17 [4.92, 7.07] 7.78 | - | n=0 | | | too few |
| move.max_speed.WR | 6.45 [5.03, 7.59] 8.40 | 6.25 [5.15, 7.36] 8.31 | 7.15 [6.15, 8.00] 8.68 | - | n=0 | | | too few |

## Runs

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| run.box_count | 7.00 [6.00, 7.00] 8.00 | 7.00 [6.00, 7.00] 8.00 | - | - | n=0 | | | too few |
| run.carrier_cross_los_s | 2.50 [2.30, 2.80] 3.30 | 2.40 [2.10, 2.80] 3.30 | - | - | n=0 | | | too few |
| run.carrier_peak_speed_before_contact | 5.67 [4.95, 6.60] 7.75 | 5.48 [4.80, 6.39] 7.67 | - | - | n=0 | | | too few |
| run.defenders_within_2yd_at_end | 3.00 [2.00, 4.00] 5.00 | 3.00 [2.00, 4.00] 5.00 | - | - | n=0 | | | too few |
| run.engaged_dl_driven_back_1s | -0.60 [-0.90, -0.30] -0.10 | -0.70 [-1.10, -0.30] 0.00 | - | - | n=0 | | | too few |
| run.engaged_dl_driven_back_2s | -0.50 [-1.40, 0.20] 0.70 | -0.60 [-1.50, 0.10] 0.70 | - | - | n=0 | | | too few |
| run.engaged_dl_driven_back_3s | 0.20 [-0.90, 1.20] 2.00 | 0.00 [-1.10, 1.10] 2.00 | - | - | n=0 | | | too few |
| run.first_contact_s | 2.70 [2.40, 3.20] 3.90 | 2.70 [2.30, 3.30] 4.10 | - | - | n=0 | | | too few |
| run.handoff_s | 1.30 [1.20, 1.40] 1.50 | 1.30 [1.10, 1.40] 1.50 | - | - | n=0 | | | too few |
| run.max_engaged_dl_driven_back_3s | 1.00 [0.10, 1.80] 2.50 | 0.80 [-0.20, 1.70] 2.50 | - | - | n=0 | | | too few |
| run.ol_forward_1s | 0.40 [0.20, 0.58] 0.76 | 0.40 [0.16, 0.64] 0.86 | - | - | n=0 | | | too few |
| run.yards | 3.00 [1.00, 6.00] 10.00 | 3.00 [1.00, 5.00] 9.00 | - | - | n=0 | | | too few |
| run.yards_after_contact | 2.40 [1.30, 3.80] 6.20 | 1.90 [0.90, 3.30] 5.30 | - | - | n=0 | | | too few |
| run.yards_before_contact | 0.60 [-0.80, 2.20] 4.70 | 0.50 [-0.90, 2.20] 5.00 | - | - | n=0 | | | too few |

## Contact and tackling

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| contact.catch.approach_headon | 9.9% | 8.7% | - | - | n=0 | | | too few |
| contact.catch.broke_contact | 12.5% | 9.8% | - | - | n=0 | | | too few |
| contact.catch.carrier_speed_0_5s_after | 3.88 [2.55, 5.37] 6.66 | 3.54 [2.24, 4.85] 6.17 | - | - | n=0 | | | too few |
| contact.catch.carrier_speed_at_contact | 4.85 [3.26, 6.39] 7.46 | 4.47 [2.85, 6.01] 7.11 | - | - | n=0 | | | too few |
| contact.catch.contact_to_whistle_s | 0.90 [0.60, 1.60] 2.40 | 0.80 [0.50, 1.30] 2.10 | - | - | n=0 | | | too few |
| contact.catch.tackler_speed_at_contact | 4.83 [3.29, 6.50] 7.67 | 4.56 [3.01, 6.13] 7.43 | - | - | n=0 | | | too few |
| contact.catch.yards_after_contact | 1.60 [0.40, 3.30] 6.10 | 1.40 [0.20, 3.30] 9.70 | - | - | n=0 | | | too few |
| contact.run.approach_headon | 9.0% | 8.7% | - | - | n=0 | | | too few |
| contact.run.broke_contact | 12.5% | 8.9% | - | - | n=0 | | | too few |
| contact.run.carrier_speed_0_5s_after | 3.25 [2.15, 4.47] 5.82 | 3.02 [2.02, 4.25] 5.41 | - | - | n=0 | | | too few |
| contact.run.carrier_speed_at_contact | 4.51 [3.54, 5.62] 6.80 | 4.19 [3.20, 5.27] 6.40 | - | - | n=0 | | | too few |
| contact.run.contact_to_whistle_s | 1.40 [0.90, 2.10] 2.90 | 1.20 [0.80, 1.80] 2.60 | - | - | n=0 | | | too few |
| contact.run.tackler_speed_at_contact | 2.85 [1.80, 4.37] 5.84 | 2.85 [1.77, 4.26] 5.70 | - | - | n=0 | | | too few |
| contact.run.yards_after_contact | 2.40 [1.30, 3.80] 6.20 | 1.90 [0.90, 3.30] 5.30 | - | - | n=0 | | | too few |

## Blocks (labeled pairs)

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| block.pass.defender_depth_1s | 0.60 [-0.00, 1.10] 1.60 | - | 0.70 [0.10, 1.20] 1.70 | - | n=0 | | | too few |
| block.pass.defender_depth_2s | 3.10 [1.90, 4.40] 5.60 | - | 3.20 [2.10, 4.50] 5.80 | - | n=0 | | | too few |
| block.pass.still_engaged_2s | 82.4% | - | 83.1% | - | n=0 | | | too few |

## Pass protection and rush

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| pass.box_rusher_depth_2s | 2.60 [1.30, 3.60] 4.50 | 2.50 [1.30, 3.60] 4.60 | 2.70 [1.60, 3.70] 4.50 | - | n=0 | | | too few |
| pass.box_rusher_speed_0_5s | 1.77 [1.27, 2.24] 2.55 | 2.14 [1.27, 3.01] 3.81 | 1.77 [1.35, 2.14] 2.50 | - | n=0 | | | too few |
| pass.nearest_defender_to_qb_at_throw | 2.96 [2.19, 3.80] 4.69 | 2.83 [2.08, 3.64] 4.48 | 2.86 [2.14, 3.64] 4.42 | - | n=0 | | | too few |
| pass.ol_depth_given_2s | 3.04 [1.82, 3.60] 4.00 | 2.98 [1.74, 3.60] 4.06 | 3.16 [2.38, 3.62] 3.96 | - | n=0 | | | too few |
| pass.pressure_2yd_before_throw | 30.5% | 31.7% | 31.9% | - | n=0 | | | too few |
| pass.qb_depth_at_throw | 7.20 [6.10, 8.30] 9.40 | 6.80 [5.60, 7.80] 9.00 | 7.40 [6.50, 8.40] 9.50 | - | n=0 | | | too few |
| pass.rushers | 4.00 [4.00, 4.00] 5.00 | 4.00 [4.00, 5.00] 6.00 | 4.00 [4.00, 4.00] 5.00 | - | n=0 | | | too few |
| pass.time_to_pressure | 2.70 [2.30, 3.00] 3.50 | 2.50 [2.20, 2.90] 3.30 | 2.70 [2.40, 3.10] 3.60 | - | n=0 | | | too few |
| pass.time_to_throw | 2.60 [2.10, 3.20] 3.90 | 2.50 [2.00, 3.00] 3.80 | 2.70 [2.30, 3.30] 4.20 | - | n=0 | | | too few |

## Routes and catches

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| catch.defenders_within_5yd_at_catch | 1.00 [1.00, 2.00] 2.00 | 1.00 [1.00, 2.00] 2.00 | - | - | n=0 | | | too few |
| catch.depth | 4.70 [0.70, 9.40] 16.50 | 4.40 [-0.20, 9.20] 16.50 | - | - | n=0 | | | too few |
| catch.speed_at_catch | 4.80 [3.02, 6.33] 7.36 | 4.78 [2.92, 6.33] 7.40 | - | - | n=0 | | | too few |
| catch.yards_after_catch | 3.00 [0.50, 7.10] 12.50 | 3.20 [0.50, 7.90] 15.00 | - | - | n=0 | | | too few |
| route.separation_1.5s | 3.32 [1.97, 4.89] 6.14 | 2.92 [1.56, 4.68] 6.04 | 3.42 [2.01, 4.94] 6.21 | - | n=0 | | | too few |
| route.separation_2.5s | 2.45 [1.36, 3.72] 4.94 | 2.18 [1.21, 3.55] 4.90 | 2.36 [1.30, 3.67] 4.91 | - | n=0 | | | too few |
| route.target_depth_at_throw | 4.60 [1.00, 9.70] 14.20 | 3.90 [-0.50, 8.50] 13.10 | - | - | n=0 | | | too few |

## Ball in the air

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| air.defender_closing | 0.51 [-0.47, 1.66] 2.78 | 0.47 [-0.39, 1.58] 2.69 | - | 0.72 [-0.23, 2.04] 3.26 | n=0 | | | too few |
| air.separation_at_arrival | 3.14 [1.65, 5.22] 7.21 | 2.61 [1.26, 4.49] 6.52 | - | 2.40 [1.24, 4.12] 6.10 | n=0 | | | too few |
| air.separation_at_throw | 3.86 [2.28, 5.72] 7.62 | 3.40 [1.80, 5.14] 6.83 | - | 3.32 [1.84, 5.25] 7.24 | n=0 | | | too few |
| air.target_depth_at_arrival | 5.20 [1.50, 11.80] 18.60 | 5.00 [0.30, 11.20] 17.90 | - | 6.80 [3.80, 14.20] 21.80 | n=0 | | | too few |
| air.time | 0.80 [0.60, 1.00] 1.50 | 0.80 [0.60, 1.10] 1.50 | - | 1.00 [0.80, 1.40] 1.90 | n=0 | | | too few |

## Yards after contact by entry speed and tackle angle

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| contact.catch.yards_after_contact@behind | 1.60 [0.30, 3.40] 6.10 | 1.40 [0.20, 3.50] 10.10 | - | - | n=0 | | | too few |
| contact.catch.yards_after_contact@fast | 2.20 [0.70, 4.10] 7.40 | 1.90 [0.50, 4.00] 8.50 | - | - | n=0 | | | too few |
| contact.catch.yards_after_contact@headon | 1.40 [0.60, 3.00] 6.30 | 1.30 [0.30, 3.10] 6.90 | - | - | n=0 | | | too few |
| contact.catch.yards_after_contact@mid | 1.60 [0.40, 3.10] 5.60 | 1.40 [0.30, 3.00] 9.40 | - | - | n=0 | | | too few |
| contact.catch.yards_after_contact@side | 1.70 [0.50, 3.20] 6.20 | 1.30 [0.40, 3.00] 7.90 | - | - | n=0 | | | too few |
| contact.catch.yards_after_contact@slow | 0.80 [-0.10, 1.90] 4.20 | 0.70 [-0.10, 2.40] 11.40 | - | - | n=0 | | | too few |
| contact.run.yards_after_contact@behind | 2.60 [1.40, 4.00] 6.50 | 2.00 [1.00, 3.50] 5.50 | - | - | n=0 | | | too few |
| contact.run.yards_after_contact@fast | 3.60 [2.10, 5.90] 10.60 | 3.00 [1.50, 5.00] 8.00 | - | - | n=0 | | | too few |
| contact.run.yards_after_contact@headon | 2.00 [1.10, 3.70] 6.00 | 1.80 [0.80, 3.20] 6.10 | - | - | n=0 | | | too few |
| contact.run.yards_after_contact@mid | 2.30 [1.30, 3.40] 5.00 | 2.00 [1.10, 3.20] 4.80 | - | - | n=0 | | | too few |
| contact.run.yards_after_contact@side | 2.30 [1.20, 3.80] 6.50 | 1.80 [0.90, 3.10] 4.80 | - | - | n=0 | | | too few |
| contact.run.yards_after_contact@slow | 1.10 [0.50, 1.90] 3.00 | 0.90 [0.30, 1.80] 3.00 | - | - | n=0 | | | too few |

## Runs by concept family

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| inside_zone: run.handoff_s | 1.20 [1.10, 1.30] 1.40 | - | - | - | n=0 | | | too few |
| inside_zone: run.carrier_cross_los_s | 2.30 [2.10, 2.50] 2.70 | - | - | - | n=0 | | | too few |
| inside_zone: run.yards_before_contact | 0.70 [-0.40, 2.10] 4.00 | - | - | - | n=0 | | | too few |
| inside_zone: run.yards_after_contact | 2.20 [1.10, 3.40] 5.50 | - | - | - | n=0 | | | too few |
| inside_zone: run.max_engaged_dl_driven_back_3s | 1.10 [0.30, 1.90] 2.60 | - | - | - | n=0 | | | too few |
| inside_zone: contact.run.carrier_speed_0_5s_after | 2.85 [2.00, 3.95] 5.06 | - | - | - | n=0 | | | too few |
| inside_zone: run.yards | 3.00 [1.00, 5.00] 9.00 | - | - | - | n=0 | | | too few |
| outside_zone: run.handoff_s | 1.30 [1.20, 1.40] 1.50 | - | - | - | n=0 | | | too few |
| outside_zone: run.carrier_cross_los_s | 2.60 [2.40, 2.90] 3.30 | - | - | - | n=0 | | | too few |
| outside_zone: run.yards_before_contact | 0.40 [-1.10, 2.10] 4.40 | - | - | - | n=0 | | | too few |
| outside_zone: run.yards_after_contact | 2.60 [1.50, 3.90] 6.40 | - | - | - | n=0 | | | too few |
| outside_zone: run.max_engaged_dl_driven_back_3s | 1.00 [0.00, 1.90] 2.70 | - | - | - | n=0 | | | too few |
| outside_zone: contact.run.carrier_speed_0_5s_after | 3.55 [2.55, 4.72] 5.93 | - | - | - | n=0 | | | too few |
| outside_zone: run.yards | 3.00 [1.00, 6.00] 10.00 | - | - | - | n=0 | | | too few |
| gap_pull: run.handoff_s | 1.30 [1.20, 1.40] 1.50 | - | - | - | n=0 | | | too few |
| gap_pull: run.carrier_cross_los_s | 2.60 [2.30, 3.10] 3.60 | - | - | - | n=0 | | | too few |
| gap_pull: run.yards_before_contact | 0.70 [-0.90, 2.50] 5.30 | - | - | - | n=0 | | | too few |
| gap_pull: run.yards_after_contact | 2.50 [1.20, 4.30] 7.50 | - | - | - | n=0 | | | too few |
| gap_pull: run.max_engaged_dl_driven_back_3s | 0.80 [-0.20, 1.60] 2.40 | - | - | - | n=0 | | | too few |
| gap_pull: contact.run.carrier_speed_0_5s_after | 3.51 [2.31, 4.85] 6.52 | - | - | - | n=0 | | | too few |
| gap_pull: run.yards | 3.00 [1.00, 7.00] 12.00 | - | - | - | n=0 | | | too few |
| man_duo: run.handoff_s | 1.30 [1.20, 1.40] 1.50 | - | - | - | n=0 | | | too few |
| man_duo: run.carrier_cross_los_s | 2.40 [2.20, 2.60] 3.00 | - | - | - | n=0 | | | too few |
| man_duo: run.yards_before_contact | 0.50 [-0.60, 2.00] 3.90 | - | - | - | n=0 | | | too few |
| man_duo: run.yards_after_contact | 2.30 [1.20, 3.50] 5.60 | - | - | - | n=0 | | | too few |
| man_duo: run.max_engaged_dl_driven_back_3s | 1.10 [0.40, 1.80] 2.40 | - | - | - | n=0 | | | too few |
| man_duo: contact.run.carrier_speed_0_5s_after | 2.85 [2.00, 4.03] 5.22 | - | - | - | n=0 | | | too few |
| man_duo: run.yards | 3.00 [1.00, 5.00] 9.00 | - | - | - | n=0 | | | too few |
| draw: run.handoff_s | 1.50 [1.30, 1.60] 1.70 | - | - | - | n=0 | | | too few |
| draw: run.carrier_cross_los_s | 2.70 [2.40, 3.10] 3.40 | - | - | - | n=0 | | | too few |
| draw: run.yards_before_contact | 1.20 [-1.10, 4.80] 9.10 | - | - | - | n=0 | | | too few |
| draw: run.yards_after_contact | 2.70 [1.20, 4.30] 6.20 | - | - | - | n=0 | | | too few |
| draw: run.max_engaged_dl_driven_back_3s | -0.20 [-1.70, 0.80] 1.40 | - | - | - | n=0 | | | too few |
| draw: contact.run.carrier_speed_0_5s_after | 3.69 [2.55, 4.81] 6.54 | - | - | - | n=0 | | | too few |
| draw: run.yards | 4.00 [1.00, 9.00] 14.00 | - | - | - | n=0 | | | too few |

## Runs by box count

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| box6-: run.handoff_s | 1.30 [1.10, 1.40] 1.50 | 1.20 [1.10, 1.40] 1.50 | - | - | n=0 | | | too few |
| box6-: run.carrier_cross_los_s | 2.50 [2.20, 2.80] 3.20 | 2.30 [2.00, 2.70] 3.20 | - | - | n=0 | | | too few |
| box6-: run.yards_before_contact | 1.00 [-0.60, 2.70] 5.20 | 0.70 [-0.90, 2.50] 5.70 | - | - | n=0 | | | too few |
| box6-: run.yards_after_contact | 2.50 [1.30, 4.00] 6.60 | 2.10 [1.00, 3.70] 6.10 | - | - | n=0 | | | too few |
| box6-: run.max_engaged_dl_driven_back_3s | 1.10 [0.10, 1.90] 2.60 | 0.90 [-0.30, 1.80] 2.60 | - | - | n=0 | | | too few |
| box6-: contact.run.carrier_speed_0_5s_after | 3.33 [2.26, 4.51] 5.82 | 3.09 [2.06, 4.25] 5.46 | - | - | n=0 | | | too few |
| box6-: run.yards | 4.00 [1.00, 7.00] 11.00 | 3.00 [1.00, 6.00] 10.00 | - | - | n=0 | | | too few |
| box7: run.handoff_s | 1.30 [1.20, 1.40] 1.50 | 1.30 [1.20, 1.40] 1.50 | - | - | n=0 | | | too few |
| box7: run.carrier_cross_los_s | 2.50 [2.30, 2.80] 3.40 | 2.40 [2.20, 2.80] 3.30 | - | - | n=0 | | | too few |
| box7: run.yards_before_contact | 0.50 [-0.90, 2.10] 4.60 | 0.50 [-0.80, 2.20] 4.60 | - | - | n=0 | | | too few |
| box7: run.yards_after_contact | 2.40 [1.30, 3.80] 6.20 | 1.80 [0.90, 3.10] 5.10 | - | - | n=0 | | | too few |
| box7: run.max_engaged_dl_driven_back_3s | 0.90 [0.00, 1.70] 2.50 | 0.80 [-0.20, 1.60] 2.50 | - | - | n=0 | | | too few |
| box7: contact.run.carrier_speed_0_5s_after | 3.25 [2.24, 4.50] 5.75 | 3.02 [2.02, 4.24] 5.40 | - | - | n=0 | | | too few |
| box7: run.yards | 3.00 [1.00, 6.00] 10.00 | 3.00 [1.00, 5.00] 9.00 | - | - | n=0 | | | too few |
| box8+: run.handoff_s | 1.30 [1.20, 1.40] 1.50 | 1.30 [1.20, 1.40] 1.50 | - | - | n=0 | | | too few |
| box8+: run.carrier_cross_los_s | 2.50 [2.30, 2.80] 3.30 | 2.40 [2.20, 2.80] 3.30 | - | - | n=0 | | | too few |
| box8+: run.yards_before_contact | 0.10 [-1.10, 1.40] 3.20 | 0.10 [-1.10, 1.40] 3.90 | - | - | n=0 | | | too few |
| box8+: run.yards_after_contact | 2.10 [1.00, 3.40] 5.70 | 1.70 [0.90, 3.00] 4.50 | - | - | n=0 | | | too few |
| box8+: run.max_engaged_dl_driven_back_3s | 0.80 [0.00, 1.60] 2.40 | 0.70 [-0.30, 1.60] 2.30 | - | - | n=0 | | | too few |
| box8+: contact.run.carrier_speed_0_5s_after | 3.01 [2.02, 4.26] 5.88 | 2.79 [1.77, 4.19] 5.26 | - | - | n=0 | | | too few |
| box8+: run.yards | 2.00 [1.00, 5.00] 9.00 | 2.00 [0.00, 4.00] 8.00 | - | - | n=0 | | | too few |

## Passes by coverage

| Metric | NFL 2022 | NFL 2017 | NFL 2021 | NFL 2023 | Sim | Shift | Tail | Flag |
|---|---|---|---|---|---|---:|---:|---|
| man: route.separation_1.5s | 2.50 [1.33, 4.55] 5.84 | - | 2.59 [1.34, 4.51] 5.81 | - | n=0 | | | too few |
| man: route.separation_2.5s | 1.42 [0.95, 2.41] 3.55 | - | 1.34 [0.92, 2.28] 3.45 | - | n=0 | | | too few |
| man: air.separation_at_throw | 2.40 [1.44, 4.03] 5.73 | - | - | 2.06 [1.24, 3.58] 5.30 | n=0 | | | too few |
| man: air.defender_closing | 0.35 [-0.28, 1.11] 2.16 | - | - | 0.35 [-0.38, 1.22] 2.44 | n=0 | | | too few |
| man: air.separation_at_arrival | 1.92 [0.99, 3.64] 5.72 | - | - | 1.65 [0.94, 2.95] 4.74 | n=0 | | | too few |
| man: catch.yards_after_catch | 2.50 [0.40, 7.10] 14.20 | - | - | - | n=0 | | | too few |
| man: pass.time_to_throw | 2.50 [2.10, 3.10] 3.80 | - | 2.60 [2.20, 3.20] 4.00 | - | n=0 | | | too few |
| zone: route.separation_1.5s | 3.53 [2.21, 5.00] 6.22 | - | 3.64 [2.33, 5.11] 6.36 | - | n=0 | | | too few |
| zone: route.separation_2.5s | 2.90 [1.80, 4.06] 5.26 | - | 2.86 [1.77, 4.08] 5.29 | - | n=0 | | | too few |
| zone: air.separation_at_throw | 4.41 [2.83, 6.20] 7.95 | - | - | 3.91 [2.33, 5.77] 7.75 | n=0 | | | too few |
| zone: air.defender_closing | 0.65 [-0.55, 1.89] 2.99 | - | - | 0.99 [-0.15, 2.33] 3.52 | n=0 | | | too few |
| zone: air.separation_at_arrival | 3.70 [2.06, 5.68] 7.61 | - | - | 2.78 [1.46, 4.51] 6.53 | n=0 | | | too few |
| zone: catch.yards_after_catch | 3.20 [0.50, 7.20] 12.00 | - | - | - | n=0 | | | too few |
| zone: pass.time_to_throw | 2.60 [2.10, 3.20] 3.90 | - | 2.80 [2.30, 3.40] 4.20 | - | n=0 | | | too few |

0 ok, 0 check, 0 off, 158 without enough sim plays.

Definitions: see `definitions` in either JSON, or scripts/mechanics/metrics.py.

Guard: 12/12 matched metrics still match.
