"""Read-only measurement challenges on current saved film and synthetic CSVs.
Run from repository root: python3 out/forensic-validation/measure.py
"""
import contextlib,csv,hashlib,importlib.util,io,json,math,sys
from collections import defaultdict
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path.cwd();OUT=ROOT/'out/forensic-validation'
def mod(name,path):
 s=importlib.util.spec_from_file_location(name,ROOT/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
yawspeed=mod('yawspeed','scripts/data/yaw_speed_audit.py');yawcap=mod('yawcap','scripts/data/yaw_capability_audit.py');movement=mod('movement','scripts/data/bdb2027_movement.py');mechanics=mod('mechanics','scripts/mechanics/metrics.py')
def wrap(d):return (d+180)%360-180
def q(v):
 a=np.sort(np.asarray(v));return {'n':len(a),**({f'p{p}':float(a[min(len(a)-1,int(p/100*len(a)))]) for p in [10,50,90,99]} if len(a) else {})}
def callmain(m,path):
 out=io.StringIO()
 with contextlib.redirect_stdout(out):m.main([str(path)])
 return json.loads(out.getvalue())
def fixture(name,orient,position='CB',with_roster=True,speed=5):
 d=OUT/name;d.mkdir(exist_ok=True);path=d/'tracking.csv'
 with path.open('w') as f:
  w=csv.DictWriter(f,fieldnames=['gameId','playId','nflId','frameId','frameType','s','o','dir']);w.writeheader()
  for k,o in enumerate(orient):w.writerow(dict(gameId=1,playId=1,nflId=1,frameId=k,frameType='AFTER_SNAP',s=speed,o=o%360,dir=0))
 if with_roster:(d/'players.csv').write_text('nflId,position\n1,'+position+'\n')
 return {'speed_audit':callmain(yawspeed,path),'capability_audit':callmain(yawcap,path)}
fixtures={
 'single_frame_180_flip_straight_travel':fixture('single_flip',[0]*10+[180]+[0]*10),
 'continuous_29deg_s':fixture('deadband',[k*2.9 for k in range(61)]),
 'known_WR_excluded':fixture('wr_known',[k*60 for k in range(21)],position='WR'),
 'same_WR_roster_absent_defaults_DB':fixture('wr_no_roster',[k*60 for k in range(21)],position='WR',with_roster=False),
}
t=np.arange(0,3.01,.1);om=2.2;speed=5
circle=pd.DataFrame({'seconds':t,'x':20+speed/om*np.sin(om*t),'y':20+speed/om*(1-np.cos(om*t))})
fixtures['constant_speed_circle_analytic']={'exact_speed':speed,'exact_lateral_accel':speed*om,'exact_tangential_accel':0,'exact_turn_05s_degrees':float(om*.5*180/np.pi),'operator':movement.motion(circle)}
# Both trajectories end at rest at t=1.5; one brakes at 10 and one at20 yd/s^2.
for accel in [10,20]:
 start=1.5-5/accel;x=np.where(t<=start,5*t,np.where(t<=1.5,5*start+5*(t-start)-.5*accel*(t-start)**2,5*start+12.5/accel))
 fixtures[f'known_brake_{accel}']={'exact_peak_brake':accel,'operator':movement.motion(pd.DataFrame({'seconds':t,'x':x,'y':np.zeros(len(t))}))}
film_path=ROOT/'out/audit/film.json';film=json.load(film_path.open());agg=defaultdict(lambda:defaultdict(list));maxima=defaultdict(list);examples=[];decel=defaultdict(list);decel01=defaultdict(list);counters=defaultdict(int);alignment=defaultdict(lambda:[0,0,0]);detailed=[]
for p in film['plays']:
 if p['kind'] not in ['run','pass'] or not p.get('frames'):continue
 fr=p['frames'];mask=np.asarray(fr['t'])>=0;times=np.asarray(fr['t'])[mask];arr=np.asarray(fr['p']).reshape(len(fr['t']),len(p['roster']),3)[mask]/fr['scale'];n=len(times)
 counters['filmed_run_pass_plays']+=1
 counters['irregular_terminal_plays']+=bool(np.any(np.abs(np.diff(times)-.1)>1e-8))
 # Common mechanics operator current film, regular frames only; copy through public movement_metrics.
 regular=np.abs(times*10-np.round(times*10))<1e-7;at=arr[regular,:,:];raw={'players':[{'side':r[0],'group':('LB' if r[1].startswith('LB') else 'DB') if r[0]=='D' and not r[1].startswith(('DE','DT','NT')) else 'other'} for r in p['roster']],'xy':at[:,:,:2].reshape(len(at),-1).tolist(),'dt':.1}
 mp=mechanics.Play(raw);mechanics.movement_metrics(mp,decel);mp.xy=raw['xy'];mechanics.movement_metrics(mp,decel01)
 for i,r in enumerate(p['roster']):
  if r[0]!='D' or r[1].startswith(('DE','DT','NT')):continue
  counters['defender_paths']+=1;xy=arr[:,i,:2];ori=np.rad2deg(arr[:,i,2]);v=np.empty_like(xy)
  for k in range(n):
   a=max(0,k-1);b=min(n-1,k+1);v[k]=(xy[b]-xy[a])/(times[b]-times[a])
  sp=np.linalg.norm(v,axis=1);direction=np.rad2deg(np.arctan2(v[:,1],v[:,0]));pathmax={}
  for k in range(n):
   b=next((f'{lo}-{hi}' for lo,hi in [(0,2),(2,4),(4,6),(6,99)] if lo<=sp[k]<hi),None)
   if b is None:continue
   a=abs(wrap(ori[k]-direction[k]));alignment[b][0 if a<60 else 1 if a<120 else 2]+=1
   if k+1<n:
    dy=abs(wrap(ori[k+1]-ori[k]));agg[b]['legacy_yaw_deg_s'].append(dy*10);agg[b]['actual_dt_yaw_deg_s'].append(dy/(times[k+1]-times[k]))
   if k+2<n:
    sw=abs(wrap(ori[k+2]-ori[k]));agg[b]['legacy_swing90'].append(sw>=90);pathmax[b]=max(pathmax.get(b,0),sw/.2)
    if abs(times[k+2]-times[k]-.2)>1e-7:counters['irregular_02_windows']+=1;continue
    agg[b]['strict_02_swing90'].append(sw>=90)
    turn=abs(wrap(direction[k+2]-direction[k]));ret=float(min(sp[k:k+3])/sp[k]) if sp[k] else None
    row={'play':p['id'],'kind':p['kind'],'slot':r[1],'player':r[2],'t0':float(times[k]),'t1':float(times[k+2]),'entrySpeed':float(sp[k]),'exitSpeed':float(sp[k+2]),'minimumSpeedRetention':ret,'bodyYaw':float(sw),'travelTurn':float(turn),'nearestEvent':[e for e in p.get('eventDetails',[]) if abs(e['t']-times[k])<.21 and (e.get('a')==i or e.get('b')==i)]}
    if 2<=sp[k]<6 and sw>=90:detailed.append(row)
    if sp[k]>=3 and sw>=90 and turn<30 and ret>.8:examples.append(row)
   if k+5<n and abs(times[k+5]-times[k]-.5)<1e-7 and sp[k]>=3 and sp[k+5]>=1:
    turn=abs(wrap(direction[k+5]-direction[k]));sw=abs(wrap(ori[k+5]-ori[k]));ret=float(min(sp[k:k+6])/sp[k]);agg[b]['halfsec_travel_turn'].append(turn)
    if turn>=60:
     counters['travel_turn_60_in_05_entry3']+=1
     if sw<30:counters['travel_turn_60_in_05_body_under30']+=1
  for b,val in pathmax.items():maxima[b].append(val)
report={'source':{'commit':'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0','film':str(film_path),'filmSha256':hashlib.sha256(film_path.read_bytes()).hexdigest(),'meta':film['meta'],'limits':'One current generated game; 10Hz rounded replay; native intents/contact eligibility unavailable. No NFL prevalence or causal inference. Quantiles use legacy floor(p*n), matching the yaw scripts.'},'counters':dict(counters),'bins':{},'high_yaw_low_travel_examples':sorted(examples,key=lambda e:-e['bodyYaw'])[:15],'all_2to6_high_yaw_windows':detailed,'synthetic_operator_challenges':fixtures,'mechanics_current_decel':{},'mechanics_unquantized_001_decel':{}}
for b,g in agg.items():
 report['bins'][b]={k:({'n':len(v),'count':int(sum(v)),'rate':float(np.mean(v))} if 'swing90' in k else q(v)) for k,v in g.items()};report['bins'][b]['path_max_swing_deg_s']=q(maxima[b]);report['bins'][b]['body_vs_travel_counts']=alignment[b]
for group in ['DB','LB']:
 report['mechanics_current_decel'][group]=q(decel['move.max_decel.'+group]);report['mechanics_unquantized_001_decel'][group]=q(decel01['move.max_decel.'+group])
(OUT/'measurements.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['all_2to6_high_yaw_windows','synthetic_operator_challenges','high_yaw_low_travel_examples']},indent=2))
print('examples',json.dumps(report['high_yaw_low_travel_examples'][:3],indent=2))
