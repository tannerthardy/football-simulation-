import {writeFileSync} from 'node:fs';
import {Rng} from '../../src/core/rng.ts';
import {CENTER_Y} from '../../src/core/field.ts';
import {generateTeam,pickOffense,pickDefense} from '../../src/league/team.ts';
import {FORMATION_BY_ID} from '../../src/playbook/formations.ts';
import {RUN_BY_ID,PASS_BY_ID} from '../../src/playbook/concepts.ts';
import {FRONT_BY_ID,COVERAGE_BY_ID} from '../../src/playbook/defense.ts';
import {PlaySim,type PlaySetup} from '../../src/sim/playsim.ts';
const off=generateTeam(new Rng(31),'Home','HOM',{strength:.6});
const def=generateTeam(new Rng(32),'Away','AWY',{strength:.6});
const offense=pickOffense(off,'12'), defense=pickDefense(def,'base43');
const permute=(x:any,mode:string)=>Object.fromEntries(mode==='reverse'?Object.entries(x).reverse():mode==='sorted'?Object.entries(x).sort(([a],[b])=>a.localeCompare(b)):Object.entries(x));
function setup(seed:number,kind:string,o:string,d:string):PlaySetup {return {offense:permute(offense,o),defense:permute(defense,d),
offCall:{formation:FORMATION_BY_ID.ace_12,flip:false,kind:kind as any,run:kind==='run'?RUN_BY_ID.iz_strong:undefined,pass:kind==='pass'?PASS_BY_ID.hitches:undefined,label:'input order audit'},
defCall:{personnel:'base43',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:'c3'},los:40,ballY:CENTER_Y,firstDownX:50,seed};}

const rows=[];
for(const [o,d] of [['native','native'],['reverse','native'],['native','reverse']]) {
 const sim=new PlaySim(setup(7,'pass',o,d));
 const trace:any[]=[];
 for(const a of sim.agents) {
  const b:any=a.behavior, original=b.update.bind(b);
  b.update=(agent:any,world:any)=>{const before=b.oversetBias; const command=original(agent,world); if(sim.t<.15)trace.push({t:sim.t,slot:a.slot,kind:b.kind,oversetBefore:before,oversetAfter:b.oversetBias,command});return command};
 }
 while(sim.t<.15)sim.tick();
 rows.push({o,d,trace});
}
writeFileSync('out/forensic-root/input-order-first-request.json',JSON.stringify(rows,null,2));
console.log(JSON.stringify(rows.map(r=>({...r,trace:r.trace.filter((t:any)=>t.slot==='RG')})),null,2));
