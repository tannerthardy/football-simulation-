import {writeFileSync} from 'node:fs';
import {Rng} from '../../src/core/rng.ts';
import {CENTER_Y} from '../../src/core/field.ts';
import {generateTeam,pickOffense,pickDefense} from '../../src/league/team.ts';
import {FORMATION_BY_ID} from '../../src/playbook/formations.ts';
import {RUN_BY_ID,PASS_BY_ID} from '../../src/playbook/concepts.ts';
import {FRONT_BY_ID,COVERAGE_BY_ID} from '../../src/playbook/defense.ts';
import {PlaySim,type PlaySetup} from '../../src/sim/playsim.ts';
const off=generateTeam(new Rng(31),'Home','HOM',{strength:.6});
const def=generateTeam(new Rng(32),'Away','AWY',{strength:.6});
const offense=pickOffense(off,'12'), defense=pickDefense(def,'base43');
const permute=(x:any,mode:string)=>Object.fromEntries(mode==='reverse'?Object.entries(x).reverse():mode==='sorted'?Object.entries(x).sort(([a],[b])=>a.localeCompare(b)):Object.entries(x));
function setup(seed:number,kind:string,o:string,d:string):PlaySetup {return {offense:permute(offense,o),defense:permute(defense,d),
offCall:{formation:FORMATION_BY_ID.ace_12,flip:false,kind:kind as any,run:kind==='run'?RUN_BY_ID.iz_strong:undefined,pass:kind==='pass'?PASS_BY_ID.hitches:undefined,label:'input order audit'},
defCall:{personnel:'base43',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:'c3'},los:40,ballY:CENTER_Y,firstDownX:50,seed};}
function snapshot(sim:PlaySim){return Object.fromEntries([...sim.agents].sort((a,b)=>a.slot.localeCompare(b.slot)).map(a=>[a.slot,{idx:a.idx,pos:{...a.pos},vel:{...a.vel},facing:a.facing,kind:a.behavior.kind,readAt:a.readAt,snapReadyAt:a.snapReadyAt,plan:typeof (a.behavior as any).plan==='string'?(a.behavior as any).plan:undefined,alignmentError:a.mind.alignmentError}]))}
function run(seed:number,kind:string,o:string,d:string,canonical=false){let s=setup(seed,kind,o,d);if(canonical)s={...s,offense:permute(s.offense,'sorted'),defense:permute(s.defense,'sorted')};const sim=new PlaySim(s);const initial=snapshot(sim),samples=[];while(sim.t<3-1e-7&&sim.phase==='live'){sim.tick();samples.push({t:sim.t,state:snapshot(sim),commands:Object.fromEntries(sim.agents.map(a=>[a.slot,sim.intents[a.idx]])),events:sim.events.map(e=>({...e,a:e.a===undefined?null:sim.agents[e.a].slot,b:e.b===undefined?null:sim.agents[e.b].slot}))});}return {seed,kind,o,d,canonical,initial,samples,phase:sim.phase,outcome:sim.outcome,scoreKind:sim.scoreKind};}
const all=[];
for(const kind of ['run','pass'])for(const seed of [7,8,19])for(const [o,d]of [['native','native'],['reverse','native'],['native','reverse'],['reverse','reverse']])all.push(run(seed,kind,o,d));
const controls=[run(7,'pass','native','native',true),run(7,'pass','reverse','reverse',true)];
function normalize(x:any):any{if(Array.isArray(x))return x.map(normalize);if(x&&typeof x==='object')return Object.fromEntries(Object.entries(x).filter(([k])=>k!=='idx').map(([k,v])=>[k,normalize(v)]));return x;}
const summary=all.filter(x=>x.o!=='native'||x.d!=='native').map(x=>{const base=all.find(b=>b.seed===x.seed&&b.kind===x.kind&&b.o==='native'&&b.d==='native')!;const initialDiff=Object.keys(x.initial).filter(slot=>JSON.stringify(normalize(x.initial[slot]))!==JSON.stringify(normalize(base.initial[slot])));let first:any=null;for(let i=0;i<Math.min(x.samples.length,base.samples.length);i++){const a=x.samples[i],b=base.samples[i];const slots=Object.keys(a.state).filter(slot=>Math.hypot(a.state[slot].pos.x-b.state[slot].pos.x,a.state[slot].pos.y-b.state[slot].pos.y)>1e-9);if(slots.length){first={t:a.t,slots};break;}}const last=x.samples.at(-1),blast=base.samples.find(s=>Math.abs(s.t-(last?.t??0))<1e-7);return {seed:x.seed,kind:x.kind,o:x.o,d:x.d,initialDiff,firstPositionDivergence:first,finalCommonTime:last&&blast?last.t:null,maxPositionDelta:last&&blast?Math.max(...Object.keys(last.state).map(slot=>Math.hypot(last.state[slot].pos.x-blast.state[slot].pos.x,last.state[slot].pos.y-blast.state[slot].pos.y))):null,outcome:x.outcome,baseOutcome:base.outcome};});
writeFileSync('out/forensic-root/input-order-full.json',JSON.stringify({all,controls}));
const result={source:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',description:'Same player objects, call, seed and source; only Partial<Record> insertion order changed. First 3 seconds, no source edits.',summary,canonicalControlIdentical:JSON.stringify(normalize({...controls[0],o:null,d:null}))===JSON.stringify(normalize({...controls[1],o:null,d:null})),sampleInitial:{native:all[0].initial,reversedDefense:all[2].initial}};
writeFileSync('out/forensic-root/input-order.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
