import {readdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {readSetup} from '../forensic-architecture/revive.ts';
import {PlaySim} from '../../src/sim/playsim.ts';
import {SnapMind} from '../../src/sim/mind.ts';
import {RunBlocker} from '../../src/sim/behaviors/blocking.ts';
import {ZoneCoverage} from '../../src/sim/behaviors/defense.ts';
const hash=(x:any)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const ids=readdirSync('/workspace/audit-deep/evidence/architecture').filter(x=>x.endsWith('-setup.json')).map(x=>x.replace('-setup.json','')).sort();
let active:any=null,playId='',rows:any[]=[],calls:any={},invalidation=false;
const lifetime=new WeakMap<SnapMind,Map<string,any>>();
const aim=SnapMind.prototype.aim;
const rb=RunBlocker.prototype.update,zone=ZoneCoverage.prototype.update;
function wrap(original:any){return function(this:any,a:any,sim:any){const old=active;active={owner:this,a,sim};try{return original.call(this,a,sim)}finally{active=old}}}
RunBlocker.prototype.update=wrap(rb);ZoneCoverage.prototype.update=wrap(zone);
function observedAim(this:SnapMind,job:string,desired:any,t:number){
 if(job!=='block-fit'&&job!=='zone-drive')return aim.call(this,job,desired,t);
 const prior=(this as any).aims.get(job),target=active?.owner.target?.slot??null;
 let meta=lifetime.get(this);if(!meta){meta=new Map();lifetime.set(this,meta)}const previous=meta.get(job);
 calls[job]=(calls[job]??0)+1;
 const cross=!!prior&&t<prior.until&&!!previous&&previous.target!==target;
 if(cross&&invalidation)(this as any).aims.delete(job);
 const result=aim.call(this,job,desired,t);
 if(cross)rows.push({playId,t,slot:active?.a.slot,job,oldTarget:previous.target,target,oldAt:previous.t,until:prior.until,desired:{...desired},returned:{...result},distance:Math.hypot(desired.x-result.x,desired.y-result.y),pos:{...active?.a.pos},behavior:active?.a.behavior.kind});
 if(!prior||t>=prior.until||(cross&&invalidation))meta.set(job,{target,t});
 return result;
};
SnapMind.prototype.aim=observedAim;
const plays=[];
for(const id of ids){playId=id;const before=rows.length;const sim=new PlaySim(readSetup(id));const result=sim.run();plays.push({id,callsWithCrossTarget:rows.length-before,hash:hash(result),yards:result.yards,duration:result.duration});}
const observedRows=rows,observedCalls=calls;const pairs=[];
for(const p of plays.filter(x=>x.callsWithCrossTarget>0||x.id==='G1-P029')){
 playId=p.id;rows=[];calls={};invalidation=true;
 const changed=new PlaySim(readSetup(p.id)).run();invalidation=false;
 const interventions=rows;
 SnapMind.prototype.aim=aim;RunBlocker.prototype.update=rb;ZoneCoverage.prototype.update=zone;
 const baseline=new PlaySim(readSetup(p.id)).run();
 pairs.push({id:p.id,neutralEqual:hash(baseline)===p.hash,changedEqual:hash(changed)===p.hash,baseline:{yards:baseline.yards,duration:baseline.duration,outcome:baseline.outcome},changed:{yards:changed.yards,duration:changed.duration,outcome:changed.outcome},interventions});
 SnapMind.prototype.aim=observedAim;RunBlocker.prototype.update=wrap(rb);ZoneCoverage.prototype.update=wrap(zone);
}
SnapMind.prototype.aim=aim;RunBlocker.prototype.update=rb;ZoneCoverage.prototype.update=zone;
const out={source:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',definition:'Actual SnapMind.aim consumption while retained cache belongs to another target. All captured native setups from exact seed7game. No extra observations. Unqueried retained caches are excluded; returned stale aims may still be overridden before command execution.',plays:plays.length,calls:observedCalls,incidents:observedRows,perPlay:plays,pairs};
writeFileSync('out/forensic-root/aim-census.json',JSON.stringify(out,null,2));console.log(JSON.stringify({...out,perPlay:undefined,incidents:out.incidents.slice(0,25)},null,2));
