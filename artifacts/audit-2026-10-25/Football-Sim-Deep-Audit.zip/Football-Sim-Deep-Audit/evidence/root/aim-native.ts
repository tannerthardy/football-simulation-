import {readdirSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {readSetup} from '../forensic-architecture/revive.ts';
import {PlaySim} from '../../src/sim/playsim.ts';
import {SnapMind} from '../../src/sim/mind.ts';
import {RunBlocker} from '../../src/sim/behaviors/blocking.ts';
import {ZoneCoverage} from '../../src/sim/behaviors/defense.ts';
const hash=(x:any)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const ids=readdirSync('/workspace/audit-deep/evidence/architecture').filter(x=>x.endsWith('-setup.json')).map(x=>x.replace('-setup.json','')).sort();
let active:any=null,playId='',rows:any[]=[],calls:any={},invalidation=false; let raw:any[]=[];
const lifetime=new WeakMap<SnapMind,Map<string,any>>();
const aim=SnapMind.prototype.aim;
const rb=RunBlocker.prototype.update,zone=ZoneCoverage.prototype.update;
function wrap(original:any){return function(this:any,a:any,sim:any){const old=active;active={owner:this,a,sim};try{const c=original.call(this,a,sim);raw.push({t:sim.t,slot:a.slot,kind:this.kind,target:this.target?.slot??null,command:JSON.parse(JSON.stringify(c))});return c}finally{active=old}}}
RunBlocker.prototype.update=wrap(rb);ZoneCoverage.prototype.update=wrap(zone);
function observedAim(this:SnapMind,job:string,desired:any,t:number){
 if(job!=='block-fit'&&job!=='zone-drive')return aim.call(this,job,desired,t);
 const prior=(this as any).aims.get(job),target=active?.owner.target?.slot??null;
 let meta=lifetime.get(this);if(!meta){meta=new Map();lifetime.set(this,meta)}const previous=meta.get(job);
 calls[job]=(calls[job]??0)+1;
 const cross=!!prior&&t<prior.until&&!!previous&&previous.target!==target;
 if(cross&&invalidation)(this as any).aims.delete(job);
 const result=aim.call(this,job,desired,t);
 if(cross)rows.push({playId,t,slot:active?.a.slot,job,oldTarget:previous.target,target,oldAt:previous.t,until:prior.until,desired:{...desired},returned:{...result},distance:Math.hypot(desired.x-result.x,desired.y-result.y),pos:{...active?.a.pos},behavior:active?.a.behavior.kind});
 if(!prior||t>=prior.until||(cross&&invalidation))meta.set(job,{target,t});
 return result;
};
SnapMind.prototype.aim=observedAim;

function execute(id:string,change:boolean){playId=id;rows=[];raw=[];invalidation=change;const sim=new PlaySim(readSetup(id));const ticks:any[]=[];
const step=sim.world.step.bind(sim.world);sim.world.step=(intents,dt)=>{const before=sim.agents.map(a=>({slot:a.slot,pos:{...a.pos},vel:{...a.vel},facing:a.facing,command:JSON.parse(JSON.stringify(intents[a.idx]))}));const report=step(intents,dt);const after=sim.agents.map(a=>({slot:a.slot,pos:{...a.pos},vel:{...a.vel},facing:a.facing}));ticks.push({t:sim.t,before,after});return report;};const result=sim.run();return {hash:hash(result),yards:result.yards,duration:result.duration,raw,ticks,interventions:rows};}
const pairs=[];
for(const id of ['G1-P029','G1-P093','G1-P095','G1-P129','G1-P149','G1-P159','G1-P160']){
const base=execute(id,false),changed=execute(id,true);let firstRaw:any=null,firstFinal:any=null,maxPosition=0,firstPhysical:any=null;
for(let i=0;i<Math.min(base.raw.length,changed.raw.length);i++){const a=base.raw[i],b=changed.raw[i];if(!firstRaw&&JSON.stringify(a)!==JSON.stringify(b))firstRaw={native:a,changed:b};}
for(let i=0;i<Math.min(base.ticks.length,changed.ticks.length);i++){const a=base.ticks[i],b=changed.ticks[i];for(let j=0;j<a.before.length;j++)if(!firstFinal&&JSON.stringify(a.before[j].command)!==JSON.stringify(b.before[j].command))firstFinal={t:a.t,slot:a.before[j].slot,native:a.before[j].command,changed:b.before[j].command};for(let j=0;j<a.after.length;j++){const aa=a.after[j],bb=b.after[j];const d=Math.hypot(aa.pos.x-bb.pos.x,aa.pos.y-bb.pos.y);maxPosition=Math.max(maxPosition,d);if(!firstPhysical&&d>1e-9)firstPhysical={t:a.t+.05,slot:aa.slot,distance:d};}}
pairs.push({id,base,changed,summary:{firstRaw,firstFinal,firstPhysical,maxPosition,resultsEqual:base.hash===changed.hash}});
}
SnapMind.prototype.aim=aim;RunBlocker.prototype.update=rb;ZoneCoverage.prototype.update=zone;
writeFileSync('out/forensic-root/aim-native-traces.json',JSON.stringify(pairs));
writeFileSync('out/forensic-root/aim-native-summary.json',JSON.stringify(pairs.map(p=>({id:p.id,...p.summary})),null,2));
console.log(JSON.stringify(pairs.map(p=>({id:p.id,...p.summary})),null,2));
