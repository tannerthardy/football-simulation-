import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {readSetup} from '../forensic-architecture/revive.ts';
import {PlaySim} from '../../src/sim/playsim.ts';
import {World} from '../../src/physics/world.ts';
const hash=(v:any)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const original=World.prototype.step;
let active:any=null;
World.prototype.step=function(...args:any[]){
 if(!active)return original.apply(this,args as any);
 const key=this.bodies.length===1?'oneBodyPreview':'nativeWorld';
 const start=process.hrtime.bigint();
 try{return original.apply(this,args as any)}finally{active[key].calls++;active[key].milliseconds+=Number(process.hrtime.bigint()-start)/1e6;}
};
new PlaySim(readSetup('G1-P017')).run(); // warm-up, not measured
const rows=[];
for(const id of ['G1-P002','G1-P017','G1-P029']){
 let start=performance.now();const baseline=new PlaySim(readSetup(id)).run();const baselineMs=performance.now()-start;
 active={oneBodyPreview:{calls:0,milliseconds:0},nativeWorld:{calls:0,milliseconds:0}};
 start=performance.now();const observed=new PlaySim(readSetup(id)).run();const observedMs=performance.now()-start;const counts=active;active=null;
 rows.push({id,baselineMs,observedMs,baselineHash:hash(baseline),observedHash:hash(observed),equal:hash(baseline)===hash(observed),counts,elapsedPlay:observed.duration,frames:observed.frames?.length});
}
World.prototype.step=original;
const result={source:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',definition:'World.step calls in exact ordinary native setups. one-body calls belong to movement previews; native22-body calls include presnap and live. Timing descriptive under concurrent audit load, not clean throughput benchmark. Observer timing overhead included; no execution change.',rows};
writeFileSync('out/forensic-root/workload.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
