import fs from 'node:fs';
import assert from 'node:assert/strict';
import { CENTER_Y } from '../../src/core/field.js';
import { Rng } from '../../src/core/rng.js';
import { generateTeam, pickDefense, pickOffense } from '../../src/league/team.js';
import { RUN_BY_ID, PASS_BY_ID } from '../../src/playbook/concepts.js';
import { COVERAGE_BY_ID, FRONT_BY_ID } from '../../src/playbook/defense.js';
import { FORMATION_BY_ID } from '../../src/playbook/formations.js';
import { RunBlocker } from '../../src/sim/behaviors/blocking.js';
import { CoverageJudgment } from '../../src/sim/coverage/judgment.js';
import { ReleaseReader } from '../../src/sim/coverage/reads.js';
import type { Agent } from '../../src/sim/agent.js';
import type { Perceived } from '../../src/sim/perception.js';
import { PlaySim } from '../../src/sim/playsim.js';

// Synthetic decision experiments, not football outcome or prevalence claims.
// All execution goes through production RunBlocker.update; local variants
// replace only its private target reassessment method in this process.
type Mode = 'current'|'local'|'record-envelope';
const source='c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0';
const baseOffense = generateTeam(new Rng(51),'O','O',{strength:.55});
const baseDefense = generateTeam(new Rng(52),'D','D',{strength:.55});

function scene(mirror=1, traits:Record<string,number>={}) {
  const O=pickOffense(structuredClone(baseOffense),'21');
  for (const p of Object.values(O)) if (p) Object.assign(p.ratings,traits);
  const sim=new PlaySim({offense:O, defense:pickDefense(structuredClone(baseDefense),'base43'),
    offCall:{formation:FORMATION_BY_ID.i_pro_21,flip:false,kind:'run',run:RUN_BY_ID.iz_strong,label:'IZ'},
    defCall:{personnel:'base43',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:'Over C3'},
    los:40,ballY:CENTER_Y,firstDownX:50,seed:7});
  for(const a of sim.agents){a.body.pos={x:80+a.idx*2,y:4};a.body.vel={x:0,y:0};}
  const fb=sim.slot('F')!,rb=sim.slot('RB')!,fs=sim.slot('FS')!,mike=sim.slot('LB_M')!,mate=sim.slot('LG')!;
  const pos=(x:number,y:number)=>({x,y:CENTER_Y+mirror*y});
  rb.body.pos=pos(37,0);fb.body.pos=pos(39.5,.4);fs.body.pos=pos(47,1);mike.body.pos=pos(41.5,0);sim.qb.body.pos=pos(34,3);
  const pictures=new Map<Agent,Perceived>(sim.agents.map(a=>[a,{pos:{...a.pos},vel:{...a.vel},facing:a.facing,
    stance:null,pose:'up',age:.2,carrying:a===rb}]));
  pictures.get(rb)!.vel={x:5,y:0};pictures.get(fs)!.vel={x:1,y:0};pictures.get(mike)!.vel={x:-2,y:0};
  const ordinary=sim.see.bind(sim);
  sim.see=(a,b,s)=>a===fb?structuredClone(pictures.get(b)!):ordinary(a,b,s);
  sim.t=1.8;
  const lead=new RunBlocker({kind:'lead',target:fs,drive:{x:1,y:0}});fb.behavior=lead;
  const edit=(a:Agent,x:number,y:number,vx=0,vy=0,pose:Perceived['pose']='up')=>{
    a.body.pos=pos(x,y);a.body.vel={x:vx,y:mirror*vy};
    Object.assign(pictures.get(a)!,{pos:{...a.pos},vel:{...a.vel},pose});
  };
  return {sim,fb,rb,fs,mike,mate,pictures,lead,edit};
}
type Scene=ReturnType<typeof scene>;

// The proposed narrow local correction. It is deliberately not an interception
// oracle: a nearby teammate must have an upright/unknown acquired pose and
// remain close over this observer's existing decision interval. No new timer,
// new observations, rating, responsibility model or physics parameter.
function installLocal(s:Scene,record=false){
  const b=s.lead as any;
  b.rereadThreat=function(a:Agent,sim:PlaySim){
    const p=this.plan,target=p.target;
    if(!target||(p.kind!=='climb'&&p.kind!=='lead')||(p.combination&&!p.combination.released)||p.departure)return;
    const ref=this.workReference(a,sim),picture=this.workPicture;
    if(picture.source!=='acquired'||picture.carrier===sim.qb.idx)return;
    const dir=sim.attackDir(a.team);
    const danger=(seen:Perceived)=>{const dx=ref.x-seen.pos.x,dy=ref.y-seen.pos.y,d=Math.hypot(dx,dy);
      const closing=d>1e-9?((seen.vel.x-picture.vel.x)*dx+(seen.vel.y-picture.vel.y)*dy)/d:0;
      return{d,score:d-Math.max(0,closing)};};
    const mine=danger(sim.see(a,target));if(mine.d<4)return;
    const mates=sim.offense.filter(o=>o!==a&&o!==sim.qb&&o.idx!==picture.carrier).map(o=>sim.see(a,o));
    let best:{d:Agent,score:number}|null=null;
    const options:any[]=[];
    for(const d of sim.defense){
      if(d===target||d.engagement||d.isDown(sim.t))continue;
      const seen=sim.see(a,d),threat=danger(seen);
      if((seen.pos.x-ref.x)*dir< -1||threat.score>mine.score-2.5)continue;
      const reach=Math.hypot(seen.pos.x-a.pos.x,seen.pos.y-a.pos.y);
      const helper=mates.some(m=>{
        if(m.pose!=null&&m.pose!=='up')return false;
        const h=a.mind.decisionInterval;
        const now=Math.hypot(m.pos.x-seen.pos.x,m.pos.y-seen.pos.y);
        const later=Math.hypot(m.pos.x-seen.pos.x+(m.vel.x-seen.vel.x)*h,
          m.pos.y-seen.pos.y+(m.vel.y-seen.vel.y)*h);
        return Math.max(now,later)<reach-.5;
      });
      if(record)options.push({target:d.slot,threat:threat.score,closerThanRunner:reach<threat.d,helper});
      if(reach>=threat.d||helper)continue;
      if(!best||threat.score<best.score)best={d,score:threat.score};
    }
    if(record)this.envelopeRecord={purpose:'protect acquired runner',primary:target.slot,
      options,chose:best?.d.slot??target.slot,commitUntil:this.nextThreatRead};
    if(!best)return;
    p.target=best.d;delete p.contactFit;this.climbRead=null;this.climbAccess=null;
    this.classifyWork(a,sim,best.d);sim.event('block_threat',a,best.d,'first threat to the runner');
  };
}

const cases:{id:string,edit:(s:Scene)=>void,expected:string|null,meaning:string}[]=[
  {id:'uncovered-danger',edit:()=>{},expected:'LB_M',meaning:'Existing motivating opportunity'},
  {id:'upright-close-help',edit:s=>s.edit(s.mate,40.5,-.1,0,0),expected:'FS',meaning:'Preserve original duty behind a close upright helper'},
  {id:'down-close-help',edit:s=>s.edit(s.mate,40.5,-.1,0,0,'down'),expected:'LB_M',meaning:'Observed down teammate cannot presently supply help'},
  {id:'rising-close-help',edit:s=>s.edit(s.mate,40.5,-.1,0,0,'rising'),expected:null,meaning:'Recovery availability ambiguous: report change, no truth label'},
  {id:'unknown-pose-help',edit:s=>s.edit(s.mate,40.5,-.1,-2,0,null),expected:null,meaning:'Unknown is not known unavailable; preserve current conservative help assumption'},
  {id:'departing-close-help',edit:s=>s.edit(s.mate,40.5,-.1,0,-8),expected:'LB_M',meaning:'Near teammate rapidly leaves candidate corridor'},
  {id:'approaching-close-help',edit:s=>s.edit(s.mate,40.5,-.1,-2,0),expected:'FS',meaning:'Useful shared velocity retains help'},
  {id:'distant-distraction',edit:s=>s.edit(s.mike,41.5,15,-2,0),expected:'FS',meaning:'Distant opponent does not justify abandonment'},
  {id:'original-near-runner',edit:s=>s.edit(s.fs,40,2.5,1,0),expected:'FS',meaning:'Existing near-threat responsibility dominates'},
  {id:'original-cutback',edit:s=>s.edit(s.fs,39,-1,-2,0),expected:'FS',meaning:'Original target remains immediate danger on other side'},
  {id:'candidate-receding',edit:s=>s.edit(s.mike,41.5,0,8,0),expected:null,meaning:'Receding candidate is an opposing control; do not infer a defect from distance alone'},
];
const matrix:any[]=[];
for(const mirror of [1,-1])for(const c of cases)for(const mode of ['current','local','record-envelope'] as Mode[]){
  const s=scene(mirror);c.edit(s);if(mode!=='current')installLocal(s,mode==='record-envelope');
  const command=s.lead.update(s.fb,s.sim);
  matrix.push({case:c.id,mirror,mode,target:s.lead.target?.slot,kind:s.lead.plan.kind,command,
    expected:c.expected,meaning:c.meaning,envelope:(s.lead as any).envelopeRecord??null});
}
// Record-only common envelope is not another policy or scheduler: its parity
// is the concrete point of this arm, rather than pretending a new abstraction
// creates additional judgment.
for(const row of matrix.filter(r=>r.mode==='local')){
  const other=matrix.find(r=>r.mode==='record-envelope'&&r.case===row.case&&r.mirror===row.mirror);
  assert.equal(row.target,other.target);assert.deepEqual(row.command,other.command);
}

const traits:any[]=[];
for(const trait of ['leadBlock','runBlock','playRecognition','awareness','discipline','anticipation'])for(const rating of [1,50,99]){
  const s=scene(1,{[trait]:rating});s.edit(s.mate,40.5,-.1,0,-8);
  const command=s.lead.update(s.fb,s.sim);
  traits.push({trait,rating,target:s.lead.target?.slot,decisionInterval:s.fb.mind.decisionInterval,
    reactionTime:s.fb.profile.reactionTime,command});
}

// Existing coverage judgment recovery: actual delayed PerceptionBuffer and
// ReleaseReader, no invented common envelope. Linear histories align position
// prediction while keeping real acquired pose delay. Adapted from repository
// projected-cap control, with measured timing exported rather than assertions.
function coverageRecovery(traits:Record<string,number>={}){
  const D=pickDefense(generateTeam(new Rng(19),'D','D'),'nickel');
  for(const p of Object.values(D))if(p)Object.assign(p.ratings,traits);
  const sim=new PlaySim({offense:pickOffense(generateTeam(new Rng(7),'O','O'),'11'),defense:D,seed:3,
    offCall:{formation:FORMATION_BY_ID.gun_doubles_11,flip:false,kind:'pass',pass:PASS_BY_ID.four_verts,label:''},
    defCall:{personnel:'nickel',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover4,pressure:null,label:''},
    los:40,ballY:26,firstDownX:50});
  const a=sim.slot('FS')!,own=sim.slot('X')!,other=sim.slot('H')!,helper=sim.slot('CB_W')!;
  for(const p of sim.agents){p.body.pos={x:40,y:40};p.body.vel={x:0,y:0};}
  a.body.pos={x:52,y:20};a.body.facing=Math.PI;
  own.body.pos={x:48,y:20};own.body.vel={x:6,y:0};other.body.pos={x:50,y:25};other.body.vel={x:6,y:0};
  helper.body.pos={x:50,y:20};helper.body.vel={x:6,y:0};helper.body.support!.state='up';
  const current=sim.agents.map(p=>({...p.pos}));
  for(let i=0;i<24;i++){const back=(23-i)*sim.dt;
    sim.agents.forEach((p,j)=>p.body.pos={x:current[j].x-p.vel.x*back,y:current[j].y-p.vel.y*back});sim.perception.record(sim.agents);}
  const reader=new ReleaseReader(a,sim),judge=new CoverageJudgment();
  for(const t of [.1,.3]){sim.t=t;reader.read(sim,own);reader.read(sim,other);}
  sim.t=1.15;const primary={t:'man' as const,r:own,opts:{overTop:true}};
  const rows:any[]=[];const sample=()=>{const d=judge.decide(a,sim,reader,primary,true);
    rows.push({t:sim.t,pose:sim.see(a,helper).pose,chosen:d.t==='man'?d.r.slot:d.t,reason:judge.reason});};
  sample();helper.body.support!.state='down';
  for(let i=0;i<10;i++){sim.t+=sim.dt;for(const p of sim.agents){p.body.pos.x+=p.vel.x*sim.dt;p.body.pos.y+=p.vel.y*sim.dt;}sim.perception.record(sim.agents);sample();}
  return{traits,interval:a.mind.decisionInterval,reaction:a.profile.reactionTime,rows,
    firstDown:rows.find(r=>r.pose==='down')?.t,firstRecovery:rows.find(r=>r.chosen==='X')?.t};
}
const coverage=[coverageRecovery(),coverageRecovery({playRecognition:1,awareness:1}),coverageRecovery({playRecognition:99,awareness:99})];
const recoveries:any[]=[];
for(const mode of ['current','local','record-envelope'] as Mode[]){
  const s=scene();if(mode!=='current')installLocal(s,mode==='record-envelope');
  const rows:any[]=[];const sample=()=>{const command=s.lead.update(s.fb,s.sim);rows.push({t:s.sim.t,target:s.lead.target?.slot,command});};
  sample();s.edit(s.mike,50,10,2,0);s.edit(s.fs,40,1,-2,0);
  // This deliberately changes a supplied picture, not physical trajectories;
  // it isolates persistence/recovery once evidence is already delivered.
  s.sim.t+=.05;sample();s.sim.t=2.05;sample();recoveries.push({mode,rows});
}
const targetAims:any[]=[];
for(const control of ['changed-target','same-target','no-newcue','return-target'])for(const mode of ['current','target-key','transition-invalidate']){
  const s=scene();s.edit(s.fs,44,3,1,0);
  if(mode==='target-key'){
    const aim=s.fb.mind.aim.bind(s.fb.mind);
    s.fb.mind.aim=(job,desired,t)=>aim(job==='block-fit'?`${job}:${s.lead.target?.idx}`:job,desired,t);
  }
  if(mode==='transition-invalidate'){
    const aim=s.fb.mind.aim.bind(s.fb.mind);let previous:number|undefined;
    s.fb.mind.aim=(job,desired,t)=>{
      if(job==='block-fit'){
        if(previous!==s.lead.target?.idx)(s.fb.mind as any).aims.delete(job);
        previous=s.lead.target?.idx;
      }
      return aim(job,desired,t);
    };
  }
  const rows:any[]=[];
  const sample=()=>{const command=s.lead.update(s.fb,s.sim);rows.push({t:s.sim.t,target:s.lead.target?.slot,
    command,aims:[...(s.fb.mind as any).aims.entries()]});};
  sample();
  if(control==='changed-target'||control==='return-target'){s.mike.downUntil=10;s.pictures.get(s.mike)!.pose='down';}
  else if(control==='same-target'){s.edit(s.mike,41.5,.3,-2,0);}
  s.sim.t+=.05;sample();
  if(control==='return-target'){
    // Explicit synthetic policy transition stress. This return is injected;
    // the ordinary lead's own retarget cadence would not return this early.
    s.mike.downUntil=-1;s.edit(s.mike,41.5,-1,-2,0);s.lead.plan.target=s.mike;
    s.sim.t=1.9;sample();
  }
  s.sim.t=2.05;sample();targetAims.push({control,mode,rows});
}
for(const control of ['same-target','no-newcue'])for(const mode of ['target-key','transition-invalidate'])
  assert.deepEqual(targetAims.find(r=>r.control===control&&r.mode==='current').rows.map((r:any)=>r.command),
    targetAims.find(r=>r.control===control&&r.mode===mode).rows.map((r:any)=>r.command));
// Bounded CPU microbenchmark of target reassessment only (not game throughput).
// Reset choice, keep delivered pictures identical, alternate arm order. Cadence
// is bypassed equally because we measure cost per actual decision evaluation.
const costs:any[]=[];
for(let rep=0;rep<6;rep++)for(const mode of (rep%2?['record-envelope','local','current']:['current','local','record-envelope']) as Mode[]){
  const s=scene();s.edit(s.mate,40.5,-.1,0,-8);if(mode!=='current')installLocal(s,mode==='record-envelope');
  const b=s.lead as any;
  const call=()=>{b.plan.target=s.fs;b.plan.kind='lead';b.rereadThreat(s.fb,s.sim);};
  for(let i=0;i<100;i++)call();
  const start=process.hrtime.bigint();for(let i=0;i<1000;i++)call();
  costs.push({rep,mode,microsecondsPerDecision:Number(process.hrtime.bigint()-start)/1e6});
}
const output={source,scope:'synthetic policy comparisons, no native game or physical outcome claims',matrix,traits,coverage,recoveries,targetAims,costs};
fs.writeFileSync('out/forensic-decision/alternatives.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({source,matrix:matrix.filter(r=>r.mirror===1).map(r=>({case:r.case,mode:r.mode,target:r.target,expected:r.expected})),
  traits:traits.map(({command,...r})=>r),coverage:coverage.map(({rows,...r})=>r),recoveries,targetAims,costs,
  parity:'local and record-envelope complete commands identical in 22 paired cases'},null,2));
