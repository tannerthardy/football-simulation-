import {writeFileSync,readFileSync} from 'node:fs';
import {readSetup} from './revive.js';
import {PlaySim} from './src/sim/playsim.js';
import {movementObjective} from './src/sim/movement-objective.js';
function run(id:string,early=false){
 const sim=new PlaySim(readSetup(id)),rows:any[]=[];let before:any,cmds:any[]=[];
 const plans=()=>sim.agents.map(a=>{const p=(a.behavior as any).plan;return{slot:a.slot,kind:p?.kind,target:p?.target?.idx,engaged:!!a.engagement};});
 (globalThis as any).__auditStage=(s:any,stage:string,i:number,c:any)=>{
  if(stage==='pre'&&s.t===3.3&&early){const a=s.agents[3],b=a.behavior;b.nextRuleRead=s.t+a.mind.decisionInterval;b.readRules(a,s);}
  if(stage==='beforeDecision'){before=plans();}
  if(stage==='raw'){
   cmds[i]={t:s.t,plan:plans()[i],command:{...c,objective:movementObjective(c)}};
   const after=plans();for(let k=0;k<after.length;k++)if(k!==i&&JSON.stringify(before[k])!==JSON.stringify(after[k]))rows.push({t:s.t,actor:i,recipient:k,alreadyDecided:k<i,before:before[k],after:after[k],recipientCommand:cmds[k],actorCommand:{...c,objective:movementObjective(c)}});
  }
 };
 const r=sim.run();return {id,early,rows,result:{outcome:r.outcome,yards:r.yards,duration:r.duration,events:r.events},final:sim.agents.map(a=>({slot:a.slot,pos:a.pos}))};
}
const out={native:run('G1-P064'),early:run('G1-P064',true),forwardControl:run('G1-P054')};writeFileSync('/workspace/audit-deep/evidence/architecture/plan-order.json',JSON.stringify(out,null,2));console.log(JSON.stringify({native:out.native.result,early:out.early.result,nativeRows:out.native.rows,earlyRows:out.early.rows,forwardRows:out.forwardControl.rows},null,2));
