import {writeFileSync,readFileSync} from 'node:fs';
import {readSetup} from './revive.js';
import {PlaySim} from './src/sim/playsim.js';
const out='/workspace/audit-deep/evidence/architecture';
const sim=new PlaySim(readSetup('G1-P002'));
let physical:any;
(globalThis as any).__auditStage=(s:any,stage:string)=>{if(s.t===3.8&&stage==='pre'){physical={t:s.t,stage,body:structuredClone(s.slot('SS').body),agent:{readAt:s.slot('SS').readAt,snapReadyAt:s.slot('SS').snapReadyAt,profile:s.slot('SS').profile,speedScale:s.slot('SS').speedScale},ball:s.carrier?.idx};writeFileSync(`${out}/G1-P002-SS-3.8-body.json`,JSON.stringify(physical));}};
const r=sim.run();const prior=JSON.parse(readFileSync(`${out}/G1-P002-trace.json`,'utf8'));
console.log({sameEvents:JSON.stringify(r.events)===JSON.stringify(prior.result.events),yards:r.yards,expected:prior.result.yards,frames:r.frames.length,snapshot:!!physical});
