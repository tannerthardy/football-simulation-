import {readFileSync} from 'node:fs';
import {Rng} from './src/core/rng.js';
import {ScoutingReport} from './src/sim/recognition.js';
import {CoverageScouting} from './src/sim/qbmind.js';
export function readSetup(id:string){return JSON.parse(readFileSync(`/workspace/audit-deep/evidence/architecture/${id}-setup.json`,'utf8'),(_k,v)=>{if(!v||typeof v!=='object')return v;if(v.__number)return Number(v.__number);const {__type,...fields}=v;if(__type==='Map')return new Map(v.entries);if(__type==='Set')return new Set(v.entries);if(__type==='Rng')return Object.assign(new Rng(v.key),fields);if(__type==='ScoutingReport')return Object.assign(new ScoutingReport(),fields);if(__type==='CoverageScouting')return Object.assign(new CoverageScouting(),fields);return v;});}
