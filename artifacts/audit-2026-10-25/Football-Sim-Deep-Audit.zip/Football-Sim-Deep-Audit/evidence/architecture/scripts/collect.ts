import {writeFileSync,readFileSync,mkdirSync} from 'node:fs';
import {Rng} from './src/core/rng.js';
import {simulateGame} from './src/game/game.js';
import {generateTeam} from './src/league/team.js';
import {PlaySim} from './src/sim/playsim.js';
import {World} from './src/physics/world.js';
import {ScoutingReport} from './src/sim/recognition.js';
import {CoverageScouting} from './src/sim/qbmind.js';
import {movementObjective} from './src/sim/movement-objective.js';
import {packReplayPlay} from './scripts/replay-data.js';
import {installContactAudit} from './contact-hook.js';
const out='/workspace/audit-deep/evidence/architecture';
const selected=new Set([2,11,17,19,29,31,38,60,117,142].map(x=>`G1-P${String(x).padStart(3,'0')}`));
export const replacer=(_k:string,v:any)=>v instanceof Map?{__type:'Map',entries:[...v]}:v instanceof Set?{__type:'Set',entries:[...v]}:v instanceof Rng?{__type:'Rng',...v}:v instanceof ScoutingReport?{__type:'ScoutingReport',...v}:v instanceof CoverageScouting?{__type:'CoverageScouting',...v}:typeof v==='number'&&!Number.isFinite(v)?{__number:String(v)}:v;
const snapshot=(v:any)=>JSON.parse(JSON.stringify(v,replacer));
const save=(p:string,v:any)=>writeFileSync(p,JSON.stringify(v,replacer));
const command=(c:any)=>c?{...snapshot(c),objective:movementObjective(c)}:null;
const meta=new WeakMap<any,any>(),census:any[]=[];let current:any;
const state=(a:any)=>({idx:a.idx,slot:a.slot,team:a.team,pos:{...a.pos},vel:{...a.vel},facing:a.facing,angularVelocity:a.body.angularVelocity,energy:a.body.energy,support:snapshot(a.body.support),squeeze:a.body.squeeze,engagement:a.engagement?{blocker:a.engagement.blocker.idx,defender:a.engagement.defender.idx,helpers:a.engagement.helpers.map((x:any)=>x.idx)}:null,kind:a.behavior.kind,ctor:a.behavior.constructor.name,target:a.behavior.target?.idx,runFit:a.runFit,recog:a.recog?{read:a.recog.read,logOdds:a.recog.logOdds}:null,mind:{aims:snapshot(a.mind.aims),focus:a.mind.focus,stress:a.mind.stress,interval:a.mind.decisionInterval},plan:a.behavior.plan?{kind:a.behavior.plan.kind,target:a.behavior.plan.target?.idx,climbTo:a.behavior.plan.climbTo?.idx,drive:a.behavior.plan.drive,pullRole:a.behavior.plan.pullRole}:null});
const ball=(s:any)=>({kind:s.ball.kind,carrier:s.carrier?.idx,throwAt:s.throwAt,handoffAt:s.handoffAt,catchAt:s.catchAt,scrambled:s.scrambled,pos:s.ballPos()});
(globalThis as any).__auditSetup=(s:any,setup:any)=>{const m={...(globalThis as any).__auditGameMeta,setup:snapshot(setup),ticks:[] as any[],summary:{steps:0,rewrites:{} as any,phaseChanges:[] as any[],seenCarrierNegative:[] as any[]}};meta.set(s,m);save(`${out}/${m.id}-setup.json`,m.setup);};
(globalThis as any).__auditStage=(s:any,stage:string,i?:number,c?:any)=>{
 const m=meta.get(s);if(!m)return; const detailed=selected.has(m.id);
 if(stage==='pre'){m.tick={t:s.t,ball:ball(s),pre:detailed?s.agents.map(state):undefined,commands:{raw:[],contained:[],opened:[]},observations:[],decisions:[]};m.summary.steps++;}
 const r=m.tick;if(!r)return; current={sim:s,m,stage};
 if(stage==='beforeDecision'){r.decisions[i!]={idx:i,kind:s.agents[i!].behavior.kind,carrier:s.carrier?.idx,throwAt:s.throwAt,handoffAt:s.handoffAt};}
 if(stage==='raw'||stage==='contained'||stage==='opened'){r.commands[stage][i!]=command(c);if(stage==='raw'){const prior=r.decisions[i!];if(prior.carrier!==s.carrier?.idx||prior.throwAt!==s.throwAt||prior.kind!==s.agents[i!].behavior.kind)m.summary.phaseChanges.push({t:s.t,idx:i,slot:s.agents[i!].slot,prior,after:{kind:s.agents[i!].behavior.kind,...ball(s)}});}}
 if(['engagement','bond','spacing','final'].includes(stage))r.commands[stage]=s.intents.map(command);
 if(stage==='postPhysics'&&detailed)r.postPhysics=s.agents.map(state);
 if(stage==='post'){
   for(const [from,to] of [['raw','contained'],['contained','opened'],['opened','engagement'],['engagement','bond'],['bond','spacing'],['spacing','final']])for(let k=0;k<s.agents.length;k++){
    const a=r.commands[from]?.[k],b=r.commands[to]?.[k];if(!a||!b)continue;
    const dv=Math.hypot(a.vel.x-b.vel.x,a.vel.y-b.vel.y),df=a.facing===undefined||b.facing===undefined?null:Math.abs(Math.atan2(Math.sin(a.facing-b.facing),Math.cos(a.facing-b.facing)));
    if(dv>1e-9||(df??0)>1e-9){const q=m.summary.rewrites[to]??={count:0,maxDv:0,maxDf:0,velocityOpposed:0};q.count++;q.maxDv=Math.max(q.maxDv,dv);q.maxDf=Math.max(q.maxDf,df??0);if(a.vel.x*b.vel.x+a.vel.y*b.vel.y<0)q.velocityOpposed++;}
   }
   if(detailed){r.post=s.agents.map(state);r.ballAfter=ball(s);m.ticks.push(r);}m.tick=null;current=null;
 }
};
const oldSee=PlaySim.prototype.see;
PlaySim.prototype.see=function(a:any,b:any,...args:any[]){const v=(oldSee as any).call(this,a,b,...args);const m=meta.get(this);if(m?.tick){const row={stage:current?.stage,a:a.idx,b:b.idx,...snapshot(v)};if(selected.has(m.id))m.tick.observations.push(row);if(a.team==='D'&&this.carrier===b&&!v.carrying&&b.slot!=='QB'&&current?.stage==='beforeDecision')m.summary.seenCarrierNegative.push({t:this.t,a:a.slot,b:b.slot,kind:a.behavior.kind,age:v.age,pose:v.pose});}return v;};
const contact=installContactAudit(World);
const rng=new Rng(7),home=generateTeam(rng,'Ironmen','IRN',{strength:.55}),away=generateTeam(rng,'Comets','COM',{strength:.55});
const start=performance.now();
const game=simulateGame(home,away,{seed:7,record:true,recordLevel:'light',hooks:{playResult(sim:any,kind:any){const m=meta.get(sim);contact.onSim(sim,{id:m.id,kind});m.agents=sim.agents.map((a:any)=>({idx:a.idx,slot:a.slot,team:a.team,profile:a.profile,player:a.player}));m.initialRng=snapshot(sim.rng);const result=sim.run();m.finalRng=snapshot(sim.rng);m.result={outcome:result.outcome,yards:result.yards,duration:result.duration,events:result.events};census.push({id:m.id,result:m.result,summary:m.summary});if(selected.has(m.id)){save(`${out}/${m.id}-trace.json`,m);console.log(`wrote ${m.id} ${m.ticks.length} ticks`);}return result;}}});
const plays=game.log.map(p=>packReplayPlay(p,0)),baseline=JSON.parse(readFileSync('/workspace/football-audit/out/audit/film.json','utf8'));
const same=JSON.stringify(plays)===JSON.stringify(baseline.plays);save(`${out}/ordinary-census.json`,{neutralEqualPackedReplay:same,score:game.score,plays:census,elapsed:(performance.now()-start)/1000});save('/workspace/audit-deep/evidence/contact/ordinary-census.json',contact.finish());save(`${out}/instrumented-film-plays.json`,plays);
console.log(JSON.stringify({same,score:game.score,plays:census.length,elapsed:(performance.now()-start)/1000}));
