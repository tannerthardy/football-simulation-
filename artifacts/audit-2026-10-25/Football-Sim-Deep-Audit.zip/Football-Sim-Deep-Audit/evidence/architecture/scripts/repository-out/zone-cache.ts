import {writeFileSync} from 'node:fs';
import {readSetup} from './revive.js';
import {PlaySim} from '../../src/sim/playsim.js';
import {ZoneCoverage} from '../../src/sim/behaviors/defense.js';
import {movementObjective} from '../../src/sim/movement-objective.js';
function run(targetKey:boolean,change:boolean){
 const sim=new PlaySim(readSetup('G1-P002')),a=sim.slot('FS')!,one=sim.slot('WR1')??sim.offense[7],two=sim.slot('WR2')??sim.offense[8];
 sim.t=2;a.body.pos={x:sim.los+15,y:26.667};a.body.vel={x:0,y:0};a.body.facing=Math.PI; a.recog!.read='pass';a.mind.focus=1;(a as any).r=(key:string)=>key==='playRecognition'?1:.8;
 const z=new ZoneCoverage(a,sim,'deep_mid','A',1); a.behavior=z;
 let second=false;
 sim.see=(_a,b)=>({pos:b===one?{x:sim.los+9,y:22}:b===two?{x:sim.los+(second&&change?9.01:8.99),y:31}:{x:sim.los-5,y:26.667},vel:{x:0,y:0},facing:Math.PI,age:.1,carrying:b===sim.qb,pose:'up'} as any);
 if(targetKey){const aim=a.mind.aim.bind(a.mind);a.mind.aim=(job,p,t)=>aim(`${job}:${z.target?.idx}`,p,t);}
 const first=z.update(a,sim);const firstTarget=z.target?.slot;const firstAim=movementObjective(first);
 second=true;sim.t=2.05;const secondCommand=z.update(a,sim);return {one:one.slot,two:two.slot,first:{target:firstTarget,command:first,objective:firstAim},second:{target:z.target?.slot,command:secondCommand,objective:movementObjective(secondCommand)},aims:[...(a.mind as any).aims]};
}
const out={nativeChange:run(false,true),keyedChange:run(true,true),nativeSame:run(false,false),keyedSame:run(true,false)};writeFileSync('/workspace/audit-deep/evidence/architecture/zone-cache.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));
