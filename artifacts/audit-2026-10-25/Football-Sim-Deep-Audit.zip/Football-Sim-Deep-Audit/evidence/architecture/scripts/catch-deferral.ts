import {writeFileSync,readFileSync} from 'node:fs';
import {readSetup} from './revive.js';
import {PlaySim} from './src/sim/playsim.js';
function run(defer:boolean,gate=false){const sim=new PlaySim(readSetup('G1-P002')),a=sim.slot('SS')!;let replacement:any,receiver:any;const rows:any[]=[];
 (globalThis as any).__auditRequireAcquiredHolder=(_s:any,actor:any)=>gate&&actor===a;
 if(defer){const possess=sim.possess.bind(sim);sim.possess=(r,how)=>{const old=a.behavior;possess(r,how);if(how==='catch'){replacement=a.behavior;receiver=r;a.behavior=old;}};}
 (globalThis as any).__auditStage=(s:any,stage:string,i:number,c:any)=>{
  if(stage==='beforeDecision'&&i===a.idx&&replacement){const look=(.12+.12*(1-a.r('awareness')))/Math.max(.1,a.profile.reactionTime);if(s.see(a,receiver,look).carrying){a.behavior=replacement;replacement=null;}}
  if(stage==='raw'&&i===a.idx)rows.push({t:s.t,rng:{...s.rng},kind:a.behavior.kind,command:c,pos:{...a.pos},vel:{...a.vel}});
 };
 const r=sim.run();return{defer,gate,rows,result:{outcome:r.outcome,yards:r.yards,duration:r.duration,events:r.events}};}
const native=run(false),deferred=run(true),gatedOnly=run(false,true),both=run(true,true);const out={native,deferred,gatedOnly,both};writeFileSync('/workspace/audit-deep/evidence/architecture/catch-deferral.json',JSON.stringify(out));console.log(JSON.stringify(Object.fromEntries(Object.entries(out).map(([key,value])=>[key,{yards:value.result.yards,duration:value.result.duration,sameEvents:JSON.stringify(value.result.events)===JSON.stringify(native.result.events),firstCommandChange:value.rows.find((r,i)=>JSON.stringify(r.command)!==JSON.stringify(native.rows[i]?.command)),maxSSPositionDelta:Math.max(...value.rows.map((r,i)=>Math.hypot(r.pos.x-native.rows[i].pos.x,r.pos.y-native.rows[i].pos.y)))}])),null,2));
