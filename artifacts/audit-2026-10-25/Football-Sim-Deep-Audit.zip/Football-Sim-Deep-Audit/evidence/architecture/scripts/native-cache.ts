import {writeFileSync,readFileSync} from 'node:fs';
import {readSetup} from './revive.js';
import {PlaySim} from './src/sim/playsim.js';
import {movementObjective} from './src/sim/movement-objective.js';
function run(fix:boolean){
 const sim=new PlaySim(readSetup('G1-P029')),a=sim.slot('RT')!;let target:any,prior:any;const invalidate:any[]=[],rows:any[]=[];
 if(fix){const aim=a.mind.aim.bind(a.mind);a.mind.aim=(job,p,t)=>{if(job==='block-fit'){const next=(a.behavior as any).target;if(target&&target!==next){const old=(a.mind as any).aims.get(job);invalidate.push({t,oldTarget:target.idx,newTarget:next?.idx,oldAim:old,desired:p});(a.mind as any).aims.delete(job);}target=next;}return aim(job,p,t);};}
 (globalThis as any).__auditStage=(s:any,stage:string,i:number,c:any)=>{
  if(stage==='raw'&&i===a.idx)rows.push({t:s.t,stage,target:(a.behavior as any).target?.idx,command:{...c,objective:movementObjective(c)}});
  if(stage==='final')rows.push({t:s.t,stage,command:{...s.intents[a.idx],objective:movementObjective(s.intents[a.idx])}});
  if(stage==='post')rows.push({t:s.t,stage,players:s.agents.map((b:any)=>({slot:b.slot,pos:{...b.pos},vel:{...b.vel},facing:b.facing,state:b.body.support?.state})),engagement:a.engagement?.defender.idx});
 };
 const r=sim.run();return {fix,invalidate,rows,result:{outcome:r.outcome,yards:r.yards,duration:r.duration,events:r.events},rng:{...sim.rng}};
}
const native=run(false),fixed=run(true);const prior=JSON.parse(readFileSync('/workspace/audit-deep/evidence/architecture/G1-P029-trace.json','utf8'));
let first:any,maxDistance=0,changedRows=0;for(let i=0;i<Math.min(native.rows.length,fixed.rows.length);i++){const a=native.rows[i],b=fixed.rows[i];if(JSON.stringify(a)!==JSON.stringify(b)){first??={native:a,fixed:b};changedRows++;}if(a.stage==='post')for(let j=0;j<a.players.length;j++)maxDistance=Math.max(maxDistance,Math.hypot(a.players[j].pos.x-b.players[j].pos.x,a.players[j].pos.y-b.players[j].pos.y));}
const out={native,fixed,baselineEqualEvents:JSON.stringify(native.result.events)===JSON.stringify(prior.result.events),first,maxDistance,changedRows};writeFileSync('/workspace/audit-deep/evidence/architecture/native-cache.json',JSON.stringify(out));console.log(JSON.stringify({baselineEqualEvents:out.baselineEqualEvents,invalidate:fixed.invalidate,first,maxDistance,changedRows,native:native.result,fixed:fixed.result},null,2));
