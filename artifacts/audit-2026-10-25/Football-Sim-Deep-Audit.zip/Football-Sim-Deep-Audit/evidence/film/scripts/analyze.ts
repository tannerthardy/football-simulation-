import {readFileSync,writeFileSync} from 'node:fs';
import {supportParams} from './src/physics/support.js';
import {timeToReach} from './src/physics/reach.js';
const base='/workspace/football-audit/out/forensic-film';const out=[];
for(const id of ['G1-P002','G1-P117']){
 const f=JSON.parse(readFileSync(`${base}/${id}-21-baseline.json`,'utf8'));const A=supportParams(f.profile).traction/f.profile.massKg;
 const rows=f.points.map((p:any)=>{const t=p.ip.t;const inertial={x:p.pos.x+p.vel.x*t,y:p.pos.y+p.vel.y*t};const gap=Math.hypot(p.ip.point.x-inertial.x,p.ip.point.y-inertial.y)-.5*A*t*t-p.reach;const tt=timeToReach({pos:p.pos,vel:p.vel,profile:f.profile,speedScale:p.speedScale},p.ip.point,p.reach);return {t:p.t,ipTime:t,reachTime:tt,ip:p.ip.point,aim:p.aim,violation:gap,pos:p.pos,vel:p.vel,seen:p.seen,acceleration:p.acceleration,speedScale:p.speedScale,engaged:p.engaged,down:p.down};});
 const violations=rows.filter((r:any)=>r.violation>0&&r.reachTime<=r.ipTime);out.push({id,A,violations,rows});console.log(JSON.stringify({id,A,violationCount:violations.length,rows:rows.filter((r:any)=>Math.round(r.t*20)%4===0).map((r:any)=>({t:r.t,ipTime:r.ipTime,reachTime:r.reachTime,violation:r.violation,acceleration:r.acceleration,aim:r.aim}))}));
}
writeFileSync(`${base}/native-reach-analysis.json`,JSON.stringify(out,null,2));
