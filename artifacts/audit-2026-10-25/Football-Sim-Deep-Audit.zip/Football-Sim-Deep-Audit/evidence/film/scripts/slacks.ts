import {readFileSync,writeFileSync} from 'node:fs';
import {timeToReach} from './src/physics/reach.js';
const f=JSON.parse(readFileSync('/workspace/football-audit/out/forensic-film/G1-P002-21-baseline.json','utf8'));
const rows=[];
for(const q of f.points.filter((q:any)=>[4.2,4.25,4.3,4.35].includes(q.t))){
 const sp=Math.hypot(q.seen.vel.x,q.seen.vel.y),h={x:q.seen.vel.x/sp,y:q.seen.vel.y/sp};
 const grid=[];
 for(let k=0;k<=30;k++){const t=k/10,d=q.V*t-(q.V-sp)*q.tau*(1-Math.exp(-t/q.tau)),point={x:q.seen.pos.x+h.x*d,y:Math.min(53.333333333333336,Math.max(0,q.seen.pos.y+h.y*d))};const tt=timeToReach({pos:q.pos,vel:q.vel,profile:f.profile,speedScale:q.speedScale},point,q.reach);grid.push({t,tt,slack:tt-t,point});}
 rows.push({tick:q.t,selected:q.ip,aim:q.aim,seen:q.seen,grid});
}
writeFileSync('/workspace/football-audit/out/forensic-film/native-intercept-slacks.json',JSON.stringify(rows,null,2));console.log(JSON.stringify(rows.map(r=>({tick:r.tick,selected:r.selected.t,slacks:r.grid.filter(q=>[1.6,1.8,2.8,3].includes(q.t)).map(q=>({t:q.t,slack:q.slack}))})),null,2));
