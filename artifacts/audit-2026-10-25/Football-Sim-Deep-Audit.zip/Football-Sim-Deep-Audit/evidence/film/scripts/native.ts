import {readFileSync,writeFileSync} from 'node:fs';
import {PlaySim} from './src/sim/playsim.js';
import {Rng} from './src/core/rng.js';
import {ScoutingReport} from './src/sim/recognition.js';
import {CoverageScouting} from './src/sim/qbmind.js';
const dir='/workspace/audit-deep/evidence/architecture';
const out='/workspace/football-audit/out/forensic-film';
function revive(_k:string,v:any):any {if(!v||typeof v!=='object')return v;if(v.__number)return Number(v.__number);const t=v.__type;if(!t)return v;delete v.__type;if(t==='Map')return new Map(v.entries);if(t==='Set')return new Set(v.entries);if(t==='Rng')return Object.assign(new Rng(v.key),v);if(t==='ScoutingReport')return Object.assign(new ScoutingReport(),v);if(t==='CoverageScouting')return Object.assign(new CoverageScouting(),v);return v;}
const args=process.argv.slice(2), id=args[0]??'G1-P002', idx=Number(args[1]??21), arms=args.slice(2).length?args.slice(2):['baseline','yaw2x','horizon08','accel0','zeroDelay','brakeTurn'];
const native=JSON.parse(readFileSync(`${dir}/${id}-trace.json`,'utf8'));
const summaries=[];
for(const arm of arms){
 const setup=JSON.parse(readFileSync(`${dir}/${id}-setup.json`,'utf8'),revive),sim:any=new PlaySim(setup),a=sim.agents[idx];
 const audit={idx,arm,points:[] as any[],requests:[] as any[],states:[] as any[],interventions:[] as any[]};sim.__filmAudit=audit;
 const oldSee=sim.see.bind(sim);sim.see=(o:any,t:any,d:any)=>{if(arm==='zeroDelay'&&o===a&&t===sim.carrier&&((Number.isFinite(sim.catchAt)&&sim.catchAt>=0&&sim.t>=sim.catchAt)||(Number.isFinite(sim.handoffAt)&&sim.handoffAt>=0&&sim.t>=sim.handoffAt)))return sim.perception.perceive(t.idx,0);const seen=oldSee(o,t,d);if(arm==='fresher015'&&o===a&&t===sim.carrier&&((Number.isFinite(sim.catchAt)&&sim.catchAt>=0&&sim.t>=sim.catchAt)||(Number.isFinite(sim.handoffAt)&&sim.handoffAt>=0&&sim.t>=sim.handoffAt)))return sim.perception.perceive(t.idx,Math.max(0,seen.age-.15));return seen;};
 const oldTick=sim.tick.bind(sim);let prefixDiff:any=null,allStateEqual=true;
 sim.tick=()=>{const n=native.ticks.find((q:any)=>Math.abs(q.t-sim.t)<1e-7);let diff=0;if(n)for(let i=0;i<sim.agents.length;i++){const b=sim.agents[i];diff=Math.max(diff,Math.abs(b.pos.x-n.pre[i].pos.x),Math.abs(b.pos.y-n.pre[i].pos.y),Math.abs(b.vel.x-n.pre[i].vel.x),Math.abs(b.vel.y-n.pre[i].vel.y),Math.abs(b.facing-n.pre[i].facing));}if(diff>1e-10){allStateEqual=false;if(!prefixDiff)prefixDiff={t:sim.t,maxDiff:diff};}const c=sim.carrier;audit.states.push({t:sim.t,pos:{...a.pos},vel:{...a.vel},facing:a.facing,energy:a.body.energy,engaged:!!a.engagement,down:a.isDown(sim.t),kind:a.behavior.kind,carrier:c?.idx,carrierPos:c?{...c.pos}:null,carrierVel:c?{...c.vel}:null,distance:c?Math.hypot(c.pos.x-a.pos.x,c.pos.y-a.pos.y):null,support:JSON.parse(JSON.stringify(a.body.support))});oldTick();};
 const oldStep=sim.world.step.bind(sim.world),originalTurn=a.profile.turnRate;
 sim.world.step=(cmds:any[],dt:number)=>{const active=((Number.isFinite(sim.catchAt)&&sim.catchAt>=0&&sim.t>=sim.catchAt)||(Number.isFinite(sim.handoffAt)&&sim.handoffAt>=0&&sim.t>=sim.handoffAt))&&sim.carrier?.team!==a.team;const original=cmds[idx];if(active&&arm==='yaw2x')a.profile.turnRate=originalTurn*2;let cmd=original;if(active&&arm==='brakeTurn'&&!a.engagement&&!a.isDown(sim.t)&&Math.hypot(a.vel.x,a.vel.y)>2&&a.vel.x*cmd.vel.x+a.vel.y*cmd.vel.y<0){cmd={...cmd,vel:{x:0,y:0}};cmds=[...cmds];cmds[idx]=cmd;}if(cmd!==original||active&&arm==='yaw2x')audit.interventions.push(sim.t);audit.requests.push({t:sim.t,original,cmd});return oldStep(cmds,dt);};
 const result=sim.run();const resultSame=JSON.stringify({outcome:result.outcome,yards:result.yards,duration:result.duration,events:result.events})===JSON.stringify(native.result);
 const transferAt=Math.min(sim.catchAt>=0?sim.catchAt:Infinity,sim.handoffAt>=0?sim.handoffAt:Infinity);const postCatch=audit.states.filter(s=>s.t>=transferAt),contact=result.events.filter((e:any)=>['tackle_contact','tackle','tackle_miss','catch','oob'].includes(e.type));
 const min=Math.min(...postCatch.map(s=>s.distance??Infinity)),firstNear=postCatch.find(s=>s.distance!==null&&s.distance<1.5)?.t;
 const summary={id,idx,arm,allStateEqual,resultSame,prefixDiff,catchAt:sim.catchAt,handoffAt:sim.handoffAt,transferAt,result:{outcome:result.outcome,yards:result.yards,duration:result.duration},minDistance:min,firstWithin1_5:firstNear,interventionTicks:audit.interventions.length,events:contact};summaries.push(summary);writeFileSync(`${out}/${id}-${idx}-${arm}.json`,JSON.stringify({...summary,...audit,profile:a.profile,resultEvents:result.events,finalRng:sim.rng}));console.log(JSON.stringify(summary));
}
writeFileSync(`${out}/${id}-${idx}-summary.json`,JSON.stringify(summaries,null,2));
