import fs from 'node:fs';
import { Rng } from '../../src/core/rng.js';
import { generatePlayer } from '../../src/players/generator.js';
import { derivePhysical } from '../../src/players/physical.js';
import { World } from '../../src/physics/world.js';
import { type Body } from '../../src/physics/kinematics.js';
import { timeToReach } from '../../src/physics/reach.js';
import { newSupport, supportParams } from '../../src/physics/support.js';
const profile=derivePhysical(generatePlayer(new Rng(718),'S',{quality:.65,id:'audit-S'}));
// Give the player the ENTIRE turf traction in ANY direction immediately,
// even beyond his normal gait envelope. No external contact/strike/normal
// loading exists. This loose necessary condition is not an optimal policy.
const A=supportParams(profile).traction/profile.massKg;
const gaitA=Math.max(profile.vmax/profile.tau,profile.brake,profile.lateral);
const cases:any[]=[];
for(const initial of [{x:9,y:0},{x:0,y:0},{x:0,y:9},{x:6,y:0}])
for(const goal of [{x:0,y:3},{x:3,y:3},{x:6,y:3},{x:9,y:3},{x:12,y:0},{x:-3,y:0}])
for(const radius of [.5,1.2]){
  const body:Body={pos:{x:0,y:0},vel:{...initial},facing:Math.atan2(initial.y,initial.x),energy:1,profile,support:newSupport()};
  const predicted=timeToReach(body,goal,radius);
  const gap=(t:number)=>Math.hypot(goal.x-initial.x*t,goal.y-initial.y*t)-.5*A*t*t-radius;
  let firstNecessary=0;
  while(gap(firstNecessary)>0&&firstNecessary<10)firstNecessary+=.001;
  const world=new World([body]);const trace:any[]=[];
  for(let k=0;k<100;k++){
    const dx=goal.x-body.pos.x,dy=goal.y-body.pos.y,d=Math.hypot(dx,dy);
    world.step([{vel:{x:dx/d*profile.vmax,y:dy/d*profile.vmax}}],.05);
    trace.push({t:+((k+1)*.05).toFixed(2),pos:{...body.pos},distance:Math.hypot(goal.x-body.pos.x,goal.y-body.pos.y)});
  }
  cases.push({initial,goal,radius,predicted,earliestNecessary:firstNecessary,
    unreachableAtPrediction:gap(predicted)>1e-9,violation:gap(predicted),
    gaitOnlyViolation:Math.hypot(goal.x-initial.x*predicted,goal.y-initial.y*predicted)-.5*gaitA*predicted*predicted-radius,
    directCapture:trace.find(r=>r.distance<=radius)?.t??null,trace});
}
fs.writeFileSync(new URL('./reach-bound.json',import.meta.url),JSON.stringify({revision:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',profile,maxTractionAcceleration:A,maxGaitAcceleration:gaitA,cases},null,2));
console.log(JSON.stringify(cases.filter(c=>c.unreachableAtPrediction).map(({trace,...c})=>c),null,2));
