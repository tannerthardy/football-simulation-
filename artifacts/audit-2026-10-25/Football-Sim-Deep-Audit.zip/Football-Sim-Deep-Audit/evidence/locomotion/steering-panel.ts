import fs from 'node:fs';
import { Rng } from '../../src/core/rng.js';
import { angleDiff } from '../../src/core/vec.js';
import { generatePlayer } from '../../src/players/generator.js';
import { derivePhysical } from '../../src/players/physical.js';
import { World, type Intent } from '../../src/physics/world.js';
import { arriveVelocity, movingArrivalVelocity, type Body } from '../../src/physics/kinematics.js';
import { previewFreeMovement } from '../../src/physics/movement-preview.js';
import { timeToReach } from '../../src/physics/reach.js';
import { newSupport } from '../../src/physics/support.js';
const profile=derivePhysical(generatePlayer(new Rng(718),'S',{quality:.65,id:'audit-S'}));
const cases:any[]=[]; const dt=.05;
for(const speed of [3,6,9])for(const target0 of [{x:0,y:3},{x:3,y:3},{x:6,y:3},{x:9,y:3},{x:3,y:6},{x:6,y:6},{x:12,y:0},{x:-3,y:0}])
for(const variant of ['native','gather35','plant','preview'] as const){
  const body:Body={pos:{x:0,y:0},vel:{x:speed,y:0},facing:0,energy:1,profile,support:newSupport()};
  const world=new World([body]), trace:any[]=[];
  const predicted=timeToReach(body,target0,.5);
  for(let k=0;k<120;k++){
    const cmd:Intent={vel:arriveVelocity(body,target0,profile.vmax,0)};
    const cmdHeading=Math.atan2(cmd.vel.y,cmd.vel.x), currentHeading=Math.atan2(body.vel.y,body.vel.x), s=Math.hypot(body.vel.x,body.vel.y);
    if(variant==='gather35'&&s>2.5&&Math.abs(angleDiff(currentHeading,cmdHeading))>Math.PI/3){cmd.vel.x*=.35;cmd.vel.y*=.35;}
    if(variant==='plant'&&s>2.5&&Math.abs(angleDiff(currentHeading,cmdHeading))>Math.PI/3){cmd.vel={x:0,y:0};}
    if(variant==='preview'){
      const candidates=[cmd,{vel:{x:cmd.vel.x*.35,y:cmd.vel.y*.35}},{vel:{x:0,y:0}}];
      let best=Infinity, chosen=cmd;
      for(const candidate of candidates){
        const sample=previewFreeMovement(body,candidate,k*dt,12).at(-1)!;
        const d=Math.hypot(sample.pos.x-target0.x,sample.pos.y-target0.y);
        const score=d+.1*Math.hypot(sample.vel.x,sample.vel.y);
        if(score<best){best=score;chosen=candidate;}
      }
      cmd.vel=chosen.vel;
    }
    world.step([cmd],dt);
    const distance=Math.hypot(body.pos.x-target0.x,body.pos.y-target0.y), actualSpeed=Math.hypot(body.vel.x,body.vel.y);
    trace.push({t:+((k+1)*dt).toFixed(2),pos:{...body.pos},vel:{...body.vel},facing:body.facing,
      request:cmd,distance,speed:actualSpeed,state:body.support!.state});
  }
  cases.push({speed,target:target0,variant,predicted,capture:trace.find(r=>r.distance<.5)?.t??null,
    controlledCapture:trace.find(r=>r.distance<.5&&r.speed<1)?.t??null,
    minDistance:Math.min(...trace.map(r=>r.distance)),pathLength:trace.reduce((s,r,i)=>s+Math.hypot(r.pos.x-(trace[i-1]?.pos.x??0),r.pos.y-(trace[i-1]?.pos.y??0)),0),trace});
}
fs.writeFileSync(new URL('./steering-panel.json',import.meta.url),JSON.stringify({revision:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',dt,profile,cases},null,2));
console.log(JSON.stringify(cases.map(({trace,...c})=>c),null,2));
