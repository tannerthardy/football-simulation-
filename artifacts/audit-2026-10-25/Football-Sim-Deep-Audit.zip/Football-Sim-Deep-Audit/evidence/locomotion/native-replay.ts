import fs from 'node:fs';
import { World, type Intent } from '../../src/physics/world.js';
import { commandFacing, type Body } from '../../src/physics/kinematics.js';
const root='/workspace/audit-deep/evidence/architecture/';
const native=JSON.parse(fs.readFileSync(root+'G1-P002-trace.json','utf8'));
const snapshot=JSON.parse(fs.readFileSync(root+'G1-P002-SS-3.8-body.json','utf8'));
snapshot.body.support.since=-Infinity;
const ticks=native.ticks.filter((t:any)=>t.t>=3.8&&t.t<6.0),dt=.05;
const cases:any[]=[];
for(const variant of ['native','yaw2','instantFacing','brake2','lateral2','mass2','holdFirst','stop'] as const){
 const body:Body=structuredClone(snapshot.body),world=new World([body]);world.time=3.8;
 if(variant==='yaw2')body.profile.turnRate*=2;
 if(variant==='brake2')body.profile.brake*=2;
 if(variant==='lateral2')body.profile.lateral*=2;
 // Build World again after profile changes because it owns cached masses.
 if(variant==='mass2')body.profile.massKg*=2;
 const actualWorld=new World([body]);actualWorld.time=3.8;
 const trace:any[]=[];
 for(const tick of ticks){
  const requested:Intent=structuredClone(variant==='holdFirst'?ticks[0].commands.final[21]:tick.commands.final[21]);
  if(variant==='stop')requested.vel={x:0,y:0};
  if(variant==='instantFacing')body.facing=commandFacing(body,requested);
  const before=structuredClone(body),report=actualWorld.step([requested],dt);
  const actual=tick.postPhysics[21],runner=tick.postPhysics[tick.ball.carrier];
  const productionPlan=(actualWorld as any).plans[0];
  trace.push({t:tick.t+dt,pos:{...body.pos},vel:{...body.vel},facing:body.facing,speed:Math.hypot(body.vel.x,body.vel.y),
   requested,worldPlan:{ax:productionPlan.ax,ay:productionPlan.ay,facing:productionPlan.facing},
   positionError:Math.hypot(body.pos.x-actual.pos.x,body.pos.y-actual.pos.y),
   velocityError:Math.hypot(body.vel.x-actual.vel.x,body.vel.y-actual.vel.y),
   facingError:Math.abs(body.facing-actual.facing),
   nativeRunnerDistance:Math.hypot(body.pos.x-runner.pos.x,body.pos.y-runner.pos.y),
   achievedAccel:{x:(body.vel.x-before.vel.x)/dt,y:(body.vel.y-before.vel.y)/dt},
   state:body.support!.state,xi:body.support!.xi,contacts:report.contacts.length});
 }
 cases.push({variant,maxPositionError:Math.max(...trace.map(r=>r.positionError)),maxVelocityError:Math.max(...trace.map(r=>r.velocityError)),
  stopTime:trace.find(r=>r.speed<.2)?.t??null,
  minNativeRunnerDistance:Math.min(...trace.map(r=>r.nativeRunnerDistance)),end:trace.at(-1),trace});
}
fs.writeFileSync(new URL('./native-replay.json',import.meta.url),JSON.stringify({revision:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',snapshot,dt,cases},null,2));
console.log(JSON.stringify(cases.map(({trace,...c})=>c),null,2));
