import fs from 'node:fs';
import { Rng } from '../../src/core/rng.js';
import { angleDiff } from '../../src/core/vec.js';
import { generatePlayer } from '../../src/players/generator.js';
import { derivePhysical } from '../../src/players/physical.js';
import { World, type Intent } from '../../src/physics/world.js';
import { type Body } from '../../src/physics/kinematics.js';
import { newSupport } from '../../src/physics/support.js';
import { Agent } from '../../src/sim/agent.js';
import { chase, pursuitPoint } from '../../src/sim/behaviors/common.js';
const defPlayer=generatePlayer(new Rng(718),'S',{quality:.65,id:'audit-S'});
const runnerPlayer=generatePlayer(new Rng(723),'RB',{quality:.65,id:'audit-RB'});
const profile=derivePhysical(defPlayer), runnerProfile=derivePhysical(runnerPlayer);
const cases:any[]=[]; const dt=.05;
const scenarios=[
 {name:'stationary-cross',target:{x:3,y:3},v:{x:0,y:0}},
 {name:'cross-near',target:{x:3,y:3},v:{x:0,y:3}},
 {name:'cross-fast',target:{x:3,y:3},v:{x:0,y:6}},
 {name:'cross-far',target:{x:6,y:6},v:{x:0,y:6}},
 {name:'cross-opposite',target:{x:6,y:6},v:{x:0,y:-6}},
 {name:'downfield-oblique',target:{x:3,y:6},v:{x:6,y:0}},
 {name:'trailing',target:{x:6,y:0},v:{x:6,y:0}},
 {name:'head-on',target:{x:12,y:0},v:{x:-6,y:0}},
 {name:'opposite-oblique',target:{x:6,y:6},v:{x:-6,y:0}},
];
for(const speed of [3,6,9])for(const scenario of scenarios)for(const side of [-1,1])
for(const variant of ['native','gather35','plant'] as const){
  const body:Body={pos:{x:40,y:26.6666667},vel:{x:speed,y:0},facing:0,energy:1,profile:structuredClone(profile),support:newSupport()};
  const targetBody:Body={pos:{x:40+scenario.target.x,y:26.6666667+side*scenario.target.y},vel:{x:scenario.v.x,y:side*scenario.v.y},facing:Math.atan2(side*scenario.v.y,scenario.v.x),energy:1,profile:runnerProfile};
  const a=new Agent(0,'D','FS',defPlayer,body.profile,body,{kind:'idle',update:()=>({vel:{x:0,y:0}})});
  const target=new Agent(1,'O','RB',runnerPlayer,runnerProfile,targetBody,{kind:'idle',update:()=>({vel:{x:0,y:0}})});
  const world=new World([body]), trace:any[]=[];
  const sim:any={t:0,carrier:target,bond:null,opponents:()=>[],rng:{fork:()=>({normal:()=>0})},
    see:()=>({pos:{...targetBody.pos},vel:{...targetBody.vel},facing:targetBody.facing,stance:null,pose:'up'})};
  const contact=profile.radius+runnerProfile.radius+profile.reach*.65;
  // 3.25 s keeps every prescribed constant-velocity runner within the field.
  // Capture absence is right-censored, not proof that eventual contact cannot occur.
  for(let k=0;k<65;k++){
    sim.t=k*dt;
    const original=chase(sim,a,target),cmd=structuredClone(original) as Intent;
    const intercept=pursuitPoint(sim,a,target);
    const cmdHeading=Math.atan2(cmd.vel.y,cmd.vel.x),currentHeading=Math.atan2(body.vel.y,body.vel.x),s=Math.hypot(body.vel.x,body.vel.y);
    if(variant==='gather35'&&s>2.5&&Math.abs(angleDiff(currentHeading,cmdHeading))>Math.PI/3){cmd.vel.x*=.35;cmd.vel.y*=.35;}
    if(variant==='plant'&&s>2.5&&Math.abs(angleDiff(currentHeading,cmdHeading))>Math.PI/3){cmd.vel={x:0,y:0};}
    world.step([cmd],dt);
    targetBody.pos={x:targetBody.pos.x+targetBody.vel.x*dt,y:targetBody.pos.y+targetBody.vel.y*dt};
    const distance=Math.hypot(body.pos.x-targetBody.pos.x,body.pos.y-targetBody.pos.y);
    trace.push({t:+((k+1)*dt).toFixed(2),pos:{...body.pos},vel:{...body.vel},facing:body.facing,
      target:{...targetBody.pos},original,request:cmd,intercept,distance,
      relativeSpeed:Math.hypot(body.vel.x-targetBody.vel.x,body.vel.y-targetBody.vel.y),state:body.support!.state});
  }
  cases.push({speed,scenario,side,variant,contact,capture:trace.find(r=>r.distance<=contact)?.t??null,
    controlledCapture:trace.find(r=>r.distance<=contact&&r.relativeSpeed<=3)?.t??null,
    minDistance:Math.min(...trace.map(r=>r.distance)),at1:trace[19],at2:trace[39],trace});
}
fs.writeFileSync(new URL('./pursuit-panel.json',import.meta.url),JSON.stringify({revision:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',dt,profile,runnerProfile,cases},null,2));
console.log(JSON.stringify(cases.filter(c=>c.side===1).map(({trace,at1,at2,...c})=>c),null,2));
