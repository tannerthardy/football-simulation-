import fs from 'node:fs';
import { Rng } from '../../src/core/rng.js';
import { angleDiff } from '../../src/core/vec.js';
import { generatePlayer } from '../../src/players/generator.js';
import { derivePhysical } from '../../src/players/physical.js';
import { World, type Intent } from '../../src/physics/world.js';
import { commandFacing, locomotionAccel, type Body } from '../../src/physics/kinematics.js';
import { newSupport } from '../../src/physics/support.js';

const dt=.05, rad=Math.PI/180;
const profiles=Object.fromEntries(['S','LB','CB'].map((position,i)=>{
  const player=generatePlayer(new Rng(718+i),position as any,{quality:.65,id:`audit-${position}`});
  return [position,{player,profile:derivePhysical(player)}];
}));
const cases:any[]=[];
for(const position of ['S','LB','CB']) for(const speed of [3,6,9]) for(const angle of [0,45,90,135,180,'stop'] as const)
for(const variant of ['base','yaw2','brake2','lateral2','burst2','fixedFacing','explicit','instantFacing'] as const){
  const profile=structuredClone(profiles[position].profile);
  if(variant==='yaw2')profile.turnRate*=2;
  if(variant==='brake2')profile.brake*=2;
  if(variant==='lateral2')profile.lateral*=2;
  if(variant==='burst2')profile.tau*=.5;
  const body:Body={pos:{x:0,y:0},vel:{x:speed,y:0},facing:0,energy:1,profile,support:newSupport()};
  const world=new World([body]);
  const target=angle==='stop'?0:angle*rad;
  const cmd:Intent={vel:angle==='stop'?{x:0,y:0}:{x:9*Math.cos(target),y:9*Math.sin(target)}};
  if(variant==='fixedFacing')cmd.facing=0;
  if(variant==='explicit')cmd.facing=target;
  const trace:any[]=[];
  for(let k=0;k<80;k++){
    if(variant==='instantFacing')body.facing=commandFacing(body,cmd);
    const before=structuredClone({pos:body.pos,vel:body.vel,facing:body.facing});
    const plan=locomotionAccel(body,cmd,dt);
    const report=world.step([cmd],dt);
    const v=Math.hypot(body.vel.x,body.vel.y), heading=Math.atan2(body.vel.y,body.vel.x);
    const actualPlan=(world as any).plans[0];
    trace.push({t:+((k+1)*dt).toFixed(2),before,request:cmd,rawAtAttainedFacing:plan,
      worldPlan:{ax:actualPlan.ax,ay:actualPlan.ay,facing:actualPlan.facing,cut:actualPlan.cut},
      pos:{...body.pos},vel:{...body.vel},speed:v,
      heading:heading/rad,facing:body.facing/rad,headingError:Math.abs(angleDiff(heading,target))/rad,
      hipTravel:Math.abs(angleDiff(heading,body.facing))/rad,state:body.support!.state,
      accel:Math.hypot(body.vel.x-before.vel.x,body.vel.y-before.vel.y)/dt,
      deltaVel:{x:body.vel.x-before.vel.x,y:body.vel.y-before.vel.y},
      workResidual:report.work.residual});
  }
  cases.push({position,speed,angle,variant,profile,stopTime:trace.find(r=>r.speed<.2)?.t??null,
    align10Time:trace.find(r=>r.speed>=1&&r.headingError<=10)?.t??null,
    maxX:Math.max(...trace.map(r=>r.pos.x)),minSpeed:Math.min(...trace.map(r=>r.speed)),
    fell:trace.some(r=>r.state!=='up'),maxResidual:Math.max(...trace.map(r=>Math.abs(r.workResidual))),
    snapshots:trace.filter(r=>[.2,.5,1,1.5,2,3,4].includes(r.t)),trace});
}
fs.writeFileSync(new URL('./motor-panel.json',import.meta.url),JSON.stringify({revision:'c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0',dt,profiles,cases},null,2));
console.log(JSON.stringify({profiles:Object.fromEntries(Object.entries(profiles).map(([k,v])=>[k,v.profile])),
  rows:cases.filter(c=>c.position==='S'&&c.speed===9).map(({trace,snapshots,profile,...c})=>({...c,at1:snapshots.find(s=>s.t===1)}))},null,2));
