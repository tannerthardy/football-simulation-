#!/usr/bin/env python3
"""Restore audit scripts/results into a pinned checkout and fresh sandbox copies.
No simulation is run; no tracked production file is changed. Use a copy of the
report package if reruns must not replace its original evidence outputs.
"""
from pathlib import Path
import argparse,gzip,json,shutil,subprocess
PIN='c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0'
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--sandbox-root',type=Path,required=True);p.add_argument('--audit',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args()
repo=a.repo.resolve();audit=a.audit.resolve();sand=a.sandbox_root.resolve();e=audit/'evidence'
assert subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()==PIN,'Checkout must be exactly pinned revision'
subprocess.run(['git','-C',str(repo),'diff','--exit-code','HEAD','--','src','scripts','package.json','package-lock.json','tsconfig.json'],check=True,stdout=subprocess.DEVNULL)
if sand.exists():raise SystemExit('Refusing to overwrite an existing sandbox root; choose a fresh path')
if not (repo/'node_modules/tsx').exists():raise SystemExit('Install pinned dependencies first: npm ci --no-audit --no-fund')
changes=[]
def copied(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 raw=gzip.decompress(src.read_bytes()) if src.suffix=='.gz' else src.read_bytes()
 if dst.suffix in ['.ts','.py']:
  before=raw.decode();after=before.replace('/workspace/football-audit',str(repo)).replace('/workspace/audit-deep',str(audit)).replace('/workspace/audit/current-film.html',str(audit/'reproduced-film.html'))
  if before!=after:changes.append(str(dst))
  raw=after.encode()
 dst.write_bytes(raw)
for lane in ['film','locomotion','contact','decision','root']:
 for src in (e/lane).glob('*'):
  if src.is_file():copied(src,repo/'out'/f'forensic-{lane}'/(src.name[:-3] if src.suffix=='.gz' else src.name))
for src in (e/'measurement').rglob('*'):
 if src.is_file():copied(src,repo/'out/forensic-validation'/src.relative_to(e/'measurement'))
for src in (e/'architecture/scripts/repository-out').glob('*.ts'):copied(src,repo/'out/forensic-architecture'/src.name)
for name in ['film-capture.ts','information-boundary.ts']:copied(e/'first-audit'/name,repo/'out/audit'/name)
for name in ['hand-law.ts','leadblock.ts']:copied(e/'first-audit'/name,repo/'out/consultant-physics'/name)
copied(e/'native-film.json',repo/'out/audit/film.json')
for name,scripts in [('film',e/'film/scripts'),('architecture-game',e/'architecture/scripts/sandbox')]:
 dst=sand/name;dst.mkdir(parents=True)
 for tree in ['src','scripts']:shutil.copytree(repo/tree,dst/tree)
 for filename in ['package.json','package-lock.json','tsconfig.json']:shutil.copy2(repo/filename,dst/filename)
 (dst/'node_modules').symlink_to(repo/'node_modules',target_is_directory=True)
 subprocess.run(['patch','--batch','--forward','-p1','-i',str(e/'patches'/f'{name}.patch')],cwd=dst,check=True)
 for src in scripts.glob('*.ts'):copied(src,dst/src.name)
(sand/'restore-receipt.json').write_text(json.dumps({'source':PIN,'repo':str(repo),'audit':str(audit),'sandboxRoot':str(sand),'rewrittenPathScripts':changes,'notes':'Only absolute artifact paths changed in restored script copies. Source changes limited to fresh sandboxes and packaged diffs. No simulation executed.'},indent=2)+'\n')
print(json.dumps({'repo':str(repo),'sandboxes':str(sand),'artifactPathRewrites':len(changes)}))
