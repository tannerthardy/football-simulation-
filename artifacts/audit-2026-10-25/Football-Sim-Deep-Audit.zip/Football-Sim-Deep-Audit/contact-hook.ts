/** Passive exact internal impulse-moment census. No decisions, RNG or new physical calls. */
export function installContactAudit(World:any) {
 const byWorld = new WeakMap<any,any>(), plays:any[]=[];
 const oldPair = World.prototype.pairImpulse, oldStep=World.prototype.step;
 World.prototype.pairImpulse=function(...args:any[]) {
  const [i,j,x,y,actor,kind,, ,aa=0,ab=0]=args;
  const a=this.bodies[i],b=this.bodies[j];
  const requestedMoment=(b.pos.x-a.pos.x)*y-(b.pos.y-a.pos.y)*x+aa+ab;
  const f=oldPair.apply(this,args), p=byWorld.get(this);
  if(p?.tick && (kind==='hands'||kind==='grasps')) {
   const key=`${kind}:${i}:${j}`;const q=p.tick.pairs[key]??={kind,i,j,net:0,absImpulse:0,calls:0};
   q.net+=requestedMoment*f;q.absImpulse+=Math.hypot(x,y)*f;q.calls++;
  }
  return f;
 };
 World.prototype.step=function(intents:any[],dt:number) {
  const p=byWorld.get(this);
  if(!p)return oldStep.call(this,intents,dt);
  p.tick={t:this.time,pairs:{}};p.steps++;
  if(this.joints.some((j:any)=>j.kind==='hands'))p.handSteps++;
  for(const j of this.joints)if(j.kind==='grasp'&&!p.seen.has(j)) {
   p.seen.add(j);const i=this.bodies.indexOf(j.a),k=this.bodies.indexOf(j.b),a=j.a,b=j.b;
   const record={t:this.time,origin:j.origin,i,k,slots:[p.sim.agents[i]?.slot,p.sim.agents[k]?.slot],
    distance:Math.hypot(b.pos.x-a.pos.x,b.pos.y-a.pos.y),reach:j.reach,legs:j.legs,
    heights:[a.profile.heightYd,b.profile.heightYd],radii:[a.profile.radius,b.profile.radius],armReach:a.profile.reach,
    positions:[{...a.pos},{...b.pos}],velocities:[{...a.vel},{...b.vel}],facings:[a.facing,b.facing],
    stateAtAcquire:[a.support?.state,b.support?.state],frames:[]};
   p.grasps.push(record);if(j.origin==='dive')p.follow.push({j,record});
  }
  const out=oldStep.call(this,intents,dt);
  for(const q of Object.values(p.tick.pairs) as any[]) {
   p.net[q.kind]=(p.net[q.kind]??0)+q.net;
   p.absolutePairStep[q.kind]=(p.absolutePairStep[q.kind]??0)+Math.abs(q.net);
   if(Math.abs(q.net)>1e-8)p.defectPairSteps[q.kind]=(p.defectPairSteps[q.kind]??0)+1;
   if(Math.abs(q.net)>p.maxPairStep){p.maxPairStep=Math.abs(q.net);p.worst={...q,t:p.tick.t,slots:[p.sim.agents[q.i]?.slot,p.sim.agents[q.j]?.slot]};}
  }
  for(const f of p.follow)if(this.time-f.record.t<.81)f.record.frames.push({t:this.time,states:[f.j.a.support?.state,f.j.b.support?.state],causes:[f.j.a.support?.cause,f.j.b.support?.cause],distance:Math.hypot(f.j.a.pos.x-f.j.b.pos.x,f.j.a.pos.y-f.j.b.pos.y),force:f.j.force,broken:f.j.broken,carrierVelocity:{...f.j.b.vel}});
  p.tick=null;return out;
 };
 return {
  onSim(sim:any,meta:any={}) {const p={sim,meta,steps:0,handSteps:0,net:{},absolutePairStep:{},defectPairSteps:{},maxPairStep:0,worst:null,grasps:[],follow:[],seen:new WeakSet(),tick:null};plays.push(p);byWorld.set(sim.world,p);},
  finish(){return {definition:'Exact angular momentum added by each delivered internal pair impulse: (positionB-positionA) cross impulseOnB + angularA + angularB, after work limiter. Summed net within each pair/physics tick before taking absolute values; not a whole-world conservation residual, not a calibrated football-effect measure.',plays:plays.map(({sim,seen,follow,tick,...p})=>({...p,outcome:sim.outcome,endTime:sim.t}))};},
  restore(){World.prototype.pairImpulse=oldPair;World.prototype.step=oldStep;}
 };
}
