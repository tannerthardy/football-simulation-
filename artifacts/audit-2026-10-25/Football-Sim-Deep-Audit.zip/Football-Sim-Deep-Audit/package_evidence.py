"""Snapshot audit scripts/results and sandbox diffs; never edit production source."""
from pathlib import Path
import difflib,gzip,hashlib,json,shutil,subprocess
ROOT=Path('/workspace/football-audit');AUDIT=Path('/workspace/audit-deep');E=AUDIT/'evidence';PIN='c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0'
assert subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()==PIN
receipts=[]
def copy(src,dst,large=True):
 src=Path(src);dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True);raw=src.read_bytes();compressed=large and len(raw)>10_000_000
 if compressed:dst=dst.with_name(dst.name+'.gz');dst.write_bytes(gzip.compress(raw,compresslevel=6,mtime=0))
 else:shutil.copy2(src,dst)
 receipts.append({'source':str(src),'packaged':str(dst.relative_to(AUDIT)),'sourceBytes':len(raw),'sourceSha256':hashlib.sha256(raw).hexdigest(),'compressed':compressed,'packagedBytes':dst.stat().st_size})
for lane in ['film','locomotion','contact','decision','root']:
 for p in sorted((ROOT/'out'/f'forensic-{lane}').rglob('*')):
  if p.is_file():copy(p,E/lane/p.relative_to(ROOT/'out'/f'forensic-{lane}'))
for p in sorted((ROOT/'out/forensic-validation').rglob('*')):
 if p.is_file():copy(p,E/'measurement'/p.relative_to(ROOT/'out/forensic-validation'))
for p in sorted((ROOT/'out/forensic-architecture').glob('*.ts')):copy(p,E/'architecture/scripts/repository-out'/p.name)
for name in ['film','architecture-game']:
 sandbox=AUDIT/'sandboxes'/name
 for p in sorted(sandbox.glob('*.ts')):copy(p,E/('film/scripts' if name=='film' else 'architecture/scripts/sandbox')/p.name)
 patch=[];changed=[]
 for tree in ['src','scripts']:
  if not (sandbox/tree).exists():continue
  for p in sorted((sandbox/tree).rglob('*')):
   if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
   rel=p.relative_to(sandbox).as_posix();base=subprocess.run(['git','-C',str(ROOT),'show',f'{PIN}:{rel}'],capture_output=True)
   before=base.stdout.decode() if base.returncode==0 else ''
   try:after=p.read_text()
   except UnicodeDecodeError:raise RuntimeError(f'Unpackaged binary sandbox change: {p}')
   if before!=after:
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile=f'a/{rel}',tofile=f'b/{rel}'));changed.append(rel)
 destination=E/'patches'/f'{name}.patch';destination.parent.mkdir(parents=True,exist_ok=True);destination.write_text(''.join(patch));print(name,'changed',changed)
copy(ROOT/'out/audit/film.json',E/'native-film.json')
copy(ROOT/'out/audit/film-capture.ts',E/'first-audit/film-capture.ts')
for p in sorted((Path('/workspace/audit/evidence')).glob('*')):
 if p.is_file() and p.name not in ['film.json','manifest.json','REPRODUCE.md']:copy(p,E/'first-audit'/p.name)
for name in ['typecheck.log','build.log','core-test-console.log','integration-console.log','data-tests.log','film-capture.log','scorecard-console.log','scorecard-seed8-console.log']:
 copy(Path('/workspace/audit')/name,E/'first-audit'/name)
copy(Path('/workspace/audit/evidence/REPRODUCE.md'),E/'first-audit/REPRODUCE-original.md')
copy(AUDIT/'contact-hook.ts',E/'contact/contact-hook.ts')
(E/'packaging-receipt.json').write_text(json.dumps({'pin':PIN,'notes':'No node_modules, whole source trees, or external NFL data copied. Large additional outputs gzip losslessly; existing native architecture traces retained in place. Summary JSONs may be postprocessed selections; full raw output is authoritative.','files':receipts},indent=2)+'\n')
print('copied',len(receipts),'files',sum(x['packagedBytes'] for x in receipts),'bytes')
