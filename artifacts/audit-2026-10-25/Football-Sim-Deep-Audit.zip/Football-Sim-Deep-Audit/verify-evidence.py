#!/usr/bin/env python3
"""Verify the preserved package evidence, including decompressed large outputs."""
from pathlib import Path
import gzip,hashlib,json,sys
A=Path(__file__).resolve().parent;E=A/'evidence'
def digest(path,compressed=False):
 h=hashlib.sha256();size=0
 with (gzip.open(path,'rb') if compressed else path.open('rb')) as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk);size+=len(chunk)
 return h.hexdigest(),size
manifest=json.loads((E/'evidence-manifest.json').read_text());fail=[]
for rel,row in manifest['files'].items():
 p=A/rel
 if not p.exists():fail.append((rel,'missing'));continue
 sha,size=digest(p)
 if (sha,size)!=(row['sha256'],row['bytes']):fail.append((rel,'hash/size mismatch'))
receipt=json.loads((E/'packaging-receipt.json').read_text())
for row in receipt['files']:
 if row['compressed']:
  sha,size=digest(A/row['packaged'],True)
  if (sha,size)!=(row['sourceSha256'],row['sourceBytes']):fail.append((row['packaged'],'decoded hash/size mismatch'))
print(json.dumps({'filesChecked':len(manifest['files']),'compressedOutputsChecked':sum(r['compressed'] for r in receipt['files']),'failures':fail},indent=2))
sys.exit(bool(fail))
