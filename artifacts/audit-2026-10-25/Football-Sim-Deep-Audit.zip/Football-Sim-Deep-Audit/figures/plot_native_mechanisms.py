#!/usr/bin/env python3
"""Plot recorded counterfactual traces; no simulation or synthetic trajectories.
Run: MPLCONFIGDIR=/tmp/mpl-football-audit python3 /workspace/audit-deep/figures/plot_native_mechanisms.py
Use --refresh-inputs to re-extract the bundled small input from original trace files.
"""
import argparse, hashlib, json, math, os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/mpl-football-audit')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch
HERE=Path(__file__).resolve().parent;ROOT=Path('/workspace/football-audit')
CACHE=HERE/'native-mechanisms-inputs.json'
PINS={
 'motor':'out/forensic-locomotion/native-replay.json',
 'engagement':'out/forensic-contact/blocked-facing.json',
 'aim':'out/forensic-root/aim-native-traces.json',
}
def prepare():
 sources={k:json.loads((ROOT/v).read_text()) for k,v in PINS.items()}
 m=sources['motor'];b=sources['engagement'];a=next(x for x in sources['aim'] if x['id']=='G1-P095')
 assert m['revision']=='c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0'
 assert b['neutral'] and all(p['equal'] for p in b['equalPrefixes'])
 data={'revision':m['revision'],'sourceHashes':{k:{'path':str(ROOT/v),'sha256':hashlib.sha256((ROOT/v).read_bytes()).hexdigest()} for k,v in PINS.items()},
 'motor':{'snapshot':m['snapshot'],'cases':[r for r in m['cases'] if r['variant'] in ['native','yaw2','stop']]},
 'engagement':{'neutral':b['neutral'],'equalPrefixes':b['equalPrefixes'],'note':b['note'],'rows':[r for r in b['rows'] if r['mode'] in ['native','pursuit-facing']]},
 'aim':{'id':a['id'],'summary':a['summary']}}
 for mode in ['base','changed']:
  data['aim'][mode]={'yards':a[mode]['yards'],'duration':a[mode]['duration'],'interventions':a[mode]['interventions'],'rows':[]}
  for t in a[mode]['ticks']:
   if t['t']>=2.95:
    pre=next(x for x in t['before'] if x['slot']=='FS');post=next(x for x in t['after'] if x['slot']=='FS')
    data['aim'][mode]['rows'].append({'t':t['t'],'pre':pre,'post':post})
 CACHE.write_text(json.dumps(data,indent=2)+'\n')
 return data
ap=argparse.ArgumentParser();ap.add_argument('--refresh-inputs',action='store_true');args=ap.parse_args()
d=prepare() if args.refresh_inputs or not CACHE.exists() else json.loads(CACHE.read_text())
NATIVE='#233f62';CHANGE='#c65c27';YAW='#148c88';INK='#16293e';MUTED='#5a6877';RUNNER='#7c838b'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.labelcolor':MUTED,'axes.edgecolor':'#ccd3db','text.color':INK,'xtick.color':MUTED,'ytick.color':MUTED,'axes.titleweight':'bold','svg.fonttype':'none','savefig.facecolor':'#ffffff'})
fig,axs=plt.subplots(1,3,figsize=(16,9.5),gridspec_kw={'width_ratios':[1,1,1]},facecolor='white')
fig.subplots_adjust(left=.055,right=.98,top=.78,bottom=.29,wspace=.29)
fig.text(.055,.972,'Different symptoms, different mechanisms',fontsize=23,weight='bold',va='top')
fig.text(.055,.925,'Recorded native states and controlled interventions • audited source c4a03f6463ea • seed-7 input scenes',fontsize=11.8,color=MUTED)
fig.text(.055,.885,'Paths show movement. Facing arrows show body orientation, not gaze. Command arrows show a request, not achieved motion.',fontsize=11,color=MUTED)

def vec(p):return np.array([p['x'],p['y']],float)
def setup(ax,title,subtitle):
 ax.set_title(title,loc='left',fontsize=14,pad=30)
 ax.text(0,1.025,subtitle,transform=ax.transAxes,fontsize=10.2,color=MUTED,va='bottom')
 ax.grid(True,color='#edf0f3',zorder=0);ax.set_axisbelow(True)
 ax.spines[['top','right']].set_visible(False)
 ax.set_xlabel('Downfield displacement (yd)',labelpad=8)
 ax.set_ylabel('Across-field displacement (yd)',labelpad=8)
 ax.set_aspect('equal',adjustable='box',anchor='N')

def arrow(ax,origin,direction,color,length,style='-|>',lw=2):
 v=np.asarray(direction,float);v=v/np.linalg.norm(v)
 end=origin+v*length
 ax.add_patch(FancyArrowPatch(origin,end,arrowstyle=style,mutation_scale=15,lw=lw,color=color,zorder=6))
 return end

def point(ax,p,color,marker='o',size=27):ax.scatter(*p,color=color,s=size,marker=marker,zorder=8,edgecolors='white',linewidths=.65)

# A: isolated motor replay from the actual SS snapshot, same recorded commands.
ax=axs[0];setup(ax,'A  P002 · safety momentum','SS, 3.80–6.00 s • isolated World replay')
m=d['motor'];origin=vec(m['snapshot']['body']['pos']);curves={}
for name,col,ls,lw,label in [('native',NATIVE,'-',3.7,'Recorded commands'),('yaw2',YAW,(0,(3,2)),2.1,'Same commands, 2× yaw rate'),('stop',CHANGE,'-',2.5,'Zero-velocity request')]:
 c=next(x for x in m['cases'] if x['variant']==name);ps=np.vstack([origin]+[vec(r['pos']) for r in c['trace']])-origin;curves[name]=ps
 ax.plot(ps[:,0],ps[:,1],color=col,ls=ls,lw=lw,label=label,zorder=3)
 point(ax,ps[-1],col,'s',32)
point(ax,np.zeros(2),NATIVE,size=42);ax.annotate('3.80 s',xy=(0,0),xytext=(9,-15),textcoords='offset points',color=NATIVE,fontsize=10)
stop=next(x for x in m['cases'] if x['variant']=='stop');yaw=next(x for x in m['cases'] if x['variant']=='yaw2')
dist=sum(np.linalg.norm(b-a) for a,b in zip(curves['stop'][:-1],curves['stop'][1:]));tstop=stop['stopTime']-m['snapshot']['t']
ax.annotate(f'Stops in {tstop:.2f} s\n{dist:.2f} yd traveled',xy=curves['stop'][-1],xytext=(-90,28),textcoords='offset points',color=CHANGE,fontsize=10,arrowprops={'arrowstyle':'-','color':CHANGE,'lw':1})
ax.annotate('6.00 s',xy=curves['native'][-1],xytext=(-45,-6),textcoords='offset points',color=NATIVE,fontsize=10)
ax.legend(loc='lower right',fontsize=9,frameon=True,facecolor='white',edgecolor='none',borderpad=.7)
ax.margins(x=.33,y=.25)
# Fixed limits give room for annotations and a genuine equal-distance scale.
ax.set_xlim(-5.3,1.8);ax.set_ylim(-5.6,3.0)
ax.text(.02,.98,f'2× yaw: max path gap {yaw["maxPositionError"]:.3f} yd',transform=ax.transAxes,ha='left',va='top',fontsize=10.2,bbox={'facecolor':'white','edgecolor':'none','alpha':.92,'pad':4})

# B: post-step positions and facing use t+0.05, never mix before/after.
ax=axs[1];setup(ax,'B  P019 · blocked linebacker','LB_W, 3.80–4.45 s • facing-only intervention')
rows={r['mode']:r for r in d['engagement']['rows']}
frames={k:[f for f in r['frames'] if f['t']+.05<=4.45+1e-7] for k,r in rows.items()}
origin=vec(frames['native'][0]['post']['pos']);endpoints={}
for mode,col,ls,lw,label in [('native',NATIVE,'-',3.7,'Native LB path'),('pursuit-facing',CHANGE,(0,(3,2)),2.1,'Change final facing only')]:
 ff=frames[mode];xy=np.array([vec(f['post']['pos'])-origin for f in ff]);endpoints[mode]=xy[-1]
 ax.plot(xy[:,0],xy[:,1],color=col,ls=ls,lw=lw,label=label,zorder=3)
 f=ff[-1];point(ax,xy[-1],col,'o',34);theta=f['post']['facing'];arrow(ax,xy[-1],[math.cos(theta),math.sin(theta)],col,.88)
# Actual native carrier trajectory, not a projected target.
rr=np.array([vec(f['runner']['pos'])-origin for f in frames['native']]);ax.plot(rr[:,0],rr[:,1],color=RUNNER,lw=1.9,ls=':',label='Native runner path',zorder=2);point(ax,rr[-1],RUNNER,'D',34)
point(ax,np.zeros(2),NATIVE,size=40);ax.annotate('3.80 s',xy=(0,0),xytext=(-8,-18),textcoords='offset points',fontsize=10,color=NATIVE)
ax.annotate('Runner, 4.45 s',xy=rr[-1],xytext=(-4,12),textcoords='offset points',fontsize=9.5,color=MUTED,ha='right')
f0=frames['native'][-1];f1=frames['pursuit-facing'][-1];gap=np.linalg.norm(endpoints['native']-endpoints['pursuit-facing']);err0=math.degrees(f0['runner']['facingError']);err1=math.degrees(f1['runner']['facingError'])
ax.text(.02,.98,f'4.45 s: path gap {gap:.3f} yd\nBody–runner angle: {err0:.0f}° → {err1:.0f}°',transform=ax.transAxes,ha='left',va='top',fontsize=10.2,bbox={'facecolor':'white','edgecolor':'none','alpha':.92,'pad':4})
ax.annotate('Body facing',xy=endpoints['native']+[-.6,0],xytext=(-64,22),textcoords='offset points',fontsize=9.3,color=NATIVE,arrowprops={'arrowstyle':'-','color':NATIVE,'lw':.8})
ax.annotate('Body facing',xy=endpoints['pursuit-facing']+[.66,.12],xytext=(8,-20),textcoords='offset points',fontsize=9.3,color=CHANGE,arrowprops={'arrowstyle':'-','color':CHANGE,'lw':.8})
ax.legend(loc='upper right',bbox_to_anchor=(1,.90),fontsize=9,frameon=True,facecolor='white',edgecolor='none',borderpad=.7)
ax.set_xlim(-1.1,4.2);ax.set_ylim(-1.4,5.02)

# C: full-game replay pair, final applied commands at the initial split.
ax=axs[2];setup(ax,'C  P095 · stale target point','FS, 3.00–4.85 s • invalidate aim on target change')
a=d['aim'];first={k:next(r for r in a[k]['rows'] if abs(r['t']-3)<1e-7) for k in ['base','changed']};origin=vec(first['base']['pre']['pos']);cpaths={}
for mode,col,ls,lw,label in [('base',NATIVE,'-',2.8,'Native FS path'),('changed',CHANGE,'-',2.4,'Invalidate old-target aim')]:
 rr=[r for r in a[mode]['rows'] if r['t']>=3];xy=np.vstack([origin]+[vec(r['post']['pos']) for r in rr])-origin;cpaths[mode]=xy
 ax.plot(xy[:,0],xy[:,1],color=col,ls=ls,lw=lw,label=label,zorder=3);point(ax,xy[-1],col,'s',32)
 v=vec(first[mode]['pre']['command']['vel']);arrow(ax,np.zeros(2),v,col,1.28,style='->',lw=2)
point(ax,np.zeros(2),NATIVE,size=40)
ax.annotate('3.00 s',xy=(0,0),xytext=(9,-7),textcoords='offset points',fontsize=10,color=NATIVE)
ax.annotate('Native request\n−7.16 yd/s sideways',xy=(.49,-1.10),xytext=(-120,27),textcoords='offset points',fontsize=9.2,color=NATIVE,arrowprops={'arrowstyle':'-','color':NATIVE,'lw':.8})
ax.annotate('Changed request\n+6.40 yd/s sideways',xy=(.76,1.0),xytext=(-155,30),textcoords='offset points',fontsize=9.2,color=CHANGE,arrowprops={'arrowstyle':'-','color':CHANGE,'lw':.8})
endgap=np.linalg.norm(cpaths['base'][-1]-cpaths['changed'][-1]);ax.plot([cpaths['base'][-1,0],cpaths['changed'][-1,0]],[cpaths['base'][-1,1],cpaths['changed'][-1,1]],color=MUTED,lw=1,ls=':')
ax.text(.02,.98,f'4.85 s: position gap {endgap:.2f} yd',transform=ax.transAxes,ha='left',va='top',fontsize=10.2,bbox={'facecolor':'white','edgecolor':'none','alpha':.92,'pad':4})
ax.annotate('4.85 s',xy=cpaths['changed'][-1],xytext=(-10,14),textcoords='offset points',fontsize=10,color=CHANGE)
ax.legend(loc='lower left',fontsize=9,frameon=True,facecolor='white',edgecolor='none',borderpad=.7)
ax.set_xlim(-4.8,2.4);ax.set_ylim(-2.4,6.3)
# Per-panel interpretation, outside data; each qualified to its intervention.
texts=[
 'Faster body rotation barely changes this path.\nA stop request arrests the same initial momentum.\nRecorded-command replay; no claim of a better tackle.',
 'Changing facing turns the body toward the runner\nwhile the blocked player follows almost the same path.\nArrow directions are body facing, not vision.',
 'The target changes X → Z, but a cached point survives.\nClearing that point reverses the first lateral request.\nArrows: request direction; recorded yardage unchanged.',
]
for ax,txt in zip(axs,texts):
 pos=ax.get_position();fig.text(pos.x0,.20,txt,fontsize=10.3,color=INK,va='top',linespacing=1.55)
fig.text(.055,.065,'All coordinates are translations of recorded field positions (equal yard scales within each panel). Panel B labels post-step time; dt = 0.05 s.',fontsize=9.2,color=MUTED)
fig.text(.055,.035,'Inputs + SHA-256 pins: native-mechanisms-inputs.json  •  Reproduce: plot_native_mechanisms.py  •  No simulated trajectories are drawn by this plotting script.',fontsize=9.2,color=MUTED)
for ext in ['png','svg']:
 fig.savefig(HERE/f'native-mechanisms.{ext}',dpi=190)
metrics={'revision':d['revision'],'A':{'yaw2MaxPositionGapYd':yaw['maxPositionError'],'stopTimeSeconds':tstop,'stopTravelYd':dist},'B':{'postStepTime':4.45,'pathGapYd':gap,'nativeFacingRunnerDegrees':err0,'changedFacingRunnerDegrees':err1},'C':{'lastPostStepTime':a['base']['rows'][-1]['t']+.05,'positionGapYd':endgap,'nativeRequestedVy':first['base']['pre']['command']['vel']['y'],'changedRequestedVy':first['changed']['pre']['command']['vel']['y']},'inputSha256':hashlib.sha256(CACHE.read_bytes()).hexdigest(),'plotScriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(HERE/'native-mechanisms-metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
print(json.dumps(metrics,indent=2))
