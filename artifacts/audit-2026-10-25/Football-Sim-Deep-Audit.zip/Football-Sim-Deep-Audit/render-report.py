from pathlib import Path
import sys, re, base64, html, hashlib, json
sys.path.insert(0, '/tmp/football-audit-render')
import markdown
from html.parser import HTMLParser

ROOT=Path(__file__).resolve().parent
docs=[('review','REVIEW.md','Revised architectural review'),('roadmap','ROADMAP.md','Revised A01–A21 roadmap'),
 ('architecture','architecture.md','Architecture and native tracing'),('locomotion','locomotion.md','Locomotion and reach'),
 ('film','film-cases.md','Native football cases'),('contact','contact.md','Contact forensics'),
 ('measurements','measurements.md','Measurement audit'),('alternatives','alternatives.md','Architectural alternatives'),
 ('integrity','experiment-integrity.md','Experiment identity and cost'),('reproduce','REPRODUCE.md','Reproduction guide')]
rendered=[];nav=[]
mapping={name:'#'+key for key,name,title in docs}
for key,name,title in docs:
 md=markdown.Markdown(extensions=['tables','fenced_code','toc'],extension_configs={'toc':{'slugify':lambda v,s,k=key:k+'-'+re.sub(r'[^a-z0-9]+','-',v.lower()).strip('-')}})
 body=md.convert((ROOT/name).read_text())
 for old,new in mapping.items():body=body.replace('href="'+old+'"','href="'+new+'"')
 if key=='review':
  image=base64.b64encode((ROOT/'figures/native-mechanisms.png').read_bytes()).decode()
  body=body.replace('src="figures/native-mechanisms.png"','src="data:image/png;base64,'+image+'"')
 nav.append('<a class="major" href="#'+key+'">'+title+'</a>')
 if key in ['review','roadmap']:
  for root in md.toc_tokens:
   for item in root.get('children',[]):nav.append('<a href="#'+item['id']+'">'+html.escape(item['name'])+'</a>')
  rendered.append('<section id="'+key+'">'+body+'</section>')
 else:rendered.append('<details open id="'+key+'"><summary>'+title+'</summary><section>'+body+'</section></details>')
css='''
:root{--ink:#192d3b;--muted:#546777;--accent:#146e72;--paper:#fff;--line:#dce5e9}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#f0f4f5;color:var(--ink);font:16px/1.7 system-ui,-apple-system,Segoe UI,sans-serif}
aside{position:fixed;top:0;bottom:0;left:0;width:265px;overflow:auto;background:#142d3b;padding:28px 22px;color:white;font-size:12px;line-height:1.4}
aside b{font-size:17px;display:block;margin-bottom:7px}aside p{color:#bcd1d7}aside a{display:block;color:#c6dde3;text-decoration:none;padding:5px 0}aside a.major{color:white;font-weight:700;margin-top:16px;font-size:14px}
main{margin:0 0 0 265px;max-width:1180px;background:white;padding:55px 58px 70px}header{border-bottom:3px solid var(--accent);padding-bottom:24px;margin-bottom:36px}.eyebrow{font-size:13px;letter-spacing:.09em;text-transform:uppercase;color:var(--accent);font-weight:700}header h1{font-size:39px;line-height:1.12;margin:14px 0}header p{color:var(--muted);max-width:750px}.actions a{display:inline-block;margin:5px 14px 0 0;font-size:14px}
h1,h2,h3{line-height:1.27;color:#153847}section>h1{font-size:30px;margin-top:42px}h2{font-size:24px;border-top:1px solid var(--line);padding-top:25px;margin-top:39px}h3{font-size:19px;margin-top:30px}p{margin:13px 0}a{color:#086d83;text-underline-offset:3px}table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.5;margin:24px 0}th,td{border:1px solid var(--line);padding:10px;vertical-align:top}th{text-align:left;background:#eaf3f4;color:#204650}tr:nth-child(even) td{background:#f9fbfc}code{font:12px/1.5 ui-monospace,Consolas,monospace;background:#eef3f5;padding:2px 4px;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f6f7;border-left:3px solid #84adb6;padding:16px;font-size:12px}pre code{padding:0}img{max-width:100%;height:auto}blockquote{border-left:3px solid #82b8bd;margin-left:0;padding-left:20px;color:var(--muted)}li{margin:6px 0}details{border:1px solid var(--line);margin:22px 0;padding:16px}summary{cursor:pointer;font-weight:700;color:var(--accent)}details section{padding:5px 10px}section,details,h2,h3{scroll-margin-top:20px}.note{background:#f0f7f7;padding:16px 20px;border-left:4px solid var(--accent);font-size:14px}.footer{border-top:1px solid var(--line);margin-top:45px;padding-top:20px;color:var(--muted);font-size:12px}
@media(max-width:950px){aside{position:static;width:auto;max-height:250px}main{margin:0;padding:30px 22px}table{font-size:12px}th,td{padding:7px}header h1{font-size:30px}}
@media print{aside,.actions,details{display:none}body{background:white;font-size:10pt}main{margin:0;padding:0;max-width:none}header h1{font-size:25pt}h1{font-size:21pt}h2{font-size:16pt;break-after:avoid}h3{font-size:12pt;break-after:avoid}table{font-size:8pt}tr{break-inside:avoid}a{color:inherit;text-decoration:none}#roadmap{break-before:page}.footer{font-size:8pt}}
'''
page='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Gridiron Engine — Deep Forensic Review</title><style>'+css+'</style></head><body><aside><b>GRIDIRON ENGINE</b><p>Independent review<br>October 23, 2026<br>Experiments · c4a03f6<br>Freshness · ccdb69cb (docs only)</p>'+''.join(nav)+'</aside><main><header><div class="eyebrow">Forensic investigation · revised conclusions</div><h1>Trace the cause.<br>Then choose the architecture.</h1><p>A deeper investigation of player decisions, pursuit, physical execution and experimental validity. Controlled native interventions, failed hypotheses, and a revised A01–A21 plan.</p><div class="actions"><a href="Football-Sim-Deep-Audit-Complete.pdf">Complete PDF + appendices</a><a href="Football-Sim-Deep-Audit.pdf">Shorter review + plan</a><a href="REVIEW.md">Review source</a><a href="ROADMAP.md">Plan source</a><a href="current-film.html">Current replay</a><a href="#reproduce">Reproduction guide</a></div></header><div class="note"><b>Central recommendation:</b> Preserve role-specific cognition. Repair demonstrated information, action-lifetime and geometry contracts; then retest adaptation on independent cases. A universal chooser has not yet earned its cost.</div>'+''.join(rendered)+'<div class="footer">Experiments pinned to c4a03f6463eacb23ce63d01bd32b4f8b547b9bc0. Latest fetched develop ccdb69cb adds VIEW-1 documentation only; engine code is identical. Selected cases are not population validation. Production source and approved plans unchanged.</div></main></body></html>'
(ROOT/'Football-Sim-Deep-Audit.html').write_text(page)

# The PDF contains the consolidated review and implementation plan; appendices
# remain in the searchable HTML and accompanying Markdown package.
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
fonts=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('Deja','DejaVuSans.ttf'),('DejaBold','DejaVuSans-Bold.ttf'),('DejaItalic','DejaVuSans-Oblique.ttf'),('DejaMono','DejaVuSansMono.ttf')]:pdfmetrics.registerFont(TTFont(name,str(fonts/file)))
pdfmetrics.registerFontFamily('Deja',normal='Deja',bold='DejaBold',italic='DejaItalic',boldItalic='DejaBold')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyAudit',fontName='Deja',fontSize=9.1,leading=13.5,spaceAfter=8,textColor=colors.HexColor('#192d3b')))
styles.add(ParagraphStyle(name='H1Audit',parent=styles['BodyAudit'],fontName='DejaBold',fontSize=21,leading=26,spaceBefore=8,spaceAfter=18,keepWithNext=True))
styles.add(ParagraphStyle(name='H2Audit',parent=styles['BodyAudit'],fontName='DejaBold',fontSize=14,leading=18,spaceBefore=18,spaceAfter=10,keepWithNext=True,textColor=colors.HexColor('#146e72')))
styles.add(ParagraphStyle(name='H3Audit',parent=styles['BodyAudit'],fontName='DejaBold',fontSize=11,leading=15,spaceBefore=12,spaceAfter=7,keepWithNext=True))
styles.add(ParagraphStyle(name='CellAudit',parent=styles['BodyAudit'],fontSize=7.1,leading=10,spaceAfter=0))
styles.add(ParagraphStyle(name='CodeAudit',parent=styles['BodyAudit'],fontName='DejaMono',fontSize=7,leading=10,leftIndent=9,backColor=colors.HexColor('#f0f4f6'),spaceBefore=6,spaceAfter=10))
class Node:
 def __init__(self,tag='',attrs=None):self.tag=tag;self.attrs=dict(attrs or []);self.children=[]
class Tree(HTMLParser):
 def __init__(self):super().__init__();self.root=Node('root');self.stack=[self.root]
 def handle_starttag(self,tag,attrs):
  n=Node(tag,attrs);self.stack[-1].children.append(n)
  if tag not in ['br','img','hr']:self.stack.append(n)
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i].tag==tag:self.stack=self.stack[:i];break
 def handle_data(self,s):self.stack[-1].children.append(s)
def plain(n):return n if isinstance(n,str) else ''.join(plain(x) for x in n.children)
def inline(n):
 if isinstance(n,str):return html.escape(n)
 s=''.join(inline(x)for x in n.children)
 if n.tag in ['strong','b']:return '<b>'+s+'</b>'
 if n.tag in ['em','i']:return '<i>'+s+'</i>'
 if n.tag=='code':return '<font name="DejaMono" size="7.5">'+s+'</font>'
 if n.tag=='br':return '<br/>'
 if n.tag=='a' and n.attrs.get('href','').startswith('http'):return '<link href="'+html.escape(n.attrs['href'],quote=True)+'" color="#086d83">'+s+'</link>'
 return s
W,H=A4;avail=W-88
story=[]
def emit(n):
 if isinstance(n,str):return
 tag=n.tag
 if tag in ['h1','h2','h3','h4']:
  story.append(Paragraph(inline(n),styles['H1Audit' if tag=='h1' else 'H2Audit' if tag=='h2' else 'H3Audit']))
 elif tag=='p':
  imgs=[x for x in n.children if isinstance(x,Node) and x.tag=='img']
  if imgs:
   for im in imgs:
    path=ROOT/im.attrs['src']
    from PIL import Image as PILImage
    with PILImage.open(path)as pic:iw,ih=pic.size
    story.append(Image(str(path),width=avail,height=avail*ih/iw));story.append(Spacer(1,8))
  elif plain(n).strip():story.append(Paragraph(inline(n),styles['BodyAudit']))
 elif tag in ['ul','ol']:
  for i,c in enumerate([c for c in n.children if isinstance(c,Node) and c.tag=='li'],1):
   prefix=str(i)+'. ' if tag=='ol' else '• '
   story.append(Paragraph(prefix+inline(c),styles['BodyAudit']))
 elif tag=='table':
  rows=[]
  def walk(x):
   if isinstance(x,str):return
   if x.tag=='tr':rows.append([c for c in x.children if isinstance(c,Node) and c.tag in ['td','th']])
   else:
    for c in x.children:walk(c)
  walk(n);nc=max(map(len,rows));weights=[]
  for i in range(nc):
   avg=sum(len(plain(r[i]))if i<len(r)else 0 for r in rows)/len(rows);weights.append(max(3,min(12,avg**.5)))
  widths=[avail*x/sum(weights)for x in weights]
  content=[[Paragraph(('<b>'+inline(c)+'</b>')if j==0 else inline(c),styles['CellAudit'])for c in row]for j,row in enumerate(rows)]
  table=Table(content,colWidths=widths,repeatRows=1,hAlign='LEFT')
  table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7f1f2')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f8fafb')]),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#d5e0e5')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
  story.extend([Spacer(1,5),table,Spacer(1,10)])
 elif tag=='pre':story.append(Paragraph(html.escape(plain(n)).replace('\n','<br/>'),styles['CodeAudit']))
 else:
  for c in n.children:emit(c)
full_pdf='--full' in sys.argv
for idx,name in enumerate([name for _,name,_ in docs] if full_pdf else ['REVIEW.md','ROADMAP.md']):
 if idx:story.append(PageBreak())
 tree=Tree();tree.feed(markdown.markdown((ROOT/name).read_text(),extensions=['tables','fenced_code']));emit(tree.root)
def footer(c,doc):
 c.saveState();c.setFont('Deja',7);c.setFillColor(colors.HexColor('#647583'));c.drawString(44,25,'GRIDIRON ENGINE · October 23, 2026 · experiment c4a03f6');c.drawRightString(W-44,25,str(doc.page));c.restoreState()
class AuditDoc(SimpleDocTemplate):
 def afterFlowable(self,flowable):
  if isinstance(flowable,Paragraph) and flowable.style.name in ['H1Audit','H2Audit']:
   title=flowable.getPlainText(); key='outline-'+str(getattr(self,'outline_counter',0)); self.outline_counter=getattr(self,'outline_counter',0)+1
   self.canv.bookmarkPage(key); self.canv.addOutlineEntry(title,key,level=0 if flowable.style.name=='H1Audit' else 1,closed=False)
pdfname='Football-Sim-Deep-Audit-Complete.pdf' if full_pdf else 'Football-Sim-Deep-Audit.pdf'
pdf=AuditDoc(str(ROOT/pdfname),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=42,bottomMargin=43,title='Gridiron Engine: Deep Forensic Review and Revised Roadmap',author='Consulting audit for Tanner')
pdf.build(story,onFirstPage=footer,onLaterPages=footer)
print(json.dumps({'htmlBytes':(ROOT/'Football-Sim-Deep-Audit.html').stat().st_size,'pdf':pdfname,'pdfBytes':(ROOT/pdfname).stat().st_size}))
