import pathlib,gzip,json,math
p=pathlib.Path(__file__).resolve().parent;base=[];cand=[]
for path in list(p.glob('current-[01]/trace.json.gz'))+list(p.glob('current-fresh/trace.json.gz')):base+=json.loads(gzip.decompress(path.read_bytes()))['rows']
for path in [p/'path-continuity-probe/trace.json.gz',p/'path-continuity-fresh/trace.json.gz']:cand+=json.loads(gzip.decompress(path.read_bytes()))['rows']
for id,slot,target in [('Z13','Y','DE_W'),('Z16','RT','DT_S'),('R01','H','DE_W'),('C01','LT','DE_W')]:
 print('\n',id,slot,target)
 for lab,rs in [('base',base),('path',cand)]:
  r=next(r for r in rs if r['id']==id);i=next(a['idx']for a in r['initial']if a['slot']==slot);j=next(a['idx']for a in r['initial']if a['slot']==target)
  first=r['firstContact']['t'] if r['firstContact'] else 5;tot=good=0
  for f in r['frames']:
   if f['t']>=first:continue
   bo=f['before'][i]['pos'];de=f['before'][j]['pos'];rb=f['before'][6]['pos'];dx=rb['x']-de['x'];dy=rb['y']-de['y'];ll=math.hypot(dx,dy);projection=((bo['x']-de['x'])*dx+(bo['y']-de['y'])*dy)/max(1e-9,ll)
   e=next((e for e in f['afterReps']if e['b']==i and e['d']==j),None)
   if e and e['hands']and math.hypot(e['hands']['normal'],e['hands']['tangent'])>1:tot+=.05;good+=.05*(projection>0)
  print(lab,'all/goodload beforeRB',round(tot,2),round(good,2),'contactevents',[(e['t'],e['type'])for e in r['events']if e['type']=='block_contact'and e.get('a')==i and e.get('b')==j])
  for t in [1.7,2,2.2,2.5,2.7,3]:
   f=min(r['frames'],key=lambda f:abs(f['t']-t));bo=f['before'][i]['pos'];de=f['before'][j]['pos'];rb=f['before'][6]['pos'];dx=rb['x']-de['x'];dy=rb['y']-de['y'];proj=((bo['x']-de['x'])*dx+(bo['y']-de['y'])*dy)/math.hypot(dx,dy);e=next((e for e in f['afterReps']if e['b']==i and e['d']==j),None)
   print(lab,round(f['t'],2),'ballside',round(proj,2),'b',tuple(round(x,2)for x in bo.values()),'d',tuple(round(x,2)for x in de.values()),'load',round(math.hypot(e['hands']['normal'],e['hands']['tangent']),1)if e and e['hands']else None)
