import type {Vec2} from '../core/vec.js';
import type {Perceived} from './perception.js';

export interface ClimbMotionSample { at:number; velocity:Vec2 }

/** An observer's short trend estimate, not another sighting. Perception has
 * already projected position at constant velocity. Add only the bounded
 * acceleration correction from two actually acquired velocity samples.
 * The correction cannot exceed one observed increment or one normal read.
 * Unknown/duplicate/reversed observation time contributes no trend. */
export function estimateClimbMotion(observed:Perceived, now:number,
 previous:ClimbMotionSample|null, decisionInterval:number):Perceived {
 const age=observed.age;
 if(!previous||!Number.isFinite(age)||age!<0||!Number.isFinite(decisionInterval)||decisionInterval<=0
  ||![previous.at,previous.velocity.x,previous.velocity.y,observed.vel.x,observed.vel.y].every(Number.isFinite))return observed;
 const elapsed=now-age!-previous.at;
 if(elapsed<=0)return observed;
 const ahead=Math.min(age!,decisionInterval,elapsed),fraction=ahead/elapsed;
 const delta={x:(observed.vel.x-previous.velocity.x)*fraction,y:(observed.vel.y-previous.velocity.y)*fraction};
 return {...observed,pos:{x:observed.pos.x+.5*delta.x*ahead,y:observed.pos.y+.5*delta.y*ahead},
  vel:{x:observed.vel.x+delta.x,y:observed.vel.y+delta.y}};
}
