/** Three explicitly selected frozen snaps. Passive wrappers forward every
 * caller argument; no extra sensing, draws, controller updates or World steps. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {reconstruct} from '../catch-opportunity-physics/reconstruct.js';
import {closestCatchOpportunity} from './geometry/catch-opportunity.js';
import {stepFlight} from '../../src/physics/ball.js';
import {sourceVersion} from '../../scripts/source-version.js';
const [mode='plan',out='out/catch-opportunity-caller/plan']=process.argv.slice(2);
const ids=['G1-P020','G2-P107','G2-P143'];
if(mode==='plan'){console.log(JSON.stringify({ids,simulatedSnaps:0,question:'Does the live caller reject mixed-time opportunities while preserving valid catch/tip execution?'}));process.exit(0);}
assert.equal(mode,'run');mkdirSync(out,{recursive:true});const start=performance.now(),rows:any[]=[];
const hash=(x:any)=>createHash('sha256').update(typeof x==='string'?x:JSON.stringify(x)).digest('hex');
for(const id of ids){
 assert(performance.now()-start<30000,'Batch wall budget');const r:any=reconstruct(id);assert.equal(r.status,'constructor-match');
 const {sim,native}=r,w=sim.world,step=w.step.bind(w),update=(sim as any).updateBall.bind(sim);
 const body=()=>sim.agents.map((a:any)=>structuredClone(a.body));let starts:any[]=[],current:any=null;const ticks:any[]=[],opportunities:any[]=[];
 w.step=(intents:any,dt:number)=>{
  starts=sim.agents.map((a:any)=>({...a.pos}));current={t:sim.t,before:body(),requests:structuredClone((sim as any).cmds),intents:structuredClone(intents),rngBefore:JSON.stringify(sim.rng)};
  const report=step(intents,dt);Object.assign(current,{after:body(),contacts:report.contacts,rngAfterWorld:JSON.stringify(sim.rng)});ticks.push(current);return report;
 };
 (sim as any).updateBall=(...args:any[])=>{
  const ball=sim.ball;if(ball.kind!=='air'||sim.t-ball.releaseT<.1)return update(...args);
  const prev=structuredClone(ball.flight.pos),flight=structuredClone(ball.flight);stepFlight(flight,sim.dt,sim.wind);const cur=flight.pos;
  const row:any={t:sim.t,bodyStartsSupplied:!!args[0],ball0:prev,ball1:structuredClone(cur),velocity:structuredClone(flight.vel),target:ball.target?.idx??null,deflected:ball.deflected,actors:[],draws:[],chances:[],rngBefore:JSON.stringify(sim.rng)};
  if(args[0])assert.deepEqual(args[0],starts,'Live caller and World must share body-start interval');
  for(const a of sim.agents){
   const tAir=sim.t-ball.releaseT,bat=a.team==='D'&&tAir<.4&&!!a.engagement;
   const eligible=a!==ball.thrower&&!a.isDown(sim.t)&&sim.t>=a.noCatchUntil&&!(a.team==='O'&&['LT','LG','C','RG','RT'].includes(a.slot))&&(!a.engagement||bat)
    &&!(a.team==='O'&&!a.tags.has('onBall')&&!sim.incidentalCatchReadiness.query(a,sim.t));
   if(!eligible)continue;
   const tracking=a===ball.target||a.tags.has('onBall'),p=a.profile,reach=p.reach+(tracking?.3:0);
   const top=a.team==='O'&&tracking?p.maxCatchHeight:tracking?p.reactReach+.5*(p.maxCatchHeight-p.reactReach):bat?p.reactReach*.95:p.reactReach;
   const dx=cur.x-prev.x,dy=cur.y-prev.y,d2=dx*dx+dy*dy,s=Math.max(0,Math.min(1,d2>1e-9?((a.pos.x-prev.x)*dx+(a.pos.y-prev.y)*dy)/d2:0));
   const dh=Math.hypot(a.pos.x-prev.x-dx*s,a.pos.y-prev.y-dy*s),z=prev.z+(cur.z-prev.z)*s;
   const old=dh<=reach&&z>=.1&&z<=top?{s,dh,z}:null,corrected=closestCatchOpportunity(starts[a.idx],a.pos,prev,cur,{reach,low:.1,top});
   if(old||corrected)row.actors.push({i:a.idx,playerId:a.player.id,slot:a.slot,body0:starts[a.idx],body1:{...a.pos},reach,top,tracking,retry:a.noCatchUntil,old,corrected});
  }
  const next=sim.rng.next,chance=sim.rng.chance;sim.rng.next=function(){const draw=next.call(this);row.draws.push(draw);return draw;};
  sim.rng.chance=function(p:number){row.chances.push(p);return chance.call(this,p);};const n=sim.events.length;
  try{return update(...args);}finally{sim.rng.next=next;sim.rng.chance=chance;row.events=structuredClone(sim.events.slice(n));row.rngAfter=JSON.stringify(sim.rng);if(row.actors.length||row.events.length)opportunities.push(row);}
 };
 const begun=performance.now();sim.event('snap',sim.slot('C')??sim.qb);
 while(sim.phase==='live'&&sim.t<25){assert(performance.now()-begun<5000,'Case wall budget');sim.tick();}
 const result=sim.buildResult();const summary={id,source:sourceVersion(),elapsedSeconds:(performance.now()-begun)/1000,phase:sim.phase,endTime:sim.t,censored:sim.phase==='live',outcome:sim.phase==='live'?null:result.outcome,gain:sim.phase==='live'?null:result.offenseYards,stats:result.stats,events:result.events,opportunityTicks:opportunities.length,
  original70b4:{framesMatch:JSON.stringify(result.frames)===JSON.stringify(native.replay.frames),eventsMatch:JSON.stringify(result.events)===JSON.stringify(native.replay.events),telemetryMatch:JSON.stringify(result.telemetry)===JSON.stringify(native.replay.telemetry),statsMatch:JSON.stringify(result.stats)===JSON.stringify(native.stats)}};
 const full={...summary,initialPlayers:sim.agents.map((a:any)=>({i:a.idx,slot:a.slot,playerId:a.player.id})),constructorRng:r.actualRng,inputHashes:{observation:hash(r.ob),calls:hash([r.setup.offCall,r.setup.defCall]),scout:hash(structuredClone(r.setup.scouting)),coverageScout:hash(structuredClone(r.setup.coverageScouting))},opportunities,ticks,result};
 writeFileSync(out+'/'+id+'.json.gz',gzipSync(JSON.stringify(full)));rows.push(summary);console.log(JSON.stringify(summary));
}
const profile=JSON.parse(readFileSync('config/baseline.json','utf8'));
writeFileSync(out+'/receipt.json',JSON.stringify({source:sourceVersion(),cases:rows,node:process.version,platform:process.platform,arch:process.arch,flags:Object.fromEntries(Object.keys(profile.flags).map(k=>[k,process.env[k]??null])),worldDefaults:profile.worldDefaults,collectorSha256:hash(readFileSync(import.meta.filename,'utf8')),elapsedSeconds:(performance.now()-start)/1000,qualification:'Frozen original inputs/constructor matches; current accepted source differences must not be relabeled historical. Real tick/body/ball endpoints and forwarded live updateBall args. Analyst-only extra geometry calls and readiness queries are pure; no extra sightings, draws or steps. FullGames:0; censored prefixes have null terminal outcome/gain.'},null,2)+'\n');
