"""Package existing evidence only; never starts a simulator."""
import difflib
import gzip
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile

p = pathlib.Path(__file__).resolve().parent
root = p.parents[1]
publication = root / 'data/reviews/current/stalk-moving-surface'
bundle = p / 'publication'
common = bundle / 'common'
common.mkdir(parents=True, exist_ok=True)
publication.mkdir(parents=True, exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
arms = ['baseline', 'picture', 'moving', 'surface', 'perimeter', 'continuity', 'composed']
relative = 'src/sim/behaviors/blocking.ts'
base = p / 'baseline-host'
base_files = {str(f.relative_to(base)): f.read_bytes()
              for f in sorted((base / 'src').rglob('*'), key=str) if f.is_file()}

def digest(files):
    h = hashlib.sha256()
    for name in sorted(files):
        h.update(name.encode() + b'\0' + files[name] + b'\0')
    return h.hexdigest()

sources = {}
for arm in arms:
    host = p / (arm + '-host')
    files = {str(f.relative_to(host)): f.read_bytes()
             for f in sorted((host / 'src').rglob('*'), key=str) if f.is_file()}
    assert set(files) == set(base_files)
    changes = [name for name in files if files[name] != base_files[name]]
    assert changes == ([] if arm == 'baseline' else [relative]), (arm, changes)
    sources[arm] = {'sourceSha256': digest(files), 'blockingSha256': sha(files[relative])}
    patch = ''.join(difflib.unified_diff(base_files[relative].decode().splitlines(True),
        files[relative].decode().splitlines(True), fromfile='a/' + relative, tofile='b/' + relative))
    (common / (arm + '-from-accepted.patch')).write_text(patch)
    (common / (arm + '-collector.mjs')).write_bytes((host / 'scripts/diag/zone-approach.mjs').read_bytes())

assert sources['baseline']['sourceSha256'] == '5b710a1b8b2bdf9bb874aa9c788424cd3c71185df9993f9f6db7eb80cf6b4482'
assert sources['perimeter']['sourceSha256'] == 'd50530adb83384baa0cfc4b82caa08f0c269a20eb813048d2a33fde54a7ec3ac'
for f in sorted(p.glob('*/trace.json.gz')):
    tape = json.loads(gzip.decompress(f.read_bytes()))
    assert tape['receipt']['source'] in [s['sourceSha256'] for s in sources.values()]
    assert tape['receipt']['diagnosticRoute'] == 'native'

before = (p / 'picture-host' / relative).read_text()
after = (p / 'perimeter-host' / relative).read_text()
(common / 'perimeter-after-picture.patch').write_text(''.join(difflib.unified_diff(
    before.splitlines(True), after.splitlines(True), fromfile='a/' + relative, tofile='b/' + relative)))
(common / 'candidate-code-tests.patch').write_bytes(subprocess.check_output([
    'git', 'diff', '--binary', '914f4d56a3b7ef2845ff0208f55d626c0ff5f880',
    '265c40e8434d3c243fb0e0a78dec2bc429eebb73', '--', 'src', 'test',
    'config/stalk-visual-request-witness.json'], cwd=root))
(common / 'sources.json').write_text(json.dumps(sources, indent=2) + '\n')
for f in sorted(p.iterdir()):
    if f.is_file() and f.suffix in ('.py', '.mjs', '.log', '.gz', '.md'):
        shutil.copyfile(f, common / f.name)
    elif f.is_file() and f.suffix == '.json' and f.name not in ('report.json', 'screen.json'):
        shutil.copyfile(f, common / f.name)
for name in ['report', 'screen']:
    (common / (name + '.json.gz')).write_bytes(gzip.compress((p / (name + '.json')).read_bytes(), mtime=0))
shutil.copytree(p / 'film', common / 'film', dirs_exist_ok=True)
shutil.copyfile(root / 'config/baseline.json', common / 'baseline-profile.json')
shutil.copyfile(root / 'scripts/baseline.mjs', common / 'baseline-launcher.mjs')

groups = {
    'discovery-a': ['baseline-0', 'baseline-1', 'baseline-2'],
    'discovery-b': ['baseline-3', 'baseline-4'],
    'picture': ['picture-0', 'picture-1', 'transfer-picture'],
    'rejected-approaches': ['moving-0', 'moving-1', 'surface-0', 'surface-1', 'transfer-surface'],
    'candidate': ['perimeter-selected-0', 'perimeter-selected-1', 'perimeter-transfer'],
    'continuity-probes': ['continuity-controls', 'continuity-fresh', 'composed-controls', 'composed-fresh'],
}
paths = {}
for name, folders in groups.items():
    members = [f for folder in folders for f in sorted((p / folder).iterdir()) if f.is_file()]
    assert members and all(not f.is_symlink() for f in members)
    paths[name] = [(f, str(f.relative_to(p))) for f in members]
paths['common'] = [(f, str(f.relative_to(common))) for f in sorted(common.rglob('*')) if f.is_file()]

archives = []
for name, members in paths.items():
    manifest = [{'path': dest, 'bytes': src.stat().st_size, 'sha256': sha(src.read_bytes())}
                for src, dest in members]
    destination = bundle / (name + '.tar.gz')
    with tarfile.open(destination, 'w:gz') as archive:
        for src, dest in members:
            assert not src.is_symlink() and not dest.startswith('/') and '..' not in pathlib.PurePosixPath(dest).parts
            archive.add(src, arcname=dest, recursive=False)
    assert destination.stat().st_size < 32 * 1024 * 1024
    with tarfile.open(destination) as archive:
        content = archive.getmembers()
        assert len(content) == len(manifest)
        for member, expected in zip(content, manifest):
            assert member.isfile() and member.name == expected['path']
            assert sha(archive.extractfile(member).read()) == expected['sha256']
    archives.append({'path': destination.name, 'bytes': destination.stat().st_size,
                     'sha256': sha(destination.read_bytes()), 'members': manifest})

manifest = {'schema': 'stalk-moving-surface-artifacts-v1',
            'acceptedDevelop': '914f4d56a3b7ef2845ff0208f55d626c0ff5f880',
            'integrationQueue': 'e8d806b940a84c7cff7e5ee066022079723c78ef',
            'codeCommit': '265c40e8434d3c243fb0e0a78dec2bc429eebb73',
            'sources': sources, 'archives': archives}
(bundle / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'sources': sources, 'archives': [{k: a[k] for k in ['path', 'bytes', 'sha256']} for a in archives]}, indent=2))
