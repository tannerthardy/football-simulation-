"""Package and validate existing artifacts; zero simulator ticks."""
import pathlib,hashlib,json,gzip,difflib,tarfile,shutil,subprocess,os,tempfile
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1];bundle=p/'publication';common=bundle/'common';common.mkdir(parents=True,exist_ok=True)
base=p.parent/'zone-track-recovery/baseline-host';sha=lambda b:hashlib.sha256(b).hexdigest()
def files(host):return {str(f.relative_to(host)):f.read_bytes()for f in(host/'src').rglob('*')if f.is_file()}
def digest(fs):
 h=hashlib.sha256()
 for name in sorted(fs):h.update(name.encode()+b'\0'+fs[name]+b'\0')
 return h.hexdigest()
basefiles=files(base);assert digest(basefiles)=='5b710a1b8b2bdf9bb874aa9c788424cd3c71185df9993f9f6db7eb80cf6b4482'
records={};patches={}
for arm,host in [('accepted',base),*[(x,p/(x+'-host'))for x in['waypoint','trend','coherent','advect','firststep','traffic']],('candidate',root)]:
 fs=files(host);patch=''
 for name in sorted(set(fs)|set(basefiles)):
  if fs.get(name)==basefiles.get(name):continue
  patch+=''.join(difflib.unified_diff(basefiles.get(name,b'').decode().splitlines(True),fs.get(name,b'').decode().splitlines(True),fromfile='a/'+name if name in basefiles else '/dev/null',tofile='b/'+name if name in fs else '/dev/null'))
 patchfile=common/(arm+'-from-accepted.patch');patchfile.write_text(patch);patches[arm]=patchfile
 records[arm]={'sourceSha256':digest(fs),'changedFiles':[f for f in sorted(set(fs)|set(basefiles))if fs.get(f)!=basefiles.get(f)],'patch':patchfile.name,'patchSha256':sha(patch.encode())}
records['intercept']={**records['accepted'],'overrideFlags':{'CLIMB_PLAN':'0'}}
assert records['candidate']['sourceSha256']=='06869378092c467aa529ffbb86abf8d1d2b76128e5f5d20a99c69bbf50347469'
# Restore every nonempty source patch independently and check every source byte.
for arm,patch in patches.items():
 if not patch.stat().st_size:continue
 with tempfile.TemporaryDirectory(prefix='climb-source-restore-',dir='/tmp')as folder:
  dest=pathlib.Path(folder);shutil.copytree(base/'src',dest/'src');env=dict(os.environ);env['GIT_CEILING_DIRECTORIES']='/tmp'
  subprocess.run(['git','apply','--check',str(patch)],cwd=dest,env=env,check=True)
  subprocess.run(['git','apply',str(patch)],cwd=dest,env=env,check=True)
  assert digest(files(dest))==records[arm]['sourceSha256'],arm
for f in p.iterdir():
 if f.is_file()and f.suffix in['.json','.gz','.py','.mjs','.ts','.log','.png']:
  if f.name=='comparison.json':(common/'comparison.json.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0))
  else:shutil.copy2(f,common/f.name)
shutil.copy2(root/'scripts/diag/climb-approach.mjs',common/'candidate-collector.mjs')
(common/'sources.json').write_text(json.dumps(records,indent=2)+'\n')
(common/'candidate-code-tests-tool.patch').write_bytes(subprocess.check_output(['git','diff','--binary','914f4d56a3b7ef2845ff0208f55d626c0ff5f880','403d7a9f114e39fb069aa3d5cb2ede648c33cbe9','--','src','test','scripts/diag/climb-approach.mjs'],cwd=root))
for file in ['config/baseline.json','scripts/baseline.mjs','scripts/source-version.ts','.nvmrc','package-lock.json']:
 shutil.copy2(root/file,common/pathlib.Path(file).name)
for d in ['forecast']:
 if(p/d).exists():shutil.copytree(p/d,common/d,dirs_exist_ok=True)
groups={
 'baseline':['baseline-0','baseline-1','baseline-transfer-0'],
 'rejected-departure':['waypoint-0','waypoint-1'],
 'rejected-prediction':['trend-0','trend-1','coherent-0','coherent-1'],
 'rejected-goals':['advect-0','advect-1','intercept-0','intercept-1','firststep-0','firststep-1'],
 'prototype':['traffic-0','traffic-1','traffic-transfer-0','traffic-transfer-1'],
 'candidate':['candidate-0','candidate-1','candidate-transfer-0','candidate-transfer-1']}
archives=[]
for name,folders in [*groups.items(),('common',None)]:
 members=[(f,str(f.relative_to(p)))for folder in folders for f in sorted((p/folder).iterdir())if f.is_file()]if folders else[(f,str(f.relative_to(common)))for f in sorted(common.rglob('*'))if f.is_file()]
 manifest=[{'path':dest,'bytes':src.stat().st_size,'sha256':sha(src.read_bytes())}for src,dest in members]
 destination=bundle/(name+'.tar.gz')
 with tarfile.open(destination,'w:gz',compresslevel=1)as archive:
  for src,dest in members:
   assert not src.is_symlink()and not dest.startswith('/')and'..'not in pathlib.PurePosixPath(dest).parts
   archive.add(src,arcname=dest,recursive=False)
 assert destination.stat().st_size<32*1024**2
 with tarfile.open(destination)as archive:
  assert len(archive.getmembers())==len(manifest)
  for member,expected in zip(archive.getmembers(),manifest):
   assert member.isfile()and member.name==expected['path'];assert sha(archive.extractfile(member).read())==expected['sha256']
 archives.append({'path':destination.name,'bytes':destination.stat().st_size,'sha256':sha(destination.read_bytes()),'members':manifest})
 print(name,destination.stat().st_size,flush=True)
manifest={'schema':'climb-access-publication-v1','acceptedDevelop':'914f4d56a3b7ef2845ff0208f55d626c0ff5f880','queue':'e8d806b940a84c7cff7e5ee066022079723c78ef','codeCommit':'403d7a9f114e39fb069aa3d5cb2ede648c33cbe9','sources':records,'archives':archives,'reusedBaselines':{'commit':'15f5113709450363f3dbc744753cbc87b422e6f3','branch':'codex/stalk-moving-surface-evidence','archives':['discovery-a.tar.gz','discovery-b.tar.gz'],'cases':['Z16','Z18','Z20','Z27'],'note':'All28 old native inputs are there; only four existing traffic opposing controls reused here. Do not simulate28 again.'},'restorationCheck':'Every source patch independently git-applied outside the checkout; full canonical runtime digests match. All tar members checked against hashes; zero additional simulations.'}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(bundle/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {a['path']}\n"for a in archives))
print('totalBytes',sum(a['bytes']for a in archives),flush=True)
