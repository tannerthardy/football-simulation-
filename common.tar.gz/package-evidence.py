"""Package existing evidence and independently restore source patches. Zero simulator ticks."""
import pathlib,hashlib,json,gzip,difflib,tarfile,shutil,subprocess,os,tempfile
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1];bundle=p/'publication';common=bundle/'common';common.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
code=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();base=p/'current-host'
def files(host):return {str(f.relative_to(host)):f.read_bytes()for f in(host/'src').rglob('*')if f.is_file()}
def digest(fs):
 h=hashlib.sha256()
 for name in sorted(fs):h.update(name.encode()+b'\0'+fs[name]+b'\0')
 return h.hexdigest()
basefiles=files(base);assert digest(basefiles)=='7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197'
records={};patches={}
for arm,host in [('accepted',base),*[(x,p/(x+'-host'))for x in['inline','recovery','contact','contact-tactile','path','path-continuity','free-path','final']]]:
 fs=files(host);patch=''
 for name in sorted(set(fs)|set(basefiles)):
  if fs.get(name)==basefiles.get(name):continue
  patch+=''.join(difflib.unified_diff(basefiles.get(name,b'').decode().splitlines(True),fs.get(name,b'').decode().splitlines(True),fromfile='a/'+name if name in basefiles else '/dev/null',tofile='b/'+name if name in fs else '/dev/null'))
 patchfile=common/(arm+'-from-accepted.patch');patchfile.write_text(patch);patches[arm]=patchfile
 records[arm]={'sourceSha256':digest(fs),'changedFiles':[f for f in sorted(set(fs)|set(basefiles))if fs.get(f)!=basefiles.get(f)],'patch':patchfile.name,'patchSha256':sha(patch.encode())}
assert digest(files(root))==records['final']['sourceSha256']=='1e56ab2a063d0ba2fbb542a7ca7a7227aec821f20a53339a569a6758e9ed87c0'
assert records['final']['changedFiles']==['src/sim/behaviors/blocking.ts']
for arm,patch in patches.items():
 if not patch.stat().st_size:continue
 with tempfile.TemporaryDirectory(prefix='run-recovery-source-restore-',dir='/tmp')as folder:
  dest=pathlib.Path(folder);shutil.copytree(base/'src',dest/'src');env=dict(os.environ);env['GIT_CEILING_DIRECTORIES']='/tmp'
  subprocess.run(['git','apply','--check',str(patch)],cwd=dest,env=env,check=True)
  subprocess.run(['git','apply',str(patch)],cwd=dest,env=env,check=True)
  assert digest(files(dest))==records[arm]['sourceSha256'],arm
for f in p.iterdir():
 if f.is_file()and f.suffix in['.json','.gz','.py','.mjs','.ts','.log','.png'] and f.name not in ['pr116-body.md','pr119-body.md']:
  if f.name=='comparison.json':(common/'comparison.json.gz').write_bytes(gzip.compress(f.read_bytes(),mtime=0))
  else:shutil.copy2(f,common/f.name)
(common/'sources.json').write_text(json.dumps(records,indent=2)+'\n')
(common/'candidate-code-tests.patch').write_bytes(subprocess.check_output(['git','diff','--binary','f4146275ce7539816bf57b4ed55a0d2be10e48c7',code,'--','src','test'],cwd=root))
old=(root/'test/runner-side-recovery.test.ts').read_text().replace('const f=scene();f.pictures.get(f.rb)!.carrying=signal;f.sim.ball=', 'const f=scene(signal);f.sim.ball=')
(common/'runner-side-recovery-before-fixture-fix.test.ts').write_text(old)
for file in ['config/baseline.json','scripts/baseline.mjs','scripts/source-version.ts','.nvmrc','package-lock.json']:
 shutil.copy2(root/file,common/pathlib.Path(file).name)
groups={
 'baseline':['current-0','current-1','current-fresh'],
 'rejected-gates':['inline-probe','recovery-probe','recovery-fresh'],
 'rejected-loaded':['contact-probe','contact-tactile-probe','contact-tactile-fresh'],
 'rejected-path':['path-probe','path-continuity-probe','path-continuity-fresh'],
 'prototype-free':['free-path-probe','free-path-fresh'],
 'candidate':['final-failures','final-controls','final-fresh']}
archives=[];costs=[]
for name,folders in [*groups.items(),('common',None)]:
 members=[(f,str(f.relative_to(p)))for folder in folders for f in sorted((p/folder).iterdir())if f.is_file()]if folders else[(f,str(f.relative_to(common)))for f in sorted(common.rglob('*'))if f.is_file()]
 manifest=[{'path':dest,'bytes':src.stat().st_size,'sha256':sha(src.read_bytes())}for src,dest in members]
 destination=bundle/(name+'.tar.gz')
 with tarfile.open(destination,'w:gz',compresslevel=1)as archive:
  for src,dest in members:
   assert not src.is_symlink()and not dest.startswith('/')and'..'not in pathlib.PurePosixPath(dest).parts
   archive.add(src,arcname=dest,recursive=False)
 assert destination.stat().st_size<32*1024**2
 with tarfile.open(destination)as archive:
  assert len(archive.getmembers())==len(manifest)
  for member,expected in zip(archive.getmembers(),manifest):
   assert member.isfile()and member.name==expected['path'];assert sha(archive.extractfile(member).read())==expected['sha256']
 archives.append({'path':destination.name,'bytes':destination.stat().st_size,'sha256':sha(destination.read_bytes()),'members':manifest})
 if folders:
  receipts=[json.loads((p/f/'receipt.json').read_text())for f in folders]
  costs.append({'group':name,'nativeContinuations':sum(len(r['cases'])for r in receipts),'collectorSeconds':sum(r['elapsedSeconds']for r in receipts)})
 print(name,destination.stat().st_size,flush=True)
manifest={'schema':'run-current-recovery-publication-v1','acceptedDevelop':'f4146275ce7539816bf57b4ed55a0d2be10e48c7','queue':'df4ee4dfe58aed5bd357ce3d2e3b73074eae5356','codeCommit':code,'sources':records,'archives':archives,'costs':costs,'qualification':'55 native all22 diagnostic continuations across accepted, rejected, prototype and final sources; 11 exact frozen inputs. Focused code tests have their own cost receipts. No games or full suite. Only common/collector.mjs versus free-path-collector.mjs passive state-field logging differs for the final pair; see diff, no extra sensing/randomness/World ticks. Archived hosts inherit outer git metadata, so canonical source digests/patches qualify their code.','restorationCheck':'All eight nonempty source patches independently git-applied outside the checkout and matched full canonical runtime digests. Every tar member hash verified. Zero additional simulation ticks.'}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(bundle/'SHA256SUMS').write_text(''.join(f"{a['sha256']}  {a['path']}\n"for a in archives))
print('totalBytes',sum(a['bytes']for a in archives),flush=True)
