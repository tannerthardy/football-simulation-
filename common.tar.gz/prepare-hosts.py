import pathlib,subprocess,tarfile,io,shutil
root=pathlib.Path.cwd();p=root/'out/catch-opportunity-caller'
for name,pin in [('baseline','f4146275ce7539816bf57b4ed55a0d2be10e48c7'),('candidate','HEAD')]:
 host=p/(name+'-host');host.mkdir();raw=subprocess.check_output(['git','archive',pin,'src','config','scripts','package.json','package-lock.json','.nvmrc'])
 with tarfile.open(fileobj=io.BytesIO(raw))as ar:ar.extractall(host,filter='data')
 if name=='candidate':
  for f in ['src/sim/catching.ts','src/sim/playsim.ts']:shutil.copy2(root/f,host/f)
 (host/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
 data=host/'out/catch-opportunity-physics';data.mkdir(parents=True);shutil.copy2(root/'out/catch-opportunity-physics/reconstruct.ts',data/'reconstruct.ts')
 for d in ['packet','audit','selected']:(data/d).symlink_to(root/'out/catch-opportunity-physics'/d,target_is_directory=True)
 tool=host/'out/catch-opportunity-caller';(tool/'geometry').mkdir(parents=True);(tool/'core').mkdir()
 shutil.copy2(p/'capture.ts',tool/'capture.ts');shutil.copy2(root/'src/physics/catch-opportunity.ts',tool/'geometry/catch-opportunity.ts');shutil.copy2(root/'src/core/vec.ts',tool/'core/vec.ts')
print('Prepared two separate exact-source hosts; data symlinks contain no imported source. Zero ticks.')
