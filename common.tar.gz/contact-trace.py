import gzip,json,pathlib,math
p=pathlib.Path(__file__).parent
for file in sorted(p.glob('baseline-*/trace.json.gz')):
 for r in json.load(gzip.open(file))['rows']:
  if not r['firstContact']:continue
  d=r['firstContact']['b'];end=r['firstContact']['t'];slots={a['idx']:a['slot']for a in r['initial']}
  owners=[a['idx']for a in r['initial']if a['plan']and a['plan']['target']==d];loads=[(f['t'],e['b'],e['helpers'])for f in r['frames']if f['t']<=end for e in f['afterReps']if e['d']==d];impacts=[(f['t'],c['i']if c['j']==d else c['j'])for f in r['frames']if f['t']<=end for c in f['report']['contacts']if c['impulse']>0 and(c['i']==d or c['j']==d)]
  ever={e['b']for f in r['frames']if f['t']<=end for e in f['afterReps']if e['d']==d}
  print('\n',r['id'],'def',slots[d],'RBfirst',end,'installed',[slots[i]for i in owners],'load',(min(t[0]for t in loads),max(t[0]for t in loads),[slots[i]for i in ever])if loads else None,'bodyfirst',impacts[:1])
  if r['id']in ['Z01','Z02','Z07','Z22','Z24','Z28','Z06','Z16']:
   for t in [0,.5,1,1.5,2,2.5,end]:
    if t>end:continue
    f=min(r['frames'],key=lambda f:abs(f['t']-t));out=[]
    for i in owners:
     b=f['before'][i];plan=f['plans'][i];dist=math.dist(b['pos'].values(),f['before'][d]['pos'].values());out.append((slots[i],plan['kind']if plan else None,slots[plan['target']]if plan and plan['target']is not None else None,round(dist,2),{k:round(v,2)for k,v in f['raw'][i]['vel'].items()},[round(v,2)for v in b['pos'].values()]))
    print(t,'RB',[round(v,2)for v in f['before'][6]['pos'].values()],'D',[round(v,2)for v in f['before'][d]['pos'].values()],'owners',out,'reps',[e['b']for e in f['beforeReps']if e['d']==d])
