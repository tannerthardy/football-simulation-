import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {PlaySim} from '../../src/sim/playsim.ts';
import {RunBlocker} from '../../src/sim/behaviors/blocking.ts';
import {previewFreeMovement} from '../../src/physics/movement-preview.ts';
import {composedClimbPreview} from './closed-preview.ts';
import {sourceVersion} from '../../scripts/source-version.ts';
const [inputPath,out]=process.argv.slice(2),inputs=JSON.parse(gunzipSync(readFileSync(inputPath))).rows,rows=[];
for(const id of ['Z06','Z14']){
 const input=inputs.find(r=>r.id===id),sim=new PlaySim(structuredClone(input.setup));
 const a=sim.slot(id==='Z06'?'RG':'Y'),controller=a.behavior;
 assert(controller instanceof RunBlocker);
 let picture;
 const see=sim.see.bind(sim);sim.see=(observer,target,...args)=>{const p=see(observer,target,...args);if(observer===a&&target===controller.target)picture=structuredClone(p);return p;};
 const planner=controller.plannedClimb;
 controller.plannedClimb=function(actor,s,target,strike){
  const previous=this.climbRead,before=structuredClone(actor.body),rng=JSON.stringify(s.rng);
  const command=planner.call(this,actor,s,target,strike);
  if(this.climbRead!==previous){
   const read=this.climbRead,held=previewFreeMovement(before,command,s.t,26,s.world.handContact);
   const composed=composedClimbPreview(actor,s.t,picture,read.meet,this.plan.drive,
    actor.mind.placementError*(1-.5*actor.r('runBlock')),strike,actor.profile.radius+target.profile.radius,s.world.handContact);
   assert.deepEqual(actor.body,before);assert.equal(JSON.stringify(s.rng),rng);
   const heldGaps=held.map(v=>({t:v.t,gap:Math.hypot(v.pos.x-picture.pos.x-picture.vel.x*v.t,v.pos.y-picture.pos.y-picture.vel.y*v.t)-strike}));
   rows.push({id,t:s.t,source:sourceVersion(),inputSha256:input.inputSha256,actorId:actor.player.id,targetId:target.player.id,
    body:before,picture,meet:read.meet,strike,plannerAttainable:read.attainable,placementError:actor.mind.placementError,
    heldMin:Math.min(...heldGaps.map(x=>x.gap)),heldFirst:heldGaps.find(x=>x.gap<=0)?.t??null,
    composedMin:Math.min(...composed.map(x=>x.gap)),composedFirst:composed.find(x=>x.gap<=0&&x.support==='up')?.t??null,
    composed,qualification:'Same exact native current body and acquired picture. Both futures are unloaded forecasts; no private future cuts, contacts, observations or random draws.'});
  }
  return command;
 };
 while(sim.phase==='live'&&sim.t<1.8)sim.tick();
}
mkdirSync(out,{recursive:true});writeFileSync(out+'/forecast.json',JSON.stringify({schema:'climb-forecast-discrepancy-v1',source:sourceVersion(),inputManifestSha256:createHash('sha256').update(readFileSync(inputPath)).digest('hex'),rows},null,2)+'\n');
console.log(rows.map(r=>({id:r.id,t:r.t,claimed:r.plannerAttainable,heldFirst:r.heldFirst,composedFirst:r.composedFirst,heldMin:r.heldMin,composedMin:r.composedMin})));
