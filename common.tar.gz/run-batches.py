import json,subprocess,pathlib,time
p=pathlib.Path(__file__).resolve().parent;host=p/'baseline-host';start=time.monotonic()
for i,ids in enumerate(json.load(open(p/'batches.json'))):
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',str(p/f'baseline-launch-{i}.json'),'--','node','--import','tsx','scripts/diag/zone-approach.mjs','run',str(p/f'baseline-{i}'),','.join(ids),'5',str(p/'inputs.json.gz'),'native']
 with open(p/f'baseline-{i}.log','w')as f:subprocess.run(cmd,cwd=host,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('completed',i,','.join(ids),flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
