"""Plot actual saved native bodies/velocity and already-consumed observations."""
import pathlib,gzip,json,os
os.environ['MPLCONFIGDIR']='/tmp/inside-stalk-film-mpl'
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
p=pathlib.Path(__file__).resolve().parent;old=p.parent/'zone-track-recovery'
arms={'reference':{r['id']:r for f in [*old.glob('perimeter-*/trace.json.gz'),*p.glob('reference-*/trace.json.gz')]for r in json.load(gzip.open(f))['rows']},
 'candidate':{r['id']:r for f in p.glob('candidate-*/trace.json.gz')for r in json.load(gzip.open(f))['rows']}}
out=p/'film';out.mkdir(exist_ok=True)
times={'F01':[1.75,2.25,2.9,3.5],'S02':[1,1.75,2.25,3],'Z26':[1.5,2,2.4,3.3],'S03':[1.5,2.25,2.8,3.5]}
for id,ts in times.items():
 initial=arms['reference'][id]['initial'];h=next(a['idx']for a in initial if a['slot']=='H');d=initial[h]['plan']['target']
 ys=[arms[a][id]['frames'][min(range(len(arms[a][id]['frames'])),key=lambda k:abs(arms[a][id]['frames'][k]['t']-ts[0]))]['before'][i]['pos']['y']for a in arms for i in [h,d,6]]
 lo=max(0,min(ys)-5);hi=min(53.3333,max(ys)+7)
 fig,axes=plt.subplots(2,4,figsize=(17,10),sharex=True,sharey=True)
 for row,arm in enumerate(arms):
  r=arms[arm][id]
  for col,t in enumerate(ts):
   f=min(r['frames'],key=lambda f:abs(f['t']-t));ax=axes[row,col];bodies=f['before']
   ax.set_facecolor('#edf5e9');ax.axvline(40,color='#436caa',lw=1)
   for x in range(30,56,5):ax.axvline(x,color='white',lw=.7)
   for i,b in enumerate(bodies):
    x,y=b['pos'].values();color='#1f67a7'if i<11 else'#c55231';ax.add_patch(Circle((x,y),b['profile']['radius'],color=color,alpha=.85))
    ax.text(x,y+.5,initial[i]['slot'],color=color,ha='center',fontsize=7,clip_on=True)
    ax.arrow(x,y,b['vel']['x']*.18,b['vel']['y']*.18,width=.02,head_width=.16,color=color,length_includes_head=True)
   for e in f['beforeReps']:
    for bi in [e['b'],*e['helpers']]:
     B,D=bodies[bi]['pos'],bodies[e['d']]['pos'];ax.plot([B['x'],D['x']],[B['y'],D['y']],color='#c89700',lw=3,alpha=.85)
   for i in [h,d]:
    b=bodies[i]['pos'];ax.add_patch(Circle((b['x'],b['y']),.68,fill=False,color='#7a2596',lw=1.5))
   B,D=bodies[h]['pos'],bodies[d]['pos'];ax.plot([B['x'],D['x']],[B['y'],D['y']],':',color='#7a2596',lw=.7)
   cmd=f['raw'][h]['vel'];ax.arrow(B['x'],B['y'],cmd['x']*.18,cmd['y']*.18,width=.02,head_width=.18,color='#7a2596',length_includes_head=True)
   c=next(c for c in r['calls']if c['t']==f['t']and c['a']==h);cues=[q for q in r['cues'][c['cueStart']:c['cueEnd']]if q['a']==h and q['b']==d]
   if cues:
    q=cues[-1]['picture']['pos'];ax.scatter([q['x']],[q['y']],marker='+',s=55,c='#248337',zorder=9)
   rb=bodies[6]['pos'];ax.add_patch(Circle((rb['x'],rb['y']),.62,fill=False,color='black',lw=1.2))
   ax.set_xlim(33,49);ax.set_ylim(lo,hi);ax.set_aspect('equal');ax.set_title(f'{arm} t={f["t"]:.2f}s');ax.set_xlabel('field x (offense →)')
 axes[0,0].set_ylabel('field y');axes[1,0].set_ylabel('field y')
 fig.suptitle(f'{id}: actual H / {initial[d]["slot"]}; #148 reference versus inside-stalk candidate',fontsize=14)
 fig.text(.5,.02,'Native tick-entry bodies/velocities; purple H arrow = raw request; gold = recorded hands; green + = consumed target picture. All22 simulated; crop only. Body facing is not gaze. Dashed job line does not establish obstruction.',ha='center',fontsize=8)
 fig.tight_layout(h_pad=3.5,rect=[0,.05,1,.95]);fig.savefig(out/(id+'.png'),dpi=135);plt.close(fig);print('wrote',id,flush=True)
