// Synthetic controller request; no native snap or imposed block outcome.
import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { PlaySim } from '../../src/sim/playsim.ts';
import { RunBlocker } from '../../src/sim/behaviors/blocking.ts';
import { sourceVersion } from '../../scripts/source-version.ts';
const input=JSON.parse(gunzipSync(readFileSync(process.argv[2]))).rows.find(r=>r.id==='F01');
function stage(distance, moving=false) {
 const sim=new PlaySim(structuredClone(input.setup));
 const a=sim.slot('H'),d=sim.slot('LB_W');
 a.body.pos={x:40,y:26};a.body.vel={x:0,y:0};a.body.facing=0;
 d.body.pos={x:40+distance,y:26};d.body.vel={x:moving?1:0,y:0};
 sim.t=1;sim.world.time=1;
 a.behavior=new RunBlocker({kind:'stalk',target:d,drive:{x:1,y:0}});
 for(let k=0;k<24;k++)sim.perception.record(sim.agents);
 const before=JSON.stringify(sim.rng),command=a.behavior.update(a,sim);
 return {distance,moving,physicalLimit:a.profile.radius+d.profile.radius+.3,bodyRadius:a.profile.radius+d.profile.radius,
  acquired:sim.see(a,d),command,engaged:!!a.engagement,rngUnchanged:before===JSON.stringify(sim.rng)};
}
console.log(JSON.stringify({source:sourceVersion(),qualification:'Synthetic frozen-player controller requests; zero World ticks/native snaps.',rows:[stage(1.2),stage(1.25),stage(1.2,true),stage(2)]}));
