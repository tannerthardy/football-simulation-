import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;old=p.parent/'zone-track-recovery'
env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH']
start=time.monotonic()
runs=[('reference-transfer',old/'perimeter-host','S01,S02,S03,S04',p/'fresh-inputs.json.gz'),
 ('candidate-old-fresh',p/'candidate-host','F01,F04',old/'transfer-inputs.json.gz'),
 ('candidate-controls',p/'candidate-host','Z08,Z26,Z28',old/'inputs.json.gz'),
 ('candidate-transfer',p/'candidate-host','S01,S02,S03,S04',p/'fresh-inputs.json.gz')]
for name,host,ids,inputs in runs:
 receipt=os.path.relpath(p/(name+'-launch.json'),host)
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',receipt,'--','node','--import','tsx',
      'scripts/diag/zone-approach.mjs','run',str(p/name),ids,'5',str(inputs),'native']
 with open(p/(name+'.log'),'w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('completed',name,flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
