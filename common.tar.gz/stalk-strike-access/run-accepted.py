"""Fill only six missing accepted-source references; reuse earlier controls."""
import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;old=p.parent/'zone-track-recovery';host=old/'baseline-host'
env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH']
start=time.monotonic()
for name,ids,inputs in [('old-fresh','F01,F04',old/'transfer-inputs.json.gz'),('transfer','S01,S02,S03,S04',p/'fresh-inputs.json.gz')]:
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/f'accepted-{name}-launch.json',host),'--',
      'node','--import','tsx','scripts/diag/zone-approach.mjs','run',str(p/f'accepted-{name}'),ids,'5',str(inputs),'native']
 with open(p/f'accepted-{name}.log','w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('completed accepted',name,flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
