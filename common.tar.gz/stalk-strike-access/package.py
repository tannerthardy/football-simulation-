"""Checksum and package existing evidence; no simulator execution."""
import pathlib,json,gzip,hashlib,difflib,shutil,subprocess,tarfile
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1];old=p.parent/'zone-track-recovery'
pub=p/'publication';common=pub/'common/stalk-strike-access';common.mkdir(parents=True,exist_ok=True)
data=root/'data/reviews/current/inside-stalk-access';data.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();base=(old/'perimeter-host/src/sim/behaviors/blocking.ts').read_text();sources=json.loads((p/'sources.json').read_text())
for arm,expected in sources.items():
 host=p/(arm+'-host');h=hashlib.sha256()
 for f in sorted([f for f in(host/'src').rglob('*')if f.is_file()],key=str):h.update(str(f.relative_to(host)).encode()+b'\0'+f.read_bytes()+b'\0')
 assert h.hexdigest()==expected
 text=(host/'src/sim/behaviors/blocking.ts').read_text()
 patch=''.join(difflib.unified_diff(base.splitlines(True),text.splitlines(True),fromfile='a/src/sim/behaviors/blocking.ts',tofile='b/src/sim/behaviors/blocking.ts'))
 (common/(arm+'-from148.patch')).write_text(patch)
 (common/(arm+'-collector.mjs')).write_bytes((host/'scripts/diag/zone-approach.mjs').read_bytes())
(common/'candidate-code-tests.patch').write_bytes(subprocess.check_output(['git','diff','--binary','6fd13e4782a08497383912272b693e6a59747d80','cd968d045b1be4654b6740e11350fb19d16cd78c','--','src','test'],cwd=root))
for f in p.iterdir():
 if f.is_file()and f.suffix in ['.py','.mjs','.md','.log','.gz']:
  shutil.copyfile(f,common/f.name)
 elif f.is_file()and f.suffix=='.json'and f.name!='summary.json':shutil.copyfile(f,common/f.name)
(common/'summary.json.gz').write_bytes(gzip.compress((p/'summary.json').read_bytes(),mtime=0))
shutil.copytree(p/'film',common/'film',dirs_exist_ok=True)
shutil.copyfile(root/'config/baseline.json',common/'baseline-profile.json')
for name in ['focused-first.json','focused-second.json','focused-final.json','typecheck.json']:
 shutil.copyfile(p/name,data/name)
shutil.copyfile(common/'summary.json.gz',data/'summary.json.gz')
shutil.copyfile(p/'fresh-inputs.json.gz',data/'fresh-inputs.json.gz')
groups={'rejected-near':['near-fresh','near-controls','joined-fresh','joined-controls'],
 'rejected-broad':['strike-fresh','strike-controls','secured-fresh','secured-controls'],
 'surface-isolation':['surface-fresh','surface-controls','retained-fresh','retained-controls'],
 'candidate':['candidate-old-fresh','candidate-controls','candidate-transfer'],
 'references':['reference-transfer','accepted-old-fresh','accepted-transfer']}
members={name:[(f,'stalk-strike-access/'+str(f.relative_to(p)))for d in dirs for f in sorted((p/d).iterdir())if f.is_file()]for name,dirs in groups.items()}
members['common']=[(f,str(f.relative_to(pub/'common')))for f in sorted((pub/'common').rglob('*'))if f.is_file()]
archives=[]
for name,files in members.items():
 manifest=[{'path':dest,'bytes':file.stat().st_size,'sha256':sha(file.read_bytes())}for file,dest in files]
 output=pub/(name+'.tar.gz')
 with tarfile.open(output,'w:gz')as tar:
  for file,dest in files:
   assert not file.is_symlink()and not dest.startswith('/')and'..'not in pathlib.PurePosixPath(dest).parts
   tar.add(file,arcname=dest,recursive=False)
 assert output.stat().st_size<32*1024*1024
 with tarfile.open(output)as tar:
  got=tar.getmembers();assert len(got)==len(manifest)
  for member,expected in zip(got,manifest):
   assert member.isfile()and member.name==expected['path']and sha(tar.extractfile(member).read())==expected['sha256']
 archives.append({'path':output.name,'bytes':output.stat().st_size,'sha256':sha(output.read_bytes()),'members':manifest})
result={'schema':'inside-stalk-artifacts-v1','codeCommit':'cd968d045b1be4654b6740e11350fb19d16cd78c',
 'dependencyPR':148,'dependencyCommit':'6fd13e4782a08497383912272b693e6a59747d80','acceptedDevelop':'914f4d56a3b7ef2845ff0208f55d626c0ff5f880',
 'integrationQueue':'e8d806b940a84c7cff7e5ee066022079723c78ef','reusedEvidence':'15f5113709450363f3dbc744753cbc87b422e6f3','sources':sources,'archives':archives}
(pub/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'archives':[{k:a[k]for k in ['path','bytes','sha256']}for a in archives],'bytes':sum(a['bytes']for a in archives)},indent=2))
