"""Saved native evidence only, including rejected arms and terminal censors."""
import pathlib,gzip,json,hashlib,math
p=pathlib.Path(__file__).resolve().parent;old=p.parent/'zone-track-recovery'
sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={r['id']:r for f in [old/'inputs.json.gz',old/'transfer-inputs.json.gz',p/'fresh-inputs.json.gz']for r in json.loads(gzip.decompress(f.read_bytes()))['rows']}
groups={'accepted':list(old.glob('baseline-[0-4]/trace.json.gz'))+list(p.glob('accepted-*/trace.json.gz')),
 'perimeter':list(old.glob('perimeter-*/trace.json.gz'))+list(p.glob('reference-*/trace.json.gz')),
 'continuity':list(old.glob('composed-*/trace.json.gz'))}
for name in ['near','joined','strike','secured','surface','retained','candidate']:groups[name]=list(p.glob(name+'-*/trace.json.gz'))
arms={};receipts=[];new=0;seconds=0;ended=0;censored=0
for arm,files in groups.items():
 arms[arm]={}
 for f in sorted(files):
  tape=json.loads(gzip.decompress(f.read_bytes()));assert tape['receipt']['diagnosticRoute']=='native'
  fresh=f.is_relative_to(p)
  receipts.append({'path':str(f.relative_to(p.parent)),'sha256':sha(f.read_bytes()),'newThisInvestigation':fresh,**tape['receipt']})
  if fresh:new+=len(tape['rows']);seconds+=tape['receipt']['elapsedSeconds']
  for r in tape['rows']:
   assert inputs[r['id']]['inputSha256']==r['inputSha256']
   assert r['source']==tape['receipt']['source']
   if fresh:
    if r['phase']=='live':assert r['gain'] is None and r['outcome'] is None;censored+=1
    else:ended+=1
   arms[arm][r['id']]=r

def segments(ts):
 out=[]
 for t in ts:
  if not out or t-out[-1][-1]>.050001:out.append([t,t])
  else:out[-1][1]=t
 return out

cases=[]
for id in ['F01','F04','Z08','Z26','Z28','S01','S02','S03','S04']:
 row={'id':id,'inputSha256':inputs[id]['inputSha256'],'setup':{k:inputs[id][k]for k in ['call','form','front','flip']},'arms':{}}
 reference=arms['perimeter'][id]
 for arm,group in arms.items():
  if id not in group:continue
  r=group[id];h=next(a['idx']for a in r['initial']if a['slot']=='H');d=r['initial'][h]['plan']['target']
  ts=[f['t']for f in r['frames']if any(e['b']==h and e['d']==d for e in f['afterReps'])]
  first=next((f for f in r['frames']if f['t']==ts[0]),None)if ts else None
  load=next((e for e in first['afterReps']if e['b']==h and e['d']==d),None)if first else None
  targetChanges=[{'t':c['t'],'from':c['before']['target'],'to':c['after']['target']}for c in r['calls']if c['a']==h and c['before']['target']!=c['after']['target']]
  traffic=[{'t':f['t'],**c}for f in r['frames']for c in f['report']['contacts']if c['i']<11 and c['j']<11 and c['impulse']>0]
  differences={key:next((f['t']for f,g in zip(reference['frames'],r['frames'])if f[key]!=g[key]),None)for key in ['raw','rng']}
  differences['runnerRaw']=next((f['t']for f,g in zip(reference['frames'],r['frames'])if f['raw'][6]!=g['raw'][6]),None)
  samples=[]
  for t in [1.5,1.75,1.9,2,2.25,2.5,2.75,2.9,3,3.25,3.5]:
   f=next((f for f in r['frames']if f['t']==t),None)
   if not f:continue
   c=next((c for c in r['calls']if c['a']==h and c['t']==t),None)
   qs=[q for q in r['cues'][c['cueStart']:c['cueEnd']]if q['a']==h and q['b']==d]if c else []
   samples.append({'t':t,'body':f['before'][h],'defender':f['before'][d],'runner':f['before'][6],
    'raw':f['raw'][h],'final':f['final'][h],'plan':c['after']if c else f['plans'][h],
    'controllerUpdated':c is not None,'consumed':qs,'reps':f['afterReps']})
  row['arms'][arm]={'source':r['source'],'blockerId':inputs[id]['setup']['offense']['H']['id'],
   'defenderSlot':r['initial'][d]['slot'],'defenderId':inputs[id]['setup']['defense'][r['initial'][d]['slot']]['id'],
   'phase':r['phase'],'endTime':r['endTime'],'outcome':r['outcome'],'gain':r['gain'],'firstContact':r['firstContact'],
   'gripIntervals':segments(ts),'firstLoad':load,'firstLoadBeforeDistance':math.dist(first['before'][h]['pos'].values(),first['before'][d]['pos'].values())if first else None,
   'physicalLimit':r['initial'][h]['body']['profile']['radius']+r['initial'][d]['body']['profile']['radius']+.3,
   'targetChanges':targetChanges,'differencesFromPerimeter':differences,'teammateImpulses':traffic,'samples':samples,'events':r['events']}
 cases.append(row)
result={'schema':'inside-stalk-access-v1','qualification':'Native all22 inputs. Final candidate is an explicit148 dependency; accepted-source comparison is separate. First-load intervals are end-of-tick samples labeled by tick start, not exact impulse integrals. Live prefixes have null terminal outcome/gain. All rejected variants and adverse results retained.','newNativeContinuations':new,'nativeCollectorSeconds':seconds,'completed':ended,'censored':censored,'receipts':receipts,'cases':cases}
assert new==49,(new,seconds)
(p/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]for k in ['newNativeContinuations','nativeCollectorSeconds','completed','censored']}))
for row in cases:
 print(row['id'],[(a,x['gain'],x['phase'],x['gripIntervals'])for a,x in row['arms'].items()if a in ['accepted','perimeter','candidate']])
