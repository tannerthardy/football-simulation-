"""Prepare isolated source archives for one near-contact-footwork probe."""
import pathlib, shutil, hashlib, json
p = pathlib.Path(__file__).resolve().parent
old = p.parent/'zone-track-recovery'
needle = """      const fit = { x: Math.max(seen.pos.x - 1.2, a.pos.x), y: seen.pos.y };
      return goTo(a, fit, { speed: .85, through: 1 });"""
replacement = """      const fit = { x: Math.max(seen.pos.x - 1.2, a.pos.x), y: seen.pos.y };
      const ordinary = goTo(a, fit, { speed: .85, through: 1 });
      const bodyContact = a.profile.radius + target.profile.radius;
      const contact = bodyContact + .3;
      if (Math.hypot(seen.pos.x-a.pos.x, seen.pos.y-a.pos.y) > contact + bodyContact) return ordinary;
      const command = secondLevelBlockApproach(a, seen, plan.drive, fit,
        a.mind.placementError * (1 - .5 * a.r('runBlock')), contact, bodyContact, ordinary, sim.t);
      const speed = Math.hypot(command.vel.x, command.vel.y), cap = a.profile.vmax * .85;
      if (speed > cap) command.vel = { x: command.vel.x*cap/speed, y: command.vel.y*cap/speed };
      return command;"""
sources={}
for name, prior in [('near','perimeter'), ('joined','composed')]:
    source=old/(prior+'-host');dest=p/(name+'-host')
    assert not dest.exists(), dest
    dest.mkdir()
    for d in ['src','scripts','config']:
        shutil.copytree(source/d,dest/d,symlinks=True)
    for f in ['package.json','package-lock.json','.nvmrc']:
        if (source/f).exists():shutil.copyfile(source/f,dest/f)
    (dest/'node_modules').symlink_to(source/'node_modules',target_is_directory=True)
    target=dest/'src/sim/behaviors/blocking.ts';text=target.read_text();assert text.count(needle)==1
    target.write_text(text.replace(needle,replacement))
    h=hashlib.sha256()
    for f in sorted([f for f in (dest/'src').rglob('*') if f.is_file()],key=str):
        h.update(str(f.relative_to(dest)).encode()+b'\0'+f.read_bytes()+b'\0')
    sources[name]=h.hexdigest()
(p/'sources.json').write_text(json.dumps(sources,indent=2)+'\n')
print(json.dumps(sources))
