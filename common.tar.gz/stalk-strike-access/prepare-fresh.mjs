import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync,gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {Rng} from '../../src/core/rng.ts';
import {generateTeam,pickOffense,pickDefense} from '../../src/league/team.ts';
const reference=JSON.parse(gunzipSync(readFileSync(new URL('../zone-track-recovery/inputs.json.gz',import.meta.url)))).rows;
const offense=generateTeam(new Rng(947),'S-O','Strike O',{strength:.55});
const defense=generateTeam(new Rng(948),'S-D','Strike D',{strength:.55});
const rows=['Z03','Z08','Z26','Z28'].map((id,index)=>{
 const r=structuredClone(reference.find(r=>r.id===id));
 r.id='S'+String(index+1).padStart(2,'0');r.setup.seed=1101+index;
 r.setup.offense=pickOffense(offense,r.setup.offCall.formation.personnel);
 r.setup.defense=pickDefense(defense,r.setup.defCall.personnel);
 if(index===0){r.flip=true;r.setup.offCall.flip=true;}
 r.inputSha256=createHash('sha256').update(JSON.stringify(r.setup)).digest('hex');return r;
});
writeFileSync(new URL('fresh-inputs.json.gz',import.meta.url),gzipSync(JSON.stringify({schema:'inside-stalk-transfer-v1',qualification:'Four untouched ordinary947/948 generated-player inputs selected before outcomes. OZ reflected, IZ, Power and Trap; seeds1101-1104. No capability tuning or endpoint selection.',rows})));
console.log(rows.map(r=>({id:r.id,call:r.call,flip:r.flip,inputSha256:r.inputSha256})));
