import pathlib, subprocess, os, time
p=pathlib.Path(__file__).resolve().parent; prior=p.parent/'zone-track-recovery'
env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH']
start=time.monotonic()
for arm in ['near','joined']:
 for name,ids,inputs in [('fresh','F01,F04','transfer-inputs.json.gz'),('controls','Z08,Z26,Z28','inputs.json.gz')]:
  command=['node','scripts/baseline.mjs','--candidate','--receipt',f'../{arm}-{name}-launch.json','--',
    'node','--import','tsx','scripts/diag/zone-approach.mjs','run',str(p/f'{arm}-{name}'),ids,'5',str(prior/inputs),'native']
  with open(p/f'{arm}-{name}.log','w')as f:subprocess.run(command,cwd=p/(arm+'-host'),env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  print('completed',arm,name,flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
