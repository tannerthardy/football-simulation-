import pathlib,gzip,json,math
p=pathlib.Path(__file__).resolve().parent
load=lambda n:json.loads(gzip.decompress((p/n/'trace.json.gz').read_bytes()))
baseline={r['id']:r for n in ['current-0','current-1','current-fresh']for r in load(n)['rows']}
candidate={r['id']:r for n in ['final-failures','final-controls','final-fresh']for r in load(n)['rows']}
def first_frames(a,b,key):
 for x,y in zip(a['frames'],b['frames']):
  if x[key]!=y[key]:return x['t']
 return None if len(a['frames'])==len(b['frames']) else min(a['endTime'],b['endTime'])
def actor_diffs(a,b):
 aa={(r['t'],r['a']):r for r in a['calls']};diff=[]
 for c in b['calls']:
  prev=aa.get((c['t'],c['a']))
  if prev and prev['command']!=c['command']:
   if not any(x['slot']==b['initial'][c['a']]['slot']for x in diff):diff.append({'t':c['t'],'slot':b['initial'][c['a']]['slot'],'before':prev['command'],'after':c['command'],'workPicture':c['stateAfter']['workPicture']})
 return diff
def metrics(r,slot,target):
 i=next(a['idx']for a in r['initial']if a['slot']==slot);j=next(a['idx']for a in r['initial']if a['slot']==target);rb=next(a['idx']for a in r['initial']if a['slot']=='RB')
 first=r['firstContact']['t']if r['firstContact'] else r['endTime'];total=good=0;windows=[];samples=[];window=None
 for f in r['frames']:
  bo,de,back=[f['before'][q]['pos']for q in [i,j,rb]];dx=back['x']-de['x'];dy=back['y']-de['y'];proj=((bo['x']-de['x'])*dx+(bo['y']-de['y'])*dy)/max(1e-9,math.hypot(dx,dy))
  e=next((e for e in f['afterReps']if e['b']==i and e['d']==j),None);force=math.hypot(e['hands']['normal'],e['hands']['tangent'])if e and e['hands']else 0
  if force>1:
   if f['t']<first:total+=.05;good+=.05*(proj>0)
   if window is None:
    window={'stepEntry':f['t'],'through':round(f['t']+.05,8),'normal':e['hands']['normal'],'tangent':e['hands']['tangent'],'extension':e['hands']['extension'],'phi':e['phi'],'runnerSideProjection':proj,'b':f['before'][i],'d':f['before'][j]};windows.append(window)
   else:window['through']=round(f['t']+.05,8)
  else:window=None
 return {'loadedSecondsBeforeRunnerContact':round(total,3),'runnerFacingLoadedSecondsBeforeRunnerContact':round(good,3),'loadWindows':windows,'blockContactEvents':[e for e in r['events']if e['type']=='block_contact'and e.get('a')==i and e.get('b')==j]}
report={'qualification':'Same-defender actual acquired requests and achieved native movement. Projection toward true runner is analyst-only geometry. Positive projection plus transmitted hand load is a screening proxy, not proof of complete obstruction. Consecutive loaded steps are load windows, not proof of a single surviving grip. Step entry clocks; completed tick is +0.05 s. No terminal gain for a live prefix. Global RNG may change when off-ball contact ordering changes.','cases':[],'geometry':[]}
for id,a in baseline.items():
 b=candidate[id];diff=actor_diffs(a,b)
 row={'id':id,'baseline':{k:a[k]for k in ['gain','phase','endTime','firstContact']},'candidate':{k:b[k]for k in ['gain','phase','endTime','firstContact']},'firstRequestDifference':diff[0]if diff else None,'actorFirstRequestDifferences':diff,'firstAchievedDifference':first_frames(a,b,'after'),'firstRngDifference':first_frames(a,b,'rng')};report['cases'].append(row)
for id,slot,target in [('R01','H','DE_W'),('C01','LT','DE_W'),('C02','RT','DT_S'),('C02','RG','LB_M'),('Z13','Y','DE_W'),('Z16','H','DE_S'),('GHC','H','LB_W')]:report['geometry'].append({'id':id,'blocker':slot,'defender':target,'baseline':metrics(baseline[id],slot,target),'candidate':metrics(candidate[id],slot,target)})
(p/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
for r in report['cases']:
 diff=r['firstRequestDifference'];print(r['id'],'gain',r['baseline']['gain'],r['candidate']['gain'],'firstRequest',None if diff is None else (diff['t'],diff['slot']),'move/RNG',r['firstAchievedDifference'],r['firstRngDifference'],'firstRBcontact',r['baseline']['firstContact']['t']if r['baseline']['firstContact']else None,r['candidate']['firstContact']['t']if r['candidate']['firstContact']else None)
for r in report['geometry']:
 print('geometry',r['id'],r['blocker'],r['defender'],[(k,r[k]['runnerFacingLoadedSecondsBeforeRunnerContact'],[(x['stepEntry'],x['through'])for x in r[k]['loadWindows']])for k in ['baseline','candidate']])
