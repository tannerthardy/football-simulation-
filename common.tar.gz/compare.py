import pathlib,gzip,json
p=pathlib.Path(__file__).resolve().parent;out=[]
load=lambda arm,id:json.loads(gzip.decompress((p/arm/(id+'.json.gz')).read_bytes()))
for id in ['G1-P020','G2-P107','G2-P143']:
 a,b=[load(arm,id)for arm in ['baseline','candidate']]
 diffs={k:a['result'][k]==b['result'][k]for k in ['frames','events','telemetry','stats']}
 oppdiff=[]
 for x,y in zip(a['opportunities'],b['opportunities']):
  if x['chances']!=y['chances']or x['draws']!=y['draws']or x['events']!=y['events']:oppdiff.append({'t':x['t'],'baseline':{k:x[k]for k in ['actors','chances','draws','events']},'candidate':{k:y[k]for k in ['actors','chances','draws','events']}})
 row={'id':id,'baselineSource':a['source'],'candidateSource':b['source'],'sourceQualifiedOriginalParity':a['original70b4'],'baselineOutcome':a['outcome'],'candidateOutcome':b['outcome'],'baselineGain':a['gain'],'candidateGain':b['gain'],'equal':diffs,'constructorAndInputMatch':a['constructorRng']==b['constructorRng']and a['inputHashes']==b['inputHashes'],'firstAchievedDifference':next((x['t']for x,y in zip(a['ticks'],b['ticks'])if x['after']!=y['after']),None),'opportunityDifferences':oppdiff,'candidateRealIntervals':all(x['bodyStartsSupplied']for x in b['opportunities'])}
 out.append(row);print(id,row['baselineOutcome'],row['candidateOutcome'],diffs,'firstachieved',row['firstAchievedDifference'],'chance difftimes',[x['t']for x in oppdiff]);
(p/'comparison.json').write_text(json.dumps(out,indent=2)+'\n')
