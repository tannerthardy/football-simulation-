import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {reconstruct} from '../catch-opportunity-physics/reconstruct.js';
const geometry=JSON.parse(readFileSync('test/fixtures/same-time-catch.json','utf8'));
const rows=geometry.cases.map((g:any)=>{
 const r:any=reconstruct(g.id);assert.equal(r.status,'constructor-match');const a=r.sim.agents[g.actor];assert.equal(a.slot,g.slot);
 const capture=JSON.parse(gunzipSync(readFileSync('out/catch-opportunity-physics/'+g.id+'-capture.json.gz')).toString());
 const window=capture.opportunities.find((o:any)=>o.t===g.t),actor=window.actors.find((p:any)=>p.i===g.actor);
 return{...g,player:a.player,energy:a.body.energy,tracking:actor.tracking,deflected:window.deflected,ballVel:window.velocity,retry:actor.retry,releaseT:r.native.replay.events.find((e:any)=>e.type==='throw').t};
});
writeFileSync('test/fixtures/catch-caller-inputs.json',JSON.stringify({source:geometry.source,qualification:'Original selected players/energies and exact matched-reproduction endpoints. Staged caller contracts, not simulator restore checkpoints. All three constructors match original RNG/call/player energy; zero World ticks in fixture preparation.',cases:rows},null,2)+'\n');
console.log('Three original constructor/player/energy matches; zero World ticks.');
