import pathlib,gzip,json,math,os
os.environ['MPLCONFIGDIR']='/tmp/football-matplotlib'
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=pathlib.Path(__file__).resolve().parent;base=[];cand=[]
for path in list((p.parent/'zone-track-recovery').glob('baseline-*/trace.json.gz'))+list(p.glob('baseline-*/trace.json.gz'))+list(p.glob('baseline-transfer-*/trace.json.gz')):base+=json.loads(gzip.decompress(path.read_bytes()))['rows']
for path in list(p.glob('traffic-*/trace.json.gz'))+list(p.glob('traffic-transfer-*/trace.json.gz')):cand+=json.loads(gzip.decompress(path.read_bytes()))['rows']
base={r['id']:r for r in base};cand={r['id']:r for r in cand};summaries=[]
for id in ['Z14','Z16','Z18','Z20','T01','T02']:
 b,c=base[id],cand[id];slot={'Z14':'Y','Z16':'Y','Z18':'Y','Z20':'C','T01':'LG','T02':'Y'}[id];idx=next(a['idx']for a in b['initial']if a['slot']==slot);target=b['initial'][idx]['plan']['target'];slots={a['idx']:a['slot']for a in b['initial']}
 first=next(((f['t'],[slots[i]for i,cmd in enumerate(f['raw'])if cmd!=c['frames'][k]['raw'][i]])for k,f in enumerate(b['frames'])if k<len(c['frames'])and f['raw']!=c['frames'][k]['raw']),None)
 print('\n',id,'first',first)
 for arm,r in [('baseline',b),('traffic',c)]:
  contact=r['firstContact'];print(arm,'end',r['gain'],'first',contact, 'slots',{k:slots.get(contact[k])for k in ['a','b']}if contact else None)
  loads=[(f['t'],e,f['before'][idx],f['before'][target])for f in r['frames']for e in f['afterReps']if e['b']==idx and e['d']==target and e['hands']and math.hypot(e['hands']['normal'],e['hands']['tangent'])>1]
  if loads:
   for at,e,ob,db in [loads[0],loads[-1]]:print('load',round(at,2),'phi',round(e['phi'],3),'normal',round(e['hands']['normal'],1),'tangent',round(e['hands']['tangent'],1),'extension',round(e['hands']['extension'],3),'speed',round(math.hypot(*ob['vel'].values()),2),'relv',[round(ob['vel'][k]-db['vel'][k],2)for k in['x','y']],'support',ob['support']['state'])
  obs=[(f['t'],x)for f in r['frames']for x in f['report']['contacts']if idx in[x['i'],x['j']]and (x['j']if x['i']==idx else x['i'])>=11 and target!=(x['j']if x['i']==idx else x['i'])and x['impulse']>1e-6]
  print('obstacle',[(round(t,2),slots[x['j']if x['i']==idx else x['i']],round(x['impulse'],1))for t,x in obs[:5]])
 fig,axs=plt.subplots(1,2,figsize=(11,5),sharex=True,sharey=True)
 for ax,(arm,r)in zip(axs,[('baseline',b),('candidate',c)]):
  peers=[idx,target,6]+[a['idx']for a in r['initial']if a['slot']in['LT','DE_W','DT_W','LG','RG','C']and a['idx']not in[idx,target]]
  colors=['purple','crimson','green','royalblue','orange','gold','gray','cyan','black']
  fs=[f for f in r['frames']if f['t']<=2.5]
  for i,color in zip(peers,colors):
   ax.plot([f['before'][i]['pos']['y']for f in fs],[f['before'][i]['pos']['x']for f in fs],color=color,label=slots[i],linewidth=2 if i in[idx,target,6]else .8)
   for at in [.5,1,1.5,2]:
    f=min(fs,key=lambda f:abs(f['t']-at));q=f['before'][i]['pos'];ax.scatter(q['y'],q['x'],s=12,color=color)
    if i in[idx,target]:ax.annotate(str(at),(q['y'],q['x']),fontsize=7,color=color)
  ax.set_title(arm);ax.set_xlabel('field lateral y (yd)');ax.grid(alpha=.3);ax.set_aspect('equal');ax.legend(fontsize=7,ncol=2)
 axs[0].set_ylabel('downfield x (yd)');fig.suptitle(id+' '+slot+' approach (0–2.5s, dots each0.5s)');fig.tight_layout();fig.savefig(p/(id+'-traffic.png'),dpi=140);plt.close(fig)
