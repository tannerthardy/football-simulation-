// Pure planner replay of exact current bodies/pictures. No future trajectory or native snaps.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {PlaySim} from '../../src/sim/playsim.ts';
import {playSideSign} from '../../src/sim/behaviors/blocking.ts';
import {clamp} from '../../src/core/vec.ts';
import {FIELD_WIDTH} from '../../src/core/field.ts';
import {previewFreeMovement} from '../../src/physics/movement-preview.ts';
import {availability,supportParams} from '../../src/physics/support.ts';
import {fatigueFactor,movingArrivalVelocity} from '../../src/physics/kinematics.ts';
const [path,inputsPath,out]=process.argv.slice(2),input=JSON.parse(readFileSync(path)),inputs=JSON.parse(gunzipSync(readFileSync(inputsPath))).rows,rows=[];
for(const q of input.rows){
 const setup=inputs.find(r=>r.id===q.id).setup,sim=new PlaySim(structuredClone(setup));
 const radius=sim.slot(q.id==='Z06'?'LB_M':'LB_W').profile.radius;
 const body=q.body,seen=q.picture,side=playSideSign(sim,sim.offCall.run)*.5;
 function choose(limit){
  const capacity=body.support?availability(body.support,supportParams(body.profile),fatigueFactor(body.energy)):1;
  let best=null;
  for(const lead of [.2,.4,.6,.8,1,1.3]){
   const meet={x:seen.pos.x+seen.vel.x*lead,y:clamp(seen.pos.y+seen.vel.y*lead+side,.5,FIELD_WIDTH-.5)};
   const vel=movingArrivalVelocity(body,meet,seen.vel,body.profile.vmax,.1,Math.hypot(seen.vel.x,seen.vel.y),1,capacity);
   const facing=Math.atan2(meet.y-body.pos.y,meet.x-body.pos.x),samples=previewFreeMovement(body,{vel,facing},q.t,26,sim.world.handContact);
   for(const s of samples){const gap=Math.hypot(s.pos.x-seen.pos.x-seen.vel.x*s.t,s.pos.y-seen.pos.y-seen.vel.y*s.t)-limit;
    if(!best||(gap<=0&&(best.gap>0||s.t<best.t))||(best.gap>0&&gap<best.gap))best={meet,lead,t:s.t,gap,vel};
    if(gap<=0)break;
   }
  }
  return best;
 }
 const original=choose(q.strike),bodyFit=choose(body.profile.radius+radius+.15);
 assert.deepEqual(original.meet,q.meet);
 rows.push({id:q.id,t:q.t,original,bodyFit});
}
writeFileSync(out,JSON.stringify({schema:'climb-body-fit-score-v1',qualification:'Exact current controller body/picture, available constant-velocity prediction. Local planning comparison only; no native outcome or knowledge of later cuts.',rows},null,2)+'\n');
console.log(rows.filter(r=>r.t>=.5&&r.t<=1.5).map(r=>({id:r.id,t:r.t,oldLead:r.original.lead,newLead:r.bodyFit.lead,oldTime:r.original.t,newTime:r.bodyFit.t,oldAim:r.original.meet,newAim:r.bodyFit.meet})));
