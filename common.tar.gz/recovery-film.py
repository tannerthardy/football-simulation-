import pathlib,gzip,json,os
os.environ['MPLCONFIGDIR']='/tmp/football-matplotlib'
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
p=pathlib.Path(__file__).resolve().parent
for id,slot,base,cand in [('R01','H','current-fresh','final-fresh'),('C01','LT','current-1','final-controls')]:
 fig,axes=plt.subplots(2,3,figsize=(15,9),sharex=True,sharey=True)
 for row,(label,folder)in enumerate([('Accepted f4146275',base),('Free runner-side recovery',cand)]):
  r=next(r for r in json.loads(gzip.decompress((p/folder/'trace.json.gz').read_bytes()))['rows']if r['id']==id)
  for col,t in enumerate([1.7,2.6,3.1]):
   f=min(r['frames'],key=lambda f:abs(f['t']-t));ax=axes[row,col];ax.set_title(f'{label} | step entry {f["t"]:.2f}s')
   for i,b in enumerate(f['before']):
    q=b['pos'];selected=r['initial'][i]['slot']in[slot,'DE_W','RB'];color='royalblue'if i<11 else'crimson'
    ax.add_patch(Circle((q['x'],q['y']),b['profile']['radius'],facecolor=color,alpha=.7 if selected else .23,edgecolor=color))
    if 28<q['x']<44 and 17<q['y']<37:ax.annotate(r['initial'][i]['slot'],(q['x'],q['y']),xytext=(2,4),textcoords='offset points',fontsize=8 if selected else 6)
    if selected:
     for command,c in [(f['raw'][i],'gray'),({'vel':b['vel']},color)]:
      v=command['vel'];ax.arrow(q['x'],q['y'],v['x']*.15,v['y']*.15,color=c,width=.016,head_width=.13,length_includes_head=True,alpha=.8)
   for e in f['afterReps']:
    if e['hands']and abs(e['hands']['normal'])+abs(e['hands']['tangent'])>1:
     a,b=[f['before'][q]['pos']for q in[e['b'],e['d']]];ax.plot([a['x'],b['x']],[a['y'],b['y']],color='black',linewidth=1.5 if r['initial'][e['b']]['slot']==slot else .5,alpha=.55)
   ax.set_xlim(28,44);ax.set_ylim(17,37);ax.set_aspect('equal');ax.grid(alpha=.2)
 fig.suptitle(f'{id}: {slot} / DE_W recovery. Native all22 core crop; gray=request, color=achieved velocity.\nBlack links mark measured hand load, not an inferred obstruction. Same frozen players and input.')
 fig.tight_layout();fig.savefig(p/(id+'-recovery.png'),dpi=120);plt.close(fig)
