import json,subprocess,pathlib,time
p=pathlib.Path(__file__).resolve().parent;start=time.monotonic()
for i,ids in enumerate([['Z03','Z12','Z16','Z27','Z08','Z26'],['Z28']]):
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',f'../surface-launch-{i}.json','--','node','--import','tsx','scripts/diag/zone-approach.mjs','run',str(p/f'surface-{i}'),','.join(ids),'5',str(p/'inputs.json.gz'),'native']
 with open(p/f'surface-{i}.log','w')as f:subprocess.run(cmd,cwd=p/'surface-host',stdout=f,stderr=subprocess.STDOUT,check=True)
 print('completed surface',i,','.join(ids),flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
