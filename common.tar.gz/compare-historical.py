import pathlib,gzip,json
p=pathlib.Path(__file__).resolve().parent;old=p.parent/'catch-opportunity-physics';rows=[]
for id in ['G1-P020','G2-P107','G2-P143']:
 original=json.loads(gzip.decompress((old/(id+'-capture.json.gz')).read_bytes()));candidate=json.loads(gzip.decompress((p/'historical'/(id+'.json.gz')).read_bytes()));film=json.loads((old/'selected'/(id+'.json')).read_text());oldops={x['t']:x for x in original['opportunities']};changes=[]
 for o in candidate['opportunities']:
  before=oldops.get(o['t']);assert before is not None
  for a in o['actors']:
   olda=next(a0 for a0 in before['actors']if a0['i']==a['i']);assert a['body0']==olda['body0'];assert a['body1']==olda['body1']
  if before['chances']!=o['chances']or before['draws']!=o['draws']or before['events']!=o['events']:
   changes.append({'t':o['t'],'baseline':{k:before[k]for k in ['chances','draws','events']},'candidate':{k:o[k]for k in ['chances','draws','events']},'geometry':[{k:a[k]for k in ['slot','playerId','body0','body1','reach','top','old','corrected']}for a in o['actors']]})
 if id=='G1-P020':
  prefix=[f for f in film['replay']['frames']if f['t']<4.55];assert prefix==[f for f in candidate['result']['frames']if f['t']<4.55]
 else:assert all(candidate['original70b4'].values())
 rows.append({'id':id,'cachedBaselineSource':original['source'],'candidateSource':candidate['source'],'candidateOutcome':candidate['outcome'],'candidateGain':candidate['gain'],'originalParity':candidate['original70b4'],'P020RecordedFramesBefore4p55Exact':id=='G1-P020','opportunityBodyEndpointsMatchCachedBaseline':True,'changedAttempts':changes})
(p/'historical-comparison.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r['id'],r['candidateOutcome'],'all original fields match',all(r['originalParity'].values()),'changed attempts',[x['t']for x in r['changedAttempts']])
