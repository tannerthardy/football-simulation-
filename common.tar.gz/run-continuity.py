import pathlib,subprocess,time
p=pathlib.Path(__file__).resolve().parent;start=time.monotonic()
for arm in ['continuity','composed']:
 for name,ids,inputs in [('fresh','F01','transfer-inputs.json.gz'),('controls','Z08,Z12,Z27','inputs.json.gz')]:
  cmd=['node','scripts/baseline.mjs','--candidate','--receipt',f'../{arm}-{name}-launch.json','--','node','--import','tsx','scripts/diag/zone-approach.mjs','run',str(p/f'{arm}-{name}'),ids,'5',str(p/inputs),'native']
  with open(p/f'{arm}-{name}.log','w')as f:subprocess.run(cmd,cwd=p/(arm+'-host'),stdout=f,stderr=subprocess.STDOUT,check=True)
  print('completed',arm,name,flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
