import pathlib,json,gzip,collections,math
p=pathlib.Path(__file__).parent;arms={}
for name in ['baseline','picture','moving']:
 arms[name]={}
 for file in sorted(p.glob(name+'-*/trace.json.gz')):
  arms[name].update({r['id']:r for r in json.load(gzip.open(file))['rows']})
for id in ['Z03','Z12','Z16','Z27','Z08','Z26','Z28']:
 a=arms['picture'][id];b=arms['moving'][id];print('\n',id)
 def first(key):return next((x['t']for x,y in zip(a['frames'],b['frames'])if x[key]!=y[key]),None)
 print('first raw/rng',first('raw'),first('rng'))
 def impacts(r):return[(f['t'],c['i'],c['j'],round(c['impulse'],2))for f in r['frames']for c in f['report']['contacts']if c['impulse']>0 and c['i']<11 and c['j']<11]
 print('off impacts picture/moving',impacts(a)[:10],impacts(b)[:10])
 if id in ['Z12','Z27','Z08']:
  print('events picture',[(e['t'],e['type'],e.get('a'),e.get('b'),e.get('note'))for e in a['events']if e['type']in ['block_contact','block_climb','fall','carrier_contact','tackle_break','tackle_wrap']])
  print('events moving',[(e['t'],e['type'],e.get('a'),e.get('b'),e.get('note'))for e in b['events']if e['type']in ['block_contact','block_climb','fall','carrier_contact','tackle_break','tackle_wrap']])
