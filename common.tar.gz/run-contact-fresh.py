import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH'];started=time.monotonic()
for name,host in [('contact-tactile-fresh',p/'contact-tactile-host')]:
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/f'{name}-launch.json',host),'--','node','--import','tsx','scripts/diag/climb-approach.mjs','run',str(p/name),'R01,R02,GHC','5',str(p/'fresh-inputs.json.gz'),'native']
 with open(p/f'{name}.log','w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(name,'completed',flush=True)
print('launcherSeconds',time.monotonic()-started,flush=True)
