"""Saved-data reduction only. Exact actor identities and censors retained."""
import pathlib,json,gzip,hashlib,math,collections
p=pathlib.Path(__file__).parent
meta={r['id']:r for f in ['inputs.json.gz','transfer-inputs.json.gz'] for r in json.load(gzip.open(p/f))['rows']}
patterns={'baseline':'baseline-*','picture':'picture-*','moving':'moving-*','surface':'surface-*','transfer-picture':'transfer-picture','transfer-surface':'transfer-surface','perimeter':'perimeter-*','continuity':'continuity-*','composed':'composed-*'}
arms={};receipts={};native=0;seconds=0;ends=0;censors=0
for arm,pattern in patterns.items():
 arms[arm]={}
 for file in sorted(p.glob(pattern+'/trace.json.gz')):
  x=json.load(gzip.open(file));receipts[str(file.relative_to(p))]={'receipt':x['receipt'],'sha256':hashlib.sha256(file.read_bytes()).hexdigest()};seconds+=x['receipt']['elapsedSeconds'];native+=len(x['rows'])
  for r in x['rows']:
   assert r['inputSha256']==meta[r['id']]['inputSha256'];assert r['source']==x['receipt']['source'];assert x['receipt']['diagnosticRoute']=='native'
   if r['phase']=='live':assert r['outcome'] is None and r['gain'] is None;censors+=1
   else:ends+=1
   arms[arm][r['id']]=r
foci={'Z03':('Z','CB_S'),'Z12':('X','CB_W'),'Z16':('Z','CB_W'),'Z27':('X','CB_W'),'Z08':('H','LB_W'),'Z26':('H','LB_W'),'Z28':('H','LB_W'),'F01':('Z','CB_S'),'F02':('LG','DT_W'),'F03':('X','CB_W'),'F04':('H','LB_W')}
def same_pair(rows,key):
 a,b=rows;return next((x['t'] for x,y in zip(a['frames'],b['frames']) if x[key]!=y[key]),None)
def segments(v):
 out=[]
 for t in v:
  if not out or t-out[-1][-1]>.050001:out.append([t,t])
  else:out[-1][1]=t
 return out
rows=[]
for id,(bs,ds) in foci.items():
 reference=arms['picture'].get(id) or arms['transfer-picture'][id];row={'id':id,'inputSha256':meta[id]['inputSha256'],'call':meta[id]['call'],'form':meta[id]['form'],'front':meta[id]['front'],'flip':meta[id]['flip'],'blocker':bs,'defender':ds,'arms':{}}
 for arm,group in arms.items():
  if id not in group:continue
  r=group[id];bi=next(a['idx'] for a in r['initial'] if a['slot']==bs);di=next(a['idx'] for a in r['initial'] if a['slot']==ds)
  membership=[f['t'] for f in r['frames'] if any(e['b']==bi and e['d']==di for e in f['afterReps'])]
  body=[{'t':f['t'],**c} for f in r['frames'] for c in f['report']['contacts'] if c['impulse']>0 and set((c['i'],c['j']))=={bi,di}]
  traffic=[{'t':f['t'],**c} for f in r['frames'] for c in f['report']['contacts'] if c['impulse']>0 and c['i']<11 and c['j']<11]
  timeline=[]
  targets=set([1.,1.5,1.75,2.,2.25,2.5,2.75,3.,3.5,4.])
  if membership:targets.add(membership[0])
  for t in sorted(targets):
   if not any(abs(f['t']-t)<1e-8 for f in r['frames']):continue
   f=next(f for f in r['frames'] if abs(f['t']-t)<1e-8);c=next(c for c in r['calls'] if c['a']==bi and c['t']==t)
   cues=[q for q in r['cues'][c['cueStart']:c['cueEnd']] if q['a']==bi and q['b']==di]
   timeline.append({'t':t,'blockerBody':f['before'][bi],'defenderBody':f['before'][di],'runnerBody':f['before'][6],'consumed':cues,'raw':f['raw'][bi],'final':f['final'][bi],'planBefore':c['before'],'planAfter':c['after'],'loaded':next((e for e in f['afterReps'] if e['b']==bi and e['d']==di),None)})
  owner=[{'t':c['t'],'before':c['before'],'after':c['after'],'command':c['command']} for c in r['calls'] if c['a']==bi and c['before']!=c['after']]
  field='offense' if bi<11 else 'defense';bplayer=meta[id]['setup'][field][bs];dplayer=meta[id]['setup']['defense'][ds]
  row['arms'][arm]={'source':r['source'],'blockerId':bplayer['id'],'defenderId':dplayer['id'],'phase':r['phase'],'endTime':r['endTime'],'outcome':r['outcome'],'gain':r['gain'],'firstRunnerContact':r['firstContact'],'gripIntervals':segments(membership),'gripTickCount':len(membership),'firstBodyImpulse':body[0] if body else None,'bodyImpulseCount':len(body),'offensiveTeammateImpulses':traffic,'firstRawDifferenceFromPicture':same_pair((reference,r),'raw'),'firstRngDifferenceFromPicture':same_pair((reference,r),'rng'),'timeline':timeline,'ownershipChanges':owner,'events':r['events']}
 rows.append(row)
result={'schema':'perimeter-stalk-native-review-v1','qualification':'Fixed selected28-case discovery plus bounded variants/transfer; not population rates. Foci preserve installed blocker and actual threatening defender identities. Grip intervals are end-of-tick samples labeled by tick start, not exact force integrals. Different endings can include changed execution randomness. Source/profile/flags and censors remain explicit.','nativeContinuations':native,'nativeCollectorSeconds':seconds,'completed':ends,'censored':censors,'receipts':receipts,'rows':rows}
assert native==76
(p/'report.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['nativeContinuations','nativeCollectorSeconds','completed','censored']}))
