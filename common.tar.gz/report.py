import pathlib,gzip,json,math,hashlib
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1]
def read(path):return json.loads(gzip.decompress(path.read_bytes()))
def rows(pattern,where=p):
 out={}
 for path in sorted(where.glob(pattern)):
  for r in read(path)['rows']:out[r['id']]=(r,path)
 return out
baseline=rows('baseline-*/trace.json.gz',p.parent/'zone-track-recovery');baseline.update(rows('baseline-*/trace.json.gz'));baseline.update(rows('baseline-transfer-*/trace.json.gz'))
candidate=rows('candidate-*/trace.json.gz');candidate.update(rows('candidate-transfer-*/trace.json.gz'))
prototype=rows('traffic-*/trace.json.gz');prototype.update(rows('traffic-transfer-*/trace.json.gz'))
inputs={r['id']:r for path in ['inputs.json.gz','transfer-inputs.json.gz']for r in read(p/path)['rows']}
foci={'Z06':'RG','Z13':'LG','Z14':'Y','Z19':'RG','Z26':'RT','C01':'RT','C02':'RG','Z16':'Y','Z18':'Y','Z20':'C','Z27':'H','T01':'LG','T02':'Y','T03':None,'T04':None}
comparison=[]
keys=['raw','final','before','after','rng','report','afterReps','ball']
def same(b,c):return len(b['frames'])==len(c['frames'])and all(x[k]==y[k]for x,y in zip(b['frames'],c['frames'])for k in keys)
def contact(r):
 e=r['firstContact'];return {'t':e['t'],'defender':r['initial'][e['b']]['slot'],'defenderIdx':e['b'],'note':e.get('note')}if e else None
def numbers(r,slot):
 result={'phase':r['phase'],'endTime':r['endTime'],'censor':r['censor'],'outcome':r['outcome'],'gain':r['gain'],'firstRunnerContact':contact(r)}
 if not slot:return result
 i=next(a['idx']for a in r['initial']if a['slot']==slot);plan=r['initial'][i]['plan'];target=plan['target']if plan['kind']=='climb'else plan['combination']['backer'];tar=r['initial'][target]
 load=[(f,e)for f in r['frames']for e in f['afterReps']if e['b']==i and e['d']==target and e['hands']and math.hypot(e['hands']['normal'],e['hands']['tangent'])>1]
 impulses=[(f['t'],x)for f in r['frames']for x in f['report']['contacts']if i in[x['i'],x['j']]and(x['j']if x['i']==i else x['i'])>=11 and(x['j']if x['i']==i else x['i'])!=target and x['impulse']>1e-6]
 def ls(pair):
  f,e=pair;b=f['before'][i];d=f['before'][target]
  return {'t':f['t'],'phi':e['phi'],'normalForce':e['hands']['normal'],'tangentForce':e['hands']['tangent'],'extension':e['hands']['extension'],'ownPos':b['pos'],'ownVel':b['vel'],'targetPos':d['pos'],'targetVel':d['vel'],'ownSupport':b['support']['state'],'targetSupport':d['support']['state']}
 result.update({'blocker':slot,'blockerIdx':i,'target':tar['slot'],'targetIdx':target,'firstLoad':ls(load[0])if load else None,'lastLoad':ls(load[-1])if load else None,'obstacleContactSteps':len(impulses),'obstacleImpulse':sum(x['impulse']for t,x in impulses),'firstTargetNotUp':next((f['t']for f in r['frames']if f['after'][target]['support']['state']!='up'),None)})
 return result
for id,(c,path)in candidate.items():
 b,bpath=baseline[id];proto,_=prototype[id]
 assert b['inputSha256']==c['inputSha256']==inputs[id]['inputSha256'];assert same(proto,c),id+' final source differs from trial'
 first=None
 for f,g in zip(b['frames'],c['frames']):
  if f['raw']!=g['raw']:
   changed=[i for i,(x,y)in enumerate(zip(f['raw'],g['raw']))if x!=y]
   first={'t':f['t'],'actors':[c['initial'][i]['slot']for i in changed],'baselineRequests':[f['raw'][i]for i in changed],'candidateRequests':[g['raw'][i]for i in changed],'states':[call['stateAfter']for call in c['calls']if call['a']in changed and abs(call['t']-g['t'])<1e-9],'consumedCues':[cue for cue in c['cues']if cue['a']in changed and abs(cue['t']-g['t'])<1e-9]};break
 rng=next((f['t']for f,g in zip(b['frames'],c['frames'])if f['rng']!=g['rng']),None)
 maxResidual=max(abs(f['report']['work']['residual'])for f in c['frames']);maxArmExcess=max((actual-limit for f in c['frames']for actual,limit in zip(f['report']['armImpulse'],f['report']['armImpulseLimit'])),default=0)
 assert maxResidual<1e-8;assert maxArmExcess<1e-8
 comparison.append({'id':id,'inputSha256':c['inputSha256'],'meta':{k:v for k,v in inputs[id].items()if k not in['setup','inputSha256']},'baselineTape':str(bpath.relative_to(root)),'candidateTape':str(path.relative_to(root)),'baselineSource':b['source'],'candidateSource':c['source'],'unchanged':same(b,c),'trialFinalHistoryIdentity':True,'firstRequestDivergence':first,'firstRngDivergence':rng,'maxWorkResidual':maxResidual,'maxArmExcess':maxArmExcess,'baseline':numbers(b,foci[id]),'candidate':numbers(c,foci[id])})
# Preserve all negative/held variants, not only the selected routing success.
arms=[]
for arm in ['baseline','waypoint','trend','coherent','advect','intercept','firststep','traffic']:
 rs=rows(arm+'-[0-9]/trace.json.gz');rr=[r for r,path in rs.values()]
 receipts=[read(path)['receipt']for path in sorted(p.glob(arm+'-[0-9]/trace.json.gz'))]
 arms.append({'arm':arm,'sources':sorted(set(r['source']for r in rr)),'flags':receipts[0]['flags']if receipts else None,'cases':len(rr),'completed':sum(r['phase']=='dead'for r in rr),'liveCensored':sum(r['phase']=='live'for r in rr),'collectorSeconds':sum(r['elapsedSeconds']for r in receipts),'rows':[{'id':r['id'],**numbers(r,foci[r['id']])}for r in rr]})
receipts=[]
for path in sorted(p.glob('*-launch.json')):
 d=json.loads(path.read_bytes());receipts.append({'file':path.name,'exitCode':d['exitCode'],'seconds':sum(c['elapsedSeconds']for c in d.get('commands',[])),'source':d.get('sourceSha256'),'commands':[c['command']for c in d.get('commands',[])]})
result={'schema':'climb-access-comparison-v1','acceptedCommit':'914f4d56a3b7ef2845ff0208f55d626c0ff5f880','queueCommit':'e8d806b940a84c7cff7e5ee066022079723c78ef','timeConvention':'Loaded force samples name recorder World-step t; the corresponding completed native tick is t+0.05. Event clocks are preserved separately. Body/velocity in load entries is step-entry geometry, not a substep contact reconstruction.','qualification':'Frozen exact initial inputs, native all22, unchanged World laws/capacities. Four saved transfer baselines reused from compatible original accepted recordings; the newer passive collector was proved identical on five witnesses. No population/gamewide rate claim. All trial-final histories compare body/request/RNG/physics exactly despite recording-format additions.','comparisons':comparison,'diagnosticArms':arms,'launchers':receipts,'newNativeContinuations':83,'newNativePrefixes':2,'fullGames':0,'newNativeContinuationBreakdown':{'eightSevenInputArms':56,'transferFreshBaseline':4,'trialTransferCandidate':8,'finalSourceCandidate':15},'nativeCollectorSeconds':sum(read(path)['receipt']['elapsedSeconds']for path in p.glob('*/trace.json.gz'))}
(p/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
for r in comparison:
 b,c=r['baseline'],r['candidate'];print(r['id'],'same',r['unchanged'],'gain',b['gain'],c['gain'],'load',b.get('firstLoad',{}).get('t')if b.get('firstLoad')else None,c.get('firstLoad',{}).get('t')if c.get('firstLoad')else None,'first diff',r['firstRequestDivergence']['t']if r['firstRequestDivergence']else None)
print('nativeCollectorSeconds',result['nativeCollectorSeconds']);print('launcherSeconds',sum(r['seconds']for r in receipts));print('checks',[(r['file'],r['seconds'])for r in receipts if any(x in r['file']for x in['focused','typecheck'])])
