/** Diagnostic controller forecast only: exact self movement, observed constant-velocity target. */
import {World,type Intent} from '../../src/physics/world.js';
import {fatigueFactor,movingArrivalVelocity} from '../../src/physics/kinematics.js';
import {availability,supportParams} from '../../src/physics/support.js';
import type {Agent} from '../../src/sim/agent.js';
import type {Perceived} from '../../src/sim/perception.js';
import type {Vec2} from '../../src/core/vec.js';
import {secondLevelBlockApproach} from '../../src/sim/run-block-fit.js';

export function composedClimbPreview(a:Agent, now:number, seen:Perceived, meet:Vec2,
 drive:Vec2, placementError:number, strike:number, bodyContact:number, handContact:World['handContact']) {
 const body=structuredClone(a.body),actor=Object.create(a) as Agent;
 Object.defineProperty(actor,'body',{value:body});
 const world=new World([body],{handContact});world.time=now;
 const samples=[];
 for(let k=0;k<26;k++){
  const elapsed=k*.05,picture={...seen,pos:{x:seen.pos.x+seen.vel.x*elapsed,y:seen.pos.y+seen.vel.y*elapsed}};
  const capacity=body.support?availability(body.support,supportParams(a.profile),fatigueFactor(body.energy)):1;
  let command:Intent={vel:movingArrivalVelocity(body,meet,seen.vel,a.profile.vmax,.1,Math.hypot(seen.vel.x,seen.vel.y),1,capacity),
   facing:Math.atan2(meet.y-actor.pos.y,meet.x-actor.pos.x)};
  if(Math.hypot(picture.pos.x-actor.pos.x,picture.pos.y-actor.pos.y)<=strike+bodyContact)
   command=secondLevelBlockApproach(actor,picture,drive,meet,placementError,strike,bodyContact,command,now+elapsed);
  world.step([command],.05);
  const t=(k+1)*.05,bx=seen.pos.x+seen.vel.x*t,by=seen.pos.y+seen.vel.y*t;
  samples.push({t,pos:{...body.pos},vel:{...body.vel},support:body.support!.state,
   gap:Math.hypot(body.pos.x-bx,body.pos.y-by)-strike,command});
 }
 return samples;
}
