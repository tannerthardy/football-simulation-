import pathlib,gzip,json,math,collections
p=pathlib.Path(__file__).resolve().parent;inputs={r['id']:r for r in json.loads(gzip.decompress((p/'inputs.json.gz').read_bytes()))['rows']};rows=[]
for path in sorted(p.glob('current-*/trace.json.gz')):
 for r in json.loads(gzip.decompress(path.read_bytes()))['rows']:
  inline={a['idx']for a in r['initial']if inputs[r['id']]['setup']['offCall']['formation']['slots'].get(a['slot'],{}).get('split')=='inline'};frames={f['t']:f for f in r['frames']}
  groups=collections.defaultdict(list)
  for c in r['calls']:
   if c['a']not in inline or not c['after']or c['after']['kind']not in['drive','reach','down','cutoff']or c['after']['target']is None:continue
   a=c['a'];d=c['after']['target'];f=frames[c['t']]
   if any(e['b']==a or a in e['helpers']for e in f['beforeReps']):continue
   cue=next((s['picture']for s in reversed(r['cues'][c['cueStart']:c['cueEnd']])if s['a']==a and s['b']==d),None)
   if cue is None:continue
   body=f['before'][a];drive={'x':1,'y':0}if c['zoneRead']and c['after']['kind']=='reach'else c['after']['drive'];dx=body['pos']['x']-cue['pos']['x'];dy=body['pos']['y']-cue['pos']['y'];phi=math.atan2(dx*-drive['y']+dy*drive['x'],-dx*drive['x']-dy*drive['y'])/(math.pi/2)
   trueDist=math.dist(body['pos'].values(),f['before'][d]['pos'].values())
   if abs(phi)>=1.1:
    groups[(a,d)].append({'t':c['t'],'phi':phi,'body':body,'seen':cue,'request':c['command'],'kind':c['after']['kind'],'trueDist':trueDist})
  for(a,d),samples in groups.items():
   summary={'id':r['id'],'blocker':r['initial'][a]['slot'],'target':r['initial'][d]['slot'],'lostFreeSteps':len(samples),'first':samples[0],'last':samples[-1]};rows.append(summary)
   print(r['id'],summary['blocker']+'→'+summary['target'],'lost free',len(samples),'first',round(samples[0]['t'],2),'phi',round(samples[0]['phi'],2),'cueage',samples[0]['seen']['age'],'requested',samples[0]['request'],'actualdist',round(samples[0]['trueDist'],2),'last',round(samples[-1]['t'],2))
(p/'inline-screen.json').write_text(json.dumps({'question':'Does the installed inline first-level blocker bypass existing acquired lost-fit recovery because of its roster slot?', 'qualification':'Saved-data inspection only. Actual distance is analyst-only; recovery eligibility below is computed from consumed cue and installed drive. This does not by itself prove that recovery wins a block.', 'rows':rows},indent=2)+'\n')
