import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;host=p/'coherent-host'
env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH']
start=time.monotonic()
for name,ids in [('0','Z06,Z13,Z14,Z19,Z26,C01'),('1','C02')]:
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/f'coherent-{name}-launch.json',host),'--',
  'node','--import','tsx','scripts/diag/climb-approach.mjs','run',str(p/f'coherent-{name}'),ids,'5',str(p/'inputs.json.gz'),'native']
 with open(p/f'coherent-{name}.log','w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('completed',name,flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
