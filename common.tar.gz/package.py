"""Package existing captures and prove source restoration; zero simulator ticks."""
import pathlib,hashlib,json,gzip,difflib,tarfile,shutil,subprocess,os,tempfile,io
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1];bundle=p/'publication';common=bundle/'common';common.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest()
code=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
def files(host):return {str(f.relative_to(host)):f.read_bytes()for f in(host/'src').rglob('*')if f.is_file()}
def digest(fs):
 h=hashlib.sha256()
 for name in sorted(fs):h.update(name.encode()+b'\0'+fs[name]+b'\0')
 return h.hexdigest()
current=p/'baseline-host';basefiles=files(current);records={};assert digest(basefiles)=='7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197'
historicalRaw=subprocess.check_output(['git','archive','70b4db6a3ef53acc1a0e90cd055f1087205daa30','src'],cwd=root)
with tarfile.open(fileobj=io.BytesIO(historicalRaw))as ar:historical={m.name:ar.extractfile(m).read()for m in ar.getmembers()if m.isfile()}
assert digest(historical)=='9513511efacc10721f8ed2cc8553ef96d7b95a5b51217b8f4c6339533b504941'
for arm,base,fs in [('candidate',basefiles,files(p/'candidate-host')),('historical',historical,files(p/'historical-host'))]:
 patch=''
 for name in sorted(set(fs)|set(base)):
  if fs.get(name)==base.get(name):continue
  patch+=''.join(difflib.unified_diff(base.get(name,b'').decode().splitlines(True),fs.get(name,b'').decode().splitlines(True),fromfile='a/'+name if name in base else '/dev/null',tofile='b/'+name if name in fs else '/dev/null'))
 path=common/(arm+'.patch');path.write_text(patch);records[arm]={'sourceSha256':digest(fs),'baseSourceSha256':digest(base),'changedFiles':[f for f in sorted(set(fs)|set(base))if fs.get(f)!=base.get(f)],'patch':path.name,'patchSha256':sha(path.read_bytes())}
 assert records[arm]['changedFiles']==['src/physics/catch-opportunity.ts','src/sim/catching.ts','src/sim/playsim.ts']
 with tempfile.TemporaryDirectory(prefix='catch-caller-restore-',dir='/tmp')as folder:
  dest=pathlib.Path(folder)
  for name,b in base.items():(dest/name).parent.mkdir(parents=True,exist_ok=True);(dest/name).write_bytes(b)
  env=dict(os.environ);env['GIT_CEILING_DIRECTORIES']='/tmp';subprocess.run(['git','apply','--check',str(path)],cwd=dest,env=env,check=True);subprocess.run(['git','apply',str(path)],cwd=dest,env=env,check=True);assert digest(files(dest))==records[arm]['sourceSha256']
assert digest(files(root))==records['candidate']['sourceSha256']
for f in p.iterdir():
 if f.is_file()and f.suffix in ['.json','.gz','.py','.mjs','.ts','.log','.patch']and f.name!='physics-evidence.tar.gz':shutil.copy2(f,common/f.name)
(common/'candidate-code-tests.patch').write_bytes(subprocess.check_output(['git','diff','--binary','f4146275ce7539816bf57b4ed55a0d2be10e48c7',code,'--','src','test'],cwd=root))
for f in ['config/baseline.json','scripts/baseline.mjs','scripts/source-version.ts','.nvmrc','package-lock.json']:shutil.copy2(root/f,common/pathlib.Path(f).name)
archives=[]
for group,folders in [('native',['baseline','candidate','historical']),('common',None)]:
 members=[(f,str(f.relative_to(p)))for d in folders for f in sorted((p/d).iterdir())if f.is_file()]if folders else[(f,str(f.relative_to(common)))for f in sorted(common.iterdir())if f.is_file()]
 entries=[{'path':name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f,name in members]
 path=bundle/(group+'.tar.gz')
 with tarfile.open(path,'w:gz',compresslevel=1)as ar:
  for f,name in members:assert not f.is_symlink()and not name.startswith('/')and '..'not in pathlib.PurePosixPath(name).parts;ar.add(f,arcname=name,recursive=False)
 assert path.stat().st_size<32*1024**2
 with tarfile.open(path)as ar:
  assert len(ar.getmembers())==len(entries)
  for item,entry in zip(ar.getmembers(),entries):assert item.isfile()and item.name==entry['path']and sha(ar.extractfile(item).read())==entry['sha256']
 archives.append({'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'members':entries})
manifest={'schema':'catch-caller-evidence-v1','acceptedDevelop':'f4146275ce7539816bf57b4ed55a0d2be10e48c7','queue':subprocess.check_output(['git','rev-parse','origin/codex/integration-queue'],cwd=root,text=True).strip(),'originalPR131':'2f9085f1e3dc8e5a19c07fc8f561dc1689413a5e','codeCommit':code,'baselineSourceSha256':digest(basefiles),'sources':records,'archives':archives,'originalInputs':{'commit':'b5b4fba9eefa5e59e8db192e77a6502341d81989','archive':'evidence.tar.gz','sha256':'7fc78954d2240c86c5bc9092c6a9d1345d9a3acbe3af061cbd33d006bb93f97b','qualification':'Verify41 declared input/evidence members plus bundled manifest. Native scout Maps restored from original prior calls using the pinned reconstruct.ts. Observation/call hashes do not replace this complete restoration receipt.'},'costs':{'newNativeSnaps':9,'newGames':0,'fullSuiteRuns':0,'groups':[{k:r[k]for k in ['source','elapsedSeconds']}|{'arm':arm,'snaps':len(r['cases'])}for arm in ['baseline','candidate','historical']for r in [json.loads((p/arm/'receipt.json').read_text())]]},'restoration':'Both source patches independently applied outside parent checkout and full src digest matched. Every archive member verified. No new World ticks in packaging. Historical baseline is reused from original native-parity capture; current baseline is actual accepted f414 source. Archived hosts inherit outer HEAD; canonical source + patches identify runtime.'}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(bundle/'SHA256SUMS').write_text(''.join(a['sha256']+'  '+a['path']+'\n'for a in archives));print(json.dumps({a['path']:a['bytes']for a in archives}),flush=True)
