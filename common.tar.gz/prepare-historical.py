import pathlib,subprocess,tarfile,io,shutil,tempfile,os
root=pathlib.Path.cwd();p=root/'out/catch-opportunity-caller';host=p/'historical-host';base='70b4db6a3ef53acc1a0e90cd055f1087205daa30'
patch=subprocess.check_output(['git','diff','f4146275ce7539816bf57b4ed55a0d2be10e48c7','--','src/sim/catching.ts','src/sim/playsim.ts']);(p/'caller-from-accepted.patch').write_bytes(patch)
with tempfile.TemporaryDirectory(prefix='catch-historical-',dir='/tmp')as folder:
 dest=pathlib.Path(folder);raw=subprocess.check_output(['git','archive',base,'src','config','scripts','package.json','package-lock.json','.nvmrc'])
 with tarfile.open(fileobj=io.BytesIO(raw))as ar:ar.extractall(dest,filter='data')
 env=dict(os.environ);env['GIT_CEILING_DIRECTORIES']='/tmp';subprocess.run(['git','apply','--check',str(p/'caller-from-accepted.patch')],cwd=dest,env=env,check=True);subprocess.run(['git','apply',str(p/'caller-from-accepted.patch')],cwd=dest,env=env,check=True)
 shutil.copy2(root/'src/physics/catch-opportunity.ts',dest/'src/physics/catch-opportunity.ts');shutil.copytree(dest,host)
(host/'node_modules').symlink_to(root/'node_modules',target_is_directory=True);data=host/'out/catch-opportunity-physics';data.mkdir(parents=True);shutil.copy2(root/'out/catch-opportunity-physics/reconstruct.ts',data/'reconstruct.ts')
for d in ['packet','audit','selected']:(data/d).symlink_to(root/'out/catch-opportunity-physics'/d,target_is_directory=True)
tool=host/'out/catch-opportunity-caller';(tool/'geometry').mkdir(parents=True);(tool/'core').mkdir();shutil.copy2(p/'capture.ts',tool/'capture.ts');shutil.copy2(root/'src/physics/catch-opportunity.ts',tool/'geometry/catch-opportunity.ts');shutil.copy2(root/'src/core/vec.ts',tool/'core/vec.ts')
print('Historical counterfactual is70b4 plus unchanged helper and the same two caller hunks only; no ticks yet.')
