import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH'];start=time.monotonic()
for arm in ['baseline','candidate']:
 host=p/(arm+'-host');cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/(arm+'-launch.json'),host),'--','node','--import','tsx','out/catch-opportunity-caller/capture.ts','run',str(p/arm)]
 with (p/(arm+'.log')).open('w')as log:subprocess.run(cmd,cwd=host,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(arm,'done',flush=True)
print('launchSeconds',time.monotonic()-start,flush=True)
