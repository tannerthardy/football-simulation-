import pathlib,gzip,json,os,math
os.environ['MPLCONFIGDIR']='/tmp/football-matplotlib'
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
p=pathlib.Path(__file__).resolve().parent
rows=[]
for path in p.glob('current-*/trace.json.gz'):rows+=json.loads(gzip.decompress(path.read_bytes()))['rows']
inputs={r['id']:r for r in json.loads(gzip.decompress((p/'inputs.json.gz').read_bytes()))['rows']}
for id in ['Z06','Z13','Z14','Z16','Z19','Z26']:
 r=next(r for r in rows if r['id']==id);meta=inputs[id];los=meta['setup']['los'];by=meta['setup']['ballY'];fig,axes=plt.subplots(2,3,figsize=(15,10),sharex=True,sharey=True)
 for ax,t in zip(axes.flat,[.4,.8,1.2,1.6,2,2.4]):
  f=min(r['frames'],key=lambda f:abs(f['t']-t));ax.set_title(f'{f["t"]:.2f}s');ax.axvline(los,color='gray',linestyle='--',linewidth=.6)
  for i,b in enumerate(f['before']):
   q=b['pos'];color='royalblue'if i<11 else'crimson'
   if abs(q['y']-by)>9:continue
   ax.add_patch(Circle((q['x'],q['y']),b['profile']['radius'],facecolor=color,alpha=.35,edgecolor=color))
   label=r['initial'][i]['slot'];plan=f['plans'][i]
   if plan and plan.get('target')is not None:label+='→'+r['initial'][plan['target']]['slot']
   ax.annotate(label,(q['x'],q['y']),xytext=(2,5),textcoords='offset points',fontsize=6)
   for command,co in [(f['raw'][i],'gray'),(f['final'][i],'orange'),({'vel':b['vel']},color)]:
    v=command['vel'];ax.arrow(q['x'],q['y'],v['x']*.16,v['y']*.16,color=co,width=.012,head_width=.1,length_includes_head=True,alpha=.6)
   if b['support']['state']!='up':ax.annotate(b['support']['state'],(q['x'],q['y']),xytext=(2,-8),textcoords='offset points',fontsize=6)
  for e in f['afterReps']:
   a=f['before'][e['b']]['pos'];b=f['before'][e['d']]['pos'];ax.plot([a['x'],b['x']],[a['y'],b['y']],color='black',alpha=.3,linewidth=.5)
  ax.set_xlim(los-7.5,los+7);ax.set_ylim(by-9,by+9);ax.set_aspect('equal');ax.grid(alpha=.2)
 fig.suptitle(id+' '+meta['call']+' '+meta['front']+' | current f4146275 | gray=request, orange=final, team-color=achieved velocity; core crop');fig.tight_layout();fig.savefig(p/(id+'.png'),dpi=130);plt.close(fig)
