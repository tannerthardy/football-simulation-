import pathlib,gzip,json,math,os
os.environ['MPLCONFIGDIR']='/tmp/stalk-film-mpl'
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
p=pathlib.Path(__file__).parent;cases=['Z03','Z12','Z16','Z27','Z08','Z26'];arms={}
for arm in ['picture','perimeter']:
 arms[arm]={r['id']:r for f in p.glob(arm+'-*/trace.json.gz')for r in json.load(gzip.open(f))['rows']}
out=p/'film';out.mkdir(exist_ok=True)
for id in cases:
 old=arms['picture'][id];focal=old['firstContact']['b'];stalker=next((a['idx']for a in old['initial']if a['plan']and a['plan']['kind']=='stalk'and a['plan']['target']==focal),10)
 focal=old['initial'][stalker]['plan']['target'];initial=old['initial'];ys=[initial[i]['body']['pos']['y']for i in [stalker,focal,6]];lo=max(0,min(ys)-7);hi=min(53.3333,max(ys)+7)
 times=[1,1.75,2.25,3]
 fig,axes=plt.subplots(2,4,figsize=(18,10),sharex=True,sharey=True)
 for row,arm in enumerate(['picture','perimeter']):
  r=arms[arm][id]
  for col,t in enumerate(times):
   ax=axes[row,col];f=min(r['frames'],key=lambda f:abs(f['t']-t));bodies=f['before']
   ax.set_facecolor('#edf5e9');ax.axvline(40,color='#436caa',lw=1.2)
   for x in range(30,56,5):ax.axvline(x,color='white',lw=.8)
   for i,b in enumerate(bodies):
    x,y=b['pos'].values();color='#1f67a7'if i<11 else'#c55231';ax.add_patch(Circle((x,y),b['profile']['radius'],facecolor=color,alpha=.85,edgecolor='white'))
    ax.text(x,y+.52,initial[i]['slot'],fontsize=6.8,ha='center',va='bottom',color=color,clip_on=True)
    vx,vy=b['vel'].values();ax.arrow(x,y,vx*.18,vy*.18,width=.025,color=color,head_width=.2,length_includes_head=True)
   for e in f['beforeReps']:
    B,D=bodies[e['b']]['pos'],bodies[e['d']]['pos'];ax.plot([B['x'],D['x']],[B['y'],D['y']],color='#c89700',lw=3,alpha=.8)
   for i in [stalker,focal]:
    x,y=bodies[i]['pos'].values();ax.add_patch(Circle((x,y),.7,fill=False,edgecolor='#7a2596',lw=1.4))
   rb=bodies[6]['pos'];ax.add_patch(Circle((rb['x'],rb['y']),.65,fill=False,edgecolor='black',lw=1.3))
   c=next(c for c in r['calls']if c['t']==f['t']and c['a']==stalker)
   cues=[q for q in r['cues'][c['cueStart']:c['cueEnd']]if q['a']==stalker and q['b']==focal]
   if cues:
    q=cues[-1]['picture']['pos'];ax.scatter([q['x']],[q['y']],marker='+',s=50,c='#248337',zorder=8)
   B,D=bodies[stalker]['pos'],bodies[focal]['pos'];ax.plot([B['x'],D['x']],[B['y'],D['y']],':',color='#7a2596',lw=.9)
   ax.set_xlim(32,52);ax.set_ylim(lo,hi);ax.set_aspect('equal');ax.set_title(f'{arm}: t={f["t"]:.2f}s',fontsize=11)
   ax.set_xlabel('field x (offense →)');ax.grid(False)
 axes[0,0].set_ylabel('field y');axes[1,0].set_ylabel('field y')
 fig.suptitle(f'{id}: actual {initial[stalker]["slot"]} → {initial[focal]["slot"]}, picture-only vs moving near surface',fontsize=15)
 fig.text(.5,.02,'Actual native tick-entry bodies/velocity; gold = recorded hands; green + = consumed defender picture. Cropped field, all22 simulated. Body facing is not gaze. Dashed center line is a job, not obstruction proof.',ha='center',fontsize=8)
 fig.tight_layout(rect=[0,.05,1,.95]);fig.savefig(out/(id+'.png'),dpi=140);plt.close(fig);print('wrote',id,flush=True)
