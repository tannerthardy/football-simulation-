import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1];env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH'];start=time.monotonic()
for output,ids,inputs in [('candidate-0','Z06,Z13,Z14,Z19,Z26,C01','inputs.json.gz'),('candidate-1','C02','inputs.json.gz'),('candidate-transfer-0','Z16,Z18,Z20,Z27,T01,T02','transfer-inputs.json.gz'),('candidate-transfer-1','T03,T04','transfer-inputs.json.gz')]:
 host=root
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/f'{output}-launch.json',host),'--','node','--import','tsx','scripts/diag/climb-approach.mjs','run',str(p/output),ids,'5',str(p/inputs),'native']
 with open(p/f'{output}.log','w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(output,'completed',flush=True)

print('launcherSeconds',time.monotonic()-start,flush=True)
