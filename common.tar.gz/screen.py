import pathlib,gzip,json,math,collections
p=pathlib.Path(__file__).resolve().parent;oldp=p.parent/'climb-objective-access';original=[]
for f in oldp.glob('baseline-[01]/trace.json.gz'):original+=json.loads(gzip.decompress(f.read_bytes()))['rows']
for f in(p.parent/'zone-track-recovery').glob('baseline-*/trace.json.gz'):original+=json.loads(gzip.decompress(f.read_bytes()))['rows']
original={r['id']:r for r in original};rows=[]
foci={'Z06':'RG','Z13':'LG','Z14':'Y','Z16':'Y','Z19':'RG','Z26':'RT','C01':'RT','C02':'RG'}
for file in sorted(p.glob('current-*/trace.json.gz')):
 d=json.loads(gzip.decompress(file.read_bytes()));print('SOURCE',d['receipt']['source'],'FLAGS',d['receipt']['flags']['RUN_CONTACT_COMPONENTS'],d['receipt']['flags']['CF_FLOW'])
 for r in d['rows']:
  b=original[r['id']];print('\n',r['id'],'old→current',b['gain'],r['gain'],'phase',r['phase'],'first',r['firstContact'])
  a=next(a for a in r['initial']if a['slot']==foci[r['id']]);idx=a['idx'];target=a['plan']['target']if a['plan']['kind']=='climb'else a['plan']['combination']['backer'];loads=[(f['t'],e)for f in r['frames']for e in f['afterReps']if e['b']==idx and e['d']==target and e['hands']and math.hypot(e['hands']['normal'],e['hands']['tangent'])>1]
  leaves=[s['t']for s in r['stages']if s['a']==idx and s['method']=='leaveCombination'];impulses=[(f['t'],x)for f in r['frames']for x in f['report']['contacts']if idx in[x['i'],x['j']]and(x['j']if x['i']==idx else x['i'])>=11 and(x['j']if x['i']==idx else x['i'])!=target and x['impulse']>1e-6]
  item={'id':r['id'],'gain':r['gain'],'phase':r['phase'],'firstContact':r['firstContact'],'blocker':a['slot'],'target':r['initial'][target]['slot'],'firstLoad':loads[0][0]if loads else None,'lastLoad':loads[-1][0]if loads else None,'departureFirst':min(leaves)if leaves else None,'departureLast':max(leaves)if leaves else None,'incidentalSteps':len(impulses),'incidentalImpulse':sum(x['impulse']for t,x in impulses)};rows.append(item);print(item)
  for t in [.6,1,1.5,2,2.5]:
   f=min(r['frames'],key=lambda f:abs(f['t']-t));print(' ',round(f['t'],2),'rep',[(r['initial'][e['b']]['slot'],r['initial'][e['d']]['slot'],round(e['phi'],2))for e in f['afterReps']],'OLx',[(r['initial'][i]['slot'],round(f['before'][i]['pos']['x'],2))for i in range(1,6)])
(p/'screen.json').write_text(json.dumps(rows,indent=2)+'\n')
