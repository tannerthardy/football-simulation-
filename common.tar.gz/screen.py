import gzip,json,pathlib,math,collections
p=pathlib.Path(__file__).parent;inputs={r['id']:r for r in json.load(gzip.open(p/'inputs.json.gz'))['rows']};out=[];seconds=0
for file in sorted(p.glob('baseline-*/trace.json.gz')):
 tape=json.load(gzip.open(file));seconds+=tape['receipt']['elapsedSeconds']
 for r in tape['rows']:
  meta=inputs[r['id']];ps=next((1 if a['plan']['drive']['y']>0 else -1 for a in r['initial'] if a['plan'] and a['slot'] in ['LT','RT','C','LG','RG'] and abs(a['plan']['drive']['y'])>1e-8),1);frames={f['t']:f for f in r['frames']};groups=collections.defaultdict(list)
  for c in r['calls']:
   idx=c['a'];plan=c['after'];cmd=c['command'];t=c['t']
   if not plan or idx not in [1,2,3,4,5]or plan['target']is None or cmd.get('cutSkill')is None or t<.35:continue
   f=frames[t];a=f['before'][idx];target=plan['target'];d=f['before'][target]
   if any(e['b']==idx or idx in e['helpers']for e in f['beforeReps']):continue
   cues=[q for q in r['cues'][c['cueStart']:c['cueEnd']]if q['a']==idx and q['b']==target]
   if not cues:continue
   seen=cues[-1]['picture'];dy=(a['pos']['y']-seen['pos']['y'])*ps;dist=math.dist(a['pos'].values(),seen['pos'].values())
   dx=seen['pos']['x']-a['pos']['x'];ny=seen['pos']['y']-a['pos']['y'];dot=dx*cmd['vel']['x']+ny*cmd['vel']['y']
   if dy>.8 and dist<6 and cmd['vel']['y']*ps>0:
    groups[(idx,target)].append({'t':t,'separation':dist,'lateralPassed':dy,'requestDotToTarget':dot,'seen':seen,'body':a,'request':cmd,'final':f['final'][idx],'targetBody':d,'plan':plan})
  screens=[]
  for (idx,target),samples in groups.items():
   screens.append({'blocker':r['initial'][idx]['slot'],'target':r['initial'][target]['slot'],'targetIdx':target,'duration':len(samples)*.05,'first':samples[0],'last':samples[-1],'targetFirstRunnerContact':bool(r['firstContact']and r['firstContact']['b']==target),'beforeFirstContact':sum(s['t']<r['firstContact']['t']for s in samples)*.05 if r['firstContact']else None})
  out.append({'id':r['id'],'meta':{k:meta[k]for k in ['call','form','front','flip']},'phase':r['phase'],'end':r['endTime'],'gain':r['gain'],'firstContact':r['firstContact'],'screens':screens,'loadedPairs':sorted(set((e['b'],e['d'])for f in r['frames']for e in f['afterReps']))})
  print(r['id'],meta['call'],meta['form'],meta['front'],'end',r['phase'],r['gain'],'first',r['initial'][r['firstContact']['b']]['slot']if r['firstContact']else None,[(s['blocker'],s['target'],round(s['duration'],2),'FIRST'if s['targetFirstRunnerContact']else'')for s in screens])
(p/'screen.json').write_text(json.dumps({'qualification':'Screening only: lateral passage or travel away is not itself bad football; future first-contact identity is analyst-only.', 'collectorSeconds':seconds,'rows':out},indent=2)+'\n');print('collectorSeconds',seconds)
