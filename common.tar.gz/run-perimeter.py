import pathlib,subprocess,time
p=pathlib.Path(__file__).resolve().parent;start=time.monotonic()
for name,ids,inputs in [('selected-0','Z03,Z12,Z16,Z27,Z08,Z26','inputs.json.gz'),('selected-1','Z28','inputs.json.gz'),('transfer','F01,F02,F03,F04','transfer-inputs.json.gz')]:
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',f'../perimeter-{name}-launch.json','--','node','--import','tsx','scripts/diag/zone-approach.mjs','run',str(p/f'perimeter-{name}'),ids,'5',str(p/inputs),'native']
 with open(p/f'perimeter-{name}.log','w')as f:subprocess.run(cmd,cwd=p/'perimeter-host',stdout=f,stderr=subprocess.STDOUT,check=True)
 print('completed perimeter',name,flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
