import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;host=p/'final-host';env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH'];start=time.monotonic()
for name,ids in [('final-failures','Z06,Z13,Z14,Z16,Z19,Z26'),('final-controls','C01,C02'),('final-fresh','R01,R02,GHC')]:
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/f'{name}-launch.json',host),'--','node','--import','tsx','scripts/diag/climb-approach.mjs','run',str(p/name),ids,'5',str(p/('fresh-inputs.json.gz' if name=='final-fresh' else 'inputs.json.gz')),'native']
 with open(p/f'{name}.log','w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(name,'completed',flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
