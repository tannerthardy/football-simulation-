import {readFileSync,writeFileSync} from 'node:fs';import {gzipSync,gunzipSync} from 'node:zlib';import {createHash} from 'node:crypto';
import {Rng} from '../../src/core/rng.ts';import {generateTeam,pickOffense,pickDefense} from '../../src/league/team.ts';
import {RUN_BY_ID} from '../../src/playbook/concepts.ts';import {FRONT_BY_ID,COVERAGE_BY_ID} from '../../src/playbook/defense.ts';import {FORMATION_BY_ID} from '../../src/playbook/formations.ts';import {CENTER_Y} from '../../src/core/field.ts';
const saved=JSON.parse(gunzipSync(readFileSync(new URL('../zone-track-recovery/inputs.json.gz',import.meta.url))));const rows=saved.rows.filter(r=>['Z16','Z18','Z20','Z27'].includes(r.id));
for(const [os,ds,call,front]of [[1151,1152,'iz_weak','over'],[1251,1252,'oz_weak','under']])for(const flip of [false,true]){
 const offense=generateTeam(new Rng(os),'T-O','Transfer O',{strength:.55}),defense=generateTeam(new Rng(ds),'T-D','Transfer D',{strength:.55});
 const formation=FORMATION_BY_ID.ace_12,df=FRONT_BY_ID[front],id='T'+String(rows.length-3).padStart(2,'0');
 const setup={offense:pickOffense(offense,formation.personnel),defense:pickDefense(defense,df.personnel[0]),offCall:{formation,flip,kind:'run',run:RUN_BY_ID[call],label:call},defCall:{personnel:df.personnel[0],front:df,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:front},los:40,ballY:CENTER_Y,firstDownX:50,seed:10100+rows.length,record:false};
 rows.push({id,call,form:'ace_12',front,flip,rosterSeeds:[os,ds],setup,inputSha256:createHash('sha256').update(JSON.stringify(setup)).digest('hex')});
}
writeFileSync(new URL('transfer-inputs.json.gz',import.meta.url),gzipSync(JSON.stringify({schema:'climb-local-access-transfer-v1',qualification:'Four saved opposing traffic/glancing/late joins with compatible accepted-source native baselines; four new inputs chosen before outcomes, two new roster pairs and both formation flips across inside/outside zone, Over/Under. No games or frequency inference.',rows})));
console.log(rows.map(r=>({id:r.id,call:r.call,front:r.front,flip:r.flip,sha256:r.inputSha256})));
