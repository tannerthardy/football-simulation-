import pathlib,subprocess,time
p=pathlib.Path(__file__).resolve().parent;start=time.monotonic()
for arm in ['picture','surface']:
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',f'../transfer-{arm}-launch.json','--','node','--import','tsx','scripts/diag/zone-approach.mjs','run',str(p/f'transfer-{arm}'),'F01,F02,F03,F04','5',str(p/'transfer-inputs.json.gz'),'native']
 with open(p/f'transfer-{arm}.log','w')as f:subprocess.run(cmd,cwd=p/(arm+'-host'),stdout=f,stderr=subprocess.STDOUT,check=True)
 print('completed transfer',arm,flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
