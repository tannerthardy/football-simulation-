import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1];env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH'];start=time.monotonic()
for arm,host,batches in [('baseline-transfer',p.parent/'zone-track-recovery/baseline-host',['T01,T02,T03,T04']),('traffic-transfer',p/'traffic-host',['Z16,Z18,Z20,Z27,T01,T02','T03,T04'])]:
 for i,ids in enumerate(batches):
  output=f'{arm}-{i}'
  cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/f'{output}-launch.json',host),'--','node','--import','tsx','scripts/diag/climb-approach.mjs','run',str(p/output),ids,'5',str(p/'transfer-inputs.json.gz'),'native']
  with open(p/f'{output}.log','w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  print(output,'completed',flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
