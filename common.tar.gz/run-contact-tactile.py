import pathlib,subprocess,os,time
p=pathlib.Path(__file__).resolve().parent;host=p/'contact-tactile-host';env=dict(os.environ);env['PATH']='/workspace/.football-tools/node-v22.23.3-linux-x64/bin:'+env['PATH'];start=time.monotonic()
for name,ids in [('contact-tactile-probe','Z13,Z16,C01')]:
 cmd=['node','scripts/baseline.mjs','--candidate','--receipt',os.path.relpath(p/f'{name}-launch.json',host),'--','node','--import','tsx','scripts/diag/climb-approach.mjs','run',str(p/name),ids,'5',str(p/'inputs.json.gz'),'native']
 with open(p/f'{name}.log','w')as f:subprocess.run(cmd,cwd=host,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(name,'completed',flush=True)
print('launcherSeconds',time.monotonic()-start,flush=True)
