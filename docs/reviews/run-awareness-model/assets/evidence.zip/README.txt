Native packets and exact launcher receipts for the default-off run awareness pilot.
PR #36 reference outcomes are reused from ../teammate-information/assets/evidence.zip packets/candidate-outcomes.json.gz.
Original failed test-fixture variants/terminal stdout are not archived; see failure ledger in the review.
No games or full integration suite were run. See ../../run-awareness-model.md and data/reviews/current/run-awareness-model.json.
