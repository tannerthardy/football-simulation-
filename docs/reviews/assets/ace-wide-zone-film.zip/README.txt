Ace wide-zone film viewer

Extract the ZIP, then open index.html in a browser. It contains all data and
JavaScript and works offline; no server or repository checkout is required.

This is the previously provided viewer, with corrected tick-average force
labels. It contains six saved historical baseline / isolated-contact Ace
histories, not the later current-develop replay in PR #26. Source pins and
settings are embedded in the viewer. No new simulations were run to package it.

Viewer source: codex/ol-technique-audit at 4d7716a72c559d3b1717a66e843d06f5d0d754d6
index.html SHA256: b55e9fa6b0634faa68d44ecf58823404ac76dc7472d45291c5ac718324f83b40

The package was checked for integrity and includes identical viewer bytes.
The browser rendering remains unverified in this cloud checkout.
