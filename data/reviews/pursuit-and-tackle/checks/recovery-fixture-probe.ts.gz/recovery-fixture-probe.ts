import { writeFileSync } from 'node:fs';
import { CENTER_Y } from '../../src/core/field.js';
import { Rng } from '../../src/core/rng.js';
import { generateTeam, pickDefense, pickOffense } from '../../src/league/team.js';
import { RUN_BY_ID } from '../../src/playbook/concepts.js';
import { COVERAGE_BY_ID, FRONT_BY_ID } from '../../src/playbook/defense.js';
import { FORMATION_BY_ID } from '../../src/playbook/formations.js';
import { BallCarrier, observedRecoveryAllowance } from '../../src/sim/behaviors/carrier.js';
import { PlaySim } from '../../src/sim/playsim.js';
import { sourceVersion } from '../../scripts/source-version.js';
const before=sourceVersion();
const offense=generateTeam(new Rng(31),'Panel offense 1','O1',{strength:.55});
const defense=generateTeam(new Rng(32),'Panel defense 1','D1',{strength:.55});
function make(split:boolean){const formation=split?FORMATION_BY_ID.gun_wing_12:FORMATION_BY_ID.ace_11;
return new PlaySim({offense:pickOffense(offense,formation.personnel),defense:pickDefense(defense,'base43'),offCall:{formation,kind:'run',flip:split,run:split?RUN_BY_ID.split_zone:RUN_BY_ID.iz_strong,label:'recovery cue witness'},defCall:{personnel:'base43',front:split?FRONT_BY_ID.over:FRONT_BY_ID.under,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:split?'Over Cover 3':'Under Cover 3'},los:40,ballY:CENTER_Y,firstDownX:50,seed:split?11:3,record:false});}
function execute(split:boolean,observe:boolean){const sim=make(split),inspected=new WeakSet<BallCarrier>(),decisions:any[]=[],pictures:any[]=[];let evaluating=false;
if(observe){const originalSee=sim.see,originalTick=sim.tick;
sim.see=function(observer,target,...rest){const picture=originalSee.call(this,observer,target,...rest);if(evaluating&&observer.slot==='RB'&&target.team!==observer.team&&(picture.pose==='down'||picture.pose==='rising'))pictures.push({t:sim.t,target:target.idx,slot:target.slot,picture,allowance:observedRecoveryAllowance(picture,target.profile.getUp,sim.dt)});return picture;};
sim.tick=function(){const rb=sim.slot('RB')!,behavior=rb.behavior;if(behavior instanceof BallCarrier&&!inspected.has(behavior)){inspected.add(behavior);const controller=behavior as any,evaluate=controller.evaluate;controller.evaluate=function(a:any,s:any,dir:any,designed:any){evaluating=true;try{const decision=evaluate.call(this,a,s,dir,designed);decisions.push({t:sim.t,...decision});return decision;}finally{evaluating=false;}};}return originalTick.call(this);};}
const result=sim.run();return{result,decisions,pictures,final:JSON.stringify({result,bodies:sim.agents.map(a=>a.body),intents:sim.intents,minds:sim.agents.map(a=>a.mind),rng:sim.rng})};}
const rows=[false,true].map(split=>{const observed=execute(split,true),plain=execute(split,false);return{id:split?'CT-R1-split_zone-over-L-S11':'CT-R1-iz_strong-under-R-S3',outcome:observed.result.outcome,gain:observed.result.yards,end:observed.result.duration,decisions:observed.decisions,offFeetPictures:observed.pictures,observerNeutral:observed.final===plain.final};});
const after=sourceVersion();const receipt={sourceBefore:before,sourceAfter:after,scope:'Existing test and retained native fixed-panel witness; original see/evaluate calls only, no additional looks or forced falls.',rows};
writeFileSync('out/tackle-approach-current/recovery-fixture-receipt.json',JSON.stringify(receipt,null,2));
console.log(JSON.stringify({sourceBefore:before,sourceAfter:after,rows:rows.map(x=>({id:x.id,outcome:x.outcome,gain:x.gain,decisionCount:x.decisions.length,offFeetPictures:x.offFeetPictures.length,firstPicture:x.offFeetPictures[0],observerNeutral:x.observerNeutral}))}));
