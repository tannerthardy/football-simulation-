from pathlib import Path
from io import BytesIO
import subprocess,tempfile,hashlib,json,tarfile,gzip,os,sys,re
BASE='f4146275ce7539816bf57b4ed55a0d2be10e48c7'
QUEUE='9a6bb795179a4b2e61ed59d25bcf23ca5e40f423'
SOURCE='7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197'
REPO=Path('/workspace/football-decision-commitment')
WR=Path('/workspace/football-receiver-route-effort')
OUT=REPO/'out/commitment-publication';OUT.mkdir(exist_ok=True)
STAGE=Path('/workspace/football-free-fit-objective-continuity/out/commitment-evidence/stage');STAGE.mkdir(exist_ok=True)
FINAL=len(sys.argv)>1 and sys.argv[1]=='--final'
CONFIG=json.loads(Path(sys.argv[2]).read_text()) if len(sys.argv)>2 else {}
def git(*args,cwd=REPO):return subprocess.check_output(['git',*args],cwd=cwd)
def sha(b):return hashlib.sha256(b).hexdigest()
def emit(name,data):
 p=STAGE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p
def digest(root):
 h=hashlib.sha256()
 for p in sorted(str(p.relative_to(root)) for p in (root/'src').rglob('*') if p.is_file()):h.update(p.encode()+b'\0'+(root/p).read_bytes()+b'\0')
 return h.hexdigest()
sources=[]
source_specs=[('accepted',BASE,SOURCE),('own-objective','aa88c66f115084a82a13a4a85f2e536c53ea7829','ca49106dc6dabb648eb1615774d8ce63d19f275d064fe5e349724ee13e0b2300'),('receiver-route-effort','279d26ececa443504aec7ad760aad9b9ece9ee85','62e740cda23aef7f178754ccd045017deee9b8e77b90aaeb5b0d45aff820237c')]
source_specs += [(r['name'],r['code'],r['runtime']) for r in CONFIG.get('diagnostics',[])]
for name,pin,expected in source_specs:
 patch=git('diff','--binary',BASE,pin,'--','src');p=emit('sources/'+name+'.patch',patch)
 with tempfile.TemporaryDirectory(prefix='commitment-source-restore-',dir='/tmp') as tmp:
  root=Path(tmp)
  with tarfile.open(fileobj=BytesIO(git('archive',BASE,'src'))) as t:t.extractall(root,filter='data')
  if patch:subprocess.run(['git','apply','--unsafe-paths',str(p)],cwd=root,check=True,capture_output=True)
  got=digest(root);assert got==expected,(name,got,expected)
 sources.append(dict(name=name,code=pin,base=BASE,sourceSha256=expected,restoredSha256=got,patch='sources/'+name+'.patch',patchSha256=sha(patch)))

# Reuse immutable native catalogs. No download or extraction of another data
# archive and no NFL file read is needed. Hash the actual local simulator tape
# and require equality with the selected catalog member.
refs=[('e39866c0339163443065df1d456a064fe3a73d9c','data/reviews/movement-continuation-2026-10-19/manifest.json'),('55d672c90a68aa6d830fc0019d863b191bf39c80','data/reviews/defensive-snap-response/manifest.json'),('dc403bf5f70c7c508638bbfc2a449edd3d866237','manifest.json'),('d56a4509db0c26210b472d8ee1882064c0151ef9','data/reviews/run-flow/manifest.json')]
catalogs=[]
for pin,path in refs:
 raw=git('show',pin+':'+path);m=json.loads(raw);archives=m['archives']
 if isinstance(archives,dict):
  ars=[dict(path=str(Path(path).parent/a.get('file',key+'.tar.gz')),sha256=a['sha256'],members=a['members']) for key,a in archives.items()]
 else:ars=[dict(path=str(Path(path).parent/a['path']) if str(Path(path).parent)!='.' else a['path'],sha256=a['sha256'],members=a['members']) for a in archives]
 catalogs.append(dict(pin=pin,manifest=path,manifestSha256=sha(raw),archives=ars))
parents=[REPO/'out/decision-commitment/native/baseline-inputs.json',WR/'out/receiver-route-effort/baseline-inputs.json']
paths={}
for p in parents:
 for case,row in json.loads(p.read_text()).items():paths[row['path']]=dict(case=case,reason='Native comparison',expected=row['fileSha256'])
# Full saved-audit catalog and offense climb references are already selected
# outputs, not another round of scenario selection.
for rootfile,key in [(REPO/'out/decision-commitment/defense/evidence.json','catalog'),(REPO/'out/decision-commitment/offense/saved-evidence.json','tapes'),(REPO/'out/decision-commitment/modifiers/manifest.json','inputs')]:
 for row in json.loads(rootfile.read_text())[key]:
  path=row.get('path');expected=row.get('sha256') or row.get('fileSha256')
  if path and expected:paths.setdefault(path,dict(case=row.get('case') or Path(path).parent.name,reason='Saved audit',expected=expected))
# Fresh FTOSS selected before its new result; already in the modifier catalog.
reuse=[]
for name,row in sorted(paths.items()):
 p=Path(name);actual=sha(p.read_bytes());assert actual==row['expected'],(name,actual,row['expected'])
 matches=[]
 for cat in catalogs:
  for a in cat['archives']:
   for member in a['members']:
    if member['sha256']==actual:
     matches.append(dict(pin=cat['pin'],archive=a['path'],archiveSha256=a['sha256'],member=member['path'],memberBytes=member['bytes'],memberSha256=actual,manifest=cat['manifest'],manifestSha256=cat['manifestSha256']))
 assert matches,('Missing immutable retrieval map',name,actual)
 reuse.append(dict(originalPath=name,case=row['case'],reason=row['reason'],sha256=actual,bytes=p.stat().st_size,verified='Actual local tape hash equals immutable catalog member; no recollection',retrieval=matches[0]))
reusefile=emit('reuse-map.json',(json.dumps(reuse,indent=2)+'\n').encode())

archives={}
def add(group,name,path):
 path=Path(path);assert path.is_file() and not path.is_symlink(),path
 assert not any(z in path.parts for z in ['.git','node_modules','__pycache__'])
 assert not re.search(r'(^|/)(nfl[-_]|tracking_week|players\.csv|plays\.csv|player_play\.csv)',str(path),re.I),path
 assert name not in archives.setdefault(group,{})
 archives[group][name]=path
root=REPO/'out/decision-commitment'
for p in sorted(root.rglob('*')):
 if not p.is_file():continue
 name=str(p.relative_to(root));group='metadata-native' if name.startswith('native/') or name=='capture.mjs' else 'audits'
 add(group,name,p)
for p in sorted((WR/'out/receiver-route-effort').rglob('*')):
 if p.is_file():add('receiver',str(p.relative_to(WR/'out/receiver-route-effort')),p)
for item in sources:add('common',item['patch'],STAGE/item['patch'])
add('common','reuse-map.json',reusefile)
add('common','tooling/build.py',Path(__file__).resolve())
for label,repo,files in [('metadata',REPO,['test/run-through-objective.test.ts','test/fixtures/traffic-step.json.gz']),('receiver',WR,['test/receiver-route-effort.test.ts'])]:
 for rel in files:add('common','checked-sources/'+label+'/'+rel,repo/rel)
# Direct accepted flags/defaults/launcher/lock pin for all reproduced commands.
for rel in ['.nvmrc','config/baseline.json','scripts/baseline.mjs','scripts/source-version.ts','package.json','package-lock.json','vitest.config.ts']:
 add('common','accepted-settings/'+rel,emit('accepted-settings/'+rel,git('show',BASE+':'+rel)))
# Optional diagnostic owners retain separate source/status and archive identity.
for diagnostic in CONFIG.get('diagnostics',[]):
 diagnostic_root=Path(diagnostic['root'])
 for p in sorted(diagnostic_root.rglob('*')):
  if p.is_file():add('diagnostic-'+diagnostic['name'],str(p.relative_to(diagnostic_root)),p)
 diagnostic_repo=Path(diagnostic['repo'])
 for rel in diagnostic.get('files',[]):add('diagnostic-'+diagnostic['name'],'checked-sources/'+rel,diagnostic_repo/rel)
# Parent supplies final report filenames at checkpoint. Until then no freeze.
reports=[]
if FINAL:
 for idx,path in enumerate(CONFIG.get('reports',[])):
  p=Path(path);raw=p.read_bytes();snapshot=raw.replace(b'PUBLICATION_LINK',b'../README.md').replace(b'EVIDENCE_LINK',b'../README.md')
  target=emit('reports/'+p.name,snapshot);add('common','reports/'+p.name,target)
  reports.append(dict(originalPath=str(p),originalSha256=sha(raw),packetPath='common.tar.gz:reports/'+p.name,packetSha256=sha(snapshot),qualification='Only publication placeholder replaced by enclosing packet README; original working document untouched.'))

members={};native=[];receipts=[]
for group,paths in archives.items():
 es=[]
 for name,p in sorted(paths.items()):
  b=p.read_bytes();es.append(dict(path=name,bytes=len(b),sha256=sha(b),originalPath=str(p)))
  if name.endswith('.json.gz'):
   try:x=json.loads(gzip.decompress(b))
   except (json.JSONDecodeError,gzip.BadGzipFile):x=None
   if isinstance(x,dict) and 'ticks' in x and 'initial' in x:
    native.append(dict(archive=group,path=name,id=x['id'],source=x['source'],inputSha256=x['inputSha256'],phase=x['phase'],outcome=x['outcome'],gain=x['gain'],end=max((t['completed'] for t in x['ticks']),default=0),elapsedSeconds=x.get('elapsedSeconds')))
  if name.endswith('.json'):
   try:x=json.loads(b)
   except json.JSONDecodeError:continue
   if isinstance(x,dict) and isinstance(x.get('commands'),list):
    receipts.append(dict(archive=group,path=name,sha256=sha(b),source=x.get('sourceSha256'),commit=x.get('commit'),inputsUnchanged=x.get('inputsUnchanged'),elapsedSeconds=sum(c.get('elapsedSeconds',0) for c in x['commands']),exitCode=x.get('exitCode'),flags=x.get('flags'),worldDefaults=x.get('worldDefaults'),startedAt=x.get('startedAt')))
 members[group]=es
 out=OUT/(group+'.tar.gz')
 with out.open('wb') as f:
  with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0,compresslevel=6) as gz:
   with tarfile.open(fileobj=gz,mode='w') as t:
    for name,p in sorted(paths.items()):
     b=p.read_bytes();ti=tarfile.TarInfo(name);ti.mode=0o644;ti.mtime=0;ti.size=len(b);t.addfile(ti,BytesIO(b))
 with tarfile.open(out,'r:gz') as t:
  assert len(t.getmembers())==len(es)
  for e in es:
   b=t.extractfile(e['path']).read();assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
 print(group,len(es),out.stat().st_size,flush=True)
assert len(native)==CONFIG.get('expectedNative',6) and all(x['phase']=='dead' for x in native),native
unique={r['sha256']:r for r in receipts}
figure=root/'commitment-mechanisms.png'
(OUT/'commitment-mechanisms.png').write_bytes(figure.read_bytes())
manifest=dict(standalone=dict(file='commitment-mechanisms.png',sha256=sha(figure.read_bytes()),originalPath=str(figure)),decisions=dict(metadata='Own-objective interface approved; promotion HOLD',receiver='Independent information-contract approval with PA collision adverse retained; separate review',consumer='Raw-forward-progress proxy rejected on fresh useful redirect; HOLD',composition='Diagnostic only; HOLD, no integration readiness'),schema='football-commitment-evidence-v1',status='Final checkpoint' if FINAL else 'DRAFT waiting parent final checkpoint; do not publish',base=BASE,queue=QUEUE,baseSource=SOURCE,sources=sources,archives={g:dict(file=g+'.tar.gz',bytes=(OUT/(g+'.tar.gz')).stat().st_size,sha256=sha((OUT/(g+'.tar.gz')).read_bytes()),members=members[g]) for g in archives},native=native,reusedTapes=reuse,reports=reports,receipts=receipts,costs=dict(newNativePrefixes=len(native),newCompleted=sum(r['phase']=='dead' for r in native),newCensored=sum(r['phase']!='dead' for r in native),uniqueFrozenInputs=len(set(r['inputSha256'] for r in native)),nativeCaseWallSeconds=sum(r['elapsedSeconds'] or 0 for r in native),uniqueCommandReceipts=len(unique),recordedUniqueCommandWallSeconds=sum(r['elapsedSeconds'] for r in unique.values()),newFullGames=0,newFullSuites=0,newNFLQueries=0,newNFLReads=0,newNFLData=0,packagerSimulations=0,qualification='Original command receipts deduplicated by content SHA; original accepted test failures/typecheck fixtures/pure calls retained. Cached native tapes are hash-checked reuse, not new plays. Native case-wall and launcher/check wall are distinct, not summed twice.'),limits=['Two independent accepted-base candidates; no combined candidate or integration verification.','Metadata case endings can change through existing traffic maneuvers and shared execution draws; adverse/inconclusive evidence stays visible.','Receiver correction removes one private target-effort branch; global ball/flight information debt remains.','Architecture overload probe is17 actual ZoneCoverage calls on explicitly supplied pictures, not a native snap.','Additional material-progress source, if included, is a separate HOLD consumer diagnostic, not a third proposed production candidate.','Naive pull-bound clamp is a HOLD diagnostic only; it can move cutback duty and suppress a real declared runner. No run-fits source change ships.','Full old climb tapes are retrieved from dc403 immutable baseline archive; selected result JSON retains the audited identities/cues.'],security=dict(NFLTrajectoriesIncluded=False,NFLReceiptIncluded=False,allowlist='Only explicit local simulation/diagnostic roots and accepted Git source/settings; no secrets/caches/raw tracking.'))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'README.md').write_text('''# Football commitment evidence — 2026-10-19

This is data-only evidence on accepted f4146275 and canonical queue9a6bb795.
It does not combine or adopt either candidate and contains no NFL data/read.

Each source patch is restored from accepted develop and its entire src tree
hash-checked. Two independent contract candidates are: aa88c66 own-objective metadata (ca49106 runtime),
279d26e receiver route effort (62e740c runtime). Separately preserved consumer
(e0bb47f) and producer+consumer composition (3c8bde1) are diagnostics awaiting
Flex review, not integration-ready candidates. The own-objective candidate annotates an already
selected fixed sprint point for existing traffic footwork; raw steering and
spacing law are unchanged. The receiver candidate removes private throw-target-based jogging
and temporary waypoint progression while retaining installed route behavior.
Remaining flight/teammate information debt and movement consumer limits remain.

metadata-native.tar.gz contains four new native prefixes; receiver.tar.gz has
two more. The consumer diagnostic adds two and composition adds three, for eleven
completed prefixes across five unique frozen inputs. Different endings alone
are not causal proof. audits.tar.gz preserves saved defense/offense/modifier/architecture audits,
17 supplied-picture ZoneCoverage calls, opposing pull-bound clamp failure,
focused/typecheck failures and independent reviews. Composition's initial yield
and typecheck child passes were invalidated by concurrent parent commit; original
receipts and the valid frozen reruns are retained with receipt-invalidation.md. common.tar.gz includes
source patches, exact tests/fixture, accepted44-flag settings, reports and the
reuse map. The clamp is a pure diagnostic, not a third production candidate. The material
progress consumer's .05yd raw-forward proxy is rejected by a fresh useful
redirect; producer, consumer and composition remain HOLD for owner review.
Receiver information-contract approval retains the PA collision adverse.

Exact unchanged baselines and large historical climb tapes are already published.
Use common.tar.gz:reuse-map.json to fetch only each named immutable archive and
member, checking both SHA256 values. Actual local tape bytes were checked against
those immutable member catalogs. No fresh baseline collection is implied. Local
/workspace paths in scripts are original locations; map them to the corresponding
packet/reused member rather than downloading another dataset. Native t labels
step entry; completed body time is t+.05. Rounded film is not a checkpoint.

The standalone commitment-mechanisms.png is copied unchanged for direct linking.
Each archive member is read back and checked before publication. manifest.json
records producing revision/runtime/input/source hashes, all resolved flags,
original wall costs, completed/censored status and limitations. Candidates retain
their separate review decisions. Integration owns eventual combined verification.
''')
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS')
(OUT/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in files))
print('restored sources',len(sources),'new native',len(native),'reused exact tape maps',len(reuse),'costs',manifest['costs'],flush=True)
