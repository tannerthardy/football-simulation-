import gzip,hashlib,json,math,pathlib
ROOT=pathlib.Path('/workspace/football-run-movement-audit/out/run-current-build')
OUT=pathlib.Path('/workspace/football-decision-commitment/out/decision-commitment/offense')
def load(p):return json.load(gzip.open(p,'rt'))
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def speed(v):return math.hypot(v['x'],v['y'])
def relevant(row,a,tm):
 f=min(row['frames'],key=lambda f:abs(f['t']-tm));b=f['before'][a]
 call=next(c for c in row['calls'] if c['a']==a and c['t']==f['t'])
 return {'t':f['t'],'body':{k:b[k]for k in ['pos','vel','facing']},'raw':f['raw'][a],'final':f['final'][a],
  'departure':call['stateAfter']['departure'],'departureRead':call['stateAfter']['departureRead'],
  'climbRead':call['stateAfter']['climbRead'],'contacts':[c for c in f['report']['contacts']if a in(c['i'],c['j'])],
  'consumedPictures':row['cues'][call['cueStart']:call['cueEnd']]}
report={'schema':'offensive-commitment-saved-evidence-v1','accepted':'f4146275ce7539816bf57b4ed55a0d2be10e48c7','runtime':'7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197','newSimulations':0,'newTests':0,'tapes':[],'climbs':[]}
for fname in ['current-0/trace.json.gz','current-1/trace.json.gz']:
 p=ROOT/fname;x=load(p);report['tapes'].append({'path':str(p),'sha256':sha(p),'receipt':x['receipt']})
 for id,slot,times in [('Z13','LG',[1,1.2,1.6,2,2.4,2.65]),('Z19','RG',[1.1,1.35,1.6,1.85,2.1,2.6]),('C01','RT',[.85,1.1,1.35,1.85]),('C01','C',[1,1.4,1.8,2.2,2.25])]:
  row=next((r for r in x['rows']if r['id']==id),None)
  if not row:continue
  a=next(a['idx']for a in row['initial']if a['slot']==slot)
  report['climbs'].append({'id':id,'player':row['initial'][a]['playerId'],'actor':a,'slot':slot,'inputSha256':row['inputSha256'],'installed':next(p for p in row['installed']if p['slot']==slot),'events':[e for e in row['events']if e.get('a')==a and e['type'].startswith('block_')],'firstRunnerContact':row['firstContact'],'samples':[relevant(row,a,t)for t in times]})
p=pathlib.Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PASS13.json.gz');x=load(p)
report['tapes'].append({'path':str(p),'sha256':sha(p),'inputSha256':x['inputSha256'],'source':x['source']})
report['receiverFlight']={'events':[e for e in x['events']if e['type']in['throw','catch']],'samples':[]}
for t in x['ticks']:
 if t['t']not in[2.75,2.8,2.85,3,3.5,3.85]:continue
 report['receiverFlight']['samples'].append({'t':t['t'],'ball':t['ball'],'actors':[{'idx':i,'slot':x['initial'][i]['slot'],'player':x['initial'][i]['player']['id'],'raw':t['requests'][i],'achievedSpeed':speed(t['before'][i]['vel'])}for i in[7,8,9,10]]})
(OUT/'saved-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'sha256':sha(OUT/'saved-evidence.json'),'bytes':(OUT/'saved-evidence.json').stat().st_size,'newSimulations':0,'newTests':0}))
