import gzip,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent
load=lambda p:json.load(gzip.open(p))
c=load('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/COUNTER2.json.gz')
b=load('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/DUO.json.gz')
n=load('/workspace/football-traffic-progress-composition/out/traffic-progress-composition/native/DUO.json.gz')
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,2,figsize=(13,4.7));ax=axs[0]
i=next(a['idx'] for a in c['initial'] if a['slot']=='LB_W');ts=[t for t in c['ticks'] if .8<=t['t']<=2.35]
a=[a for a in c['aims'] if a['a']==i and a['job']=='run-fit' and .8<=a['t']<=2.35]
ax.plot([t['t'] for t in ts],[t['before'][i]['pos']['y'] for t in ts],color='#202e3a',lw=2.5,label='Achieved defender position')
ax.step([t['t'] for t in a],[t['desired']['y'] for t in a],where='post',color='#e1972a',lw=2,label='Newly requested fit')
ax.step([t['t'] for t in a],[t['selected']['y'] for t in a],where='post',color='#bf4758',lw=1.5,ls='--',label='Selected held fit')
ax.axvline(1.55,color='#888',lw=1,ls=':');ax.annotate('Pull crosses range cutoff\nRun belief remains unchanged',xy=(1.55,30.91),xytext=(1.1,33),arrowprops={'arrowstyle':'->','color':'#666'},fontsize=9)
ax.set(xlabel='Time from snap (s)',ylabel='Lateral field coordinate (yd)',title='Counter: responsibility read versus changing destination',ylim=(23,35));ax.legend(loc='lower left',fontsize=8,frameon=False)
ax=axs[1];i=next(a['idx'] for a in b['initial'] if a['slot']=='FS')
for r,style,label in [(b,'--','Accepted'),(n,'-','Waypoint + material-progress proposal')]:
 ts=[t for t in r['ticks'] if 2.35-1e-6<=t['t']<=3.05+1e-6]
 ax.plot([t['t'] for t in ts],[(t['intents'][i]['vel']['x']**2+t['intents'][i]['vel']['y']**2)**.5 for t in ts],style,color='#d07b26',lw=2,label=label+' final request')
 ax.plot([t['t'] for t in ts],[(t['before'][i]['vel']['x']**2+t['before'][i]['vel']['y']**2)**.5 for t in ts],style,color='#247d8c',lw=2,label=label+' achieved speed')
ts=[t for t in b['ticks'] if 2.35-1e-6<=t['t']<=3.05+1e-6]
ax.plot([t['t'] for t in ts],[(t['requests'][i]['vel']['x']**2+t['requests'][i]['vel']['y']**2)**.5 for t in ts],color='#555',lw=1,ls=':',label='Accepted raw request')
ax.set(xlabel='Time from snap (s)',ylabel='Speed (yd/s)',title='Duo: a committed sprint suppressed by traffic handling',ylim=(0,10));ax.legend(loc='upper right',fontsize=7.5,frameon=False)
fig.text(.02,.015,'Exact saved native data. Counter illustrates a policy discontinuity, not permission to follow every pull. Duo is one matched local example; no general speed/YAC claim.',fontsize=8,color='#555')
fig.tight_layout(rect=(0,.055,1,1));fig.savefig(O/'commitment-mechanisms.png',dpi=170)
