import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import assert from 'node:assert/strict';
const archive = '/workspace/football-linebacker-run-flow/out/run-flow/accepted-host';
const destination = '/workspace/football-decision-commitment/out/decision-commitment/architecture/zone-overload-results.json';
const expectedSource = '7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197';
const walk = (base, dir='src') => readdirSync(join(base,dir),{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(base,join(dir,e.name)):[join(dir,e.name)]).sort();
const hash = base => {const h=createHash('sha256');for(const p of walk(base))h.update(p).update('\0').update(readFileSync(join(base,p))).update('\0');return h.digest('hex');};
const sourceBefore = hash(archive); assert.equal(sourceBefore, expectedSource);
const started = performance.now();
const [{Rng},{generateTeam,pickOffense,pickDefense},{PASS_BY_ID},{FORMATION_BY_ID},{COVERAGE_BY_ID,FRONT_BY_ID},{PlaySim},{ZoneCoverage},{movementObjective}] = await Promise.all([
  import(`${archive}/src/core/rng.ts`), import(`${archive}/src/league/team.ts`), import(`${archive}/src/playbook/concepts.ts`),
  import(`${archive}/src/playbook/formations.ts`),import(`${archive}/src/playbook/defense.ts`),import(`${archive}/src/sim/playsim.ts`),
  import(`${archive}/src/sim/behaviors/defense.ts`),import(`${archive}/src/sim/movement-objective.ts`)
]);
const offense = generateTeam(new Rng(31),'Synthetic O','SYO',{strength:.6});
const defense = generateTeam(new Rng(32),'Synthetic D','SYD',{strength:.6});
function fixture(){
 const sim=new PlaySim({offense:pickOffense(offense,'11'),defense:pickDefense(defense,'base43'),seed:13,
  offCall:{formation:FORMATION_BY_ID.gun_doubles_11,flip:false,kind:'pass',pass:PASS_BY_ID.four_verts,label:'Synthetic zone overload contract'},
  defCall:{personnel:'base43',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover3,pressure:null,zoneStyle:'match',label:'Synthetic hook'},
  los:40,ballY:26,firstDownX:50});
 const a=sim.slot('LB_W'), seam=sim.slot('H'), other=sim.slot('Y'); assert(a&&seam&&other);
 const technique=new ZoneCoverage(a,sim,'hook_w','A',-1,'match'); a.behavior=technique;
 const lm=technique.recordedLandmark();a.body.pos={x:lm.x-1,y:lm.y};a.body.vel={x:4,y:0};a.body.facing=0;
 a.recog.read='pass';Object.defineProperty(a.mind,'placementError',{get:()=>0});
 const pictures=new Map(sim.agents.map(r=>[r,{pos:{x:r.team==='O'?60:55,y:50},vel:{x:0,y:0},age:.2,stance:null,pose:'up',carrying:false,facing:0}]));
 pictures.set(sim.qb,{pos:{x:35,y:26},vel:{x:0,y:0},age:.2,stance:null,pose:'up',carrying:true,facing:0});
 pictures.set(sim.slot('RB'),{pos:{x:35,y:25},vel:{x:0,y:0},age:.2,stance:null,pose:'up',carrying:false,facing:0});
 pictures.set(seam,{pos:{x:45,y:lm.y},vel:{x:6,y:0},age:.2,stance:null,pose:'up',carrying:false,facing:0});
 const observed=[];sim.see=(_observer,target)=>{observed.push(target.idx);return structuredClone(pictures.get(target));};sim.qbEyes=null;
 let spots=0;const ordinarySpot=technique.spotUnderneath.bind(technique);technique.spotUnderneath=(...args)=>{spots++;return ordinarySpot(...args);};
 function read(t,focus){sim.t=t;a.mind.focus=focus;spots=0;observed.length=0;const before={nextPatternRead:technique.nextPatternRead,hesitationUntil:technique.patternHesitationUntil};const command=technique.update(a,sim);
  const objective=movementObjective(command);return {t,focus,zoneRating:a.r('zoneCoverage'),overloadScore:focus*(.5+.5*a.r('zoneCoverage')),before,
   nextPatternRead:technique.nextPatternRead,hesitationUntil:technique.patternHesitationUntil,spotBranchCalls:spots,
   request:{...command},objective:objective??null,target:technique.target?.slot??null,body:{pos:{...a.pos},vel:{...a.vel}},
   consumed:[...new Set(observed)].map(idx=>({idx,slot:sim.agents[idx].slot,picture:pictures.get(sim.agents[idx])})),
   seam:{idx:seam.idx,picture:pictures.get(seam),distance:Math.hypot(pictures.get(seam).pos.x-a.pos.x,pictures.get(seam).pos.y-a.pos.y),
    carryEligible: pictures.get(seam).vel.x>4.5 && pictures.get(seam).pos.x-sim.los>2 && pictures.get(seam).pos.x-sim.los<13 && Math.abs(pictures.get(seam).pos.y-lm.y)<6},
   tags:[...a.tags]};
 }
 return {sim,a,seam,other,pictures,technique,lm,read};
}
function fourBeats(f,focus){const rows=[];for(let i=0;i<4;i++){const t=i===0?1:f.technique.nextPatternRead+.001;rows.push(f.read(t,focus));}return rows;}
const established=fixture();const first=established.read(.7,1);assert.equal(first.spotBranchCalls,0);assert.equal(first.target,'H');assert.equal(first.objective?.kind,'moving');
established.pictures.set(established.other,{pos:{x:43,y:established.lm.y-4},vel:{x:0,y:0},age:.2,stance:null,pose:'up',carrying:false,facing:Math.PI});
const resumed=fourBeats(established,.4);assert(resumed.every(r=>r.spotBranchCalls===1&&r.seam.carryEligible&&r.target==='H'));
const clear=fixture();clear.pictures.set(clear.other,structuredClone(established.pictures.get(established.other)));const high=fourBeats(clear,1);assert(high.every(r=>r.spotBranchCalls===0&&r.target==='H'));
const ambiguous=fixture();ambiguous.pictures.set(ambiguous.seam,{pos:{x:45,y:ambiguous.lm.y-.6},vel:{x:5.5,y:3},age:.2,stance:null,pose:'up',carrying:false,facing:Math.atan2(3,5.5)});
ambiguous.pictures.set(ambiguous.other,{pos:{x:45,y:ambiguous.lm.y+.6},vel:{x:5.5,y:-3},age:.2,stance:null,pose:'up',carrying:false,facing:Math.atan2(-3,5.5)});
const conflict=fourBeats(ambiguous,.4);assert(conflict.every(r=>r.spotBranchCalls===1));
// Remove only the extra route while impairment persists: the original seam remains valid.
const cancellationT=established.technique.nextPatternRead+.001;
established.pictures.set(established.other,{pos:{x:60,y:50},vel:{x:0,y:0},age:.2,stance:null,pose:'up',carrying:false,facing:0});
const canceled=established.read(cancellationT,.4);assert.equal(canceled.spotBranchCalls,0);assert.equal(canceled.objective?.kind,'moving');
// Reintroduce route to establish pending hesitation, then verify existing priorities bypass it.
established.pictures.set(established.other,structuredClone(clear.pictures.get(clear.other)));const pending=established.read(established.technique.nextPatternRead+.001,.4);assert.equal(pending.spotBranchCalls,1);
const pendingAt=pending.t;
established.sim.throwAt=pendingAt-1;established.sim.ball={kind:'air',flight:{pos:{x:45,y:20,z:1.5},vel:{x:5,y:0,z:-1},drag:0},thrower:established.sim.qb,target:null,releaseT:pendingAt-1,releaseX:35,intended:{x:48,y:20,z:1},arrivalT:pendingAt+.3,deflected:false,throwaway:false};
established.sim.ballPath=[];
const throwPriority=established.read(pendingAt+.05,.4);assert.equal(throwPriority.spotBranchCalls,0);assert(throwPriority.tags.includes('onBall'));
established.sim.ball={kind:'held',carrier:established.sim.slot('RB')};established.sim.throwAt=-1;established.a.recog.read='run';established.sim.handoffAt=pendingAt;
established.pictures.set(established.sim.slot('RB'),{pos:{x:39,y:24.5},vel:{x:4,y:0},age:.2,stance:null,pose:'up',carrying:true,facing:0});
const runPriority=established.read(pendingAt+.10,.4);assert.equal(runPriority.spotBranchCalls,0);
const elapsed=(performance.now()-started)/1000;assert(elapsed<3,'Pure probe exceeded declared3s budget');assert.equal(hash(archive),sourceBefore);
const result={qualification:'SYNTHETIC actual-controller calls. Frozen explicitly supplied acquired pictures; acquisition itself is not simulated. No PlaySim.tick, World, achieved movement, catch resolution, or play outcome. Direct private-field reads are passive diagnostics. Empty flight path is only a recognized-throw priority control, not a flight/contest validity test.',
 importedRoot:archive,importedCommit:'f4146275ce7539816bf57b4ed55a0d2be10e48c7',importedSourceSha256:sourceBefore,sourceUnchanged:true,launcherSourceQualification:'The baseline wrapper hashes its own checkout; actual engine imports exclusively use importedRoot above.',
 elapsedSeconds:elapsed,fixture:{teams:[31,32],seed:13,formation:'gun_doubles_11',defense:'over/cover3/base43',installedTechnique:'hook_w match',bodyFrozen:true,allPictureAge:.2,lowFocus:.4,ordinaryFocus:1},
 results:{acceptedCarry:first,nonconflictingAddedRouteLowFocus:resumed,nonconflictingHighFocus:high,ambiguousCrossingLowFocus:conflict,removeOnlyExtraRoute:canceled,pendingBeforePriority:pending,recognizedThrow:throwPriority,currentRun:runPriority}};
writeFileSync(destination,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({elapsedSeconds:elapsed,importedSourceSha256:sourceBefore,zoneRating:first.zoneRating,firstRequest:first.request,
 lowFocusRequests:resumed.map(r=>({t:r.t,request:r.request,spot:r.spotBranchCalls,staleTarget:r.target,deadline:r.hesitationUntil})),
 highFocusRequest:high[0].request,ambiguousAllSpot:conflict.every(r=>r.spotBranchCalls===1),removedExtraRouteRequest:canceled.request,recognizedThrowBypasses:throwPriority.spotBranchCalls===0,currentRunBypasses:runPriority.spotBranchCalls===0},null,2));
