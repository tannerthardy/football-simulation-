# Decision commitment: post-decision movement audit

Question: when a defender looks hesitant, did he withhold a football decision, or did a later movement consumer weaken an already committed request?

Pinned accepted runtime: `f4146275ce7539816bf57b4ed55a0d2be10e48c7`, source digest `7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197`. This is a saved-data review of ten exact native inputs, not ten new simulations. The reducer/manifest identifies the input/tape hashes and records exact selected snapshots; native sampling is 20 Hz and `t` is entry time, `completed=t+.05` is achieved-body time. Original launch receipts retain Node22.23.3, 44 flags, RUN_CONTACT_COMPONENTS=1 and unchanged World defaults. No new native snap, NFL query, source physics change or full suite was run by this subtask.

## What is actually happening

The visual impression can hide three different mechanisms:

1. **Duty still being held.** DUO FS/SD-S1 has read run at .55s, but at1.50s legitimately preserves an alley cap with request(-5.988,-1.170), delivered unchanged. It is not yet a free interior runner. Before his run read, at .50s he is still executing coverage: request(+4.276,+.381). Committing every such player directly to the ball would remove legitimate play-action and final-level protection.
2. **Strong duty request weakened after selection.** DUO FS at2.55–2.85s requests a9.387yd/s chase every tick, receives(0,0), and physically decelerates4.421→1.992yd/s. His run recognition did not disappear; he is up, unloaded, unconstrained by a recorded engagement/contact, and the actual ball is9.03→6.47yd away. The next consumer, teammate spacing, is responsible for this request change. At2.55 the nearest acquired teammate is DT_S/SD-EDGE1 at approximately(44.387,24.079), velocity(+2.530,-.319), acquired age.05s,4.17yd away from FS at(48.392,25.232). That acquired incoming path can create a real upcoming collision; zero is not automatically wrong, and the distance between current centers does not establish clearance.
3. **Execution follows a useful request.** TOSS FS/SD-S1 at2.55 requests/delivers(-2.180,-9.130), speed9.387yd/s. Achieved speed rises4.894→6.353 by3.10. Same safety/capability, different traffic. A blanket minimum-speed or aggression intervention would misdiagnose the previous case.

The first raw→final change is DUO FS2.40: raw(-8.308,-4.370) becomes(-3.219,-2.882). By2.50 raw(-8.253,-4.472) becomes(-2.568,-2.817), then2.55 becomes zero. There is no FS engagement/contact; all selected body states and acquired teammate pictures are in `selected-snapshots.json`.

The repeated post-selection phenomenon is real but not a league prevalence estimate. Across10 selected tapes after.50s:8,536 defender-ticks;5,020 screened free ticks (up, no current rep/contact, no load/lean/foot/strike, no raw push/dive/lunge);4,463 strong requests>=3yd/s;175 are cut below half,48 below1yd/s. Correlated ticks and heterogeneous ending/contact exposure prohibit treating these as independent errors.

## A small architectural gap

Accepted `runThrough()` computes a sprint velocity through an already chosen point but omits its own-objective metadata. `chase()` spreads that request through its far pursuit arm. Accepted spacing's compound traffic action requires `movementObjective(raw)` and only applies to man/zone behavior kinds. Thus a committed chase can be braked/gathered but cannot even be evaluated for the already implemented goal-preserving traffic step. This is an information/consumer interface gap; it is not evidence that the player needs a commitment timer or more aggression.

Small correction in parent worktree: annotate the existing runThrough target `{kind:'fixed',point:target}` using `withMovementObjective`. A forecast-derived interception point is still fixed for this command; its future velocity is not known or invented. Numeric velocity, speed, facing, cut skill, observations, RNG and physical capacities are untouched.

Admission scope: man/zone ordinary chase/pursueIfLive, run-fit→chase and playBall fallback catch-spot sprints. Pass-rush, blitz, run-fit, pursuit, receiver and blocking behavior kinds remain excluded from the existing compound action. `goTo()` remains unannotated; alternate close `gatheringApproach`/`chooseApproach` returns also remain unannotated. These explicit limitations are not silently repaired in this change.

## Opposing evidence and unresolved limit

FTOSS LB_W/SD-LB2 at1.75–1.85 requests~8.97yd/s but receives~.55, achieved2.786→1.947yd/s. At1.80 an acquired DT_W is1.93yd away and Mike2.91yd away, both in the requested lateral flow corridor. Unlike the DUO far chase, this run-fit uses `track()` and already carries an objective through the LB_PLAN spread. Metadata alone does not explain all slow flow. Native phase recording must distinguish radial headway, gather, compound-action rejection and actual collision before selecting an additional intervention.

PA SS/SD-S2 at2.50 is another legitimate opposing constraint: an acquired rising LB_S is only.857yd away in the requested path. Raw(-4.395,+1.788) becomes(-.832,+1.221). A stopped/rising teammate is a real obstacle, not an excuse to force a sprint through him.

The saved collector loses Symbol metadata in structuredClone. Absence in old JSON cannot itself prove absence at runtime; the runThrough/chase path above is established by source. Existing snapshots provide actual spacing peer pictures, but no per-stage selection reason or predicted clearances. Small next native instrumentation: capture own objective before/after behavior/contact/spacing and a passive spacing decision reason (radial, gather, stepAround admission/rejection) with already acquired peer pictures. Never re-query perception or draw randomness to record this.

## Focused contracts

New `test/run-through-objective.test.ts` has7 checks. On accepted source3 fail/4 pass. Candidate source `ca49106dc6dabb648eb1615774d8ce63d19f275d064fe5e349724ee13e0b2300` has7 pass; existing traffic-step8, spacing-yield8 and traffic-turning13 also pass:36 total. Runtime tests preserve numeric sprint parity and copied fixed target, actual far chase retention with exactly3 existing see calls, clear lane, unknown moving objective, loaded and real obstruction controls.

The traffic fixture is deliberately a **mechanical contract**, not a restored DUO decision: exact saved native bodies and peer pictures, synthetic fixed waypoint one second along the recorded raw request. Old no-goal projected clearance is−.06154yd; the accepted compound action with fixed metadata produces>.25yd clearance while retaining the goal and without extra sensing/body mutation. This proves interface usefulness, not native football transfer. Parent owns DUO native continuation plus TOSS/PASS13 opposing transfer.

Failures remain visible: first numerical-parity assertion had a test-only floating multiplication-order error; corrected before the definitive accepted3fail receipt. Typecheck caught fixture-array implicit-any callbacks; corrected with an array type assertion. Neither changed runtime code or discarded adverse movement evidence. Logs and receipts remain here.

Final typecheck passes; receipt `typecheck-final.json` records parent docs-head06ac0ba556a368f542084ecb256eb8fa4af44ac3 with unchanged candidate runtime ca49106. New tests remain7, existing focused29, total36.
