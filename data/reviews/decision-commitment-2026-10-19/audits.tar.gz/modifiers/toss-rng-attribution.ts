import {readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{Rng}from'../../../src/core/rng.js';import{supportParams}from'../../../src/physics/support.js';import{contactQuality}from'../../../src/sim/tackle-window.js';
const base=JSON.parse(gunzipSync(readFileSync('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/TOSS.json.gz')).toString()),candidate=JSON.parse(gunzipSync(readFileSync(new URL('../native/candidate/TOSS.json.gz',import.meta.url))).toString());
const common=JSON.parse(base.ticks.find((r:any)=>r.t===3.55).rng),results=[];
for(const[name,data,n]of[['baseline',base,3],['candidate',candidate,2]]as const){
 const tick=data.ticks.find((r:any)=>r.t===3.6),rng=new Rng(13);Object.assign(rng,common);
 const handFightNormals=Array.from({length:n},()=>rng.normal(0,.25));
 const entryRng=JSON.stringify(rng),entryStateMatch=entryRng===tick.rng;
 const missDraw=rng.next(),fumbleDraw=rng.next(),executionNormal=rng.normal(0,1),legsNormal=rng.normal(0,.15);
 const afterAttempt=JSON.stringify(rng);
 const nextRunHandFightNormals=Array.from({length:2},()=>rng.normal(0,.25));
 const reconstructed=JSON.stringify(rng),recordedNext=data.ticks.find((r:any)=>r.t===3.65).rng,matches=reconstructed===recordedNext;
 const d=tick.after[18],c=tick.after[6],player=data.initial[18].player,runner=data.initial[6].player;
 const dd=Math.hypot(d.pos.x-c.pos.x,d.pos.y-c.pos.y),body=d.profile.radius+c.profile.radius,arms=body+d.profile.reach,q=contactQuality(dd,body,arms),T=(player.ratings.tackling*.85+player.ratings.pursuit*.15)/98,E=(runner.ratings.elusiveness-1)/98,P=((runner.ratings.breakTackle-1)*.7+(runner.ratings.strength-1)*.3)/98;
 const clamp=(x:number,l:number,h:number)=>Math.max(l,Math.min(h,x));
 // Use the same r01 scale as Agent.r; explicit ratings below aid review.
 const tacklerT=((player.ratings.tackling-1)*.85+(player.ratings.pursuit-1)*.15)/98;
 const execution=clamp((1-.35*clamp(.5*P+.5*E-tacklerT,-1,1))*Math.exp(.3*executionNormal),.2,1.6),quality=clamp(clamp(.25+.85*q,.1,1)*execution,.08,1);
 const nx=(c.pos.x-d.pos.x)/dd,ny=(c.pos.y-d.pos.y)/dd,cs=Math.hypot(c.vel.x,c.vel.y),cosA=-((c.vel.x/cs)*nx+(c.vel.y/cs)*ny),fromBehind=cosA<-.3?1:0;
 const legs=clamp(.1+.55*((player.ratings.tackling-1)/98)*q+.25*fromBehind+legsNormal,0,1),capacity=supportParams(d.profile).armForce*(.3+2.5*quality*quality)*(.6+.6*((player.ratings.tackling-1)/98));
 results.push({name,at:3.6,initialCommonRng:common,runRepCount:n,handFightNormals,entryRng,entryStateMatch,missDraw,fumbleDraw,executionNormal,legsNormal,afterAttempt,nextRunHandFightNormals,reconstructed,recorded:recordedNext,exactNextStateMatch:matches,entry:{defenderId:data.initial[18].player.id,carrierId:data.initial[6].player.id,dd,q,body,arms},inferredExecution:execution,inferredQuality:quality,inferredLegs:legs,inferredGripCapacity:capacity,cosApproach:cosA,ratings:{tackler:player.ratings,runner:runner.ratings}});
}
writeFileSync(new URL('toss-rng-attribution.json',import.meta.url),JSON.stringify({qualification:'Collector RNG is recorded at World.step boundary BEFORE post-physics tackle attempts. Pure replay from saved3.55 entry:3/2 run-rep handfight normals exactly match saved3.60 entry. Then ordinary CB miss/fumble/execution/leg draws plus next2 handfight normals checked against3.65 entry. No new native play or forced execution. Inferred grip quality uses same saved geometry and production formulas.',results},null,2)+'\n');console.log(JSON.stringify(results.map(r=>({name:r.name,exactEntryStateMatch:r.entryStateMatch,exactNextStateMatch:r.exactNextStateMatch,draws:{miss:r.missDraw,fumble:r.fumbleDraw,execution:r.executionNormal,legs:r.legsNormal},entry:r.entry,execution:r.inferredExecution,quality:r.inferredQuality,legs:r.inferredLegs,capacity:r.inferredGripCapacity})),null,2));
