import json,gzip,pathlib,hashlib
R=pathlib.Path(__file__).resolve().parent
pairs=[('PASS13','/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PASS13.json.gz',R.parent/'native/candidate/PASS13.json.gz'),('FTOSS','/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/FTOSS.json.gz',R.parent/'native/fresh-candidate/FTOSS.json.gz')]
out=[]
for name,p,q in pairs:
 a=json.load(gzip.open(p,'rt'));b=json.load(gzip.open(q,'rt'));keys=['t','completed','before','requests','intents','after','reps','contacts','reads','ball','rng'];diffs=[]
 if len(a['ticks'])!=len(b['ticks']):diffs.append('tick count')
 for x,y in zip(a['ticks'],b['ticks']):
  for k in keys:
   if x[k]!=y[k]:diffs.append({'t':x['t'],'field':k})
 initialExclusive=[]
 for i,(m,n) in enumerate(zip(a['initial'],b['initial'])):
  for k in m.keys()&n.keys():
   if m[k]!=n[k]:diffs.append({'field':'initial','actor':i,'key':k})
  initialExclusive.append({'actor':i,'baselineOnly':sorted(m.keys()-n.keys()),'candidateOnly':sorted(n.keys()-m.keys())})
 for k in ['inputSha256','setup','phase','outcome','gain','events','result']:
  if a[k]!=b[k]:diffs.append({'field':k})
 row={'case':name,'inputSha256':a['inputSha256'],'baselineSource':a['source'],'candidateSource':b['source'],'baselineTape':{'path':p,'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()},'candidateTape':{'path':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest()},'ticks':len(a['ticks']),'comparedKeys':keys,'initialExclusiveMetadata':initialExclusive,'allComparedIdentical':not diffs,'differences':diffs,'phase':a['phase'],'gain':a['gain'],'outcome':a['outcome']};out.append(row)
print(json.dumps(out,indent=2));(R/'unaffected-identity.json').write_text(json.dumps(out,indent=2)+'\n')
