import json,gzip,pathlib,math,hashlib
R=pathlib.Path(__file__).resolve().parent
pairs={'DUO':'/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/DUO.json.gz','TOSS':'/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/TOSS.json.gz','PASS13':'/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PASS13.json.gz'}
results={}
for name,p in pairs.items():
 a=json.load(gzip.open(p,'rt'));q=R.parent/'native/candidate'/f'{name}.json.gz';b=json.load(gzip.open(q,'rt'));bs={x['t']:x for x in b['ticks']};first={}
 for x in a['ticks']:
  if x['t'] not in bs:continue
  y=bs[x['t']]
  for key in ['requests','intents','before','after','rng']:
   if key in first or x[key]==y[key]:continue
   if isinstance(x[key],list):
    changes=[i for i,(m,n) in enumerate(zip(x[key],y[key])) if m!=n]
    first[key]={'t':x['t'],'actors':[{'idx':i,'slot':a['initial'][i]['slot'],'id':a['initial'][i]['player']['id']} for i in changes]}
   else:first[key]={'t':x['t']}
 rows=[]
 for t in sorted(bs):
  x=next((x for x in a['ticks'] if x['t']==t),None);y=bs[t]
  if not x:continue
  for i in ([20] if name=='DUO' else [15,16,17,20,21] if name=='TOSS' else []):
   if name=='DUO' and not 2.3<=t<=3.25:continue
   if name=='TOSS' and not 1.7<=t<=3.5:continue
   rows.append({'t':t,'idx':i,'slot':a['initial'][i]['slot'],'id':a['initial'][i]['player']['id'],'baseline':{'request':x['requests'][i],'delivered':x['intents'][i],'body':x['before'][i],'achieved':x['after'][i]},'candidate':{'request':y['requests'][i],'delivered':y['intents'][i],'requestGoal':y['requestObjectives'][i],'deliveredGoal':y['intentObjectives'][i],'body':y['before'][i],'achieved':y['after'][i]}})
 results[name]={'baselineTape':{'path':p,'sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()},'candidateTape':{'path':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest()},'first':first,'endings':{'baseline':{'gain':a['gain'],'phase':a['phase'],'events':a['events']},'candidate':{'gain':b['gain'],'phase':b['phase'],'events':b['events']}},'rows':rows}
 print(name,'first',first)
 if name=='DUO':
  for r in rows:
   if r['t'] in [2.3,2.4,2.5,2.55,2.65,2.85,3.,3.1,3.25]:
    z=r['candidate'];o=r['baseline'];goal=z['requestGoal'];print(r['t'],'baseFinal',o['delivered']['vel'],'newfinal',z['delivered']['vel'],'posdelta',math.dist(o['achieved']['pos'].values(),z['achieved']['pos'].values()),'sp',math.hypot(*o['achieved']['vel'].values()),math.hypot(*z['achieved']['vel'].values()),'goal',goal)
 print('wraps',[(e['t'],e['type'],e.get('a'),e.get('b'),e.get('note')) for e in a['events'] if 'tackle' in e['type']],[(e['t'],e['type'],e.get('a'),e.get('b'),e.get('note')) for e in b['events'] if 'tackle' in e['type']])
(R/'native-comparison.json').write_text(json.dumps(results,indent=2)+'\n')
