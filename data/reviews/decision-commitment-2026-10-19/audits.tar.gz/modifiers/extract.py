import gzip,json,hashlib,pathlib
R=pathlib.Path(__file__).resolve().parent
cases=[('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/DUO.json.gz',20,[.5,.75,1.5,2.35,2.4,2.45,2.5,2.55,2.85,3.1]),('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/FTOSS.json.gz',16,[1.65,1.75,1.8,1.85,2]),('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/TOSS.json.gz',20,[.5,1.5,2.55,3.1]),('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/PA.json.gz',21,[2.35,2.5,2.75])]
out=[]
for p,actor,times in cases:
 b=pathlib.Path(p);a=json.load(gzip.open(b,'rt'));rows=[]
 for t in times:
  x=next(x for x in a['ticks'] if x['t']==t);peers=[]
  for cue in a['cues']:
   if cue['t']==t and cue['a']==actor and cue.get('consumer') is None and cue['b']>=11:
    j=cue['b'];peers.append({'idx':j,'slot':a['initial'][j]['slot'],'playerId':a['initial'][j]['player']['id'],'profile':a['initial'][j]['profile'],'picture':cue['picture']})
  rows.append({'t':t,'completed':x['completed'],'body':x['before'][actor],'request':x['requests'][actor],'delivered':x['intents'][actor],'achievedBody':x['after'][actor],'read':x['reads'][actor],'peers':peers,'contacts':[c for c in x['contacts'] if actor in[c['i'],c['j']]],'reps':[r for r in x['reps'] if actor in[r['b'],r['d']]],'ball':x['ball']})
 out.append({'case':a['id'],'path':p,'sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'source':a['source'],'inputSha256':a['inputSha256'],'actor':a['initial'][actor],'rows':rows,'qualification':'Exact recorded body/request/acquired spacing pictures. Symbols were omitted by original collector; no football objective reconstruction claimed.'})
(R/'selected-snapshots.json').write_text(json.dumps(out,indent=2)+'\n')
