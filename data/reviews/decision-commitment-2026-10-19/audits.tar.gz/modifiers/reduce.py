import gzip,json,math,hashlib,pathlib,collections
ROOT=pathlib.Path('/workspace/football-decision-commitment/out/decision-commitment/modifiers')
base=pathlib.Path('/workspace/football-defensive-snap-response/out/defensive-snap-response')
flow=pathlib.Path('/workspace/football-linebacker-run-flow/out/run-flow')
paths=[base/'baseline'/f'{x}.json.gz' for x in ['TOSS','DUO','IZ','PA']]+[base/'fresh-baseline'/f'{x}.json.gz' for x in ['FTOSS','FTOSS-L','PA13','PASS13']]+[flow/'extra-baseline'/f'{x}.json.gz' for x in ['OZ24','COUNTER2']]
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
mag=lambda v:math.hypot(v['x'],v['y'])
out=[]; totals=collections.Counter(); windows=[]
for path in paths:
 data=json.load(gzip.open(path,'rt')); actors=data['initial']; rows=[]; current={}
 for tick in data['ticks']:
  contact={x[k] for x in tick.get('contacts',[]) for k in ['i','j']}; rep={x[k] for x in tick.get('reps',[]) for k in ['b','d']}
  for i,a in enumerate(actors):
   if i<11: continue
   raw=tick['requests'][i]; final=tick['intents'][i]; before=tick['before'][i]; after=tick['after'][i]
   rs=mag(raw['vel']); fs=mag(final['vel']); sp=mag(before['vel']); asp=mag(after['vel']); change=math.hypot(raw['vel']['x']-final['vel']['x'],raw['vel']['y']-final['vel']['y'])
   support=before.get('support') or {}; free=i not in rep and i not in contact and support.get('state')=='up' and not support.get('foot') and not support.get('strike') and mag(support.get('lean',{'x':0,'y':0}))<1e-6 and mag(support.get('load',{'x':0,'y':0}))<1e-6 and (raw.get('push') or 0)<1e-6 and not raw.get('dive') and not raw.get('lunge')
   if tick['t']>=.5:
    totals['defender_ticks']+=1
    if free: totals['free_ticks']+=1
    if free and rs>=3:
     totals['strong_free_ticks']+=1
     if fs<rs*.5:totals['strong_free_halved_ticks']+=1
     if fs<1:totals['strong_free_below1_ticks']+=1
   if change>1 and tick['t']>=.5:
    carrier=tick.get('ball',{}).get('carrier'); dist=math.dist(before['pos'].values(),tick['before'][carrier]['pos'].values()) if isinstance(carrier,int) else None
    row={'case':data['id'],'t':tick['t'],'i':i,'id':a['player']['id'],'slot':a['slot'],'behavior':a['behavior'],'duty':a.get('runFit'),'raw':raw,'final':final,'rawSpeed':rs,'finalSpeed':fs,'beforeSpeed':sp,'afterSpeed':asp,'free':free,'rep':i in rep,'touch':i in contact,'distanceCarrier':dist,'pos':before['pos'],'facing':before['facing'],'support':support,'read':tick.get('reads',[None]*22)[i]}
    rows.append(row)
   key=i
   condition=free and rs>=3 and fs<rs*.5 and tick['t']>=.5
   if condition:
    current.setdefault(key,[]).append((tick['t'],rs,fs,sp,asp))
   elif key in current:
    v=current.pop(key)
    if len(v)>=3: windows.append({'case':data['id'],'i':i,'slot':a['slot'],'id':a['player']['id'],'start':v[0][0],'end':v[-1][0], 'n':len(v),'rows':v})
 for i,v in current.items():
  if len(v)>=3:windows.append({'case':data['id'],'i':i,'slot':actors[i]['slot'],'id':actors[i]['player']['id'],'start':v[0][0],'end':v[-1][0], 'n':len(v),'rows':v})
 out.append({'case':data['id'],'path':str(path),'sha256':H(path),'source':data['source'],'inputSha256':data['inputSha256'],'phase':data['phase'],'gain':data.get('gain'),'rows':rows})
result={'definition':'strong free raw>=3yd/s; final<half raw; screenedfree=no current native rep/contact, pre-step support up with no foot/strike/lean/load or raw push/dive/lunge. Does not exclude previous contact/grasp; exact finalists checked individually. Raw requests are post-containment PlaySim.cmds, not pure behavior output.','totals':dict(totals),'windows':windows,'tapes':out}
(ROOT/'reduced.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'totals':totals,'windows':[{k:v for k,v in w.items() if k!='rows'} for w in windows]},indent=2))
print('Top strong/free reductions')
for a in sorted([r for t in out for r in t['rows'] if r['free'] and r['rawSpeed']>=3],key=lambda r:r['rawSpeed']-r['finalSpeed'],reverse=True)[:35]:print(a['case'],a['slot'],a['id'],a['t'],'raw',round(a['rawSpeed'],3),'final',round(a['finalSpeed'],3),'achieved',round(a['beforeSpeed'],3),'to',round(a['afterSpeed'],3),'carrier',round(a['distanceCarrier'] or -1,3),'supportload',a['support'].get('load'))
