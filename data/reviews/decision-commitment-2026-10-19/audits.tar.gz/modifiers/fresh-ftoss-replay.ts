import{readFileSync,writeFileSync}from'node:fs';import{gunzipSync}from'node:zlib';
import{Agent}from'../../../src/sim/agent.js';
import{previewFreeMovement}from'../../../src/physics/movement-preview.js';
import{spaceTeammates as original}from'../../../src/sim/spacing.js';
import{withMovementObjective as oldGoal}from'../../../src/sim/movement-objective.js';
import{spaceTeammates as material}from'/workspace/football-traffic-material-progress/src/sim/spacing.ts';
import{withMovementObjective as newGoal}from'/workspace/football-traffic-material-progress/src/sim/movement-objective.ts';
import type{Intent}from'../../../src/physics/world.js';
const dataPath='/workspace/football-traffic-progress-composition/out/traffic-progress-composition/fresh-native/FTOSS.json.gz';
const data=JSON.parse(gunzipSync(readFileSync(dataPath)).toString()),idx=15,init=data.initial[idx],first=data.ticks[0].before[idx],rows:any[]=[];
const create=()=>new Agent(idx,'D',init.slot,init.player,first.profile,structuredClone(first),{kind:init.behavior,update(){throw Error('Do not re-decide');}}),a=create(),b=create();
for(const tick of data.ticks){
 if(tick.t>1.8)break;
 const pictures=new Map<number,any>();for(const c of data.cues)if(c.t===tick.t&&c.a===idx&&c.b>=11&&c.b!==idx&&c.consumer===null)pictures.set(c.b,structuredClone(c.picture));
 if(pictures.size!==10)continue;
 const peers=[...pictures].map(([j])=>({idx:j,team:'D',profile:data.initial[j].profile,get pos(){throw Error('Hidden peer position');},get vel(){throw Error('Hidden peer velocity');}}as unknown as Agent));
 const goal=tick.requestObjectives[idx];
 function choose(actor:Agent,fn:typeof original,attach:typeof oldGoal){
  Object.assign(actor.body,structuredClone(tick.before[idx]));let raw=structuredClone(tick.requests[idx]);if(goal)raw=attach(raw,goal);
  const intents:Intent[]=[raw,...peers.map(()=>({vel:{x:0,y:0},free:true}))];let count=0;
  fn([actor,...peers],intents,(_a,p)=>{count++;return pictures.get(p.idx);},{now:tick.t});if(count!==10)throw Error('Extra acquired query');return intents[0];
 }
 const old=choose(a,original,oldGoal),next=choose(b,material,newGoal);if(tick.t<1.55)continue;
 function score(command:Intent){
  const body=structuredClone(tick.before[idx]),path=previewFreeMovement(body,command,tick.t,12),last=path.at(-1)!,raw=tick.requests[idx],s=Math.hypot(raw.vel.x,raw.vel.y),forward={x:raw.vel.x/s,y:raw.vel.y/s};
  let minimum=Infinity,peer:any=null;
  for(const[j,p]of pictures){const touch=.9*(body.profile.radius+data.initial[j].profile.radius);let x=body.pos.x-p.pos.x,y=body.pos.y-p.pos.y,best=Math.hypot(x,y)-touch;for(const sample of path){const rx=sample.pos.x-p.pos.x-p.vel.x*sample.t,ry=sample.pos.y-p.pos.y-p.vel.y*sample.t,dx=rx-x,dy=ry-y,u=Math.max(0,Math.min(1,-(x*dx+y*dy)/Math.max(1e-12,dx*dx+dy*dy)));best=Math.min(best,Math.hypot(x+u*dx,y+u*dy)-touch);x=rx;y=ry;}if(best<minimum){minimum=best;peer={idx:j,slot:data.initial[j].slot,id:data.initial[j].player.id,picture:p};}}
  const flow=goal?.kind==='moving'?goal.velocity:{x:0,y:0};return{command,progress:(last.pos.x-body.pos.x)*forward.x+(last.pos.y-body.pos.y)*forward.y,error:goal?Math.hypot(last.pos.x-goal.point.x-flow.x*last.t,last.pos.y-goal.point.y-flow.y*last.t):null,clearance:minimum,closestPeer:peer,upright:path.every(s=>s.support==='up'),path};
 }
 rows.push({t:tick.t,actor:{idx,slot:init.slot,id:init.player.id,duty:init.runFit},body:tick.before[idx],raw:tick.requests[idx],goal,original:score(old),material:score(next),nativeFinal:tick.intents[idx],nativeMatched:JSON.stringify(next.vel)===JSON.stringify(tick.intents[idx].vel)});
}
const output={question:'First fresh-player native divergence: meaningful approach redirect or arbitrary epsilon goal gain?',dataPath,sourcePins:{originalConsumer:'ca49106dc6dabb648eb1615774d8ce63d19f275d064fe5e349724ee13e0b2300',materialConsumer:'e0bb47feae9f8604fd739a2fc96acd2946f95fe65eb2ea76c5ff623ad17247fc',recording:'3c8bde145798f38d6a4a2af47c04da0f6bfff8b1be00641cf017628f3b3b6cbd'},qualification:'Exact own bodies and10 acquired teammate queries. No private position/velocity access, no re-reading, RNG or native simulation. Held-command .6s preview ignores future contacts/cuts.',rows};
writeFileSync(new URL('fresh-ftoss-replay.json',import.meta.url),JSON.stringify(output,null,2)+'\n');for(const r of rows.filter(r=>r.t>=1.6&&r.t<=1.7))console.log(JSON.stringify({t:r.t,nativeMatched:r.nativeMatched,goal:r.goal,old:{vel:r.original.command.vel,progress:r.original.progress,error:r.original.error,clearance:r.original.clearance,closest:r.original.closestPeer},material:{vel:r.material.command.vel,progress:r.material.progress,error:r.material.error,clearance:r.material.clearance,upright:r.material.upright}},null,2));
