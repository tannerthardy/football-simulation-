import json,gzip,hashlib,time,math
from pathlib import Path
start=time.perf_counter()
root=Path('/workspace/football-decision-commitment/out/decision-commitment/defense')
paths={
'TOSS':Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/TOSS.json.gz'),
'IZ':Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/IZ.json.gz'),
'OZ24':Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/OZ24.json.gz'),
'COUNTER2':Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/COUNTER2.json.gz'),
'DUO':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/DUO.json.gz'),
'PA':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/PA.json.gz'),
'PA13':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PA13.json.gz'),
'PASS13':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PASS13.json.gz'),
'FTOSS':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/FTOSS.json.gz'),
'FTOSS-L':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/FTOSS-L.json.gz')}
selected={
'TOSS':{'SS':[1.75,2,2.25,2.45,2.5,2.65], 'LB_S':[1.35,1.55,1.65,2.5]},
'FTOSS':{'SS':[2.25,2.5,2.6,2.65,2.85,3]},
'FTOSS-L':{'SS':[2.25,2.5,2.65,2.85]},
'COUNTER2':{'LB_W':[1.5,1.55,1.65,1.7,2,2.05,2.1], 'LB_M':[2.1,2.2,2.75,3.25,3.3]},
'PA':{'LB_M':[.35,1.8,2,2.05,2.2]},
'PA13':{'LB_M':[.35,1.8,2,2.05,2.2]},
'IZ':{'LB_M':[1.8,2,2.35,2.75]}}
rows=[];catalog=[];reads=[]
for name,path in paths.items():
 raw=path.read_bytes();d=json.loads(gzip.decompress(raw)); ids={a['slot']:a for a in d['initial']};idx={a['idx']:a for a in d['initial']}
 catalog.append({'case':name,'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'source':d['source'],'inputSha256':d['inputSha256'],'duration':d['ticks'][-1]['completed'],'phase':d['phase'],'outcome':d['outcome'],'gain':d['gain'],'flagsReceipt':str(path.parent/'receipt.json')})
 per={a['idx']:[] for a in d['initial'] if a['idx']>=11}
 for e in d['events']:
  if e['type']=='read':per[e['a']].append({'t':e['t'],'note':e['note']})
 reads.append({'case':name,'runCall':d['setup']['offCall']['kind']=='run','actors':[{'idx':a,'slot':idx[a]['slot'],'id':idx[a]['player']['id'],'commits':q} for a,q in per.items()]})
 for slot,times in selected.get(name,{}).items():
  actor=ids[slot];a=actor['idx'];job=actor.get('runFit')
  for tm in times:
   tick=next((x for x in d['ticks'] if abs(x['t']-tm)<1e-7),None)
   if tick is None:continue
   call=next((x for x in d['calls'] if x['a']==a and abs(x['t']-tm)<1e-7),None)
   consumed=d['cues'][call['cues'][0]:call['cues'][1]] if call else []
   rb=[x for x in consumed if x['b']==ids['RB']['idx']]
   core={c['b']:c['picture'] for c in consumed if idx[c['b']]['slot'] in ['LT','LG','C','RG','RT'] or idx[c['b']]['player']['position']=='TE'}
   surface=None
   if job and core:
    if job['side']>0:surface=max(v['pos']['y']+idx[i]['profile']['radius'] for i,v in core.items())
    else:surface=min(v['pos']['y']-idx[i]['profile']['radius'] for i,v in core.items())
   history=[x for x in d['events'] if x['type']=='read' and x['a']==a and x['t']<=tm]
   rows.append({'case':name,'idx':a,'slot':slot,'playerId':actor['player']['id'],'t':tm,'completed':tick['completed'],'installedRunFit':job,'currentBelief':history[-1] if history else None,
     'before':{k:tick['before'][a][k] for k in ('pos','vel','facing')},'rawRequest':tick['requests'][a],'finalIntent':tick['intents'][a],
     'achieved':{k:tick['after'][a][k] for k in ('pos','vel','facing')},'firstConsumedRB':rb[0] if rb else None,
     'surface':surface,'outsideSurface':bool(job['side']*(rb[0]['picture']['pos']['y']-surface)>0) if job and rb and surface is not None else None,
     'aims':[x for x in d.get('aims',[]) if x['a']==a and x['t']==tm],
     'reps':[x for x in tick['reps'] if a in (x['b'],x['d'])],
     'bodyContacts':[x for x in tick['contacts'] if a in (x['i'],x['j'])],
     'events':[x for x in d['events'] if x['t']==tm and (x.get('a')==a or x.get('b')==a)]})
result={'kind':'Saved-data audit, no new native simulations','acceptedDevelop':'f4146275ce7539816bf57b4ed55a0d2be10e48c7','source':'7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197','catalog':catalog,'recognition':reads,'witnesses':rows,'elapsedSeconds':time.perf_counter()-start}
(root/'evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print('selected witness rows',len(rows),'tapes',len(paths),'elapsedSeconds',result['elapsedSeconds'])
for r in reads:
 print(r['case'],'commits',sum(len(a['commits']) for a in r['actors']),'rereads',[(a['slot'],a['commits']) for a in r['actors'] if len(a['commits'])>1])
