import json,gzip,math
from pathlib import Path
T={
'TOSS':Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/TOSS.json.gz'),
'IZ':Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/IZ.json.gz'),
'OZ24':Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/OZ24.json.gz'),
'COUNTER2':Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/COUNTER2.json.gz'),
'DUO':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/DUO.json.gz'),
'PA':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/PA.json.gz'),
'PA13':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PA13.json.gz'),
'PASS13':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PASS13.json.gz')}
if __name__=='__main__':
 for name,p in T.items():
  d=json.load(gzip.open(p,'rt'));A={a['idx']:a for a in d['initial']}; print('\nCASE',name,'source',d['source'],'final',d['phase'],d['outcome'],d['gain'])
  print('READS',[(q['t'],q['a'],q.get('note')) for q in d['events'] if q['type']=='read'])
  print('END',[(q['t'],q['type'],q.get('a'),q.get('b')) for q in d['events'] if q['type'] in ['handoff','catch','throw','tackle','tackle_wrap','missed_tackle','pitch_catch']])
  for a,x in A.items():
   if not x['slot'].startswith('LB') and x['slot'] not in ['FS','SS']:continue
   print('ACTOR',a,x['slot'],x['player']['id'],'JOB',x.get('runFit'))
   old=None
   for t in d['ticks']:
    if t['t']>3.2:break
    if t['t']*100%20>1e-5:continue
    call=[q for q in d['calls'] if q['a']==a and q['t']==t['t']]
    aim=[q for q in d.get('aims',[]) if q['a']==a and q['t']==t['t']]
    v=t['requests'][a]['vel'];u=t['intents'][a]['vel'];b=t['before'][a]
    print(t['t'], 'p',tuple(round(b['pos'][z],2) for z in ('x','y')),'v',tuple(round(b['vel'][z],2) for z in ('x','y')),'raw',tuple(round(v[z],2) for z in ('x','y')),'final',tuple(round(u[z],2) for z in ('x','y')),'kind',call[0]['kind'] if call else None,'aim',[(q['job'],round(q['desired']['y'],2),round(q['selected']['y'],2)) for q in aim])
