import fs from 'node:fs';
import zlib from 'node:zlib';
import {alignOffense} from '../../../src/playbook/alignment.ts';
import {linePicture,gapSurfaceIn} from '../../../src/sim/live-gaps.ts';
import {pullers} from '../../../src/sim/run-fits.ts';
const path='/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/COUNTER2.json.gz';
const d=JSON.parse(zlib.gunzipSync(fs.readFileSync(path)));
const out=[];
for (const time of [1.1,1.2,1.3,1.4,1.5,1.55,1.6,1.7,1.85,2,2.05,2.1]) {
 const tick=d.ticks.find(x=>x.t===time),call=d.calls.find(x=>x.t===time&&x.a===17);
 const cueList=d.cues.slice(...call.cues), seen=new Map();
 for(const cue of cueList)if(!seen.has(cue.b))seen.set(cue.b,cue.picture);
 const agents=d.initial.map(q=>({...q,engagement:tick.reps.some(r=>r.b===q.idx||r.d===q.idx)?{}:null,team:q.idx<11?'O':'D'}));
 const a=agents[17],sim={t:time,los:d.setup.los,ballY:d.setup.ballY,offAlign:alignOffense(d.setup.offCall.formation,d.setup.offCall.flip,d.setup.los,d.setup.ballY),offense:agents.slice(0,11),attackDir:()=>1,see:(_a,b)=>{const s=seen.get(b.idx);if(!s)throw Error('missing saved cue '+b.idx);return s;}};
 const p=linePicture(sim,a),gap=gapSurfaceIn(p,'C',1),ps=pullers(sim,a),gs=[];
 for(const b of p.departed) {
   const s=b.seen,dir=Math.sign(s.vel.y),arrive=s.pos.y+s.vel.y*.4,target=arrive+dir*.6;
   gs.push({idx:b.agent.idx,slot:b.agent.slot,pos:s.pos,vel:s.vel,target,deltaAlongPull:(target-gap.y)*dir,eligible:(target-gap.y)*dir>0&&(target-gap.y)*dir<6,countsAsPull:ps.includes(s)});
 }
 out.push({t:time,gap,departed:gs,firstCue:seen.get(6),request:call.command,aim:d.aims.find(x=>x.a===17&&x.t===time&&x.job==='run-fit')});
}
fs.writeFileSync('out/decision-commitment/defense/pull-objective.json',JSON.stringify({kind:'pure replay of saved consumed pictures; no World step, sensing or RNG',inputSha256:d.inputSha256,source:d.source,rows:out},null,2)+'\n');
for(const r of out) console.log(JSON.stringify({t:r.t,gap:r.gap.y,desired:r.aim.desired.y,pullers:r.departed,req:r.request.vel.y}));
