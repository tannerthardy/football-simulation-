import fs from 'node:fs';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {gaitLag} from '../../../src/physics/kinematics.ts';
import {requestToCover} from '../../../src/sim/motion-plan.ts';
import {track} from '../../../src/sim/behaviors/common.ts';
const outDir='out/decision-commitment/defense',path='/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/COUNTER2.json.gz';
const tape=JSON.parse(zlib.gunzipSync(fs.readFileSync(path))),oldReplay=JSON.parse(fs.readFileSync(outDir+'/pull-objective.json'));
const source=fs.readFileSync('src/sim/run-fits.ts','utf8');
const oldText=`      if ((target - gy) * dir > 0 && (target - gy) * dir < PULL_REACH) {\n        gy = target; pullSide = dir; a.tags.add('fit-pull-read');\n      }`;
const newText=`      if ((target - gy) * dir > 0) {\n        gy += dir * Math.min((target - gy) * dir, PULL_REACH);\n        pullSide = dir; a.tags.add('fit-pull-read');\n      }`;
assert.equal(source.split(oldText).length,2,'isolated accepted pull overlay must match');
// Companion pull-bound.patch is a separately saved unified diff, validated with git apply --check.
// Deliberately pure copy of only this overlay. No tactics, sensing, RNG, body stepping, or held-action update.
function overlay(gy,pulls,kind,arm) {
 const changes=[];
 if(kind==='interior')return {gy,changes};
 for(const p of pulls) {
  const dir=Math.sign(p.vel.y),target=p.pos.y+p.vel.y*.4+dir*.6,delta=(target-gy)*dir;
  if(delta>0&&(arm==='clamp'||delta<6)) {
   const before=gy;gy=arm==='clamp'?gy+dir*Math.min(delta,6):target;
   changes.push({dir,target,delta,before,after:gy});
  }
 }
 return {gy,changes};
}
const rows=[];
for(const r of oldReplay.rows.filter(r=>r.t>=1.5&&r.t<=2.1)) {
 const pulls=r.departed.filter(p=>p.countsAsPull);
 // At these saved deep-mesh ticks before2.05 RB |vy|<1.5: FLOW_READ leaves gap as its input.
 // At2.05/2.10 there are no source-replay pullers. Thus both overlays are identity regardless of current RB-flow gy.
 const flowActive=Math.abs(r.firstCue.vel.y)>1.5;
 assert.ok(!flowActive||pulls.length===0,'do not infer unsaved current decisionInterval for flow-active arm');
 const old=overlay(r.gap.y,pulls,'insert','reject'),candidate=overlay(r.gap.y,pulls,'insert','clamp');
 const change=candidate.gy-old.gy;
 const newDesired={...r.aim.desired,y:r.aim.desired.y+change};
 rows.push({t:r.t,actualOldDesired:r.aim.desired,samePictureProposedDesired:newDesired,delta:change,flowActive,
   pullInputs:pulls.map(p=>({idx:p.idx,slot:p.slot,pos:p.pos,vel:p.vel})),oldOverlay:old,proposedOverlay:candidate,
   qualification:r.t>=2.05?'Pullers reconstructed with recorded tick reps; LG rep creation boundary is time-ambiguous. Proposed delta zero in this reconstruction. This is not a prediction of the native changed trajectory.':'Same consumed cue and same known gap; remaining recorded scrape/placement terms held identical.'});
}
const at=tape.ticks.find(t=>t.t===1.7),actor=tape.initial[17],a={body:at.before[17],profile:actor.profile,pos:at.before[17].pos,vel:at.before[17].vel};
const oldAim=tape.aims.find(x=>x.a===17&&x.t===1.7&&x.job==='run-fit'),newAim=rows.find(r=>r.t===1.7).samePictureProposedDesired;
const interval=oldAim.heldUntil-1.7,horizon=2*interval;
function request(goal,urgency=.75) {
 const fit=track(a,goal,{x:0,y:0},{speed:.78+.15*urgency,gain:3,facing:Math.PI});
 const vy=Math.max(-a.profile.vmax,Math.min(a.profile.vmax,requestToCover(gaitLag(a.profile),goal.y-a.pos.y,horizon,a.vel.y)));
 return {...fit,vel:{x:fit.vel.x,y:vy}};
}
const oldRequest=request(oldAim.selected),newRequest=request(newAim),actual=at.requests[17];
assert.ok(Math.abs(oldRequest.vel.x-actual.vel.x)<1e-12&&Math.abs(oldRequest.vel.y-actual.vel.y)<1e-12,'same-body accepted request must match recorded command');
for(const u of [.1,.5,.95]) for(const [goal,expected] of [[oldAim.selected,oldRequest],[newAim,newRequest]]) {
 const req=request(goal,u);assert.ok(Math.abs(req.vel.x-expected.vel.x)<1e-12&&Math.abs(req.vel.y-expected.vel.y)<1e-12,'unknown urgency does not bind either same-body request');
}
const savedRemote=oldReplay.rows.find(r=>r.t===1.7),remote=savedRemote.departed.find(p=>p.slot==='LG'&&p.countsAsPull);
const controls=[];
for(const kind of ['insert','cutback','interior']) {
 const baseline=overlay(savedRemote.gap.y,[remote],kind,'reject'),candidate=overlay(savedRemote.gap.y,[remote],kind,'clamp');
 controls.push({kind,synthetic:'Fresh observer first acquires this remote pull picture at1.70; same geometry, no earlier admitted pull. This is a contract probe, not a second native encounter.',gap:savedRemote.gap,pull:remote,baseline,candidate,delta:candidate.gy-baseline.gy});
}
// A different acquired threat into the installed gap: this probe only evaluates the existing declaration predicate.
const declaredSeen={pos:{x:39,y:30.2},vel:{x:4,y:0},carrying:true},declarationGap={y:30.2,width:1.2};
function declared(gy,kind) {
 const reachLos=Math.max(0,Math.min(1,(40-declaredSeen.pos.x)/Math.max(.5,declaredSeen.vel.x)));
 const crossing=declaredSeen.pos.y+declaredSeen.vel.y*reachLos,half=Math.max(.6,declarationGap.width/2);
 const isDeclared=Math.abs(crossing-gy)<half+1&&declaredSeen.pos.x>38.4;
 return {crossing,half,isDeclared,existingChaseBranch:isDeclared&&kind!=='cutback'};
}
const declarationControl={synthetic:'Same remote observed pull plus an acquired carrying runner declaring the originally installed C-gap. No trajectory claim.',seen:declaredSeen,
 baseline:declared(savedRemote.gap.y,'insert'),candidate:declared(overlay(savedRemote.gap.y,[remote],'insert','clamp').gy,'insert')};
const result={type:'Bounded pure sensitivity diagnostic; source never edited; no World steps, new observations, or RNG',
 baseSource:tape.source,inputSha256:tape.inputSha256,tapePath:path,tapeSha256:crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex'),
 proposedChange:oldText+'\n=>\n'+newText,rows,
 sameBodyAtExistingAdoption:{t:1.7,body:a.body.pos,velocity:a.vel,decisionIntervalFromActualNewHold:interval,horizon,actualRecordedRequest:actual,acceptedRecomputed:oldRequest,proposedRecomputed:newRequest,newAim,
 qualification:'Exact request law evaluation at the old trajectory and old1.70 adoption. Urgency sensitivity .10–.95 checked inactive. This is not an exact native counterfactual; changed earlier motion would change the body, cues and future timing.'},
 opposingControls:controls,declarationControl,
 decision:'HOLD naive clamp as production fix: it repairs the local disappearance but newly admits initially remote pulls, moves explicit cutback jobs, and can erase a real declared-runner threat. Run must define admission versus continuation of the installed duty before native comparison.'};
fs.writeFileSync(outDir+'/pull-bound-result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({rows:rows.map(r=>({t:r.t,old:r.actualOldDesired.y,proposed:r.samePictureProposedDesired.y})),sameBodyAt1_7:result.sameBodyAtExistingAdoption,controls:controls.map(c=>({kind:c.kind,delta:c.delta})),declarationControl,decision:result.decision},null,2));
