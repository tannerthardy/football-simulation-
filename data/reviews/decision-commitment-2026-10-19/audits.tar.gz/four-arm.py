import gzip,json,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent
load=lambda p:json.load(gzip.open(p))
base=Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline')
roots={'accepted':base,'metadata':O/'native/candidate','consumer':Path('/workspace/football-traffic-material-progress/out/traffic-material-progress/native'),'both':Path('/workspace/football-traffic-progress-composition/out/traffic-progress-composition/native')}
result={'qualification':'Two exact frozen inputs; separate arms before composition, unchanged accepted tape reused. Current output contrasts decisions/achieved motion, not uniform quality or causal grip claims. All event times retain original tick-entry convention; endpoint=t+.05.','cases':{}}
for k in ['DUO','TOSS']:
 rs={arm:load(root/f'{k}.json.gz') for arm,root in roots.items()}
 r0=rs['accepted'];rec={}
 for arm,r in rs.items():
  assert r['inputSha256']==r0['inputSha256'];assert r['setup']==r0['setup']
  common_initial=[{f:a[f] for f in a.keys()&b.keys()}=={f:b[f] for f in a.keys()&b.keys()} for a,b in zip(r0['initial'],r['initial'])];assert all(common_initial)
  rec[arm]={'path':str(roots[arm]/f'{k}.json.gz'),'sha256':hashlib.sha256((roots[arm]/f'{k}.json.gz').read_bytes()).hexdigest(),'source':r['source'],'inputSha256':r['inputSha256'],'phase':r['phase'],'outcome':r['outcome'],'gain':r['gain'],'endpoint':r['ticks'][-1]['completed'],'first_request':None,'first_intent':None,'first_body':None,'first_RNG':None,'selectedFS':[]}
  for a,b in zip(r0['ticks'],r['ticks']):
   for field,key in [('requests','first_request'),('intents','first_intent'),('after','first_body')]:
    if rec[arm][key] is None and a[field]!=b[field]:
     actors=[{'idx':i,'slot':r['initial'][i]['slot'],'id':r['initial'][i]['player']['id'],'before':a[field][i],'after':b[field][i]} for i in range(len(a[field])) if a[field][i]!=b[field][i]]
     if field=='after':actors=[{f:v[f] for f in ['idx','slot','id']} for v in actors]
     rec[arm][key]={'t':a['t'],'actors':actors}
   if rec[arm]['first_RNG'] is None and a['rng']!=b['rng']:rec[arm]['first_RNG']=a['t']
  idx=next(a['idx'] for a in r['initial'] if a['slot']=='FS')
  for t in r['ticks']:
   if any(abs(t['t']-v)<1e-7 for v in [2.4,2.55,2.85]):rec[arm]['selectedFS'].append({'t':t['t'],'pos':t['before'][idx]['pos'],'velocity':t['before'][idx]['vel'],'request':t['requests'][idx],'intent':t['intents'][idx],'ownGoal':t.get('requestObjectives',[None]*22)[idx]})
 result['cases'][k]=rec
(O/'four-arm.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:{a:{f:r[f] for f in ['phase','outcome','gain','first_RNG']}|{'first_intent_t':r['first_intent']['t'] if r['first_intent'] else None} for a,r in arms.items()} for k,arms in result['cases'].items()},indent=2))
