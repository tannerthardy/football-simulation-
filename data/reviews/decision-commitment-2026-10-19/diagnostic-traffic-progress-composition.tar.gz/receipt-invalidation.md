The original yield/typecheck child commands passed, but their wrappers correctly
returned exit1/inputsUnchanged=false because the parent committed the unchanged
protected files while they ran. Their source/test digests match the later frozen
commit, but these are retained as invalidated receipts, not passing validation.
Rerun only those two checks after freezing64d7838; keep the earlier31-check pass
from before that commit as source-compatible evidence with its actual head.
The first31-check command named traffic-yield.test.ts, which does not exist;
Vitest selected the four real named files and ran31 checks. Its missing8 were
subsequently run as spacing-yield.test.ts. Do not report39 from that first command.
No engine source or test semantics changed during these checks.
