import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {Agent} from '../../src/sim/agent.js';
import {spaceTeammates} from '../../src/sim/spacing.js';
import {withMovementObjective} from '../../src/sim/movement-objective.js';
import {previewFreeMovement} from '../../src/physics/movement-preview.js';
import type {Intent} from '../../src/physics/world.js';
const root=new URL('./',import.meta.url),outputs:any[]=[];
for(const[name,idx,start,end]of [['DUO',20,2.55,2.85],['TOSS',16,2.9,3.5]] as const){
 const data=JSON.parse(gunzipSync(readFileSync(new URL(`/workspace/football-decision-commitment/out/decision-commitment/native/candidate/${name}.json.gz`,'file://'))).toString());
 const init=data.initial[idx],first=data.ticks[0].before[idx];
 const make=()=>new Agent(idx,'D',init.slot,init.player,first.profile,structuredClone(first),{kind:init.behavior,update(){throw Error('No new football decision');}});
 const actor=make(),legacy=make();actor.runFit=legacy.runFit=structuredClone(init.runFit);
 for(const tick of data.ticks){
  if(tick.t>end)break;
  const pictures=new Map<number,any>();
  for(const cue of data.cues){if(cue.t===tick.t&&cue.a===idx&&cue.consumer===null&&cue.b>=11&&cue.b!==idx)pictures.set(cue.b,structuredClone(cue.picture));}
  if(pictures.size!==10)continue;
  const peers=[...pictures].map(([j])=>({idx:j,team:'D',profile:data.initial[j].profile,get pos(){throw Error('Hidden peer position');},get vel(){throw Error('Hidden peer velocity');}} as unknown as Agent));
  const goal=tick.requestObjectives[idx],raw:Intent=structuredClone(tick.requests[idx]);
  function choose(a:Agent,ownGoal:boolean){
   Object.assign(a.body,structuredClone(tick.before[idx]));
   let command:Intent=structuredClone(raw);
   if(goal&&(ownGoal||goal.kind!=='fixed'))command=withMovementObjective(command,goal);
   const intents:Intent[]=[command,...peers.map(()=>({vel:{x:0,y:0},free:true}))];let reads=0;
   const prev=data.ticks.find((r:any)=>r.t===Math.round((tick.t-.05)*100)/100);
   const constrained=prev?.contacts.some((c:any)=>c.i===idx||c.j===idx)||tick.reps.some((r:any)=>r.b===idx||r.d===idx);
   spaceTeammates([a,...peers],intents,(_a,p)=>{reads++;return pictures.get(p.idx);},{now:tick.t,constrained:constrained?new Set([a.body]):undefined});
   if(reads!==10)throw Error(`Extra observations ${reads}`);
   return intents[0];
  }
  const old=choose(legacy,false),next=choose(actor,true);
  if(tick.t<start)continue;
  function score(command:Intent){
   const body=structuredClone(tick.before[idx]),path=previewFreeMovement(body,command,tick.t,12),last=path.at(-1)!;
   let minimum=Infinity,peer=null;
   for(const[j,p]of pictures){
    const touch=.9*(body.profile.radius+data.initial[j].profile.radius);
    let x=body.pos.x-p.pos.x,y=body.pos.y-p.pos.y,best=Math.hypot(x,y)-touch;
    for(const s of path){const rx=s.pos.x-p.pos.x-p.vel.x*s.t,ry=s.pos.y-p.pos.y-p.vel.y*s.t,dx=rx-x,dy=ry-y,u=Math.max(0,Math.min(1,-(x*dx+y*dy)/Math.max(1e-12,dx*dx+dy*dy)));best=Math.min(best,Math.hypot(x+u*dx,y+u*dy)-touch);x=rx;y=ry;}
    if(best<minimum){minimum=best;peer={idx:j,slot:data.initial[j].slot,id:data.initial[j].player.id,picture:p};}
   }
   const speed=Math.hypot(raw.vel.x,raw.vel.y),progress=((last.pos.x-body.pos.x)*raw.vel.x+(last.pos.y-body.pos.y)*raw.vel.y)/speed;
   const flow=goal?.kind==='moving'?goal.velocity:{x:0,y:0};
   return {command,minimum,peer,progress,allUp:path.every(s=>s.support==='up'),first:path[0],last,goalError:goal?Math.hypot(last.pos.x-goal.point.x-(flow?.x??0)*last.t,last.pos.y-goal.point.y-(flow?.y??0)*last.t):null};
  }
  const entry={case:name,t:tick.t,actor:{idx,slot:init.slot,id:init.player.id},goal,body:tick.before[idx],raw,legacy:score(old),candidate:score(next),nativeIntent:tick.intents[idx],nativeReproduced:next.vel.x===tick.intents[idx].vel.x&&next.vel.y===tick.intents[idx].vel.y};outputs.push(entry);
 }
}
writeFileSync(new URL('spacing-replay.json',root),JSON.stringify({source:'accepted source plus diagnostic material-progress consumer; exact digest in receipt',qualification:'Same acquired picture/body, held command0.6s free forecast. No new native snap, sight, RNG or future receiver/runner motion. Independent spacing maneuver state replayed from existing snapshots. Old fixed metadata removed only, existing moving objectives retained.',rows:outputs},null,2)+'\n');
for(const r of outputs.filter(r=>['DUO2.55','DUO2.85','TOSS2.9','TOSS2.95','TOSS3.1','TOSS3.5'].includes(r.case+r.t))){console.log(JSON.stringify({case:r.case,t:r.t,reproduced:r.nativeReproduced,goal:r.goal,old:{vel:r.legacy.command.vel,clear:r.legacy.minimum,progress:r.legacy.progress,error:r.legacy.goalError,peer:r.legacy.peer},candidate:{vel:r.candidate.command.vel,clear:r.candidate.minimum,progress:r.candidate.progress,error:r.candidate.goalError,peer:r.candidate.peer,allUp:r.candidate.allUp}},null,2));}
