Receivers currently reduce effort to `.55` immediately when hidden throw attribution names somebody else, while the same early return skips ordinary waypoint progress and cut skill. Remove that private-target branch so RouteRunner keeps its installed responsibility and ordinary pace until the existing assignment transition replaces it. Physics, capacities, catching and blocking laws are unchanged.

Four actual-controller contracts distinguish hidden attribution from installed route progress and legitimate completion/gathering. Accepted source fails two and passes the opposing controls; the candidate passes all four plus 26 existing press/forecast/consumer checks. Typecheck passes. Independent nonauthor review approves the narrow correction.

Two exact current-source native inputs retain PASS13's Y completion/22.74-yard tackle and PA13's incomplete, with exact RNG channels throughout. PASS13's X/Z/H preserve ordinary vertical pace and make 2.55–2.70 yards more downfield progress during flight. These are changed trajectories, not outcome-identity proof. **Adverse:** PA13's faster shallow continuation creates a new H–LB collision and two contact falls; existing route traffic/avoidance remains insufficiently established. The report preserves the request/physical/contact sequence and the broader global-flight, catch-transfer and legacy-option information debts.

Base `f4146275ce7539816bf57b4ed55a0d2be10e48c7`; code `279d26ececa443504aec7ad760aad9b9ece9ee85`; runtime `62e740cda23aef7f178754ccd045017deee9b8e77b90aaeb5b0d45aff820237c`. Same 44 baseline flags. No broad campaign/full-suite repeat; Integration owns combined verification. Common immutable evidence link will be added before publication.

See [causal report](docs/reviews/receiver-route-effort-2026-10-19.md).
