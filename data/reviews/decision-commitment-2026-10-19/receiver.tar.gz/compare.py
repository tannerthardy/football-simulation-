"""Pure saved-tape comparison. No simulation, perception query or new RNG draw."""
import gzip, hashlib, json, math, pathlib
ROOT = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline')
def load(path):
    with gzip.open(path, 'rt') as f: return json.load(f)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def magnitude(v): return math.hypot(v['x'], v['y'])
def first_difference(a, b, field):
    for x, y in zip(a['ticks'], b['ticks']):
        if x[field] != y[field]:
            actors = [i for i, (p, q) in enumerate(zip(x[field], y[field])) if p != q] if isinstance(x[field], list) else None
            return {'tickEntry': x['t'], 'tickCompleted': x['completed'],
                    'actors' if field in ['requests','intents','before','after'] else 'elementIndices': actors}
    return None
def actor_sample(row, t, idx):
    tick = next(x for x in row['ticks'] if x['t'] == t)
    body = tick['before'][idx]
    return {'position': body['pos'], 'velocity': body['vel'], 'speed': magnitude(body['vel']),
            'rawRequest': tick['requests'][idx], 'finalRequest': tick['intents'][idx],
            'supportState': body['support']['state']}
def actor_summary(a, b, idx):
    result = {'idx': idx, 'slot': a['initial'][idx]['slot'], 'player': a['initial'][idx]['player']['id']}
    for field in ['requests', 'intents', 'before', 'after']:
        result['first_'+field+'_difference'] = next((x['t'] for x, y in zip(a['ticks'], b['ticks']) if x[field][idx] != y[field][idx]), None)
    result['maxPositionDeltaYd'] = max(math.dist(x[field][idx]['pos'].values(), y[field][idx]['pos'].values())
                                        for x, y in zip(a['ticks'], b['ticks']) for field in ['before','after'])
    return result
summary = {'schema': 'receiver-route-effort-native-comparison-v1', 'operator': str(pathlib.Path(__file__).name),
           'operatorSha256': sha(pathlib.Path(__file__)), 'newSimulationsByOperator': 0, 'cases': []}
for name in ['PASS13', 'PA13']:
    basepath, candidatepath = BASE / f'{name}.json.gz', ROOT / 'native' / f'{name}.json.gz'
    a, b = load(basepath), load(candidatepath)
    assert a['inputSha256'] == b['inputSha256'] and a['setup'] == b['setup']
    assert a['source'] == '7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197'
    assert b['source'] == '62e740cda23aef7f178754ccd045017deee9b8e77b90aaeb5b0d45aff820237c'
    assert len(a['ticks']) == len(b['ticks'])
    assert [x['t'] for x in a['ticks']] == [x['t'] for x in b['ticks']]
    row = {'id':name, 'inputSha256':a['inputSha256'],
           'files':{'accepted':{'path':str(basepath),'sha256':sha(basepath),'source':a['source']},
                    'candidate':{'path':str(candidatepath),'sha256':sha(candidatepath),'source':b['source']}},
           'outcomes':[{'phase':x['phase'],'outcome':x['outcome'],'gain':x['gain'],'endTime':x['ticks'][-1]['completed']}for x in [a,b]],
           'firstDifferences':{f:first_difference(a,b,f)for f in ['requests','intents','before','after','rng','ball','contacts','reps']},
           'actors':[actor_summary(a,b,i)for i in [0,6,7,8,9,10,17,20]],
           'events':{'accepted':a['events'],'candidate':b['events']}, 'samples':[]}
    samples = [2.75,2.8,3,3.5,3.8,3.85,5.05,5.65] if name == 'PASS13' else [2.4,2.65,2.8,3,3.05,3.1,3.5]
    for t in samples:
        row['samples'].append({'t':t,'actors':[{'idx':i,'slot':a['initial'][i]['slot'],
             'accepted':actor_sample(a,t,i),'candidate':actor_sample(b,t,i)}for i in ([6,7,8,9,10,20]if name=='PASS13'else[6,7,8,9,10,17])]})
    if name == 'PASS13':
        row['verticalFlightProgress'] = []
        for i in [8,9,10]:
            first,last=2.8,3.8
            p0,p1,q0,q1=actor_sample(a,first,i),actor_sample(a,last,i),actor_sample(b,first,i),actor_sample(b,last,i)
            row['verticalFlightProgress'].append({'idx':i,'slot':a['initial'][i]['slot'],
                'measurement':'downfield x displacement during the vertical flight, not private waypoint progress',
                'acceptedYd':p1['position']['x']-p0['position']['x'],'candidateYd':q1['position']['x']-q0['position']['x']})
    else:
        row['adverseCollision'] = {'tickEntry':3,'tickCompleted':3.05,
          'accepted':[c for t in a['ticks']if t['t']==3 for c in t['contacts']if {c['i'],c['j']}=={10,17}],
          'candidate':[c for t in b['ticks']if t['t']==3 for c in t['contacts']if {c['i'],c['j']}=={10,17}],
          'rngSameThroughout':all(x['rng']==y['rng']for x,y in zip(a['ticks'],b['ticks'])),
          'qualification':'Added physical encounter after receiver continuation; not a random execution draw. Existing route traffic/avoidance policy is unchanged.'}
    summary['cases'].append(row)
(ROOT/'native-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'operatorSha256':summary['operatorSha256'],'resultSha256':sha(ROOT/'native-comparison.json'),
 'cases':[{'id':x['id'],'firstDifferences':x['firstDifferences'],'outcomes':x['outcomes']}for x in summary['cases']]},indent=2))
