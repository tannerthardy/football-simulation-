import assert from 'node:assert/strict';
import {mkdirSync,readFileSync,writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {Rng} from '../../src/core/rng.ts';
import {CENTER_Y} from '../../src/core/field.ts';
import {generateTeam,pickOffense,pickDefense} from '../../src/league/team.ts';
import {RUN_BY_ID,PASS_BY_ID} from '../../src/playbook/concepts.ts';
import {FRONT_BY_ID,COVERAGE_BY_ID} from '../../src/playbook/defense.ts';
import {FORMATION_BY_ID} from '../../src/playbook/formations.ts';
import {PlaySim} from '../../src/sim/playsim.ts';
import {sourceVersion} from '../../scripts/source-version.ts';
const [mode='plan',out='out/defensive-snap-response/baseline',arm='baseline']=process.argv.slice(2);
const specs=[{id:'DUO',run:'duo',seed:11},{id:'TOSS',run:'toss',seed:13},{id:'IZ',run:'iz_strong',seed:3},{id:'PA',pass:'pa_flood',seed:11}];
if(mode==='plan'){console.log(JSON.stringify({question:'Snap gate versus motor response versus installed objective',specs,simulatedSnaps:0}));process.exit(0)}
assert.equal(mode,'run');assert(['baseline','diagnostic-half'].includes(arm));mkdirSync(out,{recursive:true});const begin=performance.now(),rows=[];
const offense=generateTeam(new Rng(31),'Snap O','SO',{strength:.55}),defense=generateTeam(new Rng(32),'Snap D','SD',{strength:.55});
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
for(const spec of specs){
 const setup={offense:pickOffense(offense,'11'),defense:pickDefense(defense,'base43'),offCall:{formation:FORMATION_BY_ID.ace_11,flip:false,kind:spec.run?'run':'pass',run:spec.run?RUN_BY_ID[spec.run]:undefined,pass:spec.pass?PASS_BY_ID[spec.pass]:undefined,label:spec.id},defCall:{personnel:'base43',front:FRONT_BY_ID.over,coverage:COVERAGE_BY_ID.cover3,pressure:null,label:'Over Cover3'},los:40,ballY:CENTER_Y,firstDownX:50,seed:spec.seed,record:true,recordEvery:1,recordLevel:'full'};
 assert(setup.offCall.run||setup.offCall.pass);const sim=new PlaySim(structuredClone(setup)),home=sim.agents.map(a=>({...a.pos})),cues=[],ticks=[],calls=[];
 const initial=sim.agents.map(a=>({idx:a.idx,slot:a.slot,player:a.player,profile:a.profile,pos:{...a.pos},snapReadyAt:a.snapReadyAt,mindSnapDelay:a.mind.snapDelay,runFit:a.runFit,behavior:a.behavior.kind,role:sim.defAlign.spots[a.slot]?.role??null}));
 if(arm==='diagnostic-half')for(const a of sim.defense){
  // Sensitivity only. Apply the exact diagnostic before constructor jitter,
  // preserving actual selected jitter and constructor RNG; no default change.
  const reduction=.5*a.profile.reactionTime*(1-.4*a.r('anticipation'));
  const old=a.snapReadyAt;a.snapReadyAt=Math.max(.02,old-reduction);
  if(a.behavior.kind==='rush')a.behavior.getOff=a.snapReadyAt;
  if(a.behavior.kind==='blitz')a.behavior.delay=a.snapReadyAt;
 }
 const see=sim.see.bind(sim);let consumer=null;sim.see=(a,b,...rest)=>{const p=see(a,b,...rest);if(a.team==='D')cues.push({t:sim.t,a:a.idx,b:b.idx,consumer,picture:structuredClone(p)});return p};
 for(const a of sim.agents){const behavior=a.behavior,update=behavior.update;behavior.update=function(...args){consumer=a.idx;const start=cues.length;const cmd=update.apply(this,args);consumer=null;calls.push({t:sim.t,a:a.idx,kind:this.kind,read:a.recog?.read,readAt:a.recog?.readAt,command:structuredClone(cmd),cues:[start,cues.length]});return cmd}}
 const step=sim.world.step.bind(sim.world);sim.world.step=(intents,dt)=>{const before=sim.agents.map(a=>structuredClone(a.body));const report=step(intents,dt);ticks.push({t:sim.t,completed:sim.t+dt,before,requests:structuredClone(sim.cmds),intents:structuredClone(intents),after:sim.agents.map(a=>structuredClone(a.body)),reps:sim.engagements.map(e=>({b:e.blocker.idx,d:e.defender.idx,phi:e.phi,control:e.control,normal:e.hands?.normalForce,tangent:e.hands?.tangentForce})),contacts:report.contacts,reads:sim.agents.map(a=>({read:a.recog?.read,readAt:a.recog?.readAt,snapReadyAt:a.snapReadyAt})),ball:{kind:sim.ball.kind,carrier:sim.carrier?.idx},rng:JSON.stringify(sim.rng)});return report};
 const start=performance.now();sim.event('snap',sim.slot('C'));while(sim.phase==='live'&&sim.t<6){assert(performance.now()-start<5000);sim.tick()}
 const result=sim.buildResult();const starts=initial.map(a=>{const i=a.idx;return{slot:a.slot,ready:a.snapReadyAt,firstRequest:ticks.find(f=>Math.hypot(f.requests[i].vel.x,f.requests[i].vel.y)>.1)?.t??null,firstIntent:ticks.find(f=>Math.hypot(f.intents[i].vel.x,f.intents[i].vel.y)>.1)?.t??null,firstSpeed:ticks.find(f=>Math.hypot(f.after[i].vel.x,f.after[i].vel.y)>.1)?.completed??null,displacement015:ticks.find(f=>Math.hypot(f.after[i].pos.x-home[i].x,f.after[i].pos.y-home[i].y)>=.15)?.completed??null,firstRunRead:ticks.find(f=>f.reads[i].read==='run')?.t??null}});
 const row={id:spec.id,inputSha256:hash(setup),setup,initial,starts,ticks,calls,cues,phase:sim.phase,outcome:sim.phase==='live'?null:result.outcome,gain:sim.phase==='live'?null:result.offenseYards,events:sim.events,result,source:sourceVersion(),elapsedSeconds:(performance.now()-start)/1000};writeFileSync(out+'/'+spec.id+'.json.gz',gzipSync(JSON.stringify(row)));rows.push({id:row.id,inputSha256:row.inputSha256,phase:row.phase,outcome:row.outcome,gain:row.gain,elapsedSeconds:row.elapsedSeconds,starts:starts.filter(s=>/DE|DT|LB/.test(s.slot))});console.log(JSON.stringify(rows.at(-1)));
}
const profile=JSON.parse(readFileSync('config/baseline.json'));writeFileSync(out+'/receipt.json',JSON.stringify({source:sourceVersion(),arm,node:process.version,flags:profile.flags,worldDefaults:profile.worldDefaults,elapsedSeconds:(performance.now()-begin)/1000,rows,qualification:'Native current accepted source; passive consumed cue/request/achieved movement. diagnostic-half is an explicit post-constructor sensitivity intervention, not an exact replay of research DEF_GETOFF or a candidate. Actual raw commands kept; completed physics timestamps distinct from tick entry. No NFL recollection or games.'},null,2));
