import pathlib,tarfile,io,subprocess,shutil
p=pathlib.Path('out/defensive-snap-response').resolve();root=pathlib.Path.cwd();s=(p/'probe.mjs').read_text()
a=s.index('const specs=');b=s.index('\nif(mode',a)
s=s[:a]+"const specs=[{id:'PASS13',pass:'four_verts',seed:13},{id:'PA13',pass:'pa_flood',seed:13},{id:'FTOSS',run:'toss',seed:13,fresh:true},{id:'FTOSS-L',run:'toss',seed:13,fresh:true,flip:true}];"+s[b:]
s=s.replace("assert.equal(mode,'run');","assert(['run','prepare'].includes(mode));").replace("flip:false,kind:spec.run?","flip:!!spec.flip,kind:spec.run?")
s=s.replace("offense:pickOffense(offense,'11'),defense:pickDefense(defense,'base43')","offense:pickOffense(spec.fresh?generateTeam(new Rng(41),'Snap O','SO',{strength:.55}):offense,'11'),defense:pickDefense(spec.fresh?generateTeam(new Rng(42),'Snap D','SD',{strength:.55}):defense,'base43')")
s=s.replace("if(arm==='diagnostic-half')for", "if(mode==='prepare'){rows.push({id:spec.id,inputSha256:hash(setup),setup,plans:sim.defense.map(a=>({slot:a.slot,plan:a.behavior.plan,job:a.runFit}))});continue}\n if(arm==='diagnostic-half')for")
s=s.replace("const profile=JSON.parse", "if(mode==='prepare'){writeFileSync(out+'/inputs.json.gz',gzipSync(JSON.stringify(rows)));console.log(JSON.stringify(rows.map(r=>({id:r.id,powerEdges:r.plans.filter(p=>p.plan==='power'&&p.job.kind==='edge')}))));process.exit(0)}\nconst profile=JSON.parse")
s=s.replace('Native current accepted source; passive','Native identified source; passive')
(p/'fresh-probe.mjs').write_text(s)
host=p/'baseline-host';host.mkdir();raw=subprocess.check_output(['git','archive','f4146275ce7539816bf57b4ed55a0d2be10e48c7','src','config','scripts','package.json','package-lock.json','.nvmrc'])
with tarfile.open(fileobj=io.BytesIO(raw))as ar:ar.extractall(host,filter='data')
(host/'node_modules').symlink_to(root/'node_modules',target_is_directory=True);(host/'out/defensive-snap-response').mkdir(parents=True);shutil.copy2(p/'fresh-probe.mjs',host/'out/defensive-snap-response/fresh-probe.mjs')
