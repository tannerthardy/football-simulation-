"""Publish existing evidence only; independently verify source restoration."""
import pathlib,hashlib,json,difflib,tarfile,subprocess,os,tempfile,shutil
p=pathlib.Path(__file__).resolve().parent;root=p.parents[1];bundle=p/'publication';common=bundle/'common';common.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();code=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
def files(host):return {str(f.relative_to(host)):f.read_bytes() for f in (host/'src').rglob('*') if f.is_file()}
def digest(fs):
 h=hashlib.sha256()
 for name in sorted(fs):h.update(name.encode()+b'\0'+fs[name]+b'\0')
 return h.hexdigest()
base=files(p/'baseline-host');assert digest(base)=='7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197'
quick=dict(base);quick['src/sim/agent.ts']=(p/'quick-agent.ts').read_bytes();candidate=files(root)
records={}
for arm,fs,expected in [('edge',candidate,'7c154e46a860b8fbc8152298865e10fbe57ae5605fa580485ba01529364d17ed'),('simple-response-latency',quick,'7e99e521a256e856b03e8fcfb0e18014f302a0443c4a18738941beaf7899d96d')]:
 assert digest(fs)==expected
 patch=''.join(''.join(difflib.unified_diff(base[name].decode().splitlines(True),fs[name].decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name)) for name in sorted(fs) if fs[name]!=base[name])
 path=common/(arm+'.patch');path.write_text(patch)
 with tempfile.TemporaryDirectory(prefix='defensive-snap-restore-',dir='/tmp') as folder:
  dest=pathlib.Path(folder)
  for name,b in base.items():(dest/name).parent.mkdir(parents=True,exist_ok=True);(dest/name).write_bytes(b)
  env=dict(os.environ);env['GIT_CEILING_DIRECTORIES']='/tmp'
  subprocess.run(['git','apply','--check',str(path)],cwd=dest,env=env,check=True);subprocess.run(['git','apply',str(path)],cwd=dest,env=env,check=True)
  assert digest(files(dest))==expected
 records[arm]={'sourceSha256':expected,'patch':path.name,'patchSha256':sha(path.read_bytes()),'changedFiles':[name for name in sorted(fs) if fs[name]!=base[name]],'restorationVerified':True}
for f in sorted(p.iterdir()):
 if f.is_file() and f.suffix in ['.json','.mjs','.py','.ts','.log','.md','.png','.svg']:shutil.copy2(f,common/f.name)
for name in ['config/baseline.json','scripts/baseline.mjs','scripts/source-version.ts','package-lock.json','.nvmrc']:shutil.copy2(root/name,common/pathlib.Path(name).name)
(common/'candidate-code-tests.patch').write_bytes(subprocess.check_output(['git','diff','--binary','f4146275ce7539816bf57b4ed55a0d2be10e48c7',code,'--','src','test'],cwd=root))
for path,name in [('scripts/diag/open-field/getoff.py','research-getoff.py'),('scripts/diag/stretch/dbhits.py','research-dbhits.py')]:
 (common/name).write_bytes(subprocess.check_output(['git','show','336e8fc940d08d119926276b7a4c7242eafb437a:'+path],cwd=root))
archives=[]
for group,folders in [('native-original',['baseline','half','candidate','edge']),('native-transfer',['fresh-baseline','fresh-edge','fresh-inputs']),('common',None)]:
 members=[(f,str(f.relative_to(p))) for d in folders for f in sorted((p/d).iterdir()) if f.is_file()] if folders else [(f,str(f.relative_to(common))) for f in sorted(common.iterdir()) if f.is_file()]
 entries=[{'path':name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f,name in members]
 path=bundle/(group+'.tar.gz')
 with tarfile.open(path,'w:gz',compresslevel=1) as ar:
  for f,name in members:
   assert not f.is_symlink() and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
   ar.add(f,arcname=name,recursive=False)
 assert path.stat().st_size<32*1024**2
 with tarfile.open(path) as ar:
  assert len(ar.getmembers())==len(entries)
  for item,entry in zip(ar.getmembers(),entries):assert item.isfile() and item.name==entry['path'] and sha(ar.extractfile(item).read())==entry['sha256']
 archives.append({'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'members':entries})
analysis=json.loads((p/'analysis.json').read_text())
manifest={'schema':'defensive-snap-response-v1','codeCommit':code,'acceptedDevelop':analysis['acceptedDevelop'],'queue':analysis['queue'],'baselineSourceSha256':digest(base),'sourcePatches':records,'archives':archives,'cost':{k:v for k,v in analysis['cost'].items() if k not in ['focused','typecheck']},'status':'Review-only power-edge candidate. No latency or experiment/default activation. Adverse toss and PA-pressure tradeoff retained; independent Run disposition required.','qualification':['half is an explicit post-constructor sensitivity intervention, not an exact replay of DEF_GETOFF=0.5; original inline comment overstates equivalence. Effective gates are tick reads, not initial/starts.ready saved before intervention.','candidate/ directory is the separate existing-simple-response latency trial, not the retained edge code.','Original probe receipt description says current accepted source; arm source digests and exact patches determine actual runtime.','Archived baseline host inherits outer HEAD and has empty validation digest; accepted source digest, patch restoration, full inputs and tool hashes establish provenance, not that metadata field.','Full result equality is an unaffected-control property; live prefixes have null final outcome/gain and are not completed passes or tackles.','Load samples lack episode IDs and do not prove a single continuous grip.','Raw records contain generated players only. No new NFL collection/extraction, games, or full-suite repeats.']}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(bundle/'SHA256SUMS').write_text(''.join(a['sha256']+'  '+a['path']+'\n' for a in archives));print(json.dumps({a['path']:a['bytes'] for a in archives}))
