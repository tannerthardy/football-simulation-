"""Saved-tape reduction only. No engine execution or new sensing."""
import gzip,json,statistics,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent
load=lambda arm,case:json.load(gzip.open(p/arm/(case+'.json.gz')))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
base_cases=['DUO','TOSS','IZ','PA']; fresh_cases=['PASS13','PA13','FTOSS','FTOSS-L']
groups={k:base_cases for k in ['baseline','half','candidate','edge']}|{k:fresh_cases for k in ['fresh-baseline','fresh-edge']}
all_rows={arm:{case:load(arm,case) for case in cases} for arm,cases in groups.items()}
summary={'acceptedDevelop':'f4146275ce7539816bf57b4ed55a0d2be10e48c7','queue':'9a6bb795179a4b2e61ed59d25bcf23ca5e40f423','researchScriptPin':'336e8fc940d08d119926276b7a4c7242eafb437a','arms':{},'comparisons':[]}
for arm,rows in all_rows.items():
 receipt=json.loads((p/arm/'receipt.json').read_text())
 entries=[]
 for case,r in rows.items():
  entries.append({k:r[k] for k in ['id','inputSha256','source','phase','outcome','gain','elapsedSeconds']}|{'fileSha256':sha(p/arm/(case+'.json.gz')),'effectiveSnapGates':{a['slot']:r['ticks'][0]['reads'][a['idx']]['snapReadyAt'] for a in r['initial'] if a['idx']>=11},'tickCount':len(r['ticks']),'lastCompletedTime':r['ticks'][-1]['completed']})
 box=[s for r in rows.values() for s,a in zip(r['starts'],r['initial']) if a['idx']>=11 and -.5<=a['pos']['x']-r['setup']['los']<=2 and abs(a['pos']['y']-r['setup']['ballY'])<=4.5]
 fields=['firstRequest','firstIntent','firstSpeed','displacement015','firstRunRead']
 summary['arms'][arm]={'receipt':receipt,'cases':entries,'boxOperators':{k:{'median':statistics.median(vals) if vals else None,'crossed':len(vals),'noncrossing':len(box)-len(vals)} for k in fields for vals in [[s[k] for s in box if s[k] is not None]]},'qualification':'These are tiny selected examples, not an NFL-calibration sample. .15 displacement is a different event from sensory readiness. half initial/starts.ready snapshot precedes its explicit intervention: do not read it as effective half readiness.'}
for left,right,cases in [('baseline','half',base_cases),('baseline','candidate',base_cases),('baseline','edge',base_cases),('fresh-baseline','fresh-edge',fresh_cases)]:
 for case in cases:
  a,b=all_rows[left][case],all_rows[right][case];assert a['inputSha256']==b['inputSha256'];assert summary['arms'][left]['receipt']['flags']==summary['arms'][right]['receipt']['flags']
  diff={key:next((x['t'] for x,y in zip(a['ticks'],b['ticks']) if x[key]!=y[key]),None) for key in ['requests','intents','before','after','reps','rng']}
  diff['shorterTickCount']=min(len(a['ticks']),len(b['ticks'])); diff['fullTicksEqual']=a['ticks']==b['ticks']
  summary['comparisons'].append({'left':left,'right':right,'id':case,'inputSha256':a['inputSha256'],'firstDifferences':diff,'completeResultEqual':a['result']==b['result']})
summary['tossAdverse']={}
for arm in ['baseline','edge']:
 r=all_rows[arm]['TOSS'];d=12;rb=6
 marks=[]
 for t in [.3,.4,.5,1,1.5,2,2.2,2.4,2.5,2.55,2.65]:
  f=min(r['ticks'],key=lambda f:abs(f['t']-t));cue=next((c for c in reversed(r['cues']) if c['a']==d and c['b']==rb and c['t']<=t),None)
  marks.append({'t':f['t'],'defender':{k:f['before'][d][k] for k in ['pos','vel']},'runner':{k:f['before'][rb][k] for k in ['pos','vel']},'raw':f['requests'][d],'final':f['intents'][d],'loadSamples':[e for e in f['reps'] if e['d']==d],'lastConsumedRBCue':cue})
 summary['tossAdverse'][arm]={'defenderSlot':'DE_S','defenderPlayer':r['initial'][d]['player'],'runnerPlayer':r['initial'][rb]['player'],'installedFit':r['initial'][d]['runFit'],'samples':marks,'events':[e for e in r['events'] if e['a'] in [d,rb] or e.get('b') in [d,rb]]}
summary['cost']={'nativePrefixes':sum(len(r) for r in all_rows.values()),'games':0,'fullSuiteRuns':0,'completedOutcomes':sum(r['phase']!='live' for rows in all_rows.values() for r in rows.values()),'livePrefixes':sum(r['phase']=='live' for rows in all_rows.values() for r in rows.values()),'nativeReceiptElapsedSeconds':sum(v['receipt']['elapsedSeconds'] for v in summary['arms'].values()),'focused':json.loads((p/'focused-launch.json').read_text()),'typecheck':json.loads((p/'typecheck-launch.json').read_text())}
(p/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'cost':{k:v for k,v in summary['cost'].items() if k not in ['focused','typecheck']},'focused':summary['cost']['focused']['exitCode'],'typecheck':summary['cost']['typecheck']['exitCode'],'identicalControls':[r['id'] for r in summary['comparisons'] if r['right']=='edge' and r['completeResultEqual']]}))
