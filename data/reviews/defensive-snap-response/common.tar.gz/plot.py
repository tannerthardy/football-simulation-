"""Plot actual saved coordinates only; zero simulator ticks."""
import os
os.environ['MPLCONFIGDIR']='/tmp/football-snap-response-mpl'
import gzip,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
fig,axs=plt.subplots(2,2,figsize=(12,10))
for col,arm in enumerate(['baseline','edge']):
 r=json.load(gzip.open(p/arm/'TOSS.json.gz'))
 for row,(start,end) in enumerate([(.3,.8),(1,2.8)]):
  ax=axs[row,col];fs=[f for f in r['ticks'] if start<=f['t']<=end]
  for i,c,label in [(6,'#3d8843','RB'),(7,'#b36b2d','Y blocker'),(12,'#2369ae','DE_S box edge')]:
   pts=[f['before'][i] for f in fs];ax.plot([d['pos']['x'] for d in pts],[d['pos']['y'] for d in pts],color=c,label=label)
   for t in ([.3,.5,.8] if row==0 else [1,2,2.4,2.55,2.8]):
    f=min(fs,key=lambda f:abs(f['t']-t));d=f['before'][i];ax.scatter(d['pos']['x'],d['pos']['y'],color=c,s=22)
    if i==12:ax.annotate(str(t),[d['pos']['x'],d['pos']['y']],xytext=(5,5),textcoords='offset points',fontsize=8)
  ax.axvline(40,color='gray',ls='--',label='LOS');ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('Field x (offense advances right), yd');ax.set_ylabel('Field y, yd; toss toward lower y')
  if row==0:
   f=fs[0];d=f['before'][12];v=f['requests'][12]['vel'];ax.arrow(d['pos']['x'],d['pos']['y'],v['x']*.13,v['y']*.13,width=.025,color='#2369ae',length_includes_head=True)
   ax.set_xlim(32,42);ax.set_ylim(20,27);ax.set_title(('Accepted baseline' if col==0 else 'Gap-entry candidate')+' — first request and approach')
  else:ax.set_xlim(32,42);ax.set_ylim(18,27);ax.set_title(('Accepted: body collision after missed reach' if col==0 else 'Candidate: missed reach; no body collision')+'\n1.0–2.8 s, while initially blocked')
axs[0,0].legend(fontsize=8,loc='lower left')
fig.suptitle('TOSS seed 13 — actual saved positions; unchanged snap latency / physics\nSource 7d23555a vs 7c154e46; arrows show requested velocity scaled 0.13 s')
fig.tight_layout();fig.savefig(p/'toss-geometry.png',dpi=140);fig.savefig(p/'toss-geometry.svg')
