/**
 * Outcome-selected selected-snap technique counterfactual. Every earlier snap
 * runs the published baseline. Only target ManCoverage.update and the matching
 * held-possession perception channel are replaced; this is NOT a final-native
 * candidate game. Observation makes no extra see/record/decision/RNG request.
 */
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join, resolve, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
import { gunzipSync, gzipSync } from 'node:zlib';
import { simulateGame } from './baseline-source/src/game/game.js';
import { ManCoverage as BaseManCoverage } from './baseline-source/src/sim/behaviors/defense.js';
import { Rng } from './baseline-source/src/core/rng.js';
import { gapY } from './baseline-source/src/playbook/alignment.js';

const root = resolve('.');
const dir = join(root, 'out/run-fit-follow-up');
const rawPath = join(root, 'data/reviews/pursuit-and-tackle/games/final-tail-audit.json.gz');
const input = JSON.parse(gunzipSync(readFileSync(rawPath)).toString());
const savedGame = input.rows.find((g: any) => g.gameIndex === 2);
const teams = input.leagueInputs.find((l: any) => l.league === savedGame.league).teams;
const originalHome = teams.find((t: any) => t.id === savedGame.home.id);
const originalAway = teams.find((t: any) => t.id === savedGame.away.id);
const targetSeed = 3438958840;
const expectedBaseline = '8bc3eec8d0b842021d000585bb71331be17d6a644c763b2e510303cb4372d942';
const baselineDir = join(dir, 'baseline-source');
const sha = (value: unknown) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const fileSha = (path: string) => createHash('sha256').update(readFileSync(path)).digest('hex');
const sourceSha = (sourceDir: string) => {
  const files = (folder: string): string[] => readdirSync(folder, { withFileTypes: true })
    .flatMap(e => e.isDirectory() ? files(join(folder, e.name)) : [join(folder, e.name)]);
  const hash = createHash('sha256');
  for (const file of files(join(sourceDir, 'src')).sort((a, b) => relative(sourceDir, a).localeCompare(relative(sourceDir, b), 'en', { sensitivity: 'variant' }))) {
    hash.update(relative(sourceDir, file)).update('\0').update(readFileSync(file)).update('\0');
  }
  return hash.digest('hex');
};
// Match the published sourceVersion's JS lexical path ordering exactly.
const exactSourceSha = (sourceDir: string) => {
  const files = (folder: string): string[] => readdirSync(folder, { withFileTypes: true })
    .flatMap(e => e.isDirectory() ? files(join(folder, e.name)) : [join(folder, e.name)]);
  const names = files(join(sourceDir, 'src')).map(f => relative(sourceDir, f)).sort();
  const hash = createHash('sha256');
  for (const name of names) hash.update(name).update('\0').update(readFileSync(join(sourceDir, name))).update('\0');
  return hash.digest('hex');
};
if (exactSourceSha(baselineDir) !== expectedBaseline || input.sourceBefore !== expectedBaseline || input.sourceAfter !== expectedBaseline)
  throw Error('Baseline archive/input is not the published 9c3c809 engine');
if (sha([originalHome, originalAway]) !== savedGame.beforeRosterSha256) throw Error('Saved starting roster differs');
const args = process.argv.slice(2);
const baselineOnly = args.includes('--baseline-only');
const candidateFlag = args.indexOf('--candidate');
const expectedFlag = args.indexOf('--expected');
const candidateDir = baselineOnly ? null : resolve(args[candidateFlag + 1] ?? '');
const expectedCandidate = baselineOnly ? null : args[expectedFlag + 1];
if (!baselineOnly && (candidateFlag < 0 || expectedFlag < 0 || !expectedCandidate || exactSourceSha(candidateDir!) !== expectedCandidate))
  throw Error('Provide a frozen --candidate archive and exact --expected source hash');
const candidateDefense: any = baselineOnly ? null : await import(pathToFileURL(join(candidateDir!, 'src/sim/behaviors/defense.ts')).href);
const candidatePerception: any = baselineOnly ? null : await import(pathToFileURL(join(candidateDir!, 'src/sim/perception.ts')).href);
const baseMethod = BaseManCoverage.prototype.update;

function canonical(sim: any, value: any, expandRoot = false): any {
  const agents = new Map(sim.agents.map((a: any) => [a, a.idx]));
  const bodies = new Map(sim.agents.map((a: any) => [a.body, a.idx]));
  const seen = new Map<object, string>();
  const visit = (v: any, path: string, expand = false): any => {
    if (v === null || typeof v !== 'object') return typeof v === 'function' ? '[function]' : v;
    if (!expand && v === sim) return { sim: true };
    if (!expand && agents.has(v)) return { agent: agents.get(v) };
    if (!expand && bodies.has(v)) return { body: bodies.get(v) };
    if (seen.has(v)) return { ref: seen.get(v) };
    seen.set(v, path);
    if (v instanceof Map) return { map: [...v].map(([k, val], i) => [visit(k, `${path}.${i}.key`), visit(val, `${path}.${i}.val`)]) };
    if (v instanceof Set) return { set: [...v].map((x, i) => visit(x, `${path}.${i}`)) };
    if (ArrayBuffer.isView(v)) return { typed: v.constructor.name, data: Array.from(v as any) };
    if (Array.isArray(v)) return v.map((x, i) => visit(x, `${path}.${i}`));
    return Object.fromEntries(Object.keys(v).sort().filter(k => typeof v[k] !== 'function').map(k => [k, visit(v[k], `${path}.${k}`)]));
  };
  return visit(value, 'root', expandRoot);
}

function snapshot(sim: any): any {
  return {
    t: sim.t, worldTime: sim.world.time, phase: sim.phase, outcome: sim.outcome, endSpot: canonical(sim, sim.endSpot),
    agents: sim.agents.map((a: any) => ({ idx: a.idx, team: a.team, slot: a.slot, player: canonical(sim, a.player),
      profile: canonical(sim, a.profile), body: canonical(sim, a.body, true), mind: canonical(sim, a.mind, true),
      recognition: canonical(sim, a.recog, true), behavior: canonical(sim, a.behavior, true),
      agentFields: canonical(sim, Object.fromEntries(Object.entries(a).filter(([k]) => !['player', 'profile', 'body', 'mind', 'recog', 'behavior'].includes(k)))) })),
    rng: canonical(sim, sim.rng, true), intents: canonical(sim, sim.intents), cmds: canonical(sim, sim.cmds),
    qbMind: canonical(sim, sim.qbMind, true), ball: canonical(sim, sim.ball), engagements: canonical(sim, sim.engagements),
    bond: canonical(sim, sim.bond), touchedAt: canonical(sim, sim.touchedAt), dives: canonical(sim, sim.dives), lunges: canonical(sim, sim.lunges),
    joints: canonical(sim, sim.world.joints), lastStep: canonical(sim, sim.lastStep), stats: canonical(sim, sim.stats), events: canonical(sim, sim.events),
    handoffAt: sim.handoffAt, throwAt: sim.throwAt, catchAt: sim.catchAt, catchX: sim.catchX, firstContactX: sim.firstContactX,
    possession: sim.possession, penalty: canonical(sim, sim.penalty), segments: canonical(sim, sim.segments),
    crossedLOS: sim.crossedLOS, scrambled: sim.scrambled, scrambleDrill: sim.scrambleDrill,
    nextRng: Object.assign(new Rng(0), sim.rng).nextU32(),
  };
}

/** Preserve every geometry/pose history slot; known initial pre-snap holder
 * was QB for the entire baseline staging period. Existing records acquire
 * future possession with exactly the candidate production record latency. */
function migratePossession(sim: any): () => void {
  const old: any = sim.perception;
  if (!(old.data instanceof Float64Array) || old.data.length !== 24 * sim.agents.length * 7) throw Error('Unexpected baseline perception layout');
  const next: any = new candidatePerception.PerceptionBuffer(sim.agents.length, sim.dt);
  if (next.data.length !== 24 * sim.agents.length * 8) throw Error('Unexpected candidate perception layout');
  next.head = old.head; next.count = old.count;
  for (let tick = 0; tick < 24; tick++) for (let agent = 0; agent < sim.agents.length; agent++) {
    const oldOffset = (tick * sim.agents.length + agent) * 7;
    const newOffset = (tick * sim.agents.length + agent) * 8;
    for (let field = 0; field < 7; field++) next.data[newOffset + field] = old.data[oldOffset + field];
    next.data[newOffset + 7] = agent === sim.qb.idx ? 1 : -1;
  }
  const record = next.record;
  next.record = function(states: any) { return record.call(this, states, sim.carrier?.idx ?? null); };
  sim.perception = next;
  return () => { next.record = record; sim.perception = old; };
}

function run(phase: 'baseline' | 'possession-only' | 'selected-man-fit', observe: boolean): any {
  const home = structuredClone(originalHome), away = structuredClone(originalAway);
  const seenSeeds: number[] = [], pictures: any[] = [], commands: any[] = [], samples: any[] = [];
  let initial: any = null, final: any = null, targetResult: any = null, initialPerception: any = null;
  const game = simulateGame(home, away, { seed: savedGame.seed, hooks: { playResult(sim: any) {
    seenSeeds.push(sim.rng.key);
    if (sim.rng.key !== targetSeed) return sim.run();
    if (initial) throw Error('Target seed appeared twice');
    initial = { offCall: canonical(sim, sim.offCall), defCall: canonical(sim, sim.defCall), los: sim.los, ballY: sim.ballY,
      firstDownX: sim.firstDownX, hurry: sim.hurry, wind: canonical(sim, sim.wind), snapContext: canonical(sim, sim.snapContext),
      offAlign: canonical(sim, sim.offAlign), defAlign: canonical(sim, sim.defAlign), state: snapshot(sim) };
    initialPerception = canonical(sim, sim.perception, true);
    const restorePerception = phase === 'baseline' ? () => {} : migratePossession(sim);
    const selected = phase === 'selected-man-fit' ? candidateDefense.ManCoverage.prototype.update : baseMethod;
    const originalUpdate = BaseManCoverage.prototype.update, step = sim.world.step, see = sim.see, tick = sim.tick;
    BaseManCoverage.prototype.update = observe ? function(a: any, s: any) {
      const start = pictures.length;
      const before = { t: s.t, observer: a.slot, target: this.target.slot, body: canonical(s, a.body, true),
        mind: canonical(s, a.mind, true), recognition: canonical(s, a.recog, true), fit: canonical(s, a.runFit),
        gapY: a.runFit ? gapY(s.offAlign, a.runFit.gap, a.runFit.side) : null, behavior: canonical(s, this, true) };
      const command = selected.call(this, a, s);
      commands.push({ ...before, command: structuredClone(command), picturesFrom: start, picturesTo: pictures.length });
      return command;
    } : selected;
    if (observe) {
      let beforeTick: any = null;
      sim.tick = function() { beforeTick = snapshot(this); return tick.call(this); };
      sim.see = function(a: any, b: any, ...rest: any[]) {
        const picture = see.call(this, a, b, ...rest);
        if (a.team === 'D') pictures.push({ t: this.t, worldTime: this.world.time, observer: a.slot, target: b.slot,
          scale: rest[0] ?? 1, picture: structuredClone(picture), carrier: this.carrier?.slot ?? null,
          handoffAt: this.handoffAt, read: a.recog?.read, fit: canonical(this, a.runFit), observerPos: { ...a.pos }, observerVel: { ...a.vel } });
        return picture;
      };
      sim.world.step = function(intents: any, dt: number) {
        const before = snapshot(sim);
        const report = step.call(this, intents, dt);
        samples.push({ t: sim.t, beforeTick, before, after: snapshot(sim), report: canonical(sim, report) });
        return report;
      };
    }
    try { targetResult = sim.run(); final = snapshot(sim); return targetResult; }
    finally { BaseManCoverage.prototype.update = originalUpdate; sim.world.step = step; sim.see = see; sim.tick = tick; restorePerception(); }
  } } });
  if (!targetResult || !initial || !final) throw Error('Target seed not reached');
  const targetLog = game.log.find((row: any) => row.index === 100);
  const priorLog = game.log.filter((row: any) => row.index < 100);
  const savedPriorLog = savedGame.log.filter((row: any) => row.index < 100).map(({ nativeInput, ...rest }: any) => rest);
  if (sha(priorLog) !== sha(savedPriorLog)) throw Error('Earlier game history changed');
  const gameSignature = sha({ score: game.score, log: game.log, quarterScores: game.quarterScores });
  if (phase !== 'selected-man-fit' && gameSignature !== savedGame.signature) throw Error('Baseline/possession-only changed original complete game');
  const raw = { offenseYards: targetResult.offenseYards, outcome: targetResult.outcome, duration: targetResult.duration, turnover: targetResult.turnover };
  const originalTarget = savedGame.log.find((row: any) => row.nativeInput?.seed === targetSeed);
  if (phase !== 'selected-man-fit' && sha(raw) !== sha(originalTarget.nativeInput.raw)) throw Error('Baseline target outcome differs from archived game');
  const result = { ...targetResult, frames: undefined, telemetry: undefined };
  return { phase, observe, initial, initialPerception, final, result, raw, targetLog, initialSha256: sha(initial), initialPerceptionSha256: sha(initialPerception),
    finalSha256: sha(final), resultSha256: sha(result), nextRng: final.nextRng, gameSignature, earlierLogSha256: sha(priorLog),
    seedsThroughTarget: seenSeeds.slice(0, seenSeeds.indexOf(targetSeed) + 1), pictures, commands, samples };
}

const rows: any[] = [];
for (const phase of baselineOnly ? ['baseline'] as const : ['baseline', 'possession-only', 'selected-man-fit'] as const) {
  const plain = run(phase, false), observed = run(phase, true);
  for (const key of ['initialSha256', 'initialPerceptionSha256', 'finalSha256', 'resultSha256', 'nextRng', 'gameSignature', 'earlierLogSha256'])
    if (plain[key] !== observed[key]) throw Error(`${phase} observer changed ${key}`);
  observed.observerVerified = true;
  observed.plainReceipts = Object.fromEntries(['initialSha256', 'initialPerceptionSha256', 'finalSha256', 'resultSha256', 'nextRng', 'gameSignature', 'earlierLogSha256'].map(k => [k, plain[k]]));
  rows.push(observed);
  console.log(JSON.stringify({ phase, raw: observed.raw, observerVerified: true, commands: observed.commands.length, samples: observed.samples.length, nextRng: observed.nextRng }));
}
for (const row of rows) {
  if (row.initialSha256 !== rows[0].initialSha256 || row.initialPerceptionSha256 !== rows[0].initialPerceptionSha256 || sha(row.seedsThroughTarget) !== sha(rows[0].seedsThroughTarget))
    throw Error('Selected-snap prehistory/read/RNG/state differ between phases');
}
if (rows.length > 1 && (rows[1].finalSha256 !== rows[0].finalSha256 || rows[1].resultSha256 !== rows[0].resultSha256 || rows[1].nextRng !== rows[0].nextRng))
  throw Error('Additional perception channel changed execution without the selected ManCoverage controller');
if (exactSourceSha(baselineDir) !== expectedBaseline || (!baselineOnly && exactSourceSha(candidateDir!) !== expectedCandidate)) throw Error('Frozen sources changed');
mkdirSync(dir, { recursive: true });
const output = join(dir, baselineOnly ? 'duo-transition-baseline.json.gz' : 'duo-transition-witness.json.gz');
writeFileSync(output, gzipSync(JSON.stringify({ schema: 'selected-snap-man-run-fit-counterfactual-v1', baselineSource: expectedBaseline,
  candidateMethodSource: expectedCandidate, candidateArchive: candidateDir ? relative(root, candidateDir) : null,
  toolSha256: fileSha(new URL(import.meta.url).pathname), inputSha256: fileSha(rawPath), gameIndex: 2, gameSeed: savedGame.seed, targetSeed,
  scope: 'Baseline native Game/PlaySim throughout; only selected-snap ManCoverage.update and delayed held-possession channel borrowed from candidate. This is a declared technique counterfactual, not a final-native candidate game.',
  observerGuarantee: 'Each phase rerun plain/observed; exact result, complete final target bodies/minds/intents/private RNG state plus copied-next-RNG and complete game log verified. All earlier game history and initial selected-snap geometry, bodies, minds, recognition, controllers, installed fits and RNG match.',
  limits: ['Outcome-selected single-play witness, not a frequency or calibration estimate.', 'Holding state in initial pre-snap history is QB possession, as in the selected baseline constructor; no gaze/occlusion model added.', 'Counterfactual does not include candidate Draw, fumble-whistle or any other production changes.', 'Complete GameResult log verified; hidden final game subsystem RNG is not exposed. Complete selected PlaySim RNG and body/mind/intent state are verified.', 'Candidate run-fit method may import candidate helpers; exact candidate archive hash is recorded.'], rows })));
console.log(JSON.stringify({ output: relative(root, output), baselineSource: expectedBaseline, candidateMethodSource: expectedCandidate, rows: rows.length }));
