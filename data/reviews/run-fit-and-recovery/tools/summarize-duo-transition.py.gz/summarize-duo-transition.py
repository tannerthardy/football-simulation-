"""Summarize only saved collector state; never re-simulates or replaces a cue."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/football-simulation-')
PACKET = ROOT / 'out/run-fit-follow-up/duo-transition-witness.json.gz'

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def file_digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

data = json.load(gzip.open(PACKET))
baseline, channel, candidate = data['rows']
commands = {(c['t'], c['observer'], c['target']): c for c in baseline['commands']}
changed = []
for c in candidate['commands']:
    key = c['t'], c['observer'], c['target']
    old = commands.get(key)
    if old and digest(old['command']) != digest(c['command']):
        changed.append((old, c))
if not changed:
    raise ValueError('No selected-snap command changed')
old, new = min(changed, key=lambda pair: pair[1]['t'])
t = new['t']
base_sample = next(s for s in baseline['samples'] if s['t'] == t)
new_sample = next(s for s in candidate['samples'] if s['t'] == t)
if digest(base_sample['beforeTick']) != digest(new_sample['beforeTick']):
    raise ValueError('Physical/mental state had already diverged before the first changed request')
for key in ['body', 'mind', 'recognition', 'fit', 'behavior', 'gapY']:
    if digest(old[key]) != digest(new[key]):
        raise ValueError(f'First-request actor already differed in {key}')
old_pictures = baseline['pictures'][old['picturesFrom']:old['picturesTo']]
new_pictures = candidate['pictures'][new['picturesFrom']:new['picturesTo']]
old_receiver = next(p for p in old_pictures if p['target'] == old['target'])
new_receiver = next(p for p in new_pictures if p['target'] == new['target'])
def without_channel(p):
    return {k: v for k, v in p.items() if k != 'carrying'}
if digest(old_receiver['picture']) != digest(without_channel(new_receiver['picture'])):
    raise ValueError('Position/velocity/stance/facing/pose/age changed in the causal receiver picture')
actor = new['observer']
first_positive = next(p for p in candidate['pictures'] if p['observer'] == actor
                      and p['target'] == new['target'] and p['picture'].get('carrying') is True)
last_negative = [p for p in candidate['pictures'] if p['observer'] == actor
                 and p['target'] == new['target'] and p['picture'].get('carrying') is False and p['t'] < t][-1]
def slot(sample, slot):
    return next(a for a in sample['before']['agents'] if a['slot'] == slot)
trajectory = []
for s in candidate['samples']:
    if not t <= s['t'] <= 3.0:
        continue
    b = next((x for x in baseline['samples'] if x['t'] == s['t']), None)
    if not b:
        break
    trajectory.append({'t': s['t'], 'baselineDefender': slot(b, actor)['body'],
                       'candidateDefender': slot(s, actor)['body'],
                       'baselineRunner': slot(b, new['target'])['body'],
                       'candidateRunner': slot(s, new['target'])['body'],
                       'baselineIntent': b['before']['intents'][slot(b, actor)['idx']],
                       'candidateIntent': s['before']['intents'][slot(s, actor)['idx']]})
physical_files = sorted(p.relative_to(ROOT / 'out/run-fit-follow-up/baseline-source').as_posix()
                        for p in (ROOT / 'out/run-fit-follow-up/baseline-source/src/physics').rglob('*') if p.is_file())
physical_files += ['src/players/physical.ts', 'src/players/types.ts']
capabilities = []
for relative in physical_files:
    old_hash = file_digest(ROOT / 'out/run-fit-follow-up/baseline-source' / relative)
    new_hash = file_digest(ROOT / 'out/run-fit-follow-up/final-source' / relative)
    if old_hash != new_hash:
        raise ValueError(f'Candidate changed shared physics/capability file {relative}')
    capabilities.append({'path': relative, 'sha256': old_hash, 'unchanged': True})
def important_events(row):
    return [e for e in row['result']['events'] if e['type'] in
            ['handoff', 'carrier_contact', 'tackle_wrap', 'tackle', 'fall', 'broken_tackle', 'missed_tackle', 'fumble', 'recovery', 'touchdown']]
loaded = next((s, j) for s in candidate['samples'] for j in s['after']['joints']
              if j['kind'] == 'grasp' and j.get('force', 0) > 1e-6)
slots = {a['idx']: a['slot'] for a in candidate['initial']['state']['agents']}
native_loads = []
for s in candidate['samples']:
    if s['t'] < 3.2:
        continue
    native_loads.append({
        't': s['t'], 'beforeGrasps': [j for j in s['before']['joints'] if j['kind'] == 'grasp'],
        'afterGrasps': [j for j in s['after']['joints'] if j['kind'] == 'grasp'],
        'falls': s['report']['falls'], 'work': s['report']['work'],
        'beforeBodies': [{'idx': a['idx'], 'slot': a['slot'], 'body': a['body']}
                         for a in s['before']['agents'] if a['slot'] in ['RB', 'LB_M', 'NB']],
        'afterBodies': [{'idx': a['idx'], 'slot': a['slot'], 'body': a['body']}
                        for a in s['after']['agents'] if a['slot'] in ['RB', 'LB_M', 'NB']],
    })
summary = {
    'schema': 'selected-snap-man-run-fit-summary-v1',
    'toolSha256': file_digest(Path(__file__)),
    'inputSha256': file_digest(PACKET),
    'baselineSource': data['baselineSource'],
    'candidateMethodSource': data['candidateMethodSource'],
    'scope': data['scope'],
    'initialStateShared': all(r['initialSha256'] == baseline['initialSha256'] for r in data['rows']),
    'earlierNativeGameHistoryShared': all(r['earlierLogSha256'] == baseline['earlierLogSha256'] for r in data['rows']),
    'allThreeObserverControlsExact': all(r['observerVerified'] for r in data['rows']),
    'channelOnlyFinalStateAndOutcomeUnchanged': (channel['finalSha256'], channel['resultSha256'], channel['nextRng']) ==
                                             (baseline['finalSha256'], baseline['resultSha256'], baseline['nextRng']),
    'firstChangedRequest': {
        't': t, 'observer': actor, 'target': new['target'],
        'preTickExactBodyMindRecognitionBehaviorRngAndIntentsShared': True,
        'actorBeforeUpdateExactBodyMindRecognitionBehaviorFitShared': True,
        'sameGeometryAndCueAgeExceptPossession': True,
        'baseline': old, 'candidate': new,
        'baselineReceiverPicture': old_receiver, 'candidateReceiverPicture': new_receiver,
    },
    'firstPositivePossessionCue': first_positive,
    'lastPrecedingNegativePossessionCue': last_negative,
    'physicalCapabilityModulesUnchanged': capabilities,
    'agentSlots': slots,
    'firstLoadedGrasp': {'t': loaded[0]['t'], 'joint': loaded[1],
                         'holder': slots[loaded[1]['a']['body']], 'held': slots[loaded[1]['b']['body']]},
    'maxAbsoluteWorkResidual': max(abs(s['report']['work']['residual']) for s in candidate['samples']),
    'nativeSupportAndLoadLifecycle': native_loads,
    'outcomes': [{k: r[k] for k in ['phase', 'raw', 'nextRng', 'finalSha256', 'resultSha256', 'gameSignature']} for r in data['rows']],
    'events': {r['phase']: important_events(r) for r in data['rows']},
    'earlyTrajectory': trajectory,
    'limits': data['limits'] + ['Same pre-first-change physical state proves the request transition, not that later gain changes have only one immediate physical cause.'],
}
target = ROOT / 'out/run-fit-follow-up/duo-transition-summary.json'
target.write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({
    'output': str(target.relative_to(ROOT)),
    'firstChangedRequest': {k: summary['firstChangedRequest'][k] for k in ['t', 'observer', 'target']},
    'baselineCommand': old['command'], 'candidateCommand': new['command'],
    'firstPositiveCue': {'t': first_positive['t'], 'age': first_positive['picture']['age']},
    'outcomes': [{'phase': r['phase'], **r['raw']} for r in data['rows']],
    'observerControls': 3,
}, indent=2))
