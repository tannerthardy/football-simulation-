"""Hash/reconstruct and archive saved evidence only. Never runs a simulator."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile

r=Path('out/support-escape');dest=Path('/tmp/football-support-escape-evidence/data/reviews/support-escape-objective-2026-10-20');dest.mkdir(parents=True,exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args])
base='2c98bed94adad8087c65f381d4090444ad283985';code='e634fd15efb574965e92715247c1470ae4229c31';tests='2220fdf99a472024607dc34e69d38219a4e056c2'
pair='72a9b96c4b7cdf73aaf8220da06b875fe0005367';three='2302b48fb56298605ec17aaa39cc7950f62b6c08'
paths=sorted(git('ls-tree','-r','--name-only',base,'src').decode().splitlines())
def source(ref,override=False):
 h=hashlib.sha256()
 for p in paths:h.update(p.encode()+b'\0'+git('show',f'{code if override and p=="src/sim/engagement.ts" else ref}:{p}')+b'\0')
 return h.hexdigest()
proof={'base':base,'runtime':code,'tests':tests,'baselineSource':source(base),'candidateSource':source(code),'singleFileProjectionSource':source(base,True),'pair':{'commit':pair,'source':source(pair)},'three':{'commit':three,'source':source(three)}}
assert proof['candidateSource']==proof['singleFileProjectionSource']=='db77ce918fc4d6163aa7e61c54e794cdeaf1888a1d7bf1adc2040728552e54d2'
assert git('diff','--name-only',base,code,'--','src').decode().strip()=='src/sim/engagement.ts'
(r/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for name,ref in [('runtime',code),('pair',pair),('three',three)]:
 (r/(name+'.patch')).write_bytes(git('diff','--binary',base,ref,'--','src'))
(r/'contracts.patch').write_bytes(git('diff','--binary',base,tests,'--','test/support-escape-objective.test.ts'))
receipts=[]
pairroot=Path('/workspace/football-support-continuity-pair/out/support-interaction');threeroot=Path('/workspace/football-support-continuity-interaction/out/support-interaction')
for prefix,folder in [('',r),('interaction/pair',pairroot),('interaction/three',threeroot)]:
 for p in sorted(folder.glob('*.json')):
  a=json.loads(p.read_bytes())
  if 'commands' not in a:continue
  receipts.append({'path':str(Path(prefix)/p.name),'sha256':H(p.read_bytes()),'commit':a['commit'],'source':a['sourceSha256'],'exitCode':a['exitCode'],'inputsUnchanged':a['inputsUnchanged'],'commandSeconds':sum(c['elapsedSeconds']for c in a['commands']),'native':any('capture.mjs'in str(c['command'])for c in a['commands'])})
cost={'nativeCases':20,'terminalNativeCases':20,'reusedAcceptedBaselineCases':7,'nativeCommandSeconds':sum(a['commandSeconds']for a in receipts if a['native']),'focusedAndTypecheckCommandSeconds':sum(a['commandSeconds']for a in receipts if not a['native']),'totalCommandSeconds':sum(a['commandSeconds']for a in receipts),'qualification':'Seven first-pilot, seven final, three diagnostic pair and three diagnostic three-component cases; all terminal. All retries/red checks retained. No new accepted baseline, NFL query, games, broad lab or full-suite run.'}
(r/'cost-and-receipts.json').write_text(json.dumps({'cost':cost,'receipts':receipts},indent=2)+'\n')
groups={
 'final-native.tar.gz':[(p,'final-native/'+p.name)for p in sorted((r/'final-native').glob('*'))],
 'first-pilot.tar.gz':[(p,str(p.relative_to(r)))for folder in ['native','fresh-native']for p in sorted((r/folder).glob('*'))],
 'interaction.tar.gz':[(p,str(Path('interaction')/arm/p.relative_to(folder)))for arm,folder in [('pair',pairroot),('three',threeroot)]for p in sorted(folder.rglob('*'))if p.is_file()],
 'common.tar.gz':[(p,p.name)for p in sorted(r.iterdir())if p.is_file()],
}
archives=[]
for name,members in groups.items():
 target=dest/name
 with target.open('wb')as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as gz:
   with tarfile.open(fileobj=gz,mode='w')as tar:
    for p,arc in members:
     info=tar.gettarinfo(str(p),arcname=arc);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644;tar.addfile(info,io.BytesIO(p.read_bytes()))
 inv=[]
 with tarfile.open(target)as tar:
  assert len(tar.getmembers())==len(members)
  for (p,arc),m in zip(members,tar.getmembers()):
   b=tar.extractfile(m).read();assert m.name==arc and b==p.read_bytes();inv.append({'path':arc,'bytes':len(b),'sha256':H(b)})
 archives.append({'path':name,'bytes':target.stat().st_size,'sha256':H(target.read_bytes()),'members':inv})
manifest={**proof,'queue':'4cc3337df24faa6d857b612ae62e3df3109a5296','measurementReview':'f3063e550b434d355fc050bfc604a894303ea0a0','claudeResearch':'bae3fe80d189a7d792aaafbc4eea1ae2baa79573','settings':'All44 unchanged; RUN_CONTACT_COMPONENTS1,GAIT_STEP0,CF_FLOWunset; full flags/World/defaults/node in receipts.','cost':cost,'checks':'57 distinct compatible final-source focused checks and final-test-tree typecheck; diagnostic three-way65 focused checks only, no full combined acceptance.','reusedBaselines':[{'commit':'32977c642075c94f1b4ea7f1f6bb5aacc6161385','path':'data/reviews/db-stalk-workoff-2026-10-20/baseline.tar.gz','cases':6},{'commit':'4d3e4964619403b763b70d5259bf9dc250e1ea04','path':'data/reviews/man-run-continuity-2026-10-20/fresh-baseline.tar.gz','cases':1}],'archives':archives}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['support-escape-comparison.png']:
 if (r/name).exists():shutil.copy2(r/name,dest/name)
print(json.dumps({'manifestSha256':H((dest/'manifest.json').read_bytes()),'sourceProof':proof,'cost':cost,'archives':[{k:v for k,v in a.items()if k!='members'}for a in archives]},indent=2))
