# Independent review: acquired support objective through contact

Disposition: **approve the bounded individual candidate for independent review**,
with the adverse evidence below. This approves a local request contract; it does
not certify improved block-defeat frequency, the long-run distribution, or a
combined integration candidate. Stop selected variants here.

Reviewed runtime code `e634fd15efb574965e92715247c1470ae4229c31`, source SHA256
`db77ce918fc4d6163aa7e61c54e794cdeaf1888a1d7bf1adc2040728552e54d2`.
Final test-only revision `2220fdf99a472024607dc34e69d38219a4e056c2` leaves that
runtime unchanged. Accepted baseline is
`2c98bed94adad8087c65f381d4090444ad283985`, source
`4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571`;
queue `4cc3337df24faa6d857b612ae62e3df3109a5296`. The individual candidate does
not include #169's initial contact-wait bypass or #171's responsibility repair.

This reviewer inspected source, contracts, receipts and existing native tapes.
No additional tests, simulations, NFL queries or downloads were run. The root's
compatible focused evidence comprises 14 new contracts and 43 existing checks
(57 distinct), with typecheck passing. The final eligibility contract was run
on test revision 2220fdf; earlier compatible checks and all seven final native
cases use the same runtime SHA256. Exact flags and commands are preserved in
`final-focused.json`, `continuation-info.json`, `final-typecheck.json` and
`final-native-launch.json`. Native Node version is v22.23.3, until 8 seconds;
all seven cases finished as tackles, rather than censored outcomes.

## Source, information and cadence

At an existing work-off decision, a personally acquired, positively identified,
declared support runner permits the new technique only if the tactile/acquired
blocker is behind the selected runner approach. Actual transmitted hand load
supplies current local blocker position; otherwise the defender uses his
acquired blocker picture. Administrative engagement alone does not create touch.

The attempt stores the technique, not another copied runner waypoint. Its
direction consumes the current held `runContactRead.aim`, whose aim and target
mode refresh together on the existing mind cadence. It remains gated by
`shed.runner && supportRunner`: lost or contradictory acquisition cannot import
a newly selected hidden holder through the legacy `runContactRead` fallback.
The added contradiction control explicitly varies that hidden holder.

Own-position steering updates do not acquire additional pictures. The passive
observer records the already-produced command; it performs no extra sensing or
random draw. Work-off speed magnitude, facing, posture, hands, existing attempt
expiry, physical capacities and release laws are unchanged. An occupied path
remains physically opposed. First-level fits and undeclared close-threat work
retain the previous policy. This is not a complete information audit of legacy
contact-facing, carrier fallback, contact lifecycle or across-face frame inputs.

## Achieved football and adverse evidence

The seven exact input/player pairs and tape hashes are recorded in
`final-saved-comparison.json`; the full interpretation is retained in
`FINAL-SAVED-MEMO.md`. Request time t and achieved time t+0.05 are distinct.
Actual runner positions below are diagnostic geometry, not available player
information.

- **WZ7:** at request 3.75 / achieved 3.80, the same corner's achieved projection
  toward its current owned aim improves 0.846 to 1.971 yd/s. Actual runner
  separation improves 4.098 to 3.848 yd, before the first differing RNG state
  at 4.50. Both arms still separate from the receiver at 3.80, and neither adds
  corner contact on the runner. The earned offensive escape remains.
- **OZ4:** at request 3.10 / achieved 3.15, corner projection toward its current aim
  improves 2.869 to 3.213 yd/s and runner separation 7.978 to 7.929 yd. The
  initial stale-waypoint pilot's LB cost is corrected: at that achieved frame,
  progress toward actual runner position is accepted 2.254, stale pilot 2.168,
  final 2.346 yd/s. These changes precede the first RNG difference at 3.15.
  Later closest corner separation worsens 1.593 to 1.997 yd after divergence;
  no corner wrap is added.
- **WZORD:** the useful undeclared corner escape and assist 3.05 survive. The
  opposite receiver maintains a genuinely loaded block through the ending.
  The changed LB approach has a small adverse interval: achieved 3.05 runner
  separation 3.153 to 3.186 yd, progress 3.760 to 3.617 yd/s, with the same RNG.
  Same final gain does not imply identical whole-play movement.
- **Fresh F_Q_OZ:** both arms retain the FS wrap 3.40 / tackle 4.05 and the same RNG
  throughout. Mike's achieved 4.10 current-aim progress improves -0.018 to2.634
  yd/s and actual runner separation1.770 to1.524 yd while the LG block remains.
  The far corner instead loses some early approach: at 3.40 aim progress 1.927
  to 1.735 yd/s and aim distance 10.524 to 10.620 yd. Its loaded WR block persists
  through terminal 4.05; improved request direction does not guarantee escape.
- **Fresh F_OZ, F_COUNTER and PA13:** no new exit activates; all shared native
  movement and RNG fields remain identical. These preserve opposing behavior
  but do not count as positive active transfer.

Completed gains are WZ7 25.85 to 26.12, OZ4 15.59 to 16.47, WZORD 2.89 unchanged,
F_OZ 1.49 unchanged, F_COUNTER 0.22 unchanged, PA13 14.51 unchanged, and fresh
F_Q_OZ 4.67 to 4.65. Both selected long runs worsen; their later random and
interaction paths differ. These receipts do not isolate a preventable single
decision causing all adverse ending changes. Neither worse nor better gain is
being used as the acceptance criterion.

The original copied-point pilot, runtime
`e62d6dc7aff6c31d324fba6972ba3118e4b90738ad0c4dbc4e837430375c4f4d`,
remains separately labeled in `FIRST-PILOT-MEMO.md` and `saved-comparison.json`.
Its stale-point adverse evidence is not relabeled as the final implementation.

## Remaining limit and owner decision

This repairs how contact serves an already chosen football purpose. It does not
plan a complete interception, gather or wrap. Near the sampled point, normalized
full-effort steering can still turn sharply: fresh Mike requests lateral
+1.831 yd/s at 3.70, -0.183 at 3.80, then +1.784 when the owning aim refreshes 3.85.
The forward component remains positive and achieved approach improves here;
there is no demonstrated harmful full-body reversal. Retain this as a concrete
near-goal limit rather than claiming arrival behavior is solved.

No evidence justifies stronger hands, forced release, extra speed, a cooldown,
or another selected-play variant. The narrow objective correction is reviewable
with these limits. Independent #169/#171 decisions and Integration's exact
combined verification remain separate.

## Optional composition projection review

Read-only source projection of diagnostic assembly
`2302b48fb56298605ec17aaa39cc7950f62b6c08` found no composition blocker. The four
#171 runtime files are byte-identical to `11ef170`; engagement differs from
e634fd1 only by #169's first-qualified-attempt readiness condition. It shares
the current support eligibility, keeps normal cadence after admission, and a
new engagement cannot inherit the old WeakMap entry. This is source review,
not combined behavioral acceptance; Integration owns full combined verification.
