# Measurement review: next defensive support question

Read-only review,2026-10-20 America/Phoenix. No tests, native runs, tracking
queries or downloads. Primary critique pinned at
`f3063e550b434d355fc050bfc604a894303ea0a0` (document Git blob
`c712ed059a928971d07d75edccb914530c9f1990`), accepted
`2c98bed94adad8087c65f381d4090444ad283985`, queue
`4cc3337df24faa6d857b612ae62e3df3109a5296`, research
`bae3fe80d189a7d792aaafbc4eea1ae2baa79573`.

Relevant Measurement owner guidance:
- #153 comment6299666508: responsibility/complete-command/refinement chain,
  source/denominator discipline, finish portable decisions between discoveries.
- #169 comment6299673434: achieved escape is separate from permission; retain
  WZ7's adverse angle and legitimate WR wins; don't broaden timing repair.
- #170 comment6299671944: recoverable-contact existence proof is not NFL
  frequency or a calibrated slowing target.
- #168 comment6299691885: bounded completion decisions; do not activate gait,
  yaw or generic slowing from these findings.

## What the evidence supports

1. **Strong local causal evidence:** explicit hidden-holder variation (#160),
   complete request/facing distinction (#159), installed input geometry (#156),
   same-time endpoints (#131), and earned-release interaction (#164). These
   prove particular broken contracts/limits on their producing sources. They
   do not rank ordinary current-engine prevalence.
2. **Useful reference hypotheses:** phase-aligned NFL depth/lateral geometry,
   stable player witnesses and the already accessible20-play packet. These
   can identify implausible geometry; they do not reveal gaze, installed duty,
   grip force or an admissible policy. No new data acquisition is needed.
3. **Weak as causal claims:** package TVD/tail changes, proximity labels and
   conditional acceleration envelopes. Latest research is already reconciled
   with accepted develop, so stale ancestry is not its blanket defect; it still
   has different sources/default-off flags and a broad causal composition.
   GAIT_STEP improving selected outcomes while worsening an envelope fit is
   sensitivity evidence, not a physical calibration verdict either way.

## Additional operator limits directly checked

`bae3fe80:scripts/diag/stretch/dbstalk.py` calls a DB stalked after cumulative
.4s within1yd of **any** WR/TE. It does not require one continuous episode,
the same receiver or physical load. Its reach result is any distance<=1.5yd
after the snap, potentially BEFORE the supposed stalk. Its75%/87% numbers
therefore cannot establish post-block escape probability. This differs from
`stalkreps.ts`'s native episodes and body-dependent proximity threshold;
42/432 counts unique stalked DBs aggregated over plays, not432 block episodes.

`relatch2.ts` observes administrative engagement identity after ticks. A new
rep is counted only if it previously observed a free frame; same-tick release
and re-acquisition can escape that count. It has no transmitted-load admission.
None of these limitations invalidate the recorded cases or prohibit useful
hypotheses; they limit the labels and causal conclusions.

## Strongest next bounded DB question

**When a support defender has a legitimate acquired runner objective, does
contact refinement request a useful achievable exit, or replace the job with
obsolete work across the original blocker frame?**

Competing explanations: the selected exit/held side is wrong; the intended exit
is physically secured; a later support angle is already unrecoverable; or
administrative release/re-acquisition suppresses an otherwise useful action.
#169 and #171 already address distinct timing/recognition mechanisms, and #170
supplies contact existence controls. Do not repeat them as a new discovery.
Do-It-All has claimed common.ts force-leverage/pursuit; do not duplicate that.

Start with saved OZ4's real Z/CB_S re-block3.30–3.75 and WZORD's earned
CB_W escape2.95/assist3.05. Preserve both stable actors, installed fit, acquired
QB/RB/blocker pictures, held target/side, full contact request, achieved motion,
actual hand/body load and whether useful runner access was possible. A line
between centers is not obstruction proof; a free-body preview is not loaded
attainability proof. An administrative episode can end while actual support
remains useless, and moving away from the blocker can be a successful escape.

The cheapest informative source discriminator is whether changing a hidden
opponent plan/contact-frame field changes the defender's request with installed
duty, acquired history, own bodies and transmitted evidence fixed. `workOff`
uses `latOf(axisOf(e))`, which can derive from offensive `drive`/`surfaceAxis`;
this is a concrete dependency to test, not yet a population cause or proof every
mutated fixture represents a reachable state. Bound the contract and validate
input meaning before claiming an information violation.

If the request is wrong, repair the smallest informed objective/refinement
contract with Run consulting. If the request is reasonable but unattainable
under actual loads, hand off that exact physical limit instead of boosting
speed/hands or inventing a cooldown. If both work, stop this hypothesis and
retain earned offensive advantage. Do not replace every away-component with
constant pressure: WZORD's useful existing escape specifically opposes that.

The generalizable intelligence is ownership of the football objective through
contact and legitimate release: keep what job is being served, its evidence
and conditions for revision together. This warrants one coherent consumer
repair if proven, not a technique-library or global phase-manager project.
