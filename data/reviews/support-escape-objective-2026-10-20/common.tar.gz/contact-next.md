# Next contact-policy experiment: preserve a runner objective when the blocker is behind it

Read-only saved inspection by `/root/man_commit_review`; no new simulator,
movement preview, physical intervention or source edit. Accepted develop remains
`2c98bed94adad8087c65f381d4090444ad283985`, source
`4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571`.
The #169/#171 candidates are unmerged and source-qualified separately.

## What the saved evidence does and does not establish

A simple rule to flip work-off whenever it opposes `read.aim` is unsafe:
accepted WZ7 RT/LB_S2.55–2.95 and WZORD X/CB_W2.80–2.85 legitimately work toward
a close acquired runner instead of their still-held force landmark. Their
`read.declared` is false. WZORD then separates2.95 and assists3.05. Thus an
opposing landmark projection does not itself establish a wrong football action.
No repeated declared-support wrong-side command against its *held* runner aim
was found in six accepted #169 baseline inputs or the selected #171 tapes.

The narrower question is whether a declared support player keeps working across
an obsolete fixed surface after his blocker's body no longer lies along the
acquired runner approach. Do not replace a useful away component with constant
pressure into the blocker.

| Source/input and tick entry | Acquired runner versus current blocker | Request and physical facts |
| --- | --- | --- |
| Accepted WZ7 Z `pair11O-WR3` / CB_S `pair11D-CB3`,3.40 | D→B versus D→acquiredRB cosine−.476; body-disc corridor clearance+.066yd, radii sum.480yd. | Work-off still(−1.291,+6.347)yd/s; request projection toward acquired runner3.652. |
| Same WZ7,3.60 | Cosine−.658; clearance+.450yd; acquired runner distance5.206yd, picture age.25s. | Same request; projection toward acquired runner1.988, achieved velocity projection1.547. Hands have zero normal and approximately116N tangential load. |
| Same WZ7,3.75 | Cosine−.504; clearance+.816yd; acquired runner distance4.323yd. | Same request now projects−.333yd/s away from acquired runner; achieved projection−.315. Initial rep separates3.80, so this is a short late wrong-direction interval, not proof of a long impossible hold. |
| Accepted WZORD X `pair31O-WR4` / CB_W `pair31D-CB3`,2.80 | Cosine−.851; clearance+.709yd, radii sum.541yd. | Existing away-normal request(−1.109,−5.511) has useful runner-directed projection4.669. It escapes and assists. Preserve this control. |
| Accepted OZ4 Z `pair31O-WR3` / CB_S `pair31D-CB1`,2.80 | Cosine−.993; clearance+.267yd, radii sum.493yd; acquired runner distance11.206yd. | Existing request already points usefully toward runner: projection5.362, achieved1.693; tangent load approximately106N. Geometry alone does not establish that this block should be defeated. |
| #171 source925eb44e, OZ4 same Z/CB_S,3.50 | Cosine+.997; body-disc corridor clearance−.441yd; acquired runner distance1.825yd. | This is an actually occupied front path. Hands carry approximately60N normal/39N tangent. Current request projects+.827 toward runner, achieved+1.385. Do not let every declared runner turn this legitimate WR front block into an automatic sprint-through. |

Clearance above uses the current World disc radii and the segment from defender
to his already acquired RB picture. It is a saved geometric description, not
proof that a moving blocker cannot re-enter the corridor, that his arms are
clear, or that the defender can achieve a tackle. The runner pictures are
already latency-predicted; do not advance their observation age again.

Current relative blocker position is legitimate tactile information only while
transmitted hand load/contact supplies it. Otherwise use the acquired blocker
picture; existence of an engagement object is not a perfect new sighting.
Blocker velocity must remain acquired/felt, not private offensive drive.

## Smallest discriminating pilot, not an approved implementation

Retain existing declared-support admission (`supportRunner`: no first-level
stack, personally acquired declared carrying target). When the blocker is behind
that legitimate approach, test preserving a coherent runner-directed objective
instead of the fixed across-face vector. Keep the same physical hand laws,
contact, release and capacity budgets; an appropriate request may still fail.
Do not use an arbitrary cooldown, automatic release, stronger grip or a forced
+.6 current-normal press. The successful WZORD undeclared close-threat escape
and first-level/force predeclaration can retain existing behavior.

The raw free-controller request is not a safe substitute: it can be zero while
engaged, or can still be tracking the receiver. Do-It-All owns common pursuit
and its force-leverage repair; coordinate any reuse without editing that owner.

Opposing checks that could change the decision: fixed bodies/acquired pictures
with different hidden offensive drive must not alter the defensive goal;
acquired/felt front-versus-behind geometry must matter; a real WR in the runner
corridor must retain its work; WZORD's earned escape must survive; WZ7 needs an
attainable achieved approach, not merely lower gain. No physical feasibility or
general football improvement is established by this memo alone.

## Saved inputs

- `/workspace/football-db-stalk-workoff/out/db-stalk-workoff/baseline/{WZ7,WZORD,OZ4}.json.gz`: accepted source4273994; immutable #169 evidence32977c6.
- `/workspace/football-man-run-continuity/out/man-run-continuity/reader-candidate/OZ4.json.gz`: #171 source925eb44e; changed approach and receiver coordination, not accepted current behavior.

Tick numbers are controller/physics entry. Achieved velocity projections use the
following completed step (+.05s). Persistent shed tags are not fresh-attempt
records; requests and scheduling transitions distinguish the active technique.
