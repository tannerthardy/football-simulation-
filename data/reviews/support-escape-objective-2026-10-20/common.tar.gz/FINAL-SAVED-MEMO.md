# Refreshed contact-objective candidate: seven saved native comparisons

Inspected candidate code **e634fd15efb574965e92715247c1470ae4229c31**, runtime source **db77ce918fc4d6163aa7e61c54e794cdeaf1888a1d7bf1adc2040728552e54d2**, against unchanged accepted develop **2c98bed94adad8087c65f381d4090444ad283985**, baseline source **4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571**. Queue **4cc3337df24faa6d857b612ae62e3df3109a5296**. Same exact input hashes and complete player identity mapping are verified for each pair. No #169 timing bypass, #171 coverage continuity or LB-mode change is included.

This reducer ran no simulator, test, NFL query or download. It reads the completed seven native tape pairs. The first pilot/source e62d6dc7 is retained separately in FIRST-PILOT-MEMO.md and saved-comparison.json; it is not relabeled as this candidate.

## What the correction actually achieves

The actual contact owner now consumes the defender's current already-owned support aim when its support qualification remains valid. Every activated passive defender-movement record has exitAim exactly equal to its current defensiveAim. The first pilot's stale copied-world-point defect is gone. The contact owner retains ordinary shed timing, physical hand capacity, existing read timing and ordinary off-contact controllers.

WZ7 and OZ4 provide same-defender, same-entry-body comparisons in a physically loaded WR block before random-state divergence. The request correction produces some attained movement toward the legitimately owned aim; it does not merely change a diagnostic label. It adds no DB carrier contact in these witnesses and is not yet demonstrated to solve the explosive-run tail.

| Completed input | Baseline gain | Candidate gain | First differing recorded RNG state | Carrier contact/finish |
|---|---:|---:|---|---|
| WZ7 | 25.85 | 26.12 | tick4.50, rng.s0 | Same FS wrap5.55; tackle6.40→6.45. No CB carrier contact. |
| OZ4 | 15.59 | 16.47 | tick3.15, rng.s0 | Same SS wrap3.05/slip3.35; FS wrap4.05→4.10, tackle4.65→4.70. No CB carrier contact. |
| WZORD | 2.89 | 2.89 | None | Same LB_W wrap2.75, CB_W assist3.05, tackle3.50. |
| Fresh F_OZ | 1.49 | 1.49 | None | Shared native tick fields exactly identical. No admitted exit choice. |
| Fresh F_COUNTER | .22 | .22 | None | Shared native tick fields exactly identical. No admitted exit choice. |
| PA13 | 14.51 | 14.51 | None | Shared native tick fields exactly identical. No admitted exit choice. |
| Fresh F_Q_OZ | 4.67 | 4.65 | None | Same FS wrap3.40/tackle4.05; activated CB_W and Mike choices, no added contact. |

All are completed tackles. WZORD has small numerical body differences, despite the same rounded ending and random stream. Baseline lacks the newer cached coverage snapshot, so equality claims refer to the explicitly listed shared native fields; raw contact observer phases differ by construction.

## Same-player approach and actual contact

**WZ7:** Z(pair11O-WR3) blocks CB_S(pair11D-CB3), rep starts2.20 with recorded load2.25–3.75. Both complete entry bodies are identical at request3.50. Candidate uses current support aim rather than fixed offensive-frame lateral motion. At request3.75/achieved3.80, velocity projected toward the current owned aim improves **.846→1.971yd/s**, distance to that aim **4.992→4.831yd**, and diagnostic actual-runner distance **4.098→3.848yd**. Lateral speed changes **5.311→3.200yd/s**, reducing the existing overshoot across the runner's lateral line. Recorded contact at that instant still carries tangent force−111.44 with no normal force or holding component; these are actual loaded hands, not inferred obstruction from player centers.

Both arms separate3.80; changing direction does not magically break the same hands earlier. Candidate avoids the baseline Z/CB_S recontact4.50–4.90. Closest attained CB_S/runner distance improves **4.039yd at3.85→3.541yd at3.95**, both before first RNG difference4.50, but remains far outside a useful tackle. Baseline and candidate earned offensive escape remain. The earlier backside X/CB_W choice2.70–3.05 makes only small changes and separates at the same3.10.

Before WZ7's first RNG difference, meaningful body changes are confined to X, Z, CB_S and CB_W; RB, FS and SS movement remains identical. Thus the final extra .27yd and later FS finish cannot be directly attributed to the immediate attained CB approach improvement. After4.50 the changed random-consumption path and subsequent interactions also matter.

**OZ4:** Z(pair31O-WR3) blocks CB_S(pair31D-CB1), same complete entry body at request2.80. At request3.10/achieved3.15, current-aim projected velocity improves **2.869→3.213yd/s**, distance to current aim **8.700→8.643yd**, diagnostic runner distance **7.978→7.929yd**; lateral speed decreases **3.125→2.537yd/s**. Recorded tangent force remains−100.81, normal and holding components0. Candidate separates **3.15 rather than3.20**, then recontacts **3.95 rather than3.80**. This is a real, small escape improvement before a later lost opportunity; no CB wrap is acquired.

The adverse geometry must remain visible: closest attained CB_S/runner distance later worsens **1.593→1.997yd** at achieved4.00. That later comparison follows RNG divergence3.15. Before3.15, only CB_S plus very small RG/Mike geometry changes occur; SS, RB and FS are unchanged. The same SS initial contact and later slip survive; the FS wrap happens50ms later. These tapes do not identify a single preventable new controller decision that caused all later adverse yardage. They establish a speed/angle trade-off and changed later execution path, rather than a grip correction.

**WZORD opposing controls:** X(pair31O-WR4)/CB_W(pair31D-CB3) keeps its successful close-threat **undeclared** work-off unchanged at2.80. It separates2.95 and assists the runner tackle3.05 in both arms. Opposite Z/CB_S stays physically loaded2.35 through terminal3.50, despite an admitted declared-support choice3.15. Its recorded normal force387–401, tangent force−101 to−247 and holding component62–67 persist. Useful sustained WR blocking remains possible. LG/Mike's contact movement also changes, so same ending is not whole-play equality.

**Fresh activated transfer F_Q_OZ:** exact fresh51/52-player weak OZ/Quarters setup, input hash and stable IDs in JSON. X(FDO-WR2)/CB_W(FDD-CB2) stays blocked2.20 through terminal4.05 in both arms. It is genuinely loaded: recorded normal force initially653, tangent188–453 and holding component172–195 during selected samples. At request3.40, candidate attained current-aim projection worsens **1.927→1.735yd/s**, aim distance **10.524→10.620yd**; early lateral-speed cost is real without any RNG difference. At4.05, projection improves **.227→.597yd/s** but aim distance is essentially unchanged **7.255→7.256yd**. No useful new CB arrival or forced receiver release is demonstrated.

The same fresh play supplies a second, non-CB support comparison: LG/Mike, same complete entry body3.70. At4.05, achieved current-aim projection improves **−.018→2.634yd/s**, aim distance **1.426→.858yd**, diagnostic runner distance **1.770→1.524yd**. Mike is .656yd displaced from baseline by the last common achieved frame, but remains in the block and acquires no carrier wrap. Fresh FS's ordinary tackle is preserved. This is broader evidence that the contact layer changes attained support motion, alongside adverse early CB movement; it is not evidence of reliable block defeat.

## Decision and limits

The fixed-frame request conflict is demonstrated, and the refreshed-aim implementation repairs a coherent local request contract using available information. Its attained benefit is modest and mixed. **Do not present it as the DB escape or long-run-tail solution, and do not promote based on lower yardage.** The two selected long runs worsen; the activated fresh control also loses some early CB approach speed. These are reviewable adverse findings, even though physical receiver wins and defensive finishes remain credible.

Stop selected variants here. The smallest next owner decision is whether the local request-contract repair is independently worth retaining with these limits, or should remain held until paired with the separately reviewed responsibility continuation. These saved tapes do not justify new grip strength, release timing, global speed or information privileges. They also do not isolate an inadequate physical escape law: loaded contacts and prior velocity constrain the achieved body, and off-contact coverage requests resume after release.

The tape records actual WR hand normal/tangent/hold values and event-level runner grasp/wrap/slip timing. It does **not** record the runner grasp's per-tick force, difficulty or draw. Therefore a grip-survival causal claim would exceed the available evidence. No additional passive instrumentation is required to decide this movement candidate's current limitations.

Reproduce this saved-data inspection with `python3 out/support-escape/compare_final_saved.py`. `final-saved-comparison.json` contains exact tape SHA256s, source/input pins, every admitted contact objective, current and stored aims, consumed cues, raw/final requests, achieved positions/velocities, loads, contact endings, carrier events, first RNG field difference and every changed player's maximum before/after-RNG geometry difference. Times labeled achieved refer to completed=t+0.05; actual-runner geometry is diagnostic truth, never a claimed observation.
