"""Inspect saved same-defender contact stages only; no simulator execution."""
from pathlib import Path
import gzip,hashlib,json,math

folder=Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff/baseline')
rows=[]
for name,slot,times in [('WZ7','CB_S',[3.35,3.4,3.6,3.75]),('WZORD','CB_W',[2.8,2.85]),('OZ4','CB_S',[2.8,3.])]:
    path=folder/(name+'.json.gz');raw=path.read_bytes();a=json.loads(gzip.decompress(raw))
    d=next(p for p in a['initial']if p['slot']==slot);idx=d['idx']
    for tm in times:
        contact=next((c for c in a['contact']if c['t']==tm and c['d']==idx and c['phase']=='movement'),None)
        if contact is None:continue
        tick=next(t for t in a['ticks']if t['t']==tm);dp=tick['before'][idx]['pos'];bp=tick['before'][contact['b']]['pos'];aim=contact['data']['defensiveAim']
        u={k:aim[k]-dp[k]for k in ['x','y']};br={k:bp[k]-dp[k]for k in ['x','y']};length=math.hypot(*u.values())
        final=tick['intents'][idx]['vel'];after=tick['after'][idx]
        rows.append({'case':name,'tapeSha256':hashlib.sha256(raw).hexdigest(),'source':a['source'],'inputSha256':a['inputSha256'],
            'defender':{'slot':slot,'id':d['player']['id'],'pos':dp},'blocker':{'slot':a['initial'][contact['b']]['slot'],'id':a['initial'][contact['b']]['player']['id'],'pos':bp},
            'tick':tm,'achievedAt':tick['completed'],'declared':contact['data']['declared'],'heldRunnerOrFitAim':aim,
            'blockerDotHeldAim':sum(br[k]*u[k]for k in u),'finalRequest':final,'finalRequestProjectionTowardHeldAim':sum(final[k]*u[k]for k in u)/length,
            'achievedVelocity':after['vel'],'achievedProjectionTowardHeldAim':sum(after['vel'][k]*u[k]for k in u)/length,
            'normal':contact['rep']['normal'],'tangent':contact['rep']['tangent'],
            'qualification':'Final intent follows spacing; held aim differs from latest acquired runner picture. A clear body path does not imply arms are clear or a tackle is attainable.'})
out=Path('out/support-escape/saved-decision.json');out.write_text(json.dumps({'inspectionOnly':True,'rows':rows},indent=2)+'\n')
print(json.dumps({'rows':len(rows),'path':str(out)},indent=2))
