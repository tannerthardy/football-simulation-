"""Saved native tape reducer. Does not import or run the simulator."""
from pathlib import Path
import gzip, hashlib, json, math

ROOT = Path(__file__).resolve().parent
BASE = Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff')
CASES = ['WZ7', 'OZ4', 'WZORD', 'F_OZ', 'F_COUNTER', 'PA13', 'F_Q_OZ']

def load(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw)), {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest()}

def delta(a,b): return {k:a[k]-b[k] for k in ('x','y')}
def norm(v): return math.hypot(v['x'],v['y'])
def dot(a,b): return sum(a[k]*b[k] for k in ('x','y'))
def project(v,u): return dot(v,u)/norm(u) if norm(u) else None
def angle(v,u):
    return math.degrees(math.acos(max(-1,min(1,dot(v,u)/norm(v)/norm(u))))) if norm(v)*norm(u) else None

def first_difference(a,b,path=''):
    if type(a) is not type(b): return {'path':path,'baseline':a,'candidate':b}
    if isinstance(a,dict):
        for k in a.keys() | b.keys():
            if k not in a or k not in b: return {'path':path+'.'+str(k),'baseline':a.get(k),'candidate':b.get(k)}
        for k in sorted(a):
            d=first_difference(a[k],b[k],path+'.'+str(k))
            if d is not None:return d
    elif isinstance(a,list):
        for i,(x,y) in enumerate(zip(a,b)):
            d=first_difference(x,y,path+'['+str(i)+']')
            if d is not None:return d
        if len(a)!=len(b): return {'path':path+'.length','baseline':len(a),'candidate':len(b)}
    elif a!=b: return {'path':path,'baseline':a,'candidate':b}

def identity(a,i):
    p=a['initial'][i]
    return {'index':i,'slot':p['slot'],'id':p['player']['id'],'runFit':p.get('runFit')}

def contact_summary(a,bi,di):
    reps={}
    for c in a['contact']:
        if c['b']!=bi or c['d']!=di:continue
        k=c['rep']['id'];r=reps.setdefault(k, {'id':k,'start':c['rep']['start'],'lastRecorded':c['t'],'loadedTimes':[]})
        r['lastRecorded']=max(r['lastRecorded'],c['t'])
        if c['phase']=='end':r['end']={'t':c['t'],**c['data']}
        if c['phase']=='geometry' and (abs(c['rep'].get('normal',0))+abs(c['rep'].get('tangent',0)))>0:r['loadedTimes'].append(c['t'])
    for r in reps.values():
        times=sorted(set(r.pop('loadedTimes')));r['firstRecordedLoaded']=times[0]if times else None;r['lastRecordedLoaded']=times[-1]if times else None
        r['durationToEndOrLastRecord']=(r.get('end',{}).get('t',r['lastRecorded'])-r['start'])
        r['activeAtTapeEnd']='end'not in r
    return list(reps.values())

def body_sample(a,tick,bi,di,aim,exit_aim):
    before=tick['before'][di];after=tick['after'][di];target=tick['before'][bi]
    toward=delta(aim,before['pos']);to_exit=delta(exit_aim,before['pos']);to_b=delta(target['pos'],before['pos'])
    runner=tick['before'][6]
    request=tick['intents'][di]['vel']
    return {'t':tick['t'],'achievedAt':tick['completed'],'positionBefore':before['pos'],'positionAfter':after['pos'],
        'velocityBefore':before['vel'],'achievedVelocity':after['vel'],'finalRequest':request,
        'requestProjectionToCurrentAim':project(request,toward),'achievedProjectionToCurrentAim':project(after['vel'],toward),
        'achievedAngleToCurrentAimDegrees':angle(after['vel'],toward),'distanceAfterToCurrentAim':norm(delta(aim,after['pos'])),
        'achievedProjectionToStoredAim':project(after['vel'],to_exit),'distanceAfterToStoredAim':norm(delta(exit_aim,after['pos'])),
        'requestAwayFromBlocker':-project(request,to_b),'achievedAwayFromBlocker':-project(after['vel'],to_b),
        'distanceAfterToBlocker':norm(delta(tick['after'][bi]['pos'],after['pos'])),
        'runnerPositionDiagnosticOnly':runner['pos'],'runnerVelocityDiagnosticOnly':runner['vel'],
        'runnerDistanceAfterDiagnosticOnly':norm(delta(tick['after'][6]['pos'],after['pos'])),
        'defenderMinusRunnerLateralDiagnosticOnly':after['pos']['y']-tick['after'][6]['pos']['y'],
        'defenderMinusRunnerDownfieldDiagnosticOnly':after['pos']['x']-tick['after'][6]['pos']['x']}

def changed_players(b,c,bt,ct,common,rng_t):
    rows=[]
    for i in range(len(b['initial'])):
        vals=[]
        for tm in common:
            bp,cp=bt[tm]['after'][i],ct[tm]['after'][i]
            vals.append((tm,norm(delta(cp['pos'],bp['pos'])),norm(delta(cp['vel'],bp['vel']))))
        if not any(p>1e-9 or v>1e-9 for _,p,v in vals):continue
        first=next((tm for tm,p,v in vals if p>.01 or v>.05),None)
        prior=[r for r in vals if r[0]<rng_t]
        rows.append({'player':identity(c,i),'firstGeometryDifferenceOver1cmOrVelocityOver0p05':first,
            'maximumCommonTimePositionDifference':max(vals,key=lambda r:r[1]),
            'maximumCommonTimeVelocityDifference':max(vals,key=lambda r:r[2]),
            'maximumPreRngPositionDifference':max(prior,key=lambda r:r[1])if prior else None,
            'maximumPreRngVelocityDifference':max(prior,key=lambda r:r[2])if prior else None})
    return rows

results=[]
for name in CASES:
    baseline_path=(Path('/tmp/football-db-stalk-baseline/out/man-run-continuity/fresh-baseline')/(name+'.json.gz')) if name=='F_Q_OZ' else BASE/('baseline' if name in CASES[:3] else 'transfer-baseline')/(name+'.json.gz')
    b,bp=load(baseline_path)
    c,cp=load(ROOT/'final-native'/(name+'.json.gz'))
    assert b['inputSha256']==c['inputSha256'],name
    assert [(p['slot'],p['player']['id'])for p in b['initial']]==[(p['slot'],p['player']['id'])for p in c['initial']],name
    bt={t['t']:t for t in b['ticks']};ct={t['t']:t for t in c['ticks']};common=sorted(bt.keys()&ct.keys())
    first={}
    for field in ['requests','intents','before','after','rng']:
        tm=next((t for t in common if bt[t][field]!=ct[t][field]),None)
        if tm is not None:
            av,bv=bt[tm][field],ct[tm][field]
            if field=='rng':av,bv=json.loads(av),json.loads(bv)
            first[field]={'t':tm,'achievedAt':ct[tm]['completed'] if field=='after' else None,'difference':first_difference(av,bv,field)}
        else:first[field]=None
    same_native_fields=['minds','before','requests','requestObjectives','intentObjectives','intents','after','repBefore','reps','coverage','tags','work','armImpulse','armImpulseLimit','armWork','armWorkLimit','contacts','reads','ball','rng']
    optional_fields_not_shared=[f for f in same_native_fields if any(f not in bt[t]or f not in ct[t]for t in common)]
    same_native_fields=[f for f in same_native_fields if f not in optional_fields_not_shared]
    full_fields_identical=len(bt)==len(ct)and all(all(bt[t][f]==ct[t][f]for f in same_native_fields)for t in common)
    groups={}
    for q in c['contact']:
        if q['phase']=='defender-movement'and q['data'].get('exitAim'):
            groups.setdefault((q['b'],q['d'],q['rep']['id']),[]).append(q)
    choices=[]
    for (bi,di,rep),qs in groups.items():
        samples=[]
        rng=first['rng']['t']if first['rng']else math.inf
        interesting={qs[0]['t'],qs[-1]['t']}
        lastaim=None
        for q in qs:
            if q['data']['defensiveAim']!=lastaim:interesting.add(q['t']);lastaim=q['data']['defensiveAim']
        for q in qs:
            if q['t']not in interesting:continue
            tm=q['t'];data=q['data'];lastcue=next((p for p in reversed(c['cues'])if p['t']<=tm and p['a']==di and p['b']==6),None)
            bs=body_sample(b,bt[tm],bi,di,data['defensiveAim'],data['exitAim'])if tm in bt else None
            cs=body_sample(c,ct[tm],bi,di,data['defensiveAim'],data['exitAim'])
            samples.append({'t':tm,'strictlyBeforeFirstRngDifference':tm<rng,'passiveDecision':data,
                'handNormal':q['rep']['normal'],'handTangent':q['rep']['tangent'],'hands':q['rep']['hands'],
                'latestConsumedRunnerCueByThisObserver':lastcue,'baseline':bs,'candidate':cs,
                'storedVersusCurrentAimDistance':norm(delta(data['exitAim'],data['defensiveAim']))})
        choices.append({'blocker':identity(c,bi),'defender':identity(c,di),'repId':rep,
            'firstChosen':qs[0]['t'],'lastActive':qs[-1]['t'],'storedExitAim':qs[0]['data']['exitAim'],
            'sameDefenderBodyAtEntry':bt[qs[0]['t']]['before'][di]==ct[qs[0]['t']]['before'][di],
            'baselineContacts':contact_summary(b,bi,di),'candidateContacts':contact_summary(c,bi,di),'samples':samples})
    def carrier_events(a):
        return [{**e,'actor':identity(a,e['a'])if isinstance(e.get('a'),int)else None,'other':identity(a,e['b'])if isinstance(e.get('b'),int)else None}
            for e in a['events']if e['type']in ['carrier_contact','tackle_wrap','broken_tackle','tackle','hit']]
    result={'case':name,'inputSha256':b['inputSha256'],'baseline':{**bp,'source':b['source'],'gain':b['gain'],'outcome':b['outcome'],'result':{k:b['result'][k]for k in ['duration','endX','endY','stats']}},
        'candidate':{**cp,'source':c['source'],'gain':c['gain'],'outcome':c['outcome'],'result':{k:c['result'][k]for k in ['duration','endX','endY','stats']}},
        'firstDifferences':first,'allSharedNativeTickFieldsIdentical':full_fields_identical,'sharedNativeFieldsCompared':same_native_fields,
        'optionalNativeFieldsNotShared':optional_fields_not_shared,'exitChoices':choices,
        'baselineCarrierEvents':carrier_events(b),'candidateCarrierEvents':carrier_events(c)}
    rng_t=first['rng']['t']if first['rng']else math.inf
    result['allChangedPlayers']=changed_players(b,c,bt,ct,common,rng_t)
    result['allPassiveExitAimsEqualCurrentOwnedAim']=all(q['data']['exitAim']==q['data']['defensiveAim']for q in c['contact']if q['phase']=='defender-movement'and q['data'].get('exitAim'))
    result['perimeterRunnerProximityDiagnosticOnly']=[]
    for i,p in enumerate(c['initial']):
        if p['slot']not in ['CB_S','CB_W','FS','SS']:continue
        out={'defender':identity(c,i)}
        for label,a in [('baseline',b),('candidate',c)]:
            measures=[(t['completed'],norm(delta(t['after'][i]['pos'],t['after'][6]['pos'])))for t in a['ticks']if t['ball'].get('carrier')==6]
            out[label+'MinimumDistanceAndTime']=min(measures,key=lambda z:z[1])if measures else None
        result['perimeterRunnerProximityDiagnosticOnly'].append(out)
    if name=='WZORD':
        result['successfulUndeclaredControl']={'blocker':identity(c,8),'defender':identity(c,19),
            'baselineContacts':contact_summary(b,8,19),'candidateContacts':contact_summary(c,8,19),
            'candidateMovement':[q for q in c['contact']if q['phase']=='defender-movement'and q['b']==8 and q['d']==19 and q['t']==2.8],
            'finalRequestAt2p8Identical':bt[2.8]['intents'][19]==ct[2.8]['intents'][19],
            'bodyAt2p8Identical':bt[2.8]['before'][19]==ct[2.8]['before'][19]}
    results.append(result)
payload={'mode':'saved-data inspection only; no simulator, tests, NFL query or downloads',
    'candidateCodeRevision':'e634fd15efb574965e92715247c1470ae4229c31','acceptedDevelop':'2c98bed94adad8087c65f381d4090444ad283985',
    'integrationQueue':'4cc3337df24faa6d857b612ae62e3df3109a5296','excludedCandidates':['#169','#171','LB contact-mode continuation'],
    'qualifications':['Request tick t is distinct from achieved body time completed=t+0.05.',
        'Actual runner/body positions are diagnostic outcome geometry, never claimed to be an acquired cue.',
        'Contact separation is not a tackle; uncontacted runner witnesses do not demonstrate grip failure.',
        'RNG states are recorded at completed ticks; a different later draw cannot be attributed to a single earlier movement intervention.',
        'New defender-movement phase is observational only and absent from baseline; native behavioral fields are compared separately.'],
    'cases':results}
path=ROOT/'final-saved-comparison.json';path.write_text(json.dumps(payload,indent=2)+'\n')
for r in results:
    print(r['case'],r['baseline']['gain'],'->',r['candidate']['gain'],'rng',r['firstDifferences']['rng']['t']if r['firstDifferences']['rng']else None,'nativeIdentical',r['allSharedNativeTickFieldsIdentical'])
print(path,hashlib.sha256(path.read_bytes()).hexdigest())
