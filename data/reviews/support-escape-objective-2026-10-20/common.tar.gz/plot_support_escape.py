"""Standalone plot of existing saved tapes; no simulator or NFL access."""
from pathlib import Path
import gzip, hashlib, json, math, os
os.environ.setdefault('MPLCONFIGDIR','/tmp/football-support-mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

ROOT=Path(__file__).resolve().parent
BASE=Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff/baseline')
FRESH=Path('/tmp/football-db-stalk-baseline/out/man-run-continuity/fresh-baseline')
CASES=[('WZ7',9,18,1.5),('OZ4',9,18,1.5),('F_Q_OZ',8,19,1.5),('WZORD',8,19,1.5)]
colors={'baseline':'#2f6ea6','candidate':'#dd7a22'}
provenance=[]

def load(path):
    raw=path.read_bytes();a=json.loads(gzip.decompress(raw))
    provenance.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'source':a['source'],'inputSha256':a['inputSha256']})
    return a

def intervals(values):
    groups=[]
    for t in sorted(set(values)):
        if not groups or t-groups[-1][-1]>.051:groups.append([t])
        else:groups[-1].append(t)
    return [(g[0],g[-1]+.05)for g in groups]

fig,axes=plt.subplots(2,2,figsize=(11.8,7.6))
for ax,(name,bi,di,start)in zip(axes.flat,CASES):
    b=load((FRESH if name=='F_Q_OZ'else BASE)/(name+'.json.gz'))
    c=load(ROOT/'final-native'/(name+'.json.gz'))
    assert b['inputSha256']==c['inputSha256']
    for label,a in [('baseline',b),('candidate',c)]:
        points=[]
        for t in a['ticks']:
            if t['completed']<start or t['ball'].get('carrier')!=6:continue
            d=t['after'][di]['pos'];r=t['after'][6]['pos'];points.append((t['completed'],math.hypot(d['x']-r['x'],d['y']-r['y'])))
        ax.plot([p[0]for p in points],[p[1]for p in points],color=colors[label],lw=2,label=label,zorder=4)
        loads=[p['t']for p in a['contact']if p['phase']=='geometry'and p['b']==bi and p['d']==di and abs(p['rep'].get('normal',0))+abs(p['rep'].get('tangent',0))>0]
        for lo,hi in intervals(loads):
            ax.axvspan(lo,hi,color=colors[label],alpha=.085 if label=='baseline'else .14,lw=0,zorder=0)
        own_wrap=next((p['t']for p in a['events']if p['type']=='tackle_wrap'and p['a']==di and p.get('b')==6),None)
        if label=='candidate'and own_wrap is not None:
            ax.axvline(own_wrap,color='#21834f',lw=1.3,ls=':',zorder=3)
            ax.text(own_wrap+.035,.1,'CB wrap',transform=ax.get_xaxis_transform(),color='#21834f',fontsize=8)
    bt={t['t']:t for t in b['ticks']};ct={t['t']:t for t in c['ticks']}
    rng=next((tm for tm in sorted(bt.keys()&ct.keys())if bt[tm]['rng']!=ct[tm]['rng']),None)
    if rng is not None:
        ax.axvline(rng,color='#6c6c6c',ls='--',lw=1)
        ax.text(rng+.035,.84,'RNG differs',transform=ax.get_xaxis_transform(),fontsize=8,color='#555555')
    disposition='adverse ending'if c['gain']>b['gain']else 'same ending'if c['gain']==b['gain']else 'same finish; small gain change'
    title=f"{name} · {b['initial'][di]['slot']} vs {b['initial'][bi]['slot']} block"
    ax.set_title(title,loc='left',fontsize=11,fontweight='bold',pad=10)
    ax.text(.015,.975,f"{b['gain']:.2f} → {c['gain']:.2f} yd; {disposition}",transform=ax.transAxes,va='top',fontsize=9,color='#8f331d'if c['gain']>b['gain']else'#333333',bbox={'facecolor':'white','alpha':.8,'edgecolor':'none','pad':1.5})
    ax.text(.015,.035,f"D: {b['initial'][di]['player']['id']}\nWR: {b['initial'][bi]['player']['id']}",transform=ax.transAxes,fontsize=7.5,va='bottom',bbox={'facecolor':'white','alpha':.75,'edgecolor':'none','pad':2})
    ax.set_xlabel('Time after snap (s)');ax.set_ylabel('Achieved CB–runner separation (yd)')
    ax.set_xlim(start,max(t['completed']for t in c['ticks']));ax.set_ylim(bottom=0)
    ax.grid(alpha=.18);ax.spines[['top','right']].set_visible(False)

fig.suptitle('Contact-objective repair: attained approach and sustained WR control',fontsize=15,fontweight='bold',x=.07,ha='left',y=.985)
fig.text(.07,.94,'Accepted develop 2c98bed / source 4273994f   vs   isolated e634fd15 / source db77ce91',fontsize=10)
legend=[Line2D([0],[0],color=colors['baseline'],lw=2,label='Unchanged accepted baseline'),Line2D([0],[0],color=colors['candidate'],lw=2,label='Refreshed contact objective'),Patch(facecolor=colors['baseline'],alpha=.15,label='Baseline recorded WR load'),Patch(facecolor=colors['candidate'],alpha=.25,label='Candidate recorded WR load')]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,.06),ncol=2,frameon=False,fontsize=9)
fig.text(.07,.025,'Saved native positions only; achieved time = tick completion. Shading is recorded hand load, not inferred obstruction.\nBody-center separation is not tackle eligibility. No new simulation or NFL query; adverse outcomes remain visible.',fontsize=8,color='#444444')
fig.tight_layout(rect=(.035,.145,.995,.93),h_pad=2,w_pad=2)
png=ROOT/'support-escape-comparison.png';fig.savefig(png,dpi=175,facecolor='white')
meta={'mode':'saved data only','script':str(Path(__file__).resolve()),'candidateCode':'e634fd15efb574965e92715247c1470ae4229c31','pngSha256':hashlib.sha256(png.read_bytes()).hexdigest(),'tapes':provenance}
(ROOT/'support-escape-plot-provenance.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'png':str(png),'sha256':meta['pngSha256']},indent=2))
