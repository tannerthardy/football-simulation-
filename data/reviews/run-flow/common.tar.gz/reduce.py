"""Reduce existing exact tapes only; zero engine ticks or new random draws."""
import gzip,json,math,hashlib
from pathlib import Path
p=Path(__file__).resolve().parent;root=p.parents[1];dl=p if(p/'dl-final').exists()else Path('/workspace/football-dl-acquired-run-flow/out/run-flow');old=p if(p/'baseline/TOSS.json.gz').exists()else Path('/workspace/football-defensive-snap-response/out/defensive-snap-response')
load=lambda f:json.loads(gzip.decompress(f.read_bytes()));sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
groups={k:p/k for k in ['enriched','crossover','lb-transfer','extra-baseline','lb-extra','combined','combined-interior']}|{k:dl/k for k in ['dl-pilot','dl-transfer','dl-extra','dl-final','dl-interior']}
rows={arm:{r['id']:r for f in folder.glob('*.json.gz') for r in[load(f)]}for arm,folder in groups.items()}
baseline={c:load(old/arm/(c+'.json.gz'))for arm,cases in [('baseline',['DUO','TOSS','IZ','PA']),('fresh-baseline',['PASS13','PA13','FTOSS','FTOSS-L'])]for c in cases}|rows['extra-baseline']
result={'acceptedDevelop':'f4146275ce7539816bf57b4ed55a0d2be10e48c7','queue':'9a6bb795179a4b2e61ed59d25bcf23ca5e40f423','reusedBaselineEvidence':'55d672c90a68aa6d830fc0019d863b191bf39c80','groups':{},'comparisons':[]}
for arm,rs in rows.items():
 receipt=json.loads((groups[arm]/'receipt.json').read_text());result['groups'][arm]={'receipt':receipt,'cases':[{k:r[k]for k in ['id','source','inputSha256','phase','outcome','gain','elapsedSeconds']}|{'rawSha256':sha(groups[arm]/(c+'.json.gz'))}for c,r in rs.items()]}
 if arm=='extra-baseline':continue
 for case,r in rs.items():
  b=baseline[case];assert b['inputSha256']==r['inputSha256']
  changes={key:next((x['t']for x,y in zip(b['ticks'],r['ticks'])if x[key]!=y[key]),None)for key in ['requests','intents','before','after','rng']}
  starts=[]
  for e in r['events']:
   if e['type']not in['carrier_contact','tackle_wrap','tackle','missed_tackle']:continue
   f=min(r['ticks'],key=lambda f:abs(f['t']-e['t']));entry={'event':e,'actors':{str(i):{'slot':r['initial'][i]['slot'],'playerId':r['initial'][i]['player']['id']}for i in [e.get('a'),e.get('b')]if i is not None}}
   if e['type']=='tackle_wrap':
    d,c=f['after'][e['a']],f['after'][e['b']];dx=c['pos']['x']-d['pos']['x'];dy=c['pos']['y']-d['pos']['y'];dist=math.hypot(dx,dy);sp=math.hypot(*c['vel'].values());cos=-(c['vel']['x']*dx+c['vel']['y']*dy)/max(1e-9,sp*dist)
    entry['completedTickGeometry']={'distance':dist,'approachCosine':cos,'defenderPosition':d['pos'],'runnerPosition':c['pos'],'defenderVelocity':d['vel'],'runnerVelocity':c['vel']}
   starts.append(entry)
  result['comparisons'].append({'arm':arm,'id':case,'firstDifferences':changes,'ticksEqual':b['ticks']==r['ticks'],'resultEqual':b['result']==r['result'],'events':starts})
# Verify passive enrichment against original exact native prefix.
for c,r in rows['enriched'].items():assert r['ticks']==baseline[c]['ticks'][:len(r['ticks'])]
# The one-expression prediction correction cannot affect cases that never enter that target mode.
result['inactiveReuse']=[]
for c in ['PA','PA13','PASS13']:
 r=rows['dl-transfer'][c];assert not any(x['data'].get('heldTargetFlow')is not None for x in r['contact']if x['phase']=='movement');assert r['ticks']==baseline[c]['ticks']
 result['inactiveReuse'].append({'id':c,'executedSource':r['source'],'physicalTapeEqualsAccepted':True,'newLateralModeSamples':0,'reason':'Final source changes only the active lateral target point and excludes edges from the new mode. Zero activation plus exact accepted body/command/RNG tape supplies compatible opposing evidence; not an execution receipt on the final source.'})
result['tossExecution']={}
for arm,r in [('baseline',baseline['TOSS']),('lb',rows['lb-transfer']['TOSS']),('dl',rows['dl-interior']['TOSS'])]:
 e=next(e for e in r['events']if e['type']=='tackle_wrap');f=min(r['ticks'],key=lambda f:abs(f['t']-e['t']));d,c=f['after'][e['a']],f['after'][e['b']];dist=math.dist(d['pos'].values(),c['pos'].values());body=d['profile']['radius']+c['profile']['radius'];arms=body+d['profile']['reach'];q=max(0,min(1,1-(dist-body-.25)/max(.2,arms-body-.25)));base=max(.1,min(1,.25+.85*q));t=min(r['result']['telemetry']['frames'],key=lambda f:abs(f['t']-e['t']))['tackle'];grip=next(t for t in t['tacklers']if t['a']==e['a']);result['tossExecution'][arm]={'t':e['t'],'defender':r['initial'][e['a']]['slot'],'distance':dist,'contactQuality':q,'geometricBase':base,'measuredGrip':grip,'inferredExecution':grip['grip']/base,'qualification':'Initial wrap, free tackler, uncapped final grip. Execution inferred algebraically from recorded post-physics geometry and existing tackle.ts law; no new draw or simulation.'}
result['sameExecutionGripCross']=[{'geometry':g,'executionFrom':e,'execution':result['tossExecution'][e]['inferredExecution'],'predictedGrip':max(.08,min(1,result['tossExecution'][g]['geometricBase']*result['tossExecution'][e]['inferredExecution']))}for g in ['baseline','dl']for e in ['baseline','dl']]
result['cost']={'nativePrefixes':sum(len(rs)for rs in rows.values()),'completed':sum(r['phase']!='live'for rs in rows.values()for r in rs.values()),'censored':sum(r['phase']=='live'for rs in rows.values()for r in rs.values()),'collectorElapsedSeconds':sum(v['receipt']['elapsedSeconds']for v in result['groups'].values()),'games':0,'fullSuites':0,'reusedBaselineSnaps':8}
(p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'cost':result['cost'],'tossExecution':result['tossExecution'],'inactiveReuse':[r['id']for r in result['inactiveReuse']]}))
