"""Render saved same-defender trajectories; zero simulator ticks."""
import os
os.environ['MPLCONFIGDIR']='/tmp/run-flow-mpl';os.environ['XDG_CACHE_HOME']='/tmp/run-flow-cache'
import gzip,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent;dl=Path('/workspace/football-dl-acquired-run-flow/out/run-flow');old=Path('/workspace/football-defensive-snap-response/out/defensive-snap-response')
fig,axs=plt.subplots(2,2,figsize=(12,12))
for col,case in enumerate(['TOSS','FTOSS']):
 b=json.load(gzip.open(old/('baseline'if case=='TOSS'else'fresh-baseline')/(case+'.json.gz')))
 for row,(idx,arm,folder,title) in enumerate([(15,'lb-transfer',p,'Mike: square fit vs crossover'),(14,'dl-interior',dl,'Weak tackle: blocker shoulder vs acquired run flow')]):
  a=json.load(gzip.open(folder/arm/(case+'.json.gz')));ax=axs[row,col]
  for r,style,color,label in [(b,':','#777777','Defender baseline'),(a,'-','#2369ae','Same defender candidate')]:
   fs=[f for f in r['ticks']if f['t']<=3];ds=[f['before'][idx]for f in fs];ax.plot([d['pos']['x']for d in ds],[d['pos']['y']for d in ds],style,color=color,lw=2,label=label)
   for t in [.5,1.5,2.5,3]:
    f=min(fs,key=lambda f:abs(f['t']-t));d=f['before'][idx];ax.scatter(d['pos']['x'],d['pos']['y'],s=20,color=color)
    if r is a:ax.annotate(str(t),[d['pos']['x'],d['pos']['y']],xytext=(5,-8),textcoords='offset points',fontsize=8)
   ax.plot([f['before'][6]['pos']['x']for f in fs],[f['before'][6]['pos']['y']for f in fs],style,color='#428353',alpha=.8,label='Runner '+('baseline'if r is b else'candidate'))
  ax.axvline(40,color='#999999',ls='--',lw=.8);ax.set_aspect('equal');ax.set_xlim(32,47);ax.set_ylim(15,32);ax.grid(alpha=.2);ax.set_xlabel('x, yd; offense advances right');ax.set_ylabel('y, yd; toss toward lower y');ax.set_title(('Original players'if col==0 else'Fresh players')+' — '+title,fontsize=10)
  ax.text(.03,.03,'All paths 0–3 s; marks 0.5 / 1.5 / 2.5 / 3.0 s\n'+b['initial'][idx]['slot']+' · '+b['initial'][idx]['player']['id'],transform=ax.transAxes,fontsize=8)
axs[0,0].legend(fontsize=8,loc='upper left');fig.suptitle('Run flow: actual saved positions, same calls and players in each pair\nBaseline 7d23555a · LB-only 2d76a0ab · DL-only 5b1b4a5b; unchanged physics and capacities',fontsize=12)
fig.tight_layout();fig.savefig(p/'run-flow.png',dpi=130);fig.savefig(p/'run-flow.svg')
