"""Archive existing evidence and independently prove all runtime restorations. Zero ticks."""
from pathlib import Path
import json,subprocess,hashlib,difflib,tempfile,os,tarfile,shutil
p=Path(__file__).resolve().parent;root=p.parents[1];dlroot=Path('/workspace/football-dl-acquired-run-flow');dl=dlroot/'out/run-flow';out=p/'publication';common=out/'common';common.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def files(host):return{str(f.relative_to(host)):f.read_bytes()for f in(host/'src').rglob('*')if f.is_file()}
def digest(fs):
 h=hashlib.sha256()
 for name in sorted(fs):h.update(name.encode()+b'\0'+fs[name]+b'\0')
 return h.hexdigest()
base=files(p/'accepted-host');assert digest(base)=='7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197'
variants={'lb':files(root),'dl':files(dlroot),'combined':files(p/'combined-host')}
double=dict(base);double['src/sim/engagement.ts']=(dl/'double-prediction-engagement.ts').read_bytes();variants['dl-double']=double
pilot=dict(base);s=double['src/sim/engagement.ts'].decode();s=s.replace("if (stack && job!.technique !== 'lag' && reading && back)","if (stack && job!.technique !== 'lag' && reading && !declared && back)").replace('      && backSeen.pos.x <= sim.los - 1.6\n','').replace('desired = { x: d.pos.x, y: backSeen.pos.y + backSeen.vel.y * horizon - side * trail };','desired = { x: desired.x, y: backSeen.pos.y + backSeen.vel.y * horizon - side * trail };').replace('runner: flow === undefined && declared && (!edge || advanced), flow','runner: declared && (!edge || advanced), flow');pilot['src/sim/engagement.ts']=s.encode();variants['dl-pilot']=pilot
expected={'lb':json.loads((p/'lb-transfer/receipt.json').read_text())['source'],'dl':json.loads((dl/'dl-final/receipt.json').read_text())['source'],'combined':json.loads((p/'combined/receipt.json').read_text())['source'],'dl-double':json.loads((dl/'dl-transfer/receipt.json').read_text())['source'],'dl-pilot':json.loads((dl/'dl-pilot/receipt.json').read_text())['source']}
records={}
for arm,fs in variants.items():
 assert digest(fs)==expected[arm],(arm,digest(fs),expected[arm])
 patch=''.join(''.join(difflib.unified_diff(base[name].decode().splitlines(True),fs[name].decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))for name in sorted(fs)if fs[name]!=base[name]);path=common/(arm+'.patch');path.write_text(patch)
 with tempfile.TemporaryDirectory(prefix='run-flow-restore-',dir='/tmp')as folder:
  dest=Path(folder)
  for name,b in base.items():(dest/name).parent.mkdir(parents=True,exist_ok=True);(dest/name).write_bytes(b)
  env=dict(os.environ);env['GIT_CEILING_DIRECTORIES']='/tmp';subprocess.run(['git','apply','--check',str(path)],cwd=dest,env=env,check=True);subprocess.run(['git','apply',str(path)],cwd=dest,env=env,check=True);assert digest(files(dest))==expected[arm]
 records[arm]={'sourceSha256':expected[arm],'changedFiles':[n for n in sorted(fs)if fs[n]!=base[n]],'patchSha256':sha(path.read_bytes()),'restoredCompleteDigestVerified':True}
for folder in[p,dl]:
 for f in folder.iterdir():
  if f.is_file()and f.suffix in['.json','.gz','.mjs','.py','.log','.md','.png','.svg','.ts']:
   dest=common/f.name
   if dest.exists():assert dest.read_bytes()==f.read_bytes(),f.name
   else:shutil.copy2(f,dest)
for name in ['config/baseline.json','scripts/baseline.mjs','scripts/source-version.ts','package-lock.json','.nvmrc']:shutil.copy2(root/name,common/Path(name).name)
codepins={}
for name,host in [('lb',root),('dl',dlroot)]:
 pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=host,text=True).strip();codepins[name]=pin;(common/(name+'-code-tests.patch')).write_bytes(subprocess.check_output(['git','diff','--binary','f4146275ce7539816bf57b4ed55a0d2be10e48c7',pin,'--','src','test'],cwd=host))
(common/'claude-film-cases.txt').write_bytes(subprocess.check_output(['git','show','65db81d710bc0ff75fcd6a81cc4fa8b5f1b89e5f:scripts/diag/stretch/film-cases.txt'],cwd=root))
archives=[]
for group,items in [('lb-native',[(p,k)for k in['enriched','crossover','lb-transfer','extra-baseline','lb-extra']]),('dl-prototypes',[(dl,k)for k in['dl-pilot','dl-transfer','dl-extra']]),('dl-final',[(dl,'dl-final')]),('combined',[(p,'combined')]),('common',None)]:
 members=[(f,str(f.relative_to(host)))for host,k in items for f in sorted((host/k).iterdir())if f.is_file()]if items else[(f,str(f.relative_to(common)))for f in sorted(common.iterdir())if f.is_file()]
 entries=[{'path':name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f,name in members];path=out/(group+'.tar.gz')
 with tarfile.open(path,'w:gz',compresslevel=1)as ar:
  for f,name in members:assert not f.is_symlink()and not name.startswith('/')and '..'not in Path(name).parts;ar.add(f,arcname=name,recursive=False)
 assert path.stat().st_size<32*1024**2,(group,path.stat().st_size)
 with tarfile.open(path)as ar:
  assert len(ar.getmembers())==len(entries)
  for m,e in zip(ar.getmembers(),entries):assert m.isfile()and m.name==e['path']and sha(ar.extractfile(m).read())==e['sha256']
 archives.append({'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'members':entries})
a=json.loads((p/'analysis.json').read_text());manifest={'schema':'run-flow-evidence-v1','acceptedDevelop':a['acceptedDevelop'],'queue':a['queue'],'codePins':codepins,'baselineSourceSha256':digest(base),'sources':records,'archives':archives,'cost':a['cost'],'reuse':{'baseline':{'pin':a['reusedBaselineEvidence'],'location':'data/reviews/defensive-snap-response','selection':json.loads((p/'transfer-selection.json').read_text())},'inactiveDLControls':a['inactiveReuse']},'qualifications':['Claude film page and NFL conversions were not available in this executor; published case definitions were inspected, two cases rebuilt on accepted source, no NFL collection or aggregate equivalence claim.','Archived hosts inherit outer git HEAD and empty validation digest; exact accepted pin, source patches/full digest, frozen setups, tool hashes, lock and launcher flags identify actual execution.','LB fixture setup failure and DL double-prediction assertion failure retained. DL prototype versions are not candidates.','DL-only PA/PA13/PASS13 are compatible zero-activation controls from c750 source, not final-source executions; all physical/command/RNG frames equal accepted baseline and the final correction changes only the inactive target expression.','Full result identity is used only where actually equal; extra passive/acquired-query telemetry can differ while physical tapes match.','No grip/strength/physics changes, no timing or #158/#153 package activation. Combined source is four native interaction checks, not Integration full verification.','Nine prefixes remain live; completed outcomes are distinct. Recorded contact geometry uses 20Hz body endpoints, not reconstructed within-step geometry.']}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'SHA256SUMS').write_text(''.join(e['sha256']+'  '+e['path']+'\n'for e in archives));print(json.dumps({'codePins':codepins,'archives':{e['path']:e['bytes']for e in archives},'sources':{k:v['sourceSha256']for k,v in records.items()}}))
