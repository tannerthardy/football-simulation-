/** Pure saved-geometry comparison: no controllers, movement previews, World,
 * new perceptions or RNG. Derived native shapes are not captured consumer
 * cost invocations; the four A042 cost queries use their saved preview ends.
 */
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {trafficPath,type TrafficBounds,type TrafficDisc} from '../../src/sim/traffic-path.js';
import {trafficDistance} from '/tmp/traffic-path-optimized.mts';
import {sourceVersion} from '../../scripts/source-version.js';
import {END_LINE_X,FIELD_WIDTH} from '../../src/core/field.js';

type Query={id:string;scope:string;start:{x:number;y:number};goal:{x:number;y:number};discs:TrafficDisc[];bounds?:TrafficBounds};
const source=sourceVersion(),started=performance.now(),queries:Query[]=[],inputs:Record<string,string>={};
function load(path:string){const bytes=readFileSync(path);inputs[path]=createHash('sha256').update(bytes).digest('hex');return JSON.parse(path.endsWith('.gz')?gunzipSync(bytes).toString():bytes.toString());}
const decision=load('out/navigation/route-decision-impact.json');
const goal={x:decision.raw.goal.point.x+(decision.raw.goal.velocity?.x??0)*.6,y:decision.raw.goal.point.y+(decision.raw.goal.velocity?.y??0)*.6};
const futureDiscs=decision.peers.map((p:any)=>({center:{x:p.pos.x+p.vel.x*.6,y:p.pos.y+p.vel.y*.6},radius:p.touch}));
const margin=decision.body.profile.radius+.5;
const bounds={minX:margin,maxX:END_LINE_X-margin,minY:margin,maxY:FIELD_WIDTH-margin};
for(const [i,row]of decision.evaluated.entries())queries.push({id:'A042-saved-cost-'+i,scope:'saved cost query/preview endpoint',start:row.path.at(-1).pos,goal,discs:futureDiscs,bounds});
const saved=load('out/navigation/A008-impact-route.json.gz'),actors=saved.observed.actors;
for(const t of [1.75,2,2.25,2.5]){
 const row=saved.observed.rows.find((r:any)=>r.t===t);if(!row)continue;
 for(const idx of [15,20,21]){
  const own=actors[idx],request=row.preSpacing[idx],goal=request?.objective;
  if(!goal||(goal.kind==='moving'&&!goal.velocity))continue;
  const pictures=row.consumed.filter((p:any)=>p.stage==='spacing'&&p.observer===idx&&actors[p.target].team===own.team);
  const byTarget=new Map(pictures.map((p:any)=>[p.target,p.picture]));if(byTarget.size!==10)continue;
  const discs=[...byTarget].map(([key,p]:any)=>({center:p.pos,radius:.9*(own.profile.radius+actors[key].profile.radius)}));
  const flow=goal.kind==='fixed'?{x:0,y:0}:goal.velocity,futureGoal={x:goal.point.x+flow.x*.6,y:goal.point.y+flow.y*.6};
  const margin=own.profile.radius+.5,bounds={minX:margin,maxX:END_LINE_X-margin,minY:margin,maxY:FIELD_WIDTH-margin};
  queries.push({id:`A008-shape-${idx}-${t}-current`,scope:'saved native incoming geometry, current-route shape',start:row.before[idx].pos,goal:futureGoal,discs,bounds});
  queries.push({id:`A008-shape-${idx}-${t}-future`,scope:'saved native own achieved endpoint + acquired constant-velocity future geometry; not original cost invocation',start:row.achieved[idx].pos,goal:futureGoal,discs:[...byTarget].map(([key,p]:any)=>({center:{x:p.pos.x+p.vel.x*.6,y:p.pos.y+p.vel.y*.6},radius:.9*(own.profile.radius+actors[key].profile.radius)})),bounds});
 }
}
const stages:Query[]=[
 {id:'clear-ten',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:Array.from({length:10},(_,i)=>({center:{x:i*2,y:20},radius:1}))},
 {id:'one-with-far-peers',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:0},radius:1},...Array.from({length:9},(_,i)=>({center:{x:i*2,y:20},radius:1}))]},
 {id:'arc-interior-added',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:0},radius:1},{center:{x:0,y:1.15},radius:.25},{center:{x:0,y:-1.15},radius:.25}]},
 {id:'arc-signed-a',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:.2},radius:1},{center:{x:0,y:-.95},radius:.25}]},
 {id:'arc-signed-b',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:-.2},radius:1},{center:{x:0,y:.95},radius:.25}]},
 {id:'longer-bounded-side',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:-.35},radius:1}],bounds:{minX:-4,maxX:4,minY:-2,maxY:.5}},
 {id:'bounded-null',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:-.35},radius:1}],bounds:{minX:-4,maxX:4,minY:-.1,maxY:.1}},
 {id:'contained-duplicate',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:0},radius:1},{center:{x:0,y:0},radius:1},{center:{x:.2,y:.1},radius:.3}]},
 {id:'coincident-inside',scope:'staged geometry',start:{x:0,y:0},goal:{x:0,y:0},discs:[{center:{x:0,y:0},radius:1}]},
 {id:'invalid-disc',scope:'staged invalid geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:NaN},radius:1}]},
 {id:'touching',scope:'staged geometry',start:{x:-3,y:0},goal:{x:3,y:0},discs:[{center:{x:0,y:-1},radius:1},{center:{x:0,y:1},radius:1}]},
];
queries.push(...stages);
const full=(q:Query)=>trafficPath(q.start,q.goal,q.discs,q.bounds)?.distance??null;
const lazy=(q:Query)=>trafficDistance(q.start,q.goal,q.discs,q.bounds);
const results=queries.map(q=>{const a=full(q),b=lazy(q);return{id:q.id,scope:q.scope,discs:q.discs.length,full:a,lazy:b,exact:a===b,error:a===null||b===null?(a===b?0:Infinity):Math.abs(a-b)};});
const native=queries.filter(q=>q.id.startsWith('A008'));
// Warm once, then one alternating full/lazy measurement per query set. This
// is pure local geometry timing, not whole-play CPU or a game benchmark.
for(const q of native){full(q);lazy(q);}
const times=[];
for(const [label,run]of [['full',full],['lazy',lazy]]as const){const start=performance.now();let sum=0;for(let rep=0;rep<3;rep++)for(const q of native)sum+=run(q)??0;times.push({label,queries:native.length,repeats:3,elapsedMs:performance.now()-start,checksum:sum});}
if(sourceVersion()!==source)throw Error('source changed during pure-geometry comparison');
const report={source,node:process.version,inputs,draftSha256:createHash('sha256').update(readFileSync('/tmp/traffic-path-optimized.ts')).digest('hex'),scope:'No native execution, physics preview or sensing; scalar geometry only',queryCount:queries.length,results,times,maxError:Math.max(...results.map(r=>r.error)),mismatches:results.filter(r=>r.error>1e-9),elapsedMs:performance.now()-started};
writeFileSync('out/navigation/distance-lazy-probe.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
