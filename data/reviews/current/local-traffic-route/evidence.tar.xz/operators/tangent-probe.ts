/** Ignored, bounded feasibility probe. No football or shared-policy change. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {Agent} from '../../src/sim/agent.js';
import {PerceptionBuffer,type Perceived} from '../../src/sim/perception.js';
import {spaceTeammates} from '../../src/sim/spacing.js';
import {track} from '../../src/sim/behaviors/common.js';
import {movementObjective} from '../../src/sim/movement-objective.js';
import {World,type Intent} from '../../src/physics/world.js';
import {previewFreeMovement,type MovementSample} from '../../src/physics/movement-preview.js';
import type {Body} from '../../src/physics/kinematics.js';
import {sourceVersion} from '../../scripts/source-version.js';

const start=performance.now(),source=sourceVersion();
const saved=JSON.parse(readFileSync('out/navigation/local-centered.json','utf8'));
const fixture=JSON.parse(gunzipSync(readFileSync('test/fixtures/traffic-step.json.gz')).toString());
const H=.6,DT=.05;
type Peer={key:number;pos:{x:number;y:number};vel:{x:number;y:number};touch:number;age:number};
const norm=(a:number)=>Math.atan2(Math.sin(a),Math.cos(a));
function clearance(body:Body,path:MovementSample[],p:Peer){
 let x=body.pos.x-p.pos.x,y=body.pos.y-p.pos.y,min=Math.hypot(x,y)-p.touch;
 for(const s of path){
  const xx=s.pos.x-p.pos.x-p.vel.x*s.t,yy=s.pos.y-p.pos.y-p.vel.y*s.t;
  const dx=xx-x,dy=yy-y,t=Math.max(0,Math.min(1,-(x*dx+y*dy)/Math.max(1e-12,dx*dx+dy*dy)));
  min=Math.min(min,Math.hypot(x+t*dx,y+t*dy)-p.touch);x=xx;y=yy;
 }
 return min;
}
// Exact shortest geometric path around ONE observed disc. Max across peers
// is a lower bound for combined traffic, never a certified multi-peer route.
function discCost(from:{x:number;y:number},goal:{x:number;y:number},center:{x:number;y:number},r:number){
 const ax=from.x-center.x,ay=from.y-center.y,bx=goal.x-center.x,by=goal.y-center.y;
 const da=Math.hypot(ax,ay),db=Math.hypot(bx,by),direct=Math.hypot(goal.x-from.x,goal.y-from.y);
 if(da<=r||db<=r)return Infinity;
 const sx=goal.x-from.x,sy=goal.y-from.y,t=Math.max(0,Math.min(1,-(ax*sx+ay*sy)/Math.max(1e-12,sx*sx+sy*sy)));
 if(Math.hypot(ax+t*sx,ay+t*sy)>=r)return direct;
 const angle=Math.acos(Math.max(-1,Math.min(1,(ax*bx+ay*by)/(da*db))));
 const arc=Math.max(0,angle-Math.acos(r/da)-Math.acos(r/db));
 return Math.sqrt(da*da-r*r)+Math.sqrt(db*db-r*r)+r*arc;
}
function selector(a:Agent,raw:Intent,native:Intent,peers:Peer[],now:number){
 const objective=movementObjective(raw);
 if(!objective||peers.some(p=>!Number.isFinite(p.age)||p.age<0||![p.pos.x,p.pos.y,p.vel.x,p.vel.y].every(Number.isFinite)))
  return {command:native,reason:'missing legitimate picture/objective',candidates:[]};
 const flow=objective.kind==='moving'?objective.velocity: {x:0,y:0};
 if(!flow)return {command:native,reason:'unknown objective flow',candidates:[]};
 const heading=Math.atan2(objective.point.y-a.pos.y,objective.point.x-a.pos.x);
 const distance=Math.hypot(objective.point.x-a.pos.x,objective.point.y-a.pos.y);
 const intervals=peers.flatMap(p=>{
  const dx=p.pos.x-a.pos.x,dy=p.pos.y-a.pos.y,d=Math.hypot(dx,dy),bearing=norm(Math.atan2(dy,dx)-heading);
  if(d<=p.touch||dx*Math.cos(heading)+dy*Math.sin(heading)<=0||d>distance)return [];
  const half=Math.asin(p.touch/d);return [{lo:bearing-half,hi:bearing+half,key:p.key}];
 });
 let lo=0,hi=0;
 for(let i=0;i<=intervals.length;i++)for(const span of intervals)if(span.lo<=hi&&span.hi>=lo){lo=Math.min(lo,span.lo);hi=Math.max(hi,span.hi);}
 if(lo===0&&hi===0)return {command:native,reason:'selected goal ray unobstructed',candidates:[]};
 const goal={x:objective.point.x+flow.x*H,y:objective.point.y+flow.y*H};
 const speed=Math.hypot(native.vel.x,native.vel.y);
 const requests=[{name:'native',command:native},...[lo,hi].map((offset,i)=>({name:i?'positive-tangent':'negative-tangent',
  command:{...raw,vel:{x:Math.cos(heading+offset)*speed,y:Math.sin(heading+offset)*speed}}}))];
 const candidates=requests.map(({name,command})=>{
  const path=previewFreeMovement(a.body,command,now,12),end=path.at(-1)!;
  const gaps=peers.map(p=>clearance(a.body,path,p));
  const euclideanGoalError=Math.hypot(end.pos.x-goal.x,end.pos.y-goal.y);
  const detourCost=Math.max(euclideanGoalError,...peers.map(p=>discCost(end.pos,goal,{x:p.pos.x+p.vel.x*H,y:p.pos.y+p.vel.y*H},p.touch)));
  return {name,command,path,gaps,worstClearance:Math.min(...gaps),euclideanGoalError,detourCost,
   forwardProgress:(end.pos.x-a.pos.x)*Math.cos(heading)+(end.pos.y-a.pos.y)*Math.sin(heading),
   up:path.every(s=>s.support==='up')};
 });
 const original=candidates[0];let chosen=original;
 for(const c of candidates.slice(1)){
  // A short acquired-picture forecast is not a full-route clearance demand.
  // Do not worsen interference or turn a previously clear peer into a hit.
  const noWorse=c.gaps.every((g,i)=>g>=Math.min(0,original.gaps[i])-1e-9);
  if(c.up&&c.forwardProgress>0&&noWorse&&c.detourCost<chosen.detourCost-1e-9)chosen=c;
 }
 return {command:chosen.command,reason:chosen.name,angularSilhouette:{lo,hi},goal,flow,candidates};
}
function run(mode:'head-on'|'cluster'|'clear'){
 const prior=saved.rows.find((r:any)=>r.mode===mode),bodies:Body[]=structuredClone(prior.initial);
 const agents=bodies.map((b,i)=>new Agent(i,'D',i?'FS':'SS',fixture.player,b.profile,b,
  {kind:'zone',update(){throw Error('No new football read');}}));
 const a=agents[0],world=new World(bodies);world.time=2;
 const pictures=new PerceptionBuffer(agents.length,DT);pictures.record(agents);
 const states=[];
 for(let k=0;k<60;k++){
  const now=2+k*DT,raw:Intent=track(a,prior.goal,{x:0,y:0},{speed:.7,gain:3,facing:0});
  const commands:Intent[]=[raw,...agents.slice(1).map(()=>({vel:{x:0,y:0},free:true}))];
  const acquired:{peer:number;picture:Perceived}[]=[];
  spaceTeammates(agents,commands,(_actor,peer)=>{const picture=pictures.perceive(peer.idx,.05);acquired.push({peer:peer.idx,picture:structuredClone(picture)});return picture;},{now});
  const peers:Peer[]=acquired.map(({peer,picture})=>({key:peer,pos:picture.pos,vel:picture.vel,age:picture.age!,touch:.9*(a.profile.radius+agents[peer].profile.radius)}));
  const before=structuredClone(bodies),native=commands[0],selection=selector(a,raw,native,peers,now);
  commands[0]=selection.command;
  const report=world.step(commands,DT);pictures.record(agents);
  states.push({t:now,before:before.map(b=>({pos:b.pos,vel:b.vel,support:b.support})),objective:movementObjective(raw),raw,native,acquired,
   selection,after:structuredClone(bodies),contacts:report.contacts,workResidual:report.work.residual});
 }
 const first=states.find(s=>s.selection.reason.endsWith('tangent'));
 return {mode,goal:prior.goal,initial:prior.initial,baselineSource:saved.source,baseline:prior.result,states,
  firstChanged:first?{t:first.t,before:first.before[0],raw:first.raw,native:first.native,selection:first.selection}:null,
  result:{progress:a.pos.x-prior.initial[0].pos.x,goalError:Math.hypot(prior.goal.x-a.pos.x,prior.goal.y-a.pos.y),
   lateral:a.pos.y-prior.initial[0].pos.y,speed:Math.hypot(a.vel.x,a.vel.y),state:a.body.support?.state,
   contactIntervals:states.filter(s=>s.contacts.length).map(s=>({t:s.t,contacts:s.contacts})),
   tangentTicks:states.filter(s=>s.selection.reason.endsWith('tangent')).length,
   maximumWorkResidual:Math.max(...states.map(s=>Math.abs(s.workResidual)))}};
}
const rows=(['head-on','cluster','clear'] as const).map(run);assert.equal(sourceVersion(),source);
const result={question:'Can one acquired-geometry tangent option make an achievable local detour while preserving the owned goal?',
 source,node:process.version,operatorSha256:createHash('sha256').update(readFileSync(import.meta.filename)).digest('hex'),
 baselineSource:saved.source,baselineSha256:createHash('sha256').update(readFileSync('out/navigation/local-centered.json')).digest('hex'),
 construction:'Native requested pace, unchanged raw facing/posture/effort; tangent on each side of the connected acquired-disc angular silhouette. Replan every.05s.',
 ranking:'Minimize max exact one-disc remaining path cost at achieved0.6s endpoint; that is only a lower bound for joint traffic. Reject worse peer interference; no future route is read.',
 limitations:['Staged feasibility only. Baseline may differ by the root joint-projection source change; source pins explicit.',
  'Acquired peer motion is held constant for0.6s, with timestamps/age retained. No new perception calls, hidden routes or future body states enter selection.',
  'Maximum of individual geometric detours does not certify a joint path. Radius is the existing physical touch distance, with no new buffer.',
  'Peers receive free:true exactly as the saved staged experiment; bodies can move/collide, but this is not live football reaction.'],
 rows,wallSeconds:(performance.now()-start)/1000};
const out='out/navigation/tangent-probe.json';writeFileSync(out,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({out,source,rows:rows.map(r=>({mode:r.mode,baseline:r.baseline,result:r.result,firstChanged:r.firstChanged})),wallSeconds:result.wallSeconds},null,2));
