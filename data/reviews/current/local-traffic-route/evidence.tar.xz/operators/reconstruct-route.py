import hashlib
from pathlib import Path
p=Path('out/navigation/sources');p.mkdir(exist_ok=True)
s=Path('src/sim/traffic-route.ts').read_text();i=s.index('/** Swept touch');j=s.index('/** Existing man/zone',i)
old='''function clearance(a:Agent,path:readonly MovementSample[],peer:TrafficPeer):number {
  let x=a.pos.x-peer.pos.x,y=a.pos.y-peer.pos.y,least=Math.hypot(x,y)-peer.touch;
  for(const sample of path){
    const xx=sample.pos.x-peer.pos.x-peer.vel.x*sample.t;
    const yy=sample.pos.y-peer.pos.y-peer.vel.y*sample.t;
    const dx=xx-x,dy=yy-y;
    const along=Math.max(0,Math.min(1,-(x*dx+y*dy)/Math.max(1e-12,dx*dx+dy*dy)));
    least=Math.min(least,Math.hypot(x+along*dx,y+along*dy)-peer.touch);x=xx;y=yy;
  }
  return least;
}

'''
s=s[:i]+old+s[j:];s=s.replace('oldEncounters=peers.map(peer=>encounter(a,oldPath,peer))','oldGaps=peers.map(peer=>clearance(a,oldPath,peer))');s=s.replace('''||peers.some((peer,i)=>{
        const next=encounter(a,path,peer),old=oldEncounters[i];
        return next.gap<Math.min(0,old.gap)-EPS||next.closing>old.closing+EPS;
      }))continue;''','''||peers.some((peer,i)=>clearance(a,path,peer)<Math.min(0,oldGaps[i])-EPS))continue;''')
h=hashlib.sha256()
for f in sorted((f for f in Path('src').rglob('*')if f.is_file()),key=str):h.update(str(f).encode()+b'\0'+(s.encode()if str(f)=='src/sim/traffic-route.ts' else f.read_bytes())+b'\0')
print('reconstructed903',h.hexdigest());assert h.hexdigest()=='903537e073e863941ba8a2ee95ca226c2b2657d19fbce71fbe9f6b88e52c1ad6'
for tag in ['903537e','fa06e89']:
 for rel in ['src/sim/spacing.ts','src/sim/traffic-route.ts','src/sim/traffic-path.ts']:
  t=p/tag/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(s.encode()if tag=='903537e'and rel.endswith('traffic-route.ts')else Path(rel).read_bytes())
