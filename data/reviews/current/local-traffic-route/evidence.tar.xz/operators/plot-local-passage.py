import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
base=json.loads(Path('/workspace/navigation-accepted-reference/out/navigation/local-matched-baseline.json').read_text());final=json.loads(Path('out/navigation/local-final.json').read_text())
fig,axes=plt.subplots(1,2,figsize=(11,4.2),layout='constrained')
for ax,mode in zip(axes,['head-on','cluster']):
 a=next(x for x in base['rows']if x['mode']==mode);b=next(x for x in final['rows']if x['mode']==mode);center=a['initial'][0]['pos']['y']
 for body in a['initial'][1:]:
  xy=(body['pos']['x']-50,body['pos']['y']-center);ax.add_patch(Circle(xy,body['profile']['radius'],color='#64748b',alpha=.65));ax.add_patch(Circle(xy,.9*(body['profile']['radius']+a['initial'][0]['profile']['radius']),fill=False,ls=':',lw=1,color='#94a3b8'))
 for row,color,label in [(a,'#b91c1c','Accepted movement'),(b,'#1d4ed8','Local route')]:
  pts=[row['initial'][0]['pos']]+[s['after'][0]['pos']for s in row['states']];xs=[p['x']-50 for p in pts];ys=[p['y']-center for p in pts];ax.plot(xs,ys,color=color,label=label,lw=2.3);ax.scatter(xs[-1],ys[-1],s=35,color=color,zorder=4)
 ax.scatter([8],[0],marker='*',s=130,color='#15803d',label='Unchanged goal',zorder=5)
 ax.set(xlim=(-.15,8.3),ylim=(-2.15,1.85),xlabel='Progress toward goal (yd)',ylabel='Lateral position (yd)',title=('Centered teammate'if mode=='head-on'else'Three-player cluster')+'\n'+f"3-second progress: {a['result']['progress']:.2f} → {b['result']['progress']:.2f} yd")
 ax.set_aspect('equal');ax.grid(alpha=.15);ax.spines[['top','right']].set_visible(False)
axes[0].legend(frameon=False,loc='lower right',fontsize=8)
fig.suptitle('Same goal, unchanged bodies and movement physics',fontsize=13)
fig.text(.5,.015,'Staged passive-teammate controls; no positive teammate impacts in these two continuations.',ha='center',fontsize=9,color='#475569')
fig.savefig('out/navigation/local-passage.png',dpi=170);fig.savefig('out/navigation/local-passage.svg')
