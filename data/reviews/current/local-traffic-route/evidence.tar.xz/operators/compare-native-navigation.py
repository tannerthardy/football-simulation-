import json,gzip,sys,math
from pathlib import Path

def read(p):
 return json.loads(gzip.decompress(Path(p).read_bytes()) if str(p).endswith('.gz') else Path(p).read_text())
a,b=map(read,sys.argv[1:3]);ra=a['observed']['rows'];rb=b['observed']['rows'];actors=a['observed']['actors'];names={x['idx']:x['slot'] for x in actors}
print('SOURCE',a['source'],b['source']);print('RESULT',a['observed']['result'],b['observed']['result']);print('TIME',a['observed']['runtime'],b['observed']['runtime']);print('INPUT',a['inputSha256']==b['inputSha256'],'TOOL',a['toolSha256']==b['toolSha256'])
changes=[]
for old,new in zip(ra,rb):
 for idx,(x,y) in enumerate(zip(old['applied'],new['applied'])):
  if x is None or y is None:continue
  u=x['request']['vel'];v=y['request']['vel'];d=math.hypot(u['x']-v['x'],u['y']-v['y'])
  if d>1e-8:changes.append((old['t'],idx,d,old,new,x,y))
print('CHANGED',len(changes));firsts={}
for t,idx,d,*rest in changes:
 if idx not in firsts:firsts[idx]=(t,d)
print('FIRSTPERACTOR',[(names[k],k,v) for k,v in firsts.items()])
for t,idx,d,old,new,x,y in changes[:8]:
 def summarize(row):
  raw=next((z.get('raw') for z in row['decisions'] if z['idx']==idx),None)
  pre=row['preSpacing'][idx] if row['preSpacing'] else None
  goal=pre.get('objective') if pre else None
  incoming=row['before'][idx];after=row['achieved'][idx]
  err=None
  if goal:
   gp=goal['point'];err={'before':math.hypot(incoming['pos']['x']-gp['x'],incoming['pos']['y']-gp['y']),'after':math.hypot(after['pos']['x']-gp['x'],after['pos']['y']-gp['y'])}
  return {'body':{k:incoming.get(k) for k in ['pos','vel','facing','support']},'raw':raw,'pre':pre,'applied':row['applied'][idx],'achieved':after,'goalError':err,'contacts':[z for z in row['contacts'] if z.get('a')==idx or z.get('b')==idx],'blocks':[z for z in row['blocks'] if z['blocker']==idx or z['defender']==idx],'peers':[z for z in row['consumed'] if z['observer']==idx and z['stage']=='spacing']}
 print('CHANGE',t,names[idx],idx,'delta',d,'sameEnteringBodies',old['before']==new['before'],'samePictures',old['consumed']==new['consumed'])
 print(json.dumps({'old':summarize(old),'new':summarize(new)},separators=(',',':')))
print('EVENTS OLD',json.dumps(a['observed']['events']));print('EVENTS NEW',json.dumps(b['observed']['events']))
