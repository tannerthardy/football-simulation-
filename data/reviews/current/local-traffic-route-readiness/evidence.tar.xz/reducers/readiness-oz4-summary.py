import gzip,json,math,hashlib
from pathlib import Path
pairs={k:json.loads(gzip.decompress(Path(p).read_bytes()))for k,p in [('reference','/workspace/route182-183-reference/out/readiness-186/OZ4-reference.json.gz'),('composition','/workspace/route182-183-186-check/out/readiness-186/OZ4-composition.json.gz')]}
dist=lambda a,b:math.hypot(a['x']-b['x'],a['y']-b['y'])
out={}
for key,p in pairs.items():
 actors={x['idx']:x for x in p['observed']['actors']};slots={x['slot']:x['idx']for x in actors.values()};will=slots['LB_W'];mike=slots['LB_M'];runner=slots['RB'];rows=p['observed']['rows'];items=[]
 for r in rows:
  t=r['t'];raw=r['preSpacing'][will];goal=raw and raw.get('objective');a=r['achieved'][will];mi=r['achieved'][mike];rb=r['achieved'][runner];contacts=[c for c in r['contacts']if c.get('impulse',0)>0 and(will in[c['i'],c['j']]or mike in[c['i'],c['j']])]
  if t in[1.75,2,2.25,2.3,2.4,2.55,2.75,3,3.5,4,4.2]:
   dec=next((d for d in r['decisions']if d['idx']==will),None);items.append({'t':t,'willBody':{k:r['before'][will][k]for k in ['pos','vel','facing','support']},'decision':dec,'raw':raw,'applied':r['applied'][will],'achieved':a,'runnerDistance':dist(a['pos'],rb['pos']),'mikeDistance':dist(a['pos'],mi['pos']),'goalDistance':dist(a['pos'],goal['point'])if goal else None,'mikeBody':{k:r['before'][mike][k]for k in ['pos','vel']},'mikeCommand':r['applied'][mike],'contacts':contacts,'blocks':[b for b in r['blocks']if mike==b['defender']or will==b['defender']],'peers':[p for p in r['consumed']if p['stage']=='spacing'and p['observer']==will and p['target']==mike]})
 physical=[{'t':r['t'],**c}for r in rows for c in r['contacts']if c.get('impulse',0)>0 and (will in[c['i'],c['j']]or mike in[c['i'],c['j']])]
 outcome={'source':p['source'],'inputSha256':p['inputSha256'],'toolSha256':p['toolSha256'],'slots':{'will':will,'mike':mike,'runner':runner},'result':p['observed']['result'],'wall':p['observerControl']['runtime'],'observedWall':p['observed']['runtime'],'states':items,'willPositiveContacts':[c for c in physical if will in[c['i'],c['j']]],'mikePositiveContacts':[c for c in physical if mike in[c['i'],c['j']]],'events':p['observed']['events'],'terminalRunnerDistance':dist(rows[-1]['achieved'][will]['pos'],rows[-1]['achieved'][runner]['pos']),'terminalWillPosition':rows[-1]['achieved'][will]['pos'],'terminalMikePosition':rows[-1]['achieved'][mike]['pos']}
 out[key]=outcome
 print(key,'slots',outcome['slots'],'terminalWillRunner',outcome['terminalRunnerDistance'],'firstWillContacts',outcome['willPositiveContacts'][:2],'willContactCount',len(outcome['willPositiveContacts']),'keyEvents',[e for e in outcome['events']if e['type']in['handoff','carrier_contact','tackle_wrap','broken_tackle','tackle']])
 for x in items:
  g=x['raw'].get('objective')if x['raw']else None;raw=x['raw']['request']['vel']if x['raw']else None;v=x['applied']['request']['vel'];print(x['t'],'goal',g,'raw',raw,'final',v,'speed',math.hypot(x['achieved']['vel']['x'],x['achieved']['vel']['y']),'runnerD',round(x['runnerDistance'],5),'goalD',round(x['goalDistance'],5)if x['goalDistance']is not None else None,'Mikeblocks',x['blocks'])
Path('/workspace/local-traffic-route/out/readiness-186/OZ4-summary.json').write_text(json.dumps(out,indent=2)+'\n')
