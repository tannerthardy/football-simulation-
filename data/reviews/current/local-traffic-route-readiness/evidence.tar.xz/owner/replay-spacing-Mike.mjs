/** Saved-input command-stage attribution only. No native continuation, sensing
 * or RNG; the production spacing functions may use their normal movement preview.
 * Shadow both refinements over the SAME recorded candidate incoming states.
 */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {spaceTeammates as reference} from '/workspace/route182-183-reference/src/sim/spacing.ts';
import {spaceTeammates as composition} from '/workspace/route182-183-186-check/src/sim/spacing.ts';
import * as refGoal from '/workspace/route182-183-reference/src/sim/movement-objective.ts';
import * as candidateGoal from '/workspace/route182-183-186-check/src/sim/movement-objective.ts';
import {fatigueFactor,enduranceFactor} from '/workspace/route182-183-186-check/src/physics/kinematics.ts';
const input='/workspace/route182-183-186-check/out/readiness-186/OZ4-composition.json.gz';
const bytes=readFileSync(input),tape=JSON.parse(gunzipSync(bytes));
const actors=tape.observed.actors,idx=16,own=actors[idx];
const clone=x=>structuredClone(x),hash=x=>createHash('sha256').update(x).digest('hex');
function shadow(select,goals){
 const a={idx,team:own.team,behavior:{kind:'zone'},body:null,engagement:null,
  get profile(){return this.body.profile;},get pos(){return this.body.pos;},get vel(){return this.body.vel;},
  get speedScale(){return fatigueFactor(this.body.energy)*enduranceFactor(this.body)*(1-.08*(this.body.squeeze??0));},
  isDown(){return this.body.support?.state!=='up';}};
 const output=[];let previous=null;
 for(const row of tape.observed.rows){
  const source=row.preSpacing?.[idx];assert(source,'Missing pre-spacing command');a.body=clone(row.before[idx]);
  if(a.body.support?.since===null)a.body.support.since=-Infinity;
  a.engagement=row.blocks.some(b=>b.blocker===idx||b.defender===idx)?{}:null;
  const pictures=row.consumed.filter(p=>p.stage==='spacing'&&p.observer===idx);assert.equal(pictures.length,10);
  const observed=new Map(pictures.map(p=>[p.target,clone(p.picture)]));
  // Defensive peers in this input announce no called motion. Do not silently
  // replace an installed prediction with an unmodified observation.
  assert(row.calledMotion.filter(c=>c.stage==='spacing'&&c.owners.some(i=>actors[i].team===own.team)).every(c=>c.value===null));
  const peers=pictures.map(p=>({idx:p.target,team:own.team,profile:actors[p.target].profile,
   get body(){throw Error('Private teammate body');},get pos(){throw Error('Private teammate position');},
   get vel(){throw Error('Private teammate velocity');},get engagement(){throw Error('Private teammate load');}}));
  const constrained=previous?.contacts.some(c=>c.i===idx||c.j===idx)||row.grasps.some(g=>g.a===idx||g.b===idx);
  const raw=source.objective?goals.withMovementObjective(clone(source.request),source.objective):clone(source.request);
  const commands=[raw,...peers.map(()=>({vel:{x:0,y:0},free:true}))];
  const bodyBefore=clone(a.body),pictureBefore=clone([...observed]);let reads=0;
  select([a,...peers],commands,(_a,p)=>{reads++;return observed.get(p.idx);},{now:row.t,constrained:constrained?new Set([a.body]):undefined});
  assert.equal(reads,10);assert.deepEqual(a.body,bodyBefore);assert.deepEqual([...observed],pictureBefore);
  output.push({t:row.t,raw:source,request:clone(commands[0]),objective:goals.movementObjective(commands[0])??null,
    constrained:!!constrained,ownEngaged:!!a.engagement,recorded:row.applied[idx],age: pictures.map(p=>p.sourceAge)});previous=row;
 }
 return output;
}
const old=shadow(reference,refGoal),next=shadow(composition,candidateGoal);
const delta=(a,b)=>Math.hypot(a.vel.x-b.vel.x,a.vel.y-b.vel.y);
const mismatches=next.flatMap((r,i)=>delta(r.request,r.recorded.request)>1e-10?[{t:r.t,delta:delta(r.request,r.recorded.request),replay:r.request,recorded:r.recorded.request}]:[]);
const changes=next.flatMap((r,i)=>delta(r.request,old[i].request)>1e-8?[{t:r.t,ordinary:old[i].request,selected:r.request,objective:r.objective,constrained:r.constrained,ownEngaged:r.ownEngaged}]:[]);
const result={input,sha256:hash(bytes),sourceReference:tape.source,question:'Which post-producer command change came from the new route helper on the same saved incoming path?',qualification:'Shadow refinements over recorded bodies, not alternate reacting execution. Tactile restrictions are reconstructed only for this Mike and its recorded own engagement/tactile exclusions. All defensive called-motion cues are asserted absent. Validate against native requests before attributing.',frames:next.length,mismatches,changes,old,next};
writeFileSync('out/readiness-186/OZ4-spacing-Mike-replay.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({frames:next.length,mismatches,changes:changes.filter(c=>c.t<=2.6)},null,2));
assert.equal(mismatches.length,0,'Saved-input reconstruction must match every native refined request before causal attribution');
