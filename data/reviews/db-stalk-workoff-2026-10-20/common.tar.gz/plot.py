import gzip,json,pathlib,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
root=pathlib.Path('out/db-stalk-workoff')
fig,axs=plt.subplots(2,2,figsize=(12,10))
colors={'WR':'#ad6b16','DB':'#145da0','RB':'#9b325a'}
for row,key in enumerate(['OZ4','WZ7']):
 for col,arm in enumerate(['baseline','onset']):
  a=json.load(gzip.open(root/arm/(key+'.json.gz')));s={x['slot']:x['idx']for x in a['initial']};ax=axs[row,col]
  ts=[t for t in a['ticks'] if 2.2<=t['completed']<=4.1]
  for role,slot in [('WR','Z'),('DB','CB_S'),('RB','RB')]:
   i=s[slot];xs=[t['after'][i]['pos']['y']for t in ts];ys=[t['after'][i]['pos']['x']-40 for t in ts]
   ax.plot(xs,ys,color=colors[role],lw=2.2,label=role)
   for mark in [2.3,2.8,3.65,4.1]:
    t=next((t for t in ts if abs(t['completed']-mark)<1e-7),None)
    if t:
     p=t['after'][i]['pos'];ax.scatter(p['y'],p['x']-40,color=colors[role],s=22)
     if role=='DB':ax.annotate(f'{mark:g}s',(p['y'],p['x']-40),xytext=(5,5),textcoords='offset points',fontsize=8,color=colors[role])
  ax.set_title(f'{key} — {"accepted"if col==0 else"first support wait removed"}',fontsize=12)
  ax.set_xlabel('Field width coordinate (yd)');ax.set_ylabel('Depth past LOS (yd)');ax.grid(alpha=.2)
  ax.set_xlim(8,24);ax.set_ylim(-3,13);ax.set_aspect('equal',adjustable='box');ax.axhline(0,color='#555',lw=.9,alpha=.6)
fig.suptitle('Same receiver, corner and runner: achieved paths from 2.20 to 4.10 seconds',fontsize=15)
fig.legend(handles=[Line2D([0],[0],color=c,lw=3,label=r)for r,c in colors.items()],loc='lower center',bbox_to_anchor=(.5,.055),ncol=3)
fig.subplots_adjust(left=.08,right=.98,bottom=.15,top=.90,hspace=.30,wspace=.20)
fig.text(.5,.012,'OZ4: corner returns to wrap.  WZ7: corner still loses outside leverage; neither corner contacts the runner.\nPaired frozen inputs; unchanged physical laws. Later paths include subsequent decisions and RNG divergence.',ha='center',fontsize=9)
fig.savefig(root/'db-workoff-paths.png',dpi=170)
