# Initial support work-off: saved native comparison

Zero additional simulations by this worker. `compare_onset.py` reads the root's
baseline/onset tapes, checks identical frozen input hashes, preserves tape SHA256,
and emits `onset-comparison.json`. Times denote controller/physics tick entry;
positions/velocities in selected rows are achieved at tick completion (+.05s).

Baseline source4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571;
onset sourcee98deddafb31dcf6b4c3d505dbbba6b0f0ab2f1be46de57a40547fd8dcedcc5d.
Root identifies onset codee83b735 as the isolated initial support attempt
admission, retaining subsequent cadence and the fixed movement/physics laws.
All six cases are completed outcomes, not censored prefixes. Actual attempt
timing is inferred from exact nextMoveAt resets and delivered work-off commands,
not the shed-attempt tag, which persists across re-contact. JSON now records
firstPersistentShedTagTick, actualAttemptTicks and workOffCommandTicks separately.

## OZ4: meaningful return to the play

Zpair31O-WR3 / CB_Spair31D-CB1, same initial rep8. First delivered request,
next-move/tag divergence at2.25; achieved bodies differ at completed2.30.
Raw behavior's first changed request is RB2.65, then first RNG state divergence
2.80. Therefore useful earlier motion precedes execution-randomness divergence.

- Initial work-off starts2.25 instead2.80.
- Initial rep separates2.80 instead3.20. Candidate has no later WR/CB re-contact;
  baseline pair re-acquires3.80–4.25, ending only after runner passes.
- Completed2.65: DB distance to runner12.295→11.923yd, speed2.204→4.034,
  upfield lead7.837→7.760yd and outside leverage9.473→9.053yd. He gains useful
  lateral access without forfeiting all upfield/outside positioning.
- Completed3.65: distance3.750→1.725yd while speed4.079→2.383; upfield lead
  1.407→1.592yd and outside leverage3.476→.665yd. The useful approach is not
  simply maximized speed: he gathers into the runner's path.
- Candidate this same CB loads runner3.65 and finishes4.30; baseline SS loads3.05,
  FS loads4.05 and finishes4.65. Final gains15.59→8.20, with later trajectory and
  randomness differences; do not attribute every yard to one move.

## WZ7: earlier work-off does not solve the explosive or eliminate a cost

Zpair11O-WR3 / CB_Spair11D-CB3. First delivered divergence2.40, achieved2.45;
raw first differenceCB_S2.90; RNG first divergence2.95.

- Work-off starts2.40 instead2.70; initial rep ends3.70 instead3.80.
- Later re-acquisition4.40–4.75 (separation) replaces4.50–4.90 (runner passed).
  Candidate starts a new work-off4.40; baseline never starts an actual attempt
  during that later rep, despite retaining its old shed-attempt tag.
- Completed2.85 distance11.833→11.734yd, speed2.552→3.680 and upfield lead
  9.015→9.178yd: small early benefit.
- **Completed3.65 distance4.799→4.835yd despite speed5.143→5.276.** Outside
  leverage+.026→−.634yd: candidate is now inside the runner. Earlier lateral
  effort has an adverse angle/over-flow cost as the back reaches the perimeter.
- Neither arm's CB records carrier contact. FS still supplies first contact5.55;
  final gains25.85→25.11 remain explosive. The ending does not prove this
  particular CB approach is generally better, and the tail remains unresolved.

This is a controller/read/geometry limitation, not evidence for a stronger grip:
there is no CB/runner grip to fail. No frame-law variant is included here.

## WZORD: ordinary defensive finish and legitimate sustained block preserved

Both DB trajectories and WR/DB rep chronologies are exact through all common
ticks. X/CB_W rep2.20–2.95 separates; Z/CB_S rep2.35 remains engaged at the
terminal whistle. First carrier contactLB_W2.75, CB_W assist3.05, LB_W finish3.50,
gain2.89 in both. The successful finish and sustained offensive work coexist.

This is **not full-field identity**: acquired man-support LB_Sidx17 first changes
its delivered request3.30, altering RG body after3.35; all common RNG states stay
identical. The code's role contract includes support jobs held by linebackers,
not only DB roster slots. Report the unchanged ending/DB scope precisely.

## Interpretation

Earlier admission repairs a real startup delay and creates a useful native
return in OZ4. It does not establish a universal reduction in blocking duration
or explosive tails. Preserve WZ7's outside-leverage cost and WZORD's sustained
block. A final promotion judgment needs the parent and independent controller
review to weigh this scoped admission against those supported responsibilities;
no additional population collection is justified by these three endings alone.
