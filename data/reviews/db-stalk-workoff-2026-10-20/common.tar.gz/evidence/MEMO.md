# DB stalk evidence inspection (2026-10-20)

This worker generated zero snaps, constructed zero simulators and queried zero
NFL files. It restored installed inputs and inspected the root's three completed
accepted-source native records. Parent owns the behavior and final interpretation.

## What Part 9 establishes, and what it does not

Published branch `claude/run-game-v3@2e791b61164db116819748a7a474e91b45d8144e`.
`docs/reviews/run-game-v3/part9/stalk-reps.txt` records 506 WR-on-DB run
engagements in 240 post-merge inputs (236 with any stalk). Median individual
rep duration is **0.75 s**, p25/p75 0.55/1.10, compared with pre-merge median
1.05 s. Ends: separation 299; terminal-censored 160; runner-passed 41; down 6.
Those values do not establish that individual DB blocks last forever.

The 42/432 'reaching carrier' operator checks geometric distance at any tick:
less than sum of radii + 0.6 defender reach. It does not observe a touch,
loaded grasp, first collision or assignment correctness. Likewise all 16 long
runs having some stalk is weak causal evidence by itself because 236/240 inputs
have a stalk; the paired stalk-revert intervention is the stronger evidence.
Repeated re-acquisition and poor useful support after release need a continuous
same-DB chronology rather than independent rep-duration bins.

The no-override post-merge attribution arm is **ece674aa72a2b2907c0c6a39f6d53e4f5be08483**,
source `05c4d6ec65aa5b06a871aeda614b345500d9a4f7dbdeeeb35f465bdc83568ea8`.
It contains the merged accepted checkpoint plus a research ancestry. It differs
from accepted2c98bed in nine runtime/config files (444 additions,52 deletions).
Preserve that attribution as the author's research-host result, not a newly
measured accepted-develop population. The full-flow arm is additionally dirty
and activates ten overrides. `part9-source-qualification.json` retains original
manifests, all flag values, raw-shard checksums and their absence here. No remote
NFL or large archive restoration was attempted.

## Exact installed inputs restored

`inputs.json.gz`, SHA256
`43bae85e7d8f67ef118c415bf845ccd2bc50e1606fd3b5659873bfb1e6813fed`.
`make-inputs.mjs`, `input-manifest.json`, `input-launch.json` reproduce and
bind the generation. Teams use strength .55 and the published pair11 seeds11/12
or pair31 seeds31/32. All calls/players use accepted current definitions; every
player profile, call and seed is frozen in each setup. No rounded film state
was loaded as a simulator checkpoint.

- WZ7: wz/strong/ace_12/over4/pair11/7, selected Part8 long-tail witness.
- OZ4: oz/strong/ace_12/tite4/pair31/4, selected Part8 long-tail witness.
- WZORD: wz/weak/ace_12/over2/pair31/1, first previously published random ordinary
  film input, selection seed20261021 before outcomes. It was not preselected as
  a defensive success or as a sustained-block control.

Root collected these baseline cases at fcb719d (claim-only head over accepted),
source `4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571`,
all terminal: 25.85,15.59,2.89 yards. These are fresh accepted-source outcomes,
not reproductions of the research host's experimental endings.

## Continuous DB identities and repeated frame mismatch

`inspect_saved.py` reads root's tapes and emits
`baseline-episode-inspection.json`, preserving tape/input/source hashes, rep
identity, personal carrying-picture availability, held aim changes, actual
requests/velocities/load, geometric normal comparison and release reasons.

WZ7: Z `pair11O-WR3` / CB_S `pair11D-CB3`.

- Rep6 begins2.20, active shed tag first present2.70, separates3.80.
- Same pair re-acquires as rep19 at4.50; releases4.90 after runner passed.
- Personally acquired carrying RB picture is available1.85, age.25. The held
  contact objective becomes declared at2.40, not on that earlier observation.
- Fixed defensive axis versus current DB-to-WR normal angle grows41.2°3.20,
  89.4°3.40,118.6°3.60.
- At3.40 final request(-1.2905,+6.3469) projects **-6.442 yd/s away** along the
  current contact normal, although the work-off expression intends .6 into it.
- Achieved velocity at completed3.45 is(-.9459,+4.6824). No contact with this DB
  is recorded; FS first loads carrier at5.55, ending tackle6.40.

OZ4: Z `pair31O-WR3` / CB_S `pair31D-CB1`.

- Rep8 begins2.25, active shed tag first present2.80, separates3.20.
- Same pair re-acquires rep19 at3.80; releases4.25 after runner passed.
- Personally acquired carrying RB picture available1.85, age.20; first contact
  already carries a declared runner objective.
- Fixed/current normal angles116.9°2.80 and147.8°3.00.
- At2.80 final request(-1.1598,+5.9645) projects **-5.665 yd/s away** along the
  current normal. Achieved velocity at completed2.85 is(-.1393,+2.0672).
- SS first loads runner3.05; FS loads4.05 and finishes4.65. CB_S records no grasp.

The repeated interface mismatch is real. **It is not by itself proof that
closing into the WR is better football:** moving away may legitimately clear
hands and these baseline requests still generally close toward the available
runner (WZ7 true-runner projection5.14 yd/s2.80 and3.64 at3.40; OZ4 5.36 at2.80).
A corrected support frame must therefore be judged by achieved ball-side
leverage/depth and useful return, preserving earned sustained blocks. A lower
run ending alone does not settle the question.

## Compatible historical ordinary control

Previous TOSS metadata-only tape at
`/workspace/football-decision-commitment/out/decision-commitment/native/candidate/TOSS.json.gz`
has source ca49106d over prior acceptedf414. Z SO-WR3 / CB_S SD-CB1 engagement
2.45–2.95 separates, CB then loads RB3.60, hold slips4.20, joins assist4.50.
It is a useful successful-work-off chronology and frozen input, **not** a current
accepted baseline or an unchanged numerical control: it includes held metadata
and the recent stalk source differs. Root should reuse its setup but qualify
source changes before comparing football on2c98bed.

## Smallest next decision

Parent's bounded native comparison can distinguish whether a personally
felt/acquired support contact frame improves useful depth/leverage during the
same decision, or merely exchanges the current inside pursuit for a different
wrong side. Use the same stable WR/DB IDs, separate release from re-acquisition,
record acquired goal changes, final delivered requests and achieved body motion.
Keep physical hands, grip capacity, release eligibility and speed/braking fixed.
