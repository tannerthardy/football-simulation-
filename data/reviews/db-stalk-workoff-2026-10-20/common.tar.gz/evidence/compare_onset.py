"""Compare existing root native tapes; no new simulation."""
import json,gzip,pathlib,hashlib,math
root=pathlib.Path('out/db-stalk-workoff')
def read(arm,key):
 p=root/arm/(key+'.json.gz');b=p.read_bytes();return json.loads(gzip.decompress(b)),hashlib.sha256(b).hexdigest()
def diff(a,b,path=''):
 if type(a)!=type(b):return path
 if isinstance(a,dict):
  if set(a)!=set(b):return path+'.keys'
  for k in a:
   x=diff(a[k],b[k],path+'.'+str(k))
   if x is not None:return x
 elif isinstance(a,list):
  if len(a)!=len(b):return path+'.length'
  for i,(x,y)in enumerate(zip(a,b)):
   q=diff(x,y,path+'.'+str(i))
   if q is not None:return q
 elif a!=b:return path
 return None
out=[]
for key in ['WZ7','OZ4','WZORD']:
 a,ha=read('baseline',key);b,hb=read('onset',key);assert a['inputSha256']==b['inputSha256'];common=min(len(a['ticks']),len(b['ticks']));first={}
 for field in ['before','requests','intents','after','repBefore','reps','tags','contacts','rng']:
  for x,y in zip(a['ticks'],b['ticks']):
   p=diff(x[field],y[field],field)
   if p is not None:first[field]={'t':x['t'],'completed':x['completed'],'path':p};break
 agents={x['idx']:{'slot':x['slot'],'player':x['player']['id']}for x in a['initial']};pairs={}
 for arm,d in [('baseline',a),('onset',b)]:
  ps={}
  for e in d['contact']:
   if e['b']not in[8,9]or e['d']not in[18,19]:continue
   r=e['rep']; k=r['id'];q=ps.setdefault(k,{'id':k,'blocker':agents[e['b']],'defender':agents[e['d']],'b':e['b'],'d':e['d'],'start':r['start'],'end':None,'firstPersistentShedTagTick':None,'actualAttemptTicks':[],'workOffCommandTicks':[],'selectedRows':[]})
   if e['phase']=='end':q['end']={'t':e['t'],**e['data']}
  for t in d['ticks']:
   for r in t['repBefore']:
    if r['id']not in ps:continue
    if 'shed-attempt'in t['tags'][r['d']]and ps[r['id']]['firstPersistentShedTagTick']is None:ps[r['id']]['firstPersistentShedTagTick']=t['t']
    horizon=2*t['minds'][r['d']]['decisionInterval']
    if abs(r['nextMoveAt']-(t['t']+horizon))<1e-9:ps[r['id']]['actualAttemptTicks'].append(t['t'])
    v=t['intents'][r['d']]['vel']; axis={k:-x for k,x in r['drive'].items()}
    if abs(v['x']*axis['x']+v['y']*axis['y']-.6)<1e-8:ps[r['id']]['workOffCommandTicks'].append(t['t'])
  pairs[arm]=list(ps.values())
 selected=[]
 for time in [2.2,2.25,2.4,2.6,2.8,3.,3.2,3.4,3.6,3.8,4.,4.2]:
  row={'t':time}
  for arm,d in [('baseline',a),('onset',b)]:
   t=next((t for t in d['ticks']if abs(t['t']-time)<1e-8),None)
   if not t:continue
   p=t['after'][18];rb=t['after'][6];dx=rb['pos']['x']-p['pos']['x'];dy=rb['pos']['y']-p['pos']['y'];dist=math.hypot(dx,dy);v=p['vel'];rv=rb['vel'];r=next((r for r in t['repBefore']if r['d']==18),None)
   cue=[e for e in d['contact']if e['d']==18 and e['phase']=='movement'and e['t']<=time]
   q=cue[-1]['data']if cue else None
   row[arm]={'achievedAt':t['completed'],'position':p['pos'],'velocity':v,'speed':math.hypot(v['x'],v['y']),'runnerPosition':rb['pos'],'runnerVelocity':rv,'runnerDistance':dist,'relativeClosingSpeed':((v['x']-rv['x'])*dx+(v['y']-rv['y'])*dy)/dist,'upfieldOfRunner':p['pos']['x']-rb['pos']['x'],'outsideLeverage':rb['pos']['y']-p['pos']['y'],'request':t['requests'][18],'intent':t['intents'][18],'repId':r['id']if r else None,'heldAim':q.get('defensiveAim')if q else None,'heldDeclared':q.get('declared')if q else None}
  if 'baseline'in row and'onset'in row:
   ba,ca=row['baseline'],row['onset'];row['delta']={'distance':ca['runnerDistance']-ba['runnerDistance'],'speed':ca['speed']-ba['speed'],'upfieldOfRunner':ca['upfieldOfRunner']-ba['upfieldOfRunner'],'outsideLeverage':ca['outsideLeverage']-ba['outsideLeverage']}
  selected.append(row)
 events={arm:[e for e in d['events']if e['type']in['carrier_contact','tackle_wrap','broken_tackle','tackle','fall']]for arm,d in [('baseline',a),('onset',b)]}
 record={'id':key,'inputSha256':a['inputSha256'],'source':{'baseline':a['source'],'onset':b['source']},'tapeSha256':{'baseline':ha,'onset':hb},'terminal':{'baseline':a['phase']!='live','onset':b['phase']!='live'},'gains':{'baseline':a['gain'],'onset':b['gain']},'firstDifferences':first,'commonTicks':common,'pairs':pairs,'selectedCB_S':selected,'events':events}
 out.append(record)
 print(key,'gains',record['gains'],'first',first)
 for arm in pairs:
  print(arm,[(q['id'],q['b'],q['d'],q['start'],q['end'],q['actualAttemptTicks'])for q in pairs[arm]])
 for row in selected:
  if row['t']in[2.4,2.8,3.2,3.6]and'delta'in row:print('t',row['t'],'baseposition',row['baseline']['position'],'candposition',row['onset']['position'],'delta',row['delta'])
(root/'evidence'/'onset-comparison.json').write_text(json.dumps(out,indent=2))
