import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { writeFileSync, readFileSync } from 'node:fs';
import { gzipSync } from 'node:zlib';
const root=process.cwd();
const {Rng}=await import(root+'/src/core/rng.ts');
const {generateTeam,pickDefense,pickOffense}=await import(root+'/src/league/team.ts');
const {RUN_BY_ID}=await import(root+'/src/playbook/concepts.ts');
const {COVERAGE_BY_ID,FRONT_BY_ID,PRESSURE_BY_ID}=await import(root+'/src/playbook/defense.ts');
const {FORMATION_BY_ID}=await import(root+'/src/playbook/formations.ts');
const {sourceVersion}=await import(root+'/scripts/source-version.ts');
const specs=[
 ['over3','base43','over','cover3','box',''],['under3','base43','under','cover3','spill',''],
 ['wide9','nickel','wide9','cover3','spill',''],['tite4','base34','tite','cover4','box',''],
 ['odd3','base34','odd','cover3','spill',''],['bear1','goalline','bear','cover1','box',''],
 ['over2','base43','over','cover2','box',''],['over4','base43','over','cover4','box',''],
 ['off1','base43','over','cover1_off','box',''],['mike1','base43','over','cover1','box','mike_a']
];
const cases=[
 {id:'WZ7',labId:'wz/strong/ace_12/over4/pair11/7',qualification:'Part8 selected long-tail witness; accepted-current input reconstruction from immutable call definitions and generation seeds, no simulation or exact state checkpoint.'},
 {id:'OZ4',labId:'oz/strong/ace_12/tite4/pair31/4',qualification:'Part8 selected long-tail witness; accepted-current input reconstruction from immutable call definitions and generation seeds, no simulation or exact state checkpoint.'},
 {id:'WZORD',labId:'wz/weak/ace_12/over2/pair31/1',qualification:'First published randomly selected ordinary movement-film case (selection seed20261021); chosen before this investigation outcome; not known to be a defensive win.'},
];
const rosters={};
for(const [id,os,ds]of[['pair11',11,12],['pair31',31,32]]){
 const o=generateTeam(new Rng(os),id+' O',id+'O',{strength:.55});
 const d=generateTeam(new Rng(ds),id+' D',id+'D',{strength:.55});
 rosters[id]={offense:Object.fromEntries(['11','12','13','21'].map(p=>[p,pickOffense(o,p)])),defense:Object.fromEntries(['base43','base34','nickel','goalline'].map(p=>[p,pickDefense(d,p)]))};
}
const hash=b=>createHash('sha256').update(b).digest('hex');
const rows=cases.map(c=>{
 const [concept,dir,formationId,look,roster,seed]=c.labId.split('/');
 const formation=structuredClone(FORMATION_BY_ID[formationId]);
 const run=structuredClone(RUN_BY_ID[`${concept}_${dir}`]??RUN_BY_ID[concept]);if(!run)throw Error('Unknown run');run.direction=dir;
 const [,personnel,front,coverage,edge,pressure]=specs.find(l=>l[0]===look);
 const offCall={formation,flip:false,kind:'run',run,label:concept};
 const defCall={personnel,front:FRONT_BY_ID[front],coverage:COVERAGE_BY_ID[coverage],pressure:pressure?PRESSURE_BY_ID[pressure]:null,zoneStyle:'match',runPolicy:{edge,linebacker:'stack'},label:look};
 const r=rosters[roster];
 const setup={offense:structuredClone(r.offense[formation.personnel]),defense:structuredClone(r.defense[defCall.personnel]),offCall,defCall,los:40,ballY:26.67,firstDownX:50,down:1,seed:+seed,audibles:false,hurry:false,record:false};
 return {...c,setup,inputSha256:hash(JSON.stringify(setup))};
});
const bytes=gzipSync(JSON.stringify(rows));writeFileSync('out/db-stalk-workoff/evidence/inputs.json.gz',bytes);
const publishedLab=execFileSync('git',['show','2e791b61164db116819748a7a474e91b45d8144e:scripts/diag/zone-lab/lab.ts']);
const manifest={nativeSimulations:0,simulatorConstructors:0,source:sourceVersion(),commit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),publishedLab:{commit:'2e791b61164db116819748a7a474e91b45d8144e',path:'scripts/diag/zone-lab/lab.ts',sha256:hash(publishedLab)},generatorSeeds:[{id:'pair11',o:11,d:12},{id:'pair31',o:31,d:32}],qualification:'Pure installed input restoration using current accepted definitions. No PlaySim constructed, tick advanced, observations queried or NFL data opened. Original Part8 experimental hosts/flags differ; fresh accepted comparison required. Original lab record:false (implicit default) made explicit.',fileSha256:hash(bytes),cases:rows.map(({setup,...r})=>r)};
writeFileSync('out/db-stalk-workoff/evidence/input-manifest.json',JSON.stringify(manifest,null,2));console.log(JSON.stringify(manifest,null,2));
