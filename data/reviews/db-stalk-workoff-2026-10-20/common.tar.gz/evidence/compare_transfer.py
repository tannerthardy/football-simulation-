import json,gzip,pathlib,hashlib,math,runpy
root=pathlib.Path('out/db-stalk-workoff');base=pathlib.Path('/tmp/football-db-stalk-baseline/out/db-stalk-workoff')
def read(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b)),hashlib.sha256(b).hexdigest()
def diff(a,b,path=''):
 if type(a)!=type(b):return path
 if isinstance(a,dict):
  if set(a)!=set(b):return path+'.keys'
  for k in a:
   d=diff(a[k],b[k],path+'.'+str(k))
   if d is not None:return d
 elif isinstance(a,list):
  if len(a)!=len(b):return path+'.length'
  for i,(x,y)in enumerate(zip(a,b)):
   d=diff(x,y,path+'.'+str(i))
   if d is not None:return d
 elif a!=b:return path
 return None
out=[]
for key in ['F_OZ','F_COUNTER','PA13']:
 a,ha=read(base/'transfer-baseline'/(key+'.json.gz'));b,hb=read(root/'transfer-candidate'/(key+'.json.gz'));assert a['inputSha256']==b['inputSha256'];first={}
 for field in ['before','requests','intents','after','repBefore','reps','tags','contacts','rng']:
  for x,y in zip(a['ticks'],b['ticks']):
   p=diff(x[field],y[field],field)
   if p is not None:first[field]={'t':x['t'],'completed':x['completed'],'path':p};break
 identities={x['idx']:{'slot':x['slot'],'player':x['player']['id']}for x in a['initial']};actors=[19]if key=='F_OZ'else[15,18,19]; pairs={};selected=[]
 for arm,d in [('baseline',a),('candidate',b)]:
  eps={}
  for e in d['contact']:
   if e['d']not in actors:continue
   r=e['rep'];k=r['id'];q=eps.setdefault(k,{'id':k,'b':r['b'],'d':r['d'],'blocker':identities[r['b']],'defender':identities[r['d']],'start':r['start'],'end':None,'firstPersistentShedTagTick':None,'actualAttemptTicks':[],'workOffCommandTicks':[]})
   if e['phase']=='end':q['end']={'t':e['t'],**e['data']}
  for t in d['ticks']:
   for r in t['repBefore']:
    if r['id']not in eps:continue
    if 'shed-attempt'in t['tags'][r['d']]and eps[r['id']]['firstPersistentShedTagTick']is None:eps[r['id']]['firstPersistentShedTagTick']=t['t']
    horizon=2*t['minds'][r['d']]['decisionInterval']
    if abs(r['nextMoveAt']-(t['t']+horizon))<1e-9:eps[r['id']]['actualAttemptTicks'].append(t['t'])
    v=t['intents'][r['d']]['vel']; axis={k:-x for k,x in r['drive'].items()}
    if abs(v['x']*axis['x']+v['y']*axis['y']-.6)<1e-8:eps[r['id']]['workOffCommandTicks'].append(t['t'])
  pairs[arm]=list(eps.values())
 if key!='PA13':
  actor=actors[0]
  for time in ([2.2,2.25,2.4,2.6,2.8,3.,3.15]if key=='F_OZ'else[3.45,3.5,3.6,3.75]):
   row={'t':time,'actor':identities[actor]}
   for arm,d in [('baseline',a),('candidate',b)]:
    t=next((r for r in d['ticks']if abs(r['t']-time)<1e-8),None)
    if not t:continue
    pos=t['after'][actor]['pos'];v=t['after'][actor]['vel'];rb=t['after'][6];dx=rb['pos']['x']-pos['x'];dy=rb['pos']['y']-pos['y'];dist=math.hypot(dx,dy)
    con=[r for r in d['contact']if r['d']==actor and r['phase']=='movement'and r['t']<=time]; q=con[-1]['data']if con else None;goal=q['defensiveAim']if q else None
    row[arm]={'achievedAt':t['completed'],'position':pos,'velocity':v,'speed':math.hypot(v['x'],v['y']),'intent':t['intents'][actor],'runnerPosition':rb['pos'],'runnerDistance':dist,'upfieldLead':pos['x']-rb['pos']['x'],'outsideLeverage':pos['y']-rb['pos']['y']if actor==19 else None,'heldGoal':goal,'goalDistance':math.hypot(goal['x']-pos['x'],goal['y']-pos['y'])if goal else None,'declared':q['declared']if q else None}
   selected.append(row)
 common_fields=['ticks','cues','calls','aims','contact','events','phase','outcome','gain','result','initial']
 equal={k:diff(a[k],b[k],k)is None for k in common_fields}
 out.append({'id':key,'inputSha256':a['inputSha256'],'source':{'baseline':a['source'],'candidate':b['source']},'sha256':{'baseline':ha,'candidate':hb},'gains':{'baseline':a['gain'],'candidate':b['gain']},'terminal':{'baseline':a['phase']!='live','candidate':b['phase']!='live'},'firstDifferences':first,'commonFieldsEqual':equal,'pairs':pairs,'selectedActor':selected,'nativeCostSeconds':a['elapsedSeconds']+b['elapsedSeconds']})
 print(key,'first',first,'samefields',equal,'pairs',pairs)
 for r in selected:
  print(' row',r['t'],[(arm,*(round(r[arm][k],3)if isinstance(r[arm][k],(int,float))else r[arm][k]for k in['goalDistance','runnerDistance','speed','upfieldLead','outsideLeverage']))for arm in['baseline','candidate']if arm in r])
(root/'evidence'/'transfer-comparison.json').write_text(json.dumps(out,indent=2))
cost=[]
for name,path in [('baseline',root/'baseline-launch.json'),('onset',root/'onset-native-launch.json'),('transferbaseline',base/'transfer-baseline-launch.json'),('transfercandidate',root/'transfer-candidate-launch.json')]:
 d=json.load(open(path));cost.append({'name':name,'path':str(path),'commit':d['commit'],'source':d['sourceSha256'],'exitCode':d['exitCode'],'inputsUnchanged':d['inputsUnchanged'],'seconds':sum(x['elapsedSeconds']for x in d['commands']),'flags':d['flags']})
(root/'evidence'/'native-command-costs.json').write_text(json.dumps(cost,indent=2));print('commandcost',[(c['name'],c['seconds'])for c in cost],sum(c['seconds']for c in cost))
