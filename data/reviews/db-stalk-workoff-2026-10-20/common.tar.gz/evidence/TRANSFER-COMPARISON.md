# Fresh transfer and preserved counter-responses

Inspection only, no extra simulations. Root supplied six completed native
traces on exact frozen setups. New offense/defense generated with seeds51/52;
weak OZ seed29 and weak Counter seed19. Baseline source4273994f, candidate
sourcee98dedda, all recorded baseline flags/physics unchanged. `compare_transfer.py`
checks frozen input identity and emits full tape hashes, first divergences,
same-player episode chronology and achieved geometry in `transfer-comparison.json`.

**Attempt timing does not come from the persistent shed-attempt tag.** Both
comparison tools retain that label as `firstPersistentShedTagTick` and separately
infer `actualAttemptTicks` from the existing controller's exact scheduling
transition `nextMoveAt = tick time + 2 * decisionInterval`. Recorded final
commands with projection.6 on the fixed support axis identify actual
`workOffCommandTicks`; this is distinct from a past tag persisting on a new rep.
No extra controller query or sensing was performed.

## Fresh weak outside zone: useful motion, earned block remains

X `FDO-WR2` / CB_W `FDD-CB2`, rep7 begins2.05 and remains engaged at the terminal
whistle in both arms. Baseline work-off decisions2.60/3.00; candidate2.25/2.65/3.05.
First delivered/physical divergence2.25; no RNG divergence anywhere.

Achieved at2.65 (tick2.60):

| Quantity | Baseline | Candidate |
|---|---:|---:|
| Distance to held runner objective |11.963|11.831|
| Distance to actual runner |11.020|10.884|
| Achieved speed yd/s |3.226|3.719|
| Upfield lead yd |6.748|6.748|
| Outside leverage yd |8.712|8.539|

By2.85 the objective-distance improvement is.172yd and actual distance.174yd.
This is a modest same-information motion improvement, not another tackle claim.
The legitimate sustained WR block remains effective; CB never reaches this
runner before Mike finishes. First contactMike2.60, EDGE assist2.85 and tackle
3.15 remain; both gain1.49. Changed requests/cues/contact forces exist, so do
not call whole tapes or whole results identical.

## Fresh Counter: preserve force duty and useful sustained blocks

X `FDO-WR2` / CB_W `FDD-CB2` rep6 stays engaged from2.00 to terminal3.85.
Z `FDO-WR5` / CB_S `FDD-CB1` rep7 separates2.85 after starting2.00. Both
force DBs have **no actual work-off command or attempt** in either arm. The
correction has not turned all acquired possession into permission to abandon
force leverage or automatically escape a block.

Only LB_M `FDD-LB1` changes at3.50 when TEH `FDO-TE1` engages again. Candidate
makes its first work-off immediately; baseline never starts that episode's
work-off before the terminal. Achieved3.80 goal error6.553→6.560yd (a tiny
adverse progress difference after carrier already held3.25), and runner distance
6.562→6.570. RNG stays equal; first hitLB_W3.25 and finish3.80/gain.22 hold.
This late small difference is not evidence of improved Mike pursuit. It does
confirm the role predicate can include support linebackers; scope by duty,
not position label.

## Current-source PA control

PA13 native initial state, all ticks, actual consumed pictures, controller
calls/aims, contact traces, RNG, events and final result match exactly. Current
accepted source completes14.51 yards, tackle4.25 after CB_W's wrap3.65. Its
historical incomplete result belongs to a different engine source and must not
be used as this control's ending. This comparison preserves the current PA
response; it is not whole-engine proof of honest pass information.

## Cost and stopping

Four native launcher commands total **13.442648 command seconds**. Their12
individual cases total **8.192584 case seconds** (six baseline,six candidate),
all terminal within8.0s simulated bounds. Raw receipts and exact flags are
retained; `native-command-costs.json` indexes command heads/source hashes,
input-drift result and44 flags. Pure inspection/input generation is separate.
No broad games, NFL data/query/download, roster campaign or source variant by
this worker. Stop: these examples answer whether first work-off admission can
transfer while preserving ordinary finishes and sustained blocks. WZ7's
outside-leverage loss remains visible in `ONSET-COMPARISON.md`.
