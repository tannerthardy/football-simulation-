"""Read existing current accepted tapes only; no simulation or sensing."""
import gzip,json,math,hashlib,pathlib
base=pathlib.Path('out/db-stalk-workoff'); out=[]
for key in ['WZ7','OZ4','WZORD']:
 p=base/'baseline'/f'{key}.json.gz'; b=p.read_bytes(); d=json.loads(gzip.decompress(b)); slots={a['idx']:a['slot'] for a in d['initial']}; players={a['idx']:a['player']['id'] for a in d['initial']}; episodes={}
 for c in d['contact']:
  if c['b'] not in [8,9] or c['d'] not in [18,19]:continue
  r=c['rep']; k=r['id']; ep=episodes.setdefault(k,{'repId':k,'b':r['b'],'d':r['d'],'blocker':players[r['b']],'defender':players[r['d']],'start':r['start'],'firstGeometry':None,'end':None,'readChanges':[]})
  if c['phase']=='geometry' and ep['firstGeometry'] is None:ep['firstGeometry']=c['t']
  if c['phase']=='end':ep['end']={'t':c['t'],**c['data']}
  if c['phase']=='movement':
   cur={'t':c['t'],'aim':c['data']['defensiveAim'],'declared':c['data']['declared']}
   if not ep['readChanges'] or any(cur[k]!=ep['readChanges'][-1][k] for k in ['aim','declared']):ep['readChanges'].append(cur)
 rows=[]
 for t in d['ticks']:
  for e in t['repBefore']:
   if e['id'] not in episodes:continue
   a=t['before'][e['d']]; bl=t['before'][e['b']]; axis={k:-v for k,v in e['drive'].items()}; dx=bl['pos']['x']-a['pos']['x'];dy=bl['pos']['y']-a['pos']['y'];dist=math.hypot(dx,dy);nx,ny=dx/dist,dy/dist
   intent=t['intents'][e['d']]; v=intent['vel'];actual=t['after'][e['d']]['vel']; felt=a['support']['felt'];dot=axis['x']*nx+axis['y']*ny; angle=math.degrees(math.acos(max(-1,min(1,dot))))
   row={'t':t['t'],'repId':e['id'],'d':e['d'],'tags':t['tags'][e['d']],'fixedVsCurrentNormalDegrees':angle,'request':v,'achievedVelocity':actual,'requestTowardBlocker':v['x']*nx+v['y']*ny,'achievedTowardBlocker':actual['x']*nx+actual['y']*ny,'felt':felt,'blockerPosition':bl['pos'],'defenderPosition':a['pos'],'runnerPosition':t['before'][6]['pos'],'normalForce':e.get('normal'),'tangentForce':e.get('tangent'),'hands':e.get('hands')}
   rows.append(row)
 for e in episodes.values():
  allrows=[r for r in rows if r['repId']==e['repId']];e['firstShedTaggedTick']=next((r for r in allrows if 'shed-attempt' in r['tags']),None)
  e['firstFixedNormalOver45']=next((r for r in allrows if r['fixedVsCurrentNormalDegrees']>45),None)
  e['selectedRows']=[r for r in allrows if round(r['t']*20)%4==0]
 firstcarrying={}
 for i in [18,19]:
  q=next((q for q in d['cues'] if q['a']==i and q['b']==6 and q.get('picture') and q['picture'].get('carrying') is True),None)
  firstcarrying[players[i]]=q
 out.append({'id':key,'source':d['source'],'inputSha256':d['inputSha256'],'tapeSha256':hashlib.sha256(b).hexdigest(),'terminal':d['phase']!='live','gain':d['gain'],'outcome':d['outcome'],'firstAcquiredCarryingPictures':firstcarrying,'episodes':list(episodes.values()),'carrierEvents':[e for e in d['events'] if e['type'] in ['carrier_contact','tackle_wrap','broken_tackle','tackle']]})
path=base/'evidence'/'baseline-episode-inspection.json';path.write_text(json.dumps(out,indent=2));print('saved',path)
for d in out:
 print(d['id'],d['source'],d['gain'],d['terminal'])
 for e in d['episodes']:
  print(' rep',e['repId'],e['blocker'],'>',e['defender'],'start',e['start'],'end',e['end'],'firstshed',e['firstShedTaggedTick']['t']if e['firstShedTaggedTick']else None,'first45',e['firstFixedNormalOver45']['t']if e['firstFixedNormalOver45']else None)
  for r in e['selectedRows']:
   if r['t'] in [2.8,3.0,3.2,3.4,3.6,3.8,4.0,4.2,4.6]:print('  ',r['t'],round(r['fixedVsCurrentNormalDegrees'],1),'normalrequest',round(r['requestTowardBlocker'],2),'actual',r['achievedVelocity'],'felt',r['felt'])
