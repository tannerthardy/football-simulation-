from pathlib import Path
import tarfile,json,hashlib,io,shutil
root=Path('out/db-stalk-workoff');dest=Path('/tmp/football-db-stalk-evidence/data/reviews/db-stalk-workoff-2026-10-20');dest.mkdir(parents=True,exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
archives=[]
for name,files in [('baseline',[*sorted((root/'baseline').glob('*')),*sorted((root/'transfer-baseline').glob('*'))]),('candidate',[*sorted((root/'onset').glob('*')),*sorted((root/'transfer-candidate').glob('*'))]),('common',[*sorted(root.glob('*.json')),*sorted(root.glob('*.gz')),*sorted(root.glob('*.mjs')),*sorted(root.glob('*.py')),*sorted(root.glob('*.patch')),*sorted((root/'evidence').glob('*'))])]:
 seen=set();members=[]
 with tarfile.open(dest/(name+'.tar.gz'),'w:gz') as tar:
  for p in files:
   if not p.is_file():continue
   rel=p.relative_to(root).as_posix()
   if rel in seen:continue
   seen.add(rel);data=p.read_bytes();info=tarfile.TarInfo(rel);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data));members.append({'path':rel,'bytes':len(data),'sha256':h(data)})
 data=(dest/(name+'.tar.gz')).read_bytes();archives.append({'path':name+'.tar.gz','bytes':len(data),'sha256':h(data),'members':members})
 # Read every published member, not merely archive headers.
 with tarfile.open(dest/(name+'.tar.gz'),'r:gz') as tar:
  actual={m.name:h(tar.extractfile(m).read())for m in tar.getmembers()if m.isfile()}
 assert actual=={m['path']:m['sha256']for m in members}
shutil.copy2(root/'db-workoff-paths.png',dest/'db-workoff-paths.png')
shutil.copy2('docs/reviews/db-stalk-workoff-2026-10-20.md',dest/'REPORT.md')
manifest={'acceptedDevelop':'2c98bed94adad8087c65f381d4090444ad283985','queue':'4cc3337df24faa6d857b612ae62e3df3109a5296','claudeResearch':'2e791b61164db116819748a7a474e91b45d8144e','baselineSource':'4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571','candidateCode':'e83b735fef5c947850f9b941722d13feee263b92','candidateTests':'7c33261a3340afb2748116368bd4f9e8d3c59d66','candidateSource':'e98deddafb31dcf6b4c3d505dbbba6b0f0ab2f1be46de57a40547fd8dcedcc5d','newNativeCases':12,'terminalNativeCases':12,'caseSeconds':8.192584,'commandSeconds':13.442648,'flags':'44 unchanged resolved profile settings; components1,CF_FLOWunset,GAIT_STEP0; exact receipts in common.tar.gz','archives':archives,'standalone':[{'path':p.name,'sha256':h(p.read_bytes()),'bytes':p.stat().st_size}for p in [dest/'REPORT.md',dest/'db-workoff-paths.png']]}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'README.md').write_text('''# DB support work-off evidence\n\nIndependent source: accepted2c98bed; candidate e83b735 / final test7c33261.\nSee REPORT.md and manifest.json for exact full pins, settings, source qualifications,\ninput/tape/archive hashes, native counts/costs and preserved adverse evidence.\n\n- baseline.tar.gz: baseline/ and transfer-baseline/ native tapes/receipts.\n- candidate.tar.gz: onset/ and transfer-candidate/ tapes/receipts.\n- common.tar.gz: exact input manifests, generators, passive collector, reducers,\n  launch/focused/typecheck receipts, independent review and one-file runtime patch.\n- db-workoff-paths.png: achieved paths, including WZ7 adverse leverage.\n\nRestore all three archives into out/db-stalk-workoff in a checkout of the\nchosen pinned engine. Verify manifest members before using evidence. Node22.23.3.\nNo new NFL data/query, games or full suite. No experiments activated.\nThe report's twelve play outcomes are completed; a block active at whistle still\nhas a censored duration. Persistent shed tags are not new-attempt evidence.\n''')
print(json.dumps({'directory':str(dest),'manifestSha256':h((dest/'manifest.json').read_bytes()),'archives':[{k:a[k]for k in ['path','bytes','sha256']}for a in archives],'membersVerified':sum(len(a['members'])for a in archives)},indent=2))
