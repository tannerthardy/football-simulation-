import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {derivePhysical} from '/workspace/football-linebacker-run-flow/out/run-flow/accepted-host/src/players/physical.ts';
import {locomotionAccel} from '/workspace/football-linebacker-run-flow/out/run-flow/accepted-host/src/physics/kinematics.ts';
import {World} from '/workspace/football-linebacker-run-flow/out/run-flow/accepted-host/src/physics/world.ts';
const input='/workspace/football-linebacker-run-flow/out/run-flow/transfer-inputs.json.gz';
const frozen=JSON.parse(gunzipSync(readFileSync(input)).toString())[0];
const players=[frozen.setup.offense.QB,...Object.values(frozen.setup.defense).filter((p:any)=>p.position==='LB').slice(0,1),...Object.values(frozen.setup.defense).filter((p:any)=>p.position==='DT').slice(0,1)] as any[];
const dt=.05;
const body=(profile:any,vx=0,vy=0)=>({pos:{x:0,y:0},vel:{x:vx,y:vy},facing:0,energy:1,profile});
const boundary=players.map(p=>{const profile=derivePhysical(p);return {id:p.id,position:p.position,profile,requests:[.2,.34,.4,.6,0,-.6].map(want=>({want,samples:[.34999,.35001].map(v=>({v,acc:locomotionAccel(body(profile,v),{vel:{x:want,y:0},facing:0},dt)}))}))}});
const series=[];
for(const p of players){const profile=derivePhysical(p);for(const want of [.2,.34,.4,.6,0,-.6])for(const initial of [0,.34,.35,.36]){
 const b:any=body(profile,initial),w=new World([b]); const ticks=[];
 for(let k=0;k<100;k++){const request={vel:{x:want,y:0},facing:0};const a=locomotionAccel(b,request,dt);const before={pos:{...b.pos},vel:{...b.vel}};const report=w.step([request],dt);ticks.push({t:(k+1)*dt,before,acc:a,pos:{...b.pos},vel:{...b.vel},support:b.support.state,energy:b.energy,contact:report.contacts.length});}
 const vel=ticks.map(t=>t.vel.x);const pulse=vel.slice(2).map((v,k)=>Math.abs(v-2*vel[k+1]+vel[k]));const error=vel.map(v=>want-v);const errorsign=error.map(e=>Math.abs(e)<1e-10?0:Math.sign(e));
 series.push({id:p.id,position:p.position,initial,want,at1s:ticks[19],at5s:ticks[99],errorReversals:errorsign.slice(1).filter((s,k)=>s&&errorsign[k]&&s!==errorsign[k]).length,speedReversals:vel.slice(1).filter((v,k)=>v*vel[k]<-1e-12).length,lateMaxPulse:Math.max(...pulse.slice(20)),ticks});
}}
const result={source:{accepted:'f4146275ce7539816bf57b4ed55a0d2be10e48c7',runtimeSha256:'7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197',input,inputsSha256:createHash('sha256').update(readFileSync(input)).digest('hex'),operatorSha256:createHash('sha256').update(readFileSync(import.meta.filename)).digest('hex'),dt,nativeSnaps:0,randomDraws:0},boundary,series};
writeFileSync('/workspace/football-movement-continuity/out/movement-continuity/low-speed-audit/results.json',JSON.stringify(result));
console.log(JSON.stringify({boundary,summary:series.filter(s=>s.want===.4).map(s=>({id:s.id,initial:s.initial,at1s:{v:s.at1s.vel.x,x:s.at1s.pos.x},at5s:{v:s.at5s.vel.x,x:s.at5s.pos.x},errorReversals:s.errorReversals})),maxErrorReversals:Math.max(...series.map(s=>s.errorReversals)),supportStates:[...new Set(series.flatMap(s=>s.ticks.map(t=>t.support)))]},null,2));
