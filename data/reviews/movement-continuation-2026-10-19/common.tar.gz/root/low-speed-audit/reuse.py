import gzip,json,math,hashlib
from pathlib import Path
root=Path('/workspace/football-movement-continuity/out/movement-continuity')
files=json.loads((root/'selection.json').read_text())['baseline']
rows=[]
for file in files:
 v=json.load(gzip.open(file)); ticks=v['ticks']; crosses=[]; frees=0; free_low=0; flips=[]
 for n,t in enumerate(ticks):
  for i,a in enumerate(t['before']):
   if i<11 or a['support']['state']!='up' or t['t']<v['initial'][i]['snapReadyAt']:continue
   pos=a['pos'];clear=all(i==j or math.hypot(pos['x']-b['pos']['x'],pos['y']-b['pos']['y'])>1.5 for j,b in enumerate(t['before']))
   if not clear:continue
   frees+=1; speed=math.hypot(a['vel']['x'],a['vel']['y']);free_low+=speed<.35
   if not n: continue
   previous=ticks[n-1]['before'][i];old=math.hypot(previous['vel']['x'],previous['vel']['y']);
   if (speed<.35)!=(old<.35):
    crosses.append({'t':t['t'],'slot':v['initial'][i]['slot'],'old':old,'speed':speed,'command':t['requests'][i]})
   oldcmd=ticks[n-1]['requests'][i]['vel'];newcmd=t['requests'][i]['vel']; oldmag=math.hypot(oldcmd['x'],oldcmd['y']);newmag=math.hypot(newcmd['x'],newcmd['y'])
   if min(oldmag,newmag)>=.5 and sum(oldcmd[c]*newcmd[c] for c in ['x','y'])<0:
    flips.append({'t':t['t'],'slot':v['initial'][i]['slot'],'speed':speed,'oldcmd':oldcmd,'newcmd':newcmd,'speedBelowHalf':speed<.5})
 rows.append({'id':v['id'],'path':file,'sha256':hashlib.sha256(Path(file).read_bytes()).hexdigest(),'source':v['source'],'freeUprightDefenderSamples':frees,'freeLowSpeedSamples':free_low,'thresholdCrossings':crosses,'reversalsOver90Deg':flips})
(root/'low-speed-audit/reused-evidence.json').write_text(json.dumps(rows,indent=2))
print(json.dumps([{k:v for k,v in row.items() if k not in ['thresholdCrossings','reversalsOver90Deg','source']}|{'crosses':len(row['thresholdCrossings']),'requestReversals':len(row['reversalsOver90Deg']),'nearZeroReversals':sum(f['speedBelowHalf'] for f in row['reversalsOver90Deg'])} for row in rows],indent=2))
