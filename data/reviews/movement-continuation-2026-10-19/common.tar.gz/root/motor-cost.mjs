import{readFileSync,readdirSync,writeFileSync}from'node:fs';
import{join}from'node:path';
import{createHash}from'node:crypto';
import{gunzipSync}from'node:zlib';
const sources=[['accepted','/workspace/football-linebacker-run-flow/out/run-flow/accepted-host'],['yaw','/workspace/football-movement-continuity'],['gait','/workspace/football-gait-achieved-pose'],['both','/workspace/football-movement-physics-interaction']];
const files=(dir,rel='src')=>readdirSync(join(dir,rel),{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(dir,join(rel,e.name)):[join(rel,e.name)]).sort();
const digest=dir=>{const h=createHash('sha256');for(const p of files(dir))h.update(p).update('\0').update(readFileSync(join(dir,p))).update('\0');return h.digest('hex')};
const saved=JSON.parse(gunzipSync(readFileSync('/workspace/football-linebacker-run-flow/out/run-flow/enriched/TOSS.json.gz'))),profile=saved.initial.find(a=>a.slot==='DT_W').profile;
const models=[];for(const[label,path]of sources){const{World}=await import(path+'/src/physics/world.ts');models.push({label,path,World,source:digest(path)})}
const turns=[0,Math.PI/2,Math.PI,-Math.PI/2],commands=Array.from({length:40},(_,k)=>{const h=turns[Math.floor(k/10)];return{vel:{x:5*Math.cos(h),y:5*Math.sin(h)},facing:h}});
function run(model,cycles){const body={pos:{x:0,y:0},vel:{x:1,y:0},facing:0,energy:1,profile:structuredClone(profile)},w=new model.World([body]),initial=structuredClone(body);let checksum=0;const t=performance.now();for(let i=0;i<cycles;i++){Object.assign(body,structuredClone(initial));for(let k=0;k<commands.length;k++){w.time=k*.05;w.step([commands[k]],.05)}checksum+=body.pos.x+body.pos.y+body.facing;}return{milliseconds:performance.now()-t,steps:cycles*40,checksum}}
for(const m of models)run(m,10);
const rows=[],start=performance.now();for(const order of [[0,1,2,3],[3,2,1,0],[1,0,3,2]])for(const i of order){if(performance.now()-start>30000)throw Error('30s microbudget');rows.push({model:models[i].label,...run(models[i],200)})}
const result={qualification:'Single-body fixed command/capability microbenchmark; no contacts/games, not overall game performance. Same250? actualcycles200/arm/trial,40ticks/loop;3reversedorders afterwarmup. Exact same profile/commands, resetfullbodyeachloop, different physicalintegration intentional.',profile,commands,models:models.map(({World,...m})=>m),rows};
result.summary=models.map(m=>{const times=rows.filter(r=>r.model===m.label).map(r=>r.milliseconds).sort((a,b)=>a-b);return{model:m.label,medianMs:times[1],minMs:times[0],maxMs:times[2],stepsPerTrial:8000}});
writeFileSync('out/movement-continuity/motor-cost.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result.summary));
