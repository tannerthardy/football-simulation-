import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {track} from '../../../src/sim/behaviors/common.ts';
import {World} from '../../../src/physics/world.ts';
import {angleDiff} from '../../../src/core/vec.ts';
import {sourceVersion} from '../../../scripts/source-version.ts';
const out='out/movement-continuity/preview-audit';
const r=JSON.parse(gunzipSync(readFileSync('out/movement-continuity/transfer/OZ24.json.gz')).toString());
const idx=r.initial.find((a:any)=>a.slot==='FS').idx;
function helper(body:any,target:any,tv:any,opts:any,mode='actual'){
 const fake={body,profile:body.profile,pos:body.pos};
 if(mode==='actual')return track(fake as any,target,tv,opts);
 const ex=target.x-body.pos.x,ey=Math.max(.3,Math.min(160/3-.3,target.y))-body.pos.y;
 const d=Math.hypot(ex,ey),vmax=body.profile.vmax*(opts.speed??1),k=opts.gain??2.2;
 const lead=mode==='far'?Math.min(1.2,d/vmax):mode==='continuous'?Math.min(1.2,Math.max(0,d-4)/vmax):0;
 const lx=ex+tv.x*lead,ly=ey+tv.y*lead,l=Math.hypot(lx,ly)||1;
 const brake=Math.sqrt(body.profile.brake*Math.max(0,d-.3))+1;
 const close=mode==='far'?Math.min(vmax,brake):Math.min(k*d,brake);
 let vx=tv.x+lx/l*close,vy=tv.y+ly/l*close;
 const scale=Math.min(1,vmax/Math.max(1e-9,Math.hypot(vx,vy)));
 return {vel:{x:vx*scale,y:vy*scale},facing:opts.facing};
}
const opts={speed:.65,gain:2,facing:Math.PI};
const traces=r.ticks.filter((t:any)=>t.t>=1.3&&t.t<=1.65).map((t:any)=>{
 const b=t.before[idx],q=t.requestObjectives[idx],expected=t.requests[idx];
 const actual=helper(b,q.point,q.velocity,opts);
 if(Math.hypot(actual.vel.x-expected.vel.x,actual.vel.y-expected.vel.y)>1e-10)throw new Error('reconstruction mismatch');
 return {t:t.t,d:Math.hypot(q.point.x-b.pos.x,q.point.y-b.pos.y),body:b,point:q.point,targetVelocity:q.velocity,actual,near:helper(b,q.point,q.velocity,opts,'near'),far:helper(b,q.point,q.velocity,opts,'far'),continuous:helper(b,q.point,q.velocity,opts,'continuous')};
});
const base=structuredClone(traces[3].body),point=traces[3].point,tv=traces[3].targetVelocity;
function jump(a:any,b:any){return {requestDelta:Math.hypot(b.vel.x-a.vel.x,b.vel.y-a.vel.y),headingDeltaDeg:angleDiff(Math.atan2(a.vel.y,a.vel.x),Math.atan2(b.vel.y,b.vel.x))*180/Math.PI}}
function samples(command:any){const body=structuredClone(base),world=new World([body]);return Array.from({length:8},()=>{world.step([command],.05);return {pos:{...body.pos},vel:{...body.vel},facing:body.facing,support:body.support?.state}})}
const samePicture={far:helper(base,point,tv,opts,'far'),near:helper(base,point,tv,opts,'near'),continuous:helper(base,point,tv,opts,'continuous')};
const pure=[];
for(const targetVelocity of [{x:0,y:0},{x:-3,y:0},{x:0,y:-3}]){
 const at=(d:number,mode:string)=>helper({...base,pos:{x:point.x+d,y:point.y}},point,targetVelocity,opts,mode);
 pure.push({targetVelocity,originalJump:jump(at(4+1e-8,'actual'),at(4-1e-8,'actual')),continuousJump:jump(at(4+1e-8,'continuous'),at(4-1e-8,'continuous')),originalPlus:at(4+1e-8,'actual'),originalMinus:at(4-1e-8,'actual')});
}
const result={source:sourceVersion(),question:'Does shared track have a mathematical request discontinuity at the near/far switch, independently of acquired information, random execution and contacts?',qualification:'Saved candidate-source tape is reused. All new motion is pure one-body unloaded World evidence, not a full native snap or outcome experiment. Continuous alternative is diagnostic only; no runtime source edit.',traces,samePicture:{...samePicture,jump:jump(samePicture.far,samePicture.near),farWorld:samples(samePicture.far),nearWorld:samples(samePicture.near)},pure};
writeFileSync(out+'/result.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({source:result.source,pure,samePictureJump:result.samePicture.jump,saved:traces.map(({body,...x}:any)=>x)},null,2));
