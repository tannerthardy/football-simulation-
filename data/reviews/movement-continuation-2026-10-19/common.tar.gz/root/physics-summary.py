import importlib.util,json,gzip,math
from pathlib import Path
out=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('operator',out/'compare.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=Path('/workspace/football-defensive-snap-response/out/defensive-snap-response')
roots={'accepted':base,'yaw':out/'pilot','gait':Path('/workspace/football-gait-achieved-pose/out/gait-achieved-pose/native'),'both':Path('/workspace/football-movement-physics-interaction/out/physics-interaction/native')}
cols={};identity=[]
for k in ['TOSS','PASS13']:
 rows={}
 for arm,root in roots.items():
  p=root/('baseline' if k=='TOSS' else 'fresh-baseline')/(k+'.json.gz') if arm=='accepted' else root/(k+'.json.gz')
  r=json.load(gzip.open(p));rows[arm]=m.read_native(p);vals,exc=m.samples(rows[arm]);cols.setdefault(arm,{'samples':{},'values':{}})['samples'][k]=vals
  identity.append({'case':k,'arm':arm,'source':r['source'],'inputSha256':r['inputSha256'],'phase':r['phase'],'outcome':r['outcome'],'gain':r['gain'],'end':r['ticks'][-1]['completed']})
keys=[]
for k in ['TOSS','PASS13']:
 common=set.intersection(*(set(x['samples'][k]) for x in cols.values()))
 common={i for i in common if all(x['samples'][k][i]['zone']=='clear_all' for x in cols.values())};keys.append({'case':k,'pairedSamples':len(common)})
 for arm,entry in cols.items():
  for i in common:
   for metric,v in entry['samples'][k][i]['values'].items():entry['values'].setdefault(metric,[]).append(v)
summary={arm:{metric:m.stats(xs) for metric,xs in entry['values'].items()} for arm,entry in cols.items()}
(out/'physics-summary.json').write_text(json.dumps({'identity':identity,'pairing':keys,'four_arm_clear_all':summary,'qualification':'Sameactor/time windows valid and clear of allplayers in allfourarms; speedgate2yd/s. Trackingproxy not physicaljoint ownership. Existing20NFLplayreference unchanged, no new tracking query.'},indent=2)+'\n')
print(json.dumps(summary,indent=2))
