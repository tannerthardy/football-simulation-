import { writeFileSync } from 'node:fs';
import { World } from '../../../src/physics/world.js';
import { locomotionAccel, fatigueFactor, type Body } from '../../../src/physics/kinematics.js';
import { supportParams, availability } from '../../../src/physics/support.js';

// Pure mechanical diagnostics, not a playable football scenario. No sensing,
// stochastic calls, controller changes, contact patches, or source edits.
const profile={massKg:100,radius:.3,reach:1,heightYd:2.05,vmax:9,tau:1.3,
  brake:6,lateral:6,turnRate:8,backpedal:.6,shuffle:.55,maxCatchHeight:3,
  reactReach:2.6,reactionTime:.25,power:100,balance:.5};
const make=():Body=>({pos:{x:0,y:0},vel:{x:0,y:0},facing:0,energy:1,profile:{...profile}});

function run(achievedPose:boolean,loaded:boolean,ticks:number,straight=false){
  const b=make(),w=new World([b]);
  if(loaded){
    // Synthetic high-braking sideways entry makes the ordinary ground-force
    // limiter exhaust traction, so there is literally no spare yaw torque.
    // This tests the limiting contract; it is not a native player/checkpoint.
    b.vel={x:0,y:7};b.profile.brake=30;
  }
  let planned:unknown;
  const original=(w as any).plan;
  (w as any).plan=function(body:Body,i:number,intent:any,dt:number){
    const plan=original.call(w,body,i,intent,dt);
    if(achievedPose){
      const low=1-.12*Math.max(0,body.support!.posture-.3);
      const cmd=low<1?{...intent,effort:(intent.effort??1)*low}:intent;
      const a=availability(body.support!,supportParams(body.profile),fatigueFactor(body.energy));
      const acc=locomotionAccel(body,cmd,dt,a);
      plan.ax=acc.x;plan.ay=acc.y;
    }
    planned={ax:plan.ax,ay:plan.ay,yawTarget:plan.facing};
    return plan;
  };
  const rows=[];
  for(let i=0;i<ticks;i++){
    const intent={vel:{x:straight?9:0,y:straight?0:9},facing:straight?0:Math.PI/2};
    const before={pos:{...b.pos},vel:{...b.vel},facing:b.facing,spin:b.spin??0};
    const report=w.step([intent],.05);
    rows.push({t:(i+1)*.05,intent,before,planned,
      achieved:{pos:{...b.pos},vel:{...b.vel},facing:b.facing,spin:b.spin??0,state:b.support!.state},
      groundImpulse:report.groundImpulse[0],yawImpulse:report.groundYawImpulse[0],
      residual:report.work.residual});
  }
  return rows;
}
const result={description:'Pure motor/gait consistency diagnostic; high-braking sideways entry is synthetic.',
  ordinary:{retainedVirtualPose:run(false,false,6),achievedPose:run(true,false,6)},
  noSpareYaw:{retainedVirtualPose:run(false,true,1),achievedPose:run(true,true,1)},
  straightControl:{retainedVirtualPose:run(false,false,3,true),achievedPose:run(true,false,3,true)}};
writeFileSync('out/movement-continuity/review/virtual-pose.json',JSON.stringify(result,null,2)+'\n');
for(const [name,pair] of Object.entries(result).filter(([_,v])=>typeof v!=='string')){
  console.log(name,JSON.stringify(Object.fromEntries(Object.entries(pair as any).map(([key,rows]:any)=>[key,{first:rows[0],last:rows.at(-1)}]))));
}
