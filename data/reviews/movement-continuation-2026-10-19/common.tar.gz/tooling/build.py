from pathlib import Path
from io import BytesIO
import subprocess, tempfile, hashlib, json, tarfile, gzip, os, sys, re, time

BASE='f4146275ce7539816bf57b4ed55a0d2be10e48c7'
REPO=Path('/workspace/football-movement-continuity')
OUT=REPO/'out/movement-continuation-publication'
OUT.mkdir(exist_ok=True)
STAGE=Path('/workspace/football-free-fit-objective-continuity/out/movement-evidence/stage')
STAGE.mkdir(exist_ok=True)
EXPECTED_BASE='7d23555ad67094fbe2e79726d9b761dd5f068c06fb90ff0796ec61c953750197'

def git(*args,cwd=REPO): return subprocess.check_output(['git',*args],cwd=cwd)
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(root):
 h=hashlib.sha256()
 for p in sorted((str(p.relative_to(root)) for p in (root/'src').rglob('*') if p.is_file())):
  h.update(p.encode()+b'\0'+(root/p).read_bytes()+b'\0')
 return h.hexdigest()
def commitpatch(rev): return git('diff','--binary',BASE,rev,'--','src')
def workingpatch(root): return git('diff','--binary',BASE,'--','src',cwd=root)
def emit(name,data):
 p=STAGE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p

sources=[]
def source(name,expected,patch,kind,pin=None):
 path=emit('sources/'+name+'.patch',patch)
 with tempfile.TemporaryDirectory(prefix='movement-restore-',dir='/tmp') as tmp:
  root=Path(tmp)
  with tarfile.open(fileobj=BytesIO(git('archive',BASE,'src'))) as t: t.extractall(root,filter='data')
  if patch: subprocess.run(['git','apply','--unsafe-paths',str(path)],cwd=root,check=True,capture_output=True)
  restored=digest(root)
  if restored!=expected: raise RuntimeError((name,expected,restored))
 sources.append(dict(name=name,sourceSha256=expected,patch='sources/'+name+'.patch',patchSha256=sha(patch),base=BASE,restoredSha256=restored,kind=kind,pin=pin))

source('accepted',EXPECTED_BASE,b'','accepted',BASE)
source('yaw-native','365e4a9d907fd00e6bc1239a632ecadf46c87ebca93da6d81e1ada3db4c04957',(REPO/'out/movement-continuity/native-source.patch').read_bytes(),'reused #162 native producer')
source('yaw-publication','51351a24096a139cecd658b527c54f73d391dfa14dacd20c8772bfc770383648',commitpatch('f3f4b4224e076cc750468dc930e229e95ce0e307'),'#162 reviewed reference; not accepted develop','f3f4b4224e076cc750468dc930e229e95ce0e307')
source('free-fit','565ddbd0351efa3c4cbeeb6a1c517a7624c643e6d5b5001f7857199463c5f523',commitpatch('1885a34b5da24e870ab8719cbb45feea83fa9c8d'),'held independent controller candidate','1885a34b5da24e870ab8719cbb45feea83fa9c8d')
source('track-first','4e78e876ee1cd7af00be1b5fe79a3968d5d2fb2b63f95dba21fa9e02a3eb8ca3',commitpatch('9da3b499d8af97d5f3a6c90146a119ef0965e999'),'rejected native arm','9da3b499d8af97d5f3a6c90146a119ef0965e999')
source('track-second','5d25bd245d0cfaf46738bda6c36f7207d160188bdcdf872ebf671f06d3008a07',(Path('/workspace/football-continuous-track-objective/out/continuous-track/rejected-near-join-source.patch')).read_bytes(),'rejected pure-contract arm; zero native')
# Initial failed far-cap source was not committed. Reconstruct the documented
# one-line omission and require its exact recorded full-src fingerprint.
with tempfile.TemporaryDirectory(prefix='movement-track-failure-',dir='/tmp') as tmp:
 root=Path(tmp)
 for p in git('ls-tree','-r','--name-only','9da3b499d8af97d5f3a6c90146a119ef0965e999','src').decode().splitlines():
  target=root/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(git('show','9da3b499d8af97d5f3a6c90146a119ef0965e999:'+p))
 p=root/'src/sim/behaviors/common.ts';b=p.read_bytes();old=b'Math.min(vmax, (opts.gain ?? 2.2) * d, brakeClose(d))';assert b.count(old)==1;p.write_bytes(b.replace(old,b'Math.min((opts.gain ?? 2.2) * d, brakeClose(d))'))
 assert digest(root)=='91982c1e7aa350145f03758aeb6366b639b46ba8cd659c528693ee93b56e34be'
 basecommon=emit('scratch/base-common.ts',git('show',BASE+':src/sim/behaviors/common.ts'))
 diff=subprocess.run(['diff','-u','--label','a/src/sim/behaviors/common.ts','--label','b/src/sim/behaviors/common.ts',str(basecommon),str(p)],capture_output=True)
 assert diff.returncode==1
 source('track-first-far-cap-failure','91982c1e7aa350145f03758aeb6366b639b46ba8cd659c528693ee93b56e34be',diff.stdout,'reconstructed exact failed source, full digest matched')
source('gait-achieved-pose','ee292a6a4396e81a50112f62cf344c759f62402cb9e3eb0bae8a257d00a5c2d1',commitpatch('36a77d17444658675f886c3914572faa181bd5a4'),'independent physics candidate','36a77d17444658675f886c3914572faa181bd5a4')
source('yaw-plus-gait','0eca9aa8931e5ca7f6dc07b24508bedbd80c6831d4a9a0013a1671f3e3167b70',workingpatch(Path('/workspace/football-movement-physics-interaction')),'diagnostic uncommitted interaction on #162; no production candidate')
source('contact-arrival-superseded','54a5bfc9ace7b92bc46d74e02cdad436cd5343478234fb3bdfe220ef921d00cb',commitpatch('bd18bc9e30e2f3e209f9d2bb8fe17c9ff143cf5a'),'superseded acquired-reference mismatch preserved','bd18bc9e30e2f3e209f9d2bb8fe17c9ff143cf5a')
if len(sys.argv)>1:
 cfg=json.loads(Path(sys.argv[1]).read_text())
 source('contact-arrival-final',cfg['runtime'],commitpatch(cfg['code']),'final isolated acquired-reference/controller candidate',cfg['code'])

archives={};members={};originals={}
def add(archive,arcname,path):
 path=Path(path)
 assert path.is_file() and not path.is_symlink(),str(path)
 # These are explicit local artifact roots, never arbitrary workspace walks.
 assert not any(z in path.parts for z in ['node_modules','.git','__pycache__'])
 assert not re.search(r'(^|/)(nfl-selected|nfl-common|nfl-plays|tracking_week|players\.csv|plays\.csv|player_play\.csv)',str(path),re.I),str(path)
 assert arcname not in archives.setdefault(archive,{})
 archives[archive][arcname]=path
 originals[(archive,arcname)]=str(path)
def directory(archive,prefix,root,excludes=()):
 root=Path(root)
 for p in sorted(root.rglob('*')):
  if p.is_file() and str(p.relative_to(root)) not in excludes:
   add(archive,prefix+'/'+str(p.relative_to(root)),p)

# Source patches + operator/fixture/report files. Deliberately excludes all
# NFL trajectory caches, archives and raw tracking. NFL aggregate text only.
for p in sorted((STAGE/'sources').iterdir()):add('common','sources/'+p.name,p)
add('common','tooling/build.py',Path(__file__).resolve())
if len(sys.argv)>1:add('common','tooling/final-config.json',Path(sys.argv[1]).resolve())
root=REPO/'out/movement-continuity'
for name in ['physics-summary.json','physics-summary.py','physics-summary.log','motor-cost.json','motor-cost.mjs','motor-cost-receipt.json']:
 add('common','root/'+name,root/name)
directory('common','root/low-speed-audit',root/'low-speed-audit')
directory('common','root/preview-audit',root/'preview-audit')
directory('common','root/review',root/'review')
add('common','root/nfl-reference-aggregate.txt',Path('/workspace/football-run-rep-arrival/out/run-rep-arrival/smooth-nfl.txt'))
original_nfl_receipt=(root/'nfl-receipt.json').read_bytes()
nfl_aggregate=json.loads(original_nfl_receipt)
selected=nfl_aggregate.pop('selected_ids',[])
nfl_aggregate['selectedIdCount']=len(selected)
nfl_aggregate['originalReceiptSha256']=sha(original_nfl_receipt)
nfl_aggregate['qualification']='Aggregate/provenance only; per-play IDs/events and all trajectories omitted from this packet.'
add('common','root/nfl-reference-receipt-aggregate.json',emit('nfl-reference-receipt-aggregate.json',(json.dumps(nfl_aggregate,indent=2)+'\n').encode()))
# Native baseline/yaw witnesses required directly by this continuation.
bases={
 'TOSS-completed':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/TOSS.json.gz'),
 'TOSS-enriched':Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/TOSS.json.gz'),
 'IZ-enriched':Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/IZ.json.gz'),
 'OZ24':Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/OZ24.json.gz'),
 'FTOSS':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/FTOSS.json.gz'),
 'DUO':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/DUO.json.gz'),
 'PA13':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PA13.json.gz'),
 'PASS13':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PASS13.json.gz'),
 'yaw-TOSS':root/'pilot/TOSS.json.gz',
 'yaw-PASS13':root/'pilot/PASS13.json.gz'}
for name,p in bases.items():add('baselines','native/'+name+'.json.gz',p)
for name,p in [('original',Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/baseline/receipt.json')),('fresh',Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/receipt.json')),('enriched',Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/receipt.json')),('extra',Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/receipt.json')),('yaw-pilot',root/'pilot/receipt.json')]:add('baselines','receipts/'+name+'.json',p)
# The mixed-time motor cost operator reads full accepted source from git;
# source patches already restore both production trees above.
for name,p in [('run-flow-inputs','/workspace/football-linebacker-run-flow/out/run-flow/transfer-inputs.json.gz'),('yaw-pilot-inputs',str(root/'pilot-inputs.json.gz'))]:add('baselines','inputs/'+name+'.json.gz',p)

contact=Path('/workspace/football-run-rep-arrival/out/run-rep-arrival')
for artifact in sorted(contact.rglob('*')):
 if not artifact.is_file(): continue
 relative=str(artifact.relative_to(contact))
 if relative=='nfl-common.jsonl.gz' or relative.startswith(('reference-pilot/','reference-transfer/')) or relative.startswith('reference-') or relative=='analyze-reference.py': continue
 add('contact','superseded/'+relative,artifact)
# Original54 test sources are restored from its immutable code commit.
for rel in ['test/run-rep-lateral-arrival.test.ts','test/run-contact-flow.test.ts']:
 add('contact','checked-sources/'+rel,emit('checked-contact54/'+rel,git('show','bd18bc9e30e2f3e209f9d2bb8fe17c9ff143cf5a:'+rel)))

# If owner creates final outputs inside the root, source cfg supplies its
# exact root so the prior archive remains separately identified below.
if len(sys.argv)>1:
 for artifact in sorted(contact.rglob('*')):
  if not artifact.is_file():continue
  relative=str(artifact.relative_to(contact))
  if relative=='reference-old-source.log':continue
  if relative.startswith(('reference-pilot/','reference-transfer/')) or relative.startswith('reference-') or relative=='analyze-reference.py':
   add('contact-final','final/'+relative,artifact)
 for rel in ['test/run-rep-lateral-arrival.test.ts','test/run-contact-flow.test.ts','docs/reviews/run-rep-lateral-arrival-2026-10-19.md']:
  if (contact.parent.parent/rel).is_file():
   artifact=contact.parent.parent/rel
   if rel.endswith('.md'):
    artifact=emit('checked-contact-final/'+rel,artifact.read_bytes().replace(b'PUBLICATION_LINK',b'../../../README.md'))
   add('contact-final','checked-sources/'+rel,artifact)

free=Path('/workspace/football-free-fit-objective-continuity')
directory('free-fit','free-fit',free/'out/free-fit-continuity')
directory('free-fit','native',free/'out/fit-continuity')
track=Path('/workspace/football-continuous-track-objective')
directory('track','contracts',track/'out/continuous-track')
directory('track','native',track/'out/track-continuity')
gait=Path('/workspace/football-gait-achieved-pose')
directory('gait','gait',gait/'out/gait-achieved-pose')
interaction=Path('/workspace/football-movement-physics-interaction')
directory('interaction','interaction',interaction/'out/physics-interaction')
# Exact checked source tests and reports from the candidates; no runtime edit.
for label,repo,paths in [
 ('free-fit',free,['test/run-fit-objective-continuity.test.ts','docs/reviews/free-fit-objective-continuity-2026-10-19.md']),
 ('track',track,['test/track-objective-continuity.test.ts','docs/reviews/track-objective-continuity-2026-10-19.md']),
 ('gait',gait,['test/gait-achieved-pose.test.ts']),
 ('interaction',interaction,['test/gait-achieved-pose.test.ts']),
 ('contact-final' if len(sys.argv)>1 else 'contact',Path('/workspace/football-run-rep-arrival'),[])]:
 for p in paths:add(label,'checked-sources/'+p,repo/p)

native=[];receipts=[]
for group,paths in archives.items():
 entries=[]
 for name,path in sorted(paths.items()):
  data=path.read_bytes()
  if name.endswith('.jsonl.gz'):
   for line in gzip.decompress(data).splitlines():
    row=json.loads(line);row=row.get('common',row)
    assert row.get('source')=='sim',('Non-sim trajectory in packet',group,name,row.get('id'))
  entry=dict(path=name,bytes=len(data),sha256=sha(data),originalPath=str(path));entries.append(entry)
  if name.endswith('.json.gz'):
   try:obj=json.loads(gzip.decompress(data))
   except (json.JSONDecodeError,gzip.BadGzipFile):obj=None
   if isinstance(obj,dict) and 'ticks' in obj and 'initial' in obj:
    native.append(dict(archive=group,path=name,id=obj['id'],source=obj['source'],inputSha256=obj['inputSha256'],phase=obj['phase'],outcome=obj['outcome'],gain=obj['gain'],end=max((t['completed'] for t in obj['ticks']),default=0),elapsedSeconds=obj.get('elapsedSeconds'),cached=group=='baselines'))
  if name.endswith('.json'):
   try:obj=json.loads(data)
   except json.JSONDecodeError:continue
   if isinstance(obj,dict) and isinstance(obj.get('commands'),list):
    receipts.append(dict(archive=group,path=name,sha256=sha(data),elapsedSeconds=sum(c.get('elapsedSeconds',0) for c in obj['commands']),exitCode=obj.get('exitCode'),source=obj.get('sourceSha256'),startedAt=obj.get('startedAt')))
 members[group]=entries
 out=OUT/(group+'.tar.gz')
 with out.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6) as gz:
   with tarfile.open(fileobj=gz,mode='w') as tar:
    for name,path in sorted(paths.items()):
     data=path.read_bytes();ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;ti.mtime=0;tar.addfile(ti,BytesIO(data))
 # Every stored member is independently read back after close.
 with tarfile.open(out,'r:gz') as tar:
  found=tar.getmembers();assert len(found)==len(entries)
  for e in entries:
   data=tar.extractfile(e['path']).read();assert len(data)==e['bytes'] and sha(data)==e['sha256'],e['path']
 print(group,len(entries),out.stat().st_size,flush=True)

# Copied receipts are identified by SHA; never charge duplicates twice.
unique={r['sha256']:r for r in receipts}
manifest=dict(base=BASE,baseSource=EXPECTED_BASE,status='DRAFT awaiting final contact source' if len(sys.argv)==1 else 'immutable continuation evidence; candidates retain individual dispositions',sources=sources,archives={g:dict(file=g+'.tar.gz',sha256=sha((OUT/(g+'.tar.gz')).read_bytes()),bytes=(OUT/(g+'.tar.gz')).stat().st_size,members=members[g]) for g in archives},native=native,receipts=receipts,costs=dict(uniqueCommandReceipts=len(unique),recordedUniqueCommandWallSeconds=sum(r['elapsedSeconds'] for r in unique.values()),nativeNewPrefixes=sum(not r['cached'] for r in native),nativeNewCompleted=sum(not r['cached'] and r['phase']=='dead' for r in native),nativeNewCensored=sum(not r['cached'] and r['phase']!='dead' for r in native),nativeNewUniqueInputs=len(set(r['inputSha256'] for r in native if not r['cached'])),nativeNewCaseWallSeconds=sum(r['elapsedSeconds'] or 0 for r in native if not r['cached']),cachedSelectedTapes=sum(r['cached'] for r in native),qualification='Original historical compatible receipts are reused and deduplicated by content SHA. This sum includes pure probes/checks/typechecks/mixed-time motor timing, not new game cost and not a performance pass.'),reusedOriginalEvidence=dict(pin='55d672c90a68aa6d830fc0019d863b191bf39c80',path='data/reviews/defensive-snap-response',note='Broader original8 baselines used only by low-speed saved-data audit are reusable here; selected native comparisons needed by this continuation are also packaged.'),security=dict(NFLTrajectoriesIncluded=False,newNFLDownloads=0,newNFLQueries=0,newSimulationsByPackager=0,includes='Allowlisted sim tapes, synthetic/pure results, aggregate NFL text/receipt, original failures, tests/operators, exact source patches.'))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'README.md').write_text('''# Movement continuation evidence — 2026-10-19

Data-only immutable publication on accepted f4146275. Candidate code is kept in
separate branches; this evidence is not an engine merge or acceptance decision.
See manifest.json for every artifact hash, exact source/input pin, outcome versus
censored prefix, original cost and limitations. Each full-src patch is restored
from accepted develop and hashed before publication. Each archive member is read
back and checked. No NFL trajectories, raw CSVs, credentials or caches are included.

Contact54 is superseded: its moving velocity was applied to a held, unadvanced
point. The preserved reviewer finding explains why perception.age must not be
added again. Final contact39b5 source/results are a separate archive. The report
snapshot replaces its publication placeholder with the enclosing README path;
no candidate runtime or working document was edited by the packager.
Free-fit continuity remains held. Both track variants are rejected: first loses
far seam leverage; second fails a cheap approaching-target contract without a
second native run. Gait and yaw-plus-gait physical diagnostics retain their own
readiness limits and unfinished PASS13. Cleaner requests do not establish better
NFL movement or football endings. Contact aggregate DL/TE smoothness adverse
results, stale-reference costs and mixed-time motor timing remain visible.

Reproduction: extract the needed archive, restore src with its sources/*.patch
on base f4146275, use Node22.23.3 and the pinned package-lock, and run the original
launcher command from its receipt with all44 settings. Local /workspace paths
in operators identify original artifacts; map them to the equivalent archive
members listed in manifest.json. Do not fetch/download NFL data to reproduce
these native/synthetic findings. Original baseline55d evidence remains fetchable
for the broader saved-state reuse audit. No new simulation or full suite ran in
building this packet. Integration owns combined verification.
''')
files=sorted(p for p in OUT.iterdir() if p.is_file() and p.name!='SHA256SUMS')
(OUT/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in files))
print('sources restored',len(sources),'native records',len(native),'unique input count',len(set(r['inputSha256'] for r in native if not r['cached'])),'receipt wall',manifest['costs'],flush=True)
