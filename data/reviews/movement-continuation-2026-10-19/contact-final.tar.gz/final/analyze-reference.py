import gzip,json,hashlib,sys,importlib.util
from pathlib import Path
O=Path(__file__).resolve().parent
root=Path('/workspace/football-defensive-snap-response/out/defensive-snap-response');extra=Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline')
ids=['TOSS','OZ24','FTOSS','DUO','PA13','PASS13']
paths={k:(root/'baseline'/f'{k}.json.gz' if k in ['TOSS','DUO'] else root/'fresh-baseline'/f'{k}.json.gz' if k in ['FTOSS','PA13','PASS13'] else extra/f'{k}.json.gz') for k in ids}
load=lambda p:json.load(gzip.open(p));h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows={a:{k:load(p if a=='baseline' else O/('reference-pilot' if k in ['TOSS','OZ24'] else 'reference-transfer')/f'{k}.json.gz') for k,p in paths.items()} for a in ['baseline','candidate']}
summary={'cases':{},'selected_DTW':{},'controls':{},'qualification':'Exact existing frozen inputs; causal first-divergence and common-field identity, not matched late execution. Projection advances elapsed hold time only; no extra perception.age.'}
for k in ids:
 a,b=rows['baseline'][k],rows['candidate'][k]
 assert a['inputSha256']==b['inputSha256']
 summary['cases'][k]={arm:{'source':r['source'],'inputSha256':r['inputSha256'],'phase':r['phase'],'gain':r['gain'],'outcome':r['outcome'],'endpoint':r['ticks'][-1]['completed'],'events':[e for e in r['events'] if e['type'] in ['wrap','tackle','missed_tackle','pass','catch']]} for arm,r in [('baseline',a),('candidate',b)]}
 summary['cases'][k]['firstRngDifference']=next((x['t'] for x,y in zip(a['ticks'],b['ticks']) if x['rng']!=y['rng']),None)
 summary['cases'][k]['firstIntentDifference']=next((x['t'] for x,y in zip(a['ticks'],b['ticks']) if x['intents']!=y['intents']),None)
 if k in ['PA13','PASS13']:
  ignored={'minds','intentObjectives','requestObjectives'}
  checks={'sameTickCount':len(a['ticks'])==len(b['ticks']),'commonTickFields':all(all(x[f]==y[f] for f in x.keys()&y.keys()-ignored) for x,y in zip(a['ticks'],b['ticks'])),'events':a['events']==b['events'],'result':a['result']==b['result']}
  assert all(checks.values());summary['controls'][k]=checks
for k in ['TOSS','OZ24']:
 summary['selected_DTW'][k]={}
 for arm in rows:
  r=rows[arm][k]
  if arm=='baseline' and k=='TOSS':
   rich=load(Path('/workspace/football-linebacker-run-flow/out/run-flow/enriched/TOSS.json.gz'))
   assert rich['source']==r['source'] and rich['inputSha256']==r['inputSha256']
   assert all(a['before']==b['before'] and a['intents']==b['intents'] and a['rng']==b['rng'] for a,b in zip(r['ticks'],rich['ticks']))
   r=rich
  idx=next(a['idx'] for a in r['initial'] if a['slot']=='DT_W')
  ticks=[t for t in r['ticks'] if .6-1e-8<=t['t']<=2+1e-8]
  req=[t['intents'][idx]['vel']['y'] for t in ticks];vel=[t['before'][idx]['vel']['y'] for t in ticks]
  aims=[a for a in r['aims'] if a['a']==idx and a['job'].startswith('run-contact:')]
  errors=[]
  for t in ticks:
   cues=[a for a in aims if abs(a['t']-t['t'])<1e-8]
   if cues:errors.append(abs(t['before'][idx]['pos']['y']-cues[-1]['desired']['y']))
  tv=lambda v:sum(abs(b-a) for a,b in zip(v,v[1:]))
  summary['selected_DTW'][k][arm]={'idx':idx,'actualId':r['initial'][idx]['player']['id'],'samples':len(ticks),'intentYTotalVariation':tv(req),'achievedBeforeYTotalVariation':tv(vel),'meanErrorToCurrentAcquiredOrTactileShoulder':sum(errors)/len(errors),'errorSamples':len(errors)}
# Reuse the unchanged published smooth.py measure on native common rows only.
G=lambda p:'OL' if p in ['OT','OG','C','T','G'] else 'DL' if p in ['DE','DT','NT','EDGE'] else 'DB' if p in ['CB','FS','SS','S'] else 'LB' if p in ['MLB','OLB','ILB'] else 'RB' if p=='FB' else p
for arm in rows:
 with gzip.open(O/f'reference-{arm}-common.jsonl.gz','wt') as out:
  for k,r in rows[arm].items():
   init=r['initial'];frames=[r['ticks'][0]['before']]+[t['after'] for t in r['ticks'] if abs(t['completed']*10-round(t['completed']*10))<1e-6]
   ev={'end':r['ticks'][-1]['completed']};event=next((e['t'] for e in r['events'] if e['type'] in ['handoff','pitch_catch']),None)
   if event is not None:ev['handoff']=event
   row={'id':k,'source':'sim','kind':r['setup']['offCall']['kind'],'dt':.1,'players':[{'side':'O' if i<11 else 'D','group':G(a['player']['position'])} for i,a in enumerate(init)],'carrier':next(a['idx'] for a in init if a['slot']=='RB'),'events':ev,'xy':[[round(v,2) for a in frame for v in [a['pos']['x'],a['pos']['y']]] for frame in frames]}
   out.write(json.dumps(row)+'\n')
summary['inputFiles']={k:{'path':str(p),'sha256':h(p)} for k,p in paths.items()}
(O/'reference-analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'selected_DTW':summary['selected_DTW'],'controls':summary['controls'],'results':{k:{a:{f:r[f] for f in ['phase','gain','outcome','endpoint']} for a,r in v.items() if a in ['baseline','candidate']} for k,v in summary['cases'].items()}},indent=2))
