import gzip,json,math,csv,hashlib
from pathlib import Path
OUT=Path(__file__).resolve().parent
root=Path('/workspace/football-defensive-snap-response/out/defensive-snap-response');extra=Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline')
sel={k:(root/'baseline'/f'{k}.json.gz' if k in ['TOSS','DUO'] else root/'fresh-baseline'/f'{k}.json.gz' if k in ['FTOSS','PA13','PASS13'] else extra/f'{k}.json.gz') for k in ['TOSS','OZ24','FTOSS','DUO','PA13','PASS13']}
G=lambda p:'OL' if p in ['OT','OG','C','T','G'] else 'DL' if p in ['DE','DT','NT','EDGE'] else 'DB' if p in ['CB','FS','SS','S'] else 'LB' if p in ['MLB','OLB','ILB'] else 'RB' if p=='FB' else p
for arm in ['baseline','arrival']:
 with gzip.open(OUT/f'{arm}-common.jsonl.gz','wt') as f:
  for k,p in sel.items():
   if arm=='arrival':p=OUT/('pilot' if k in ['TOSS','OZ24'] else 'transfer')/f'{k}.json.gz'
   r=json.load(gzip.open(p))
   init=r['initial'];frames=[r['ticks'][0]['before']]+[t['after'] for t in r['ticks'] if abs(t['completed']*10-round(t['completed']*10))<1e-6]
   carrier=next(a['idx'] for a in init if a['slot']=='RB')
   # Existing operator's carrier-after-exchange bin uses handoff. Native pitch
   # receipt is recorded explicitly as the same exchange phase, not hidden.
   ev={'end':r['ticks'][-1]['completed']}
   h=next((e['t'] for e in r['events'] if e['type'] in ['handoff','pitch_catch']),None)
   if h is not None:ev['handoff']=h
   xy=[[round(v,2) for a in frame for v in [a['pos']['x'],a['pos']['y']]] for frame in frames]
   row={'id':k,'source':'sim','kind':r['setup']['offCall']['kind'],'dt':.1,'players':[{'side':'O' if i<11 else 'D','group':G(a['player']['position'])} for i,a in enumerate(init)],'carrier':carrier,'events':ev,'xy':xy,'cell':{'concept':r['setup']['offCall'].get('run',{}).get('scheme')}}
   f.write(json.dumps(row)+'\n')
# Reuse the existing selected NFL cache; only carrier labels are joined from
# the already verified small player_play metadata. No tracking reread.
nfl=json.load(gzip.open('/workspace/football-movement-continuity/out/movement-continuity/nfl-selected.json.gz'));meta={}
ids={r['id'] for r in nfl}
with open('/workspace/football-yac-angle/data/raw/bdb2025/big-data-bowl-data/player_play.csv',newline='') as f:
 for r in csv.DictReader(f):
  key=r['gameId']+':'+r['playId']
  if key in ids and r['hadRushAttempt']=='1':meta[key]=r['nflId']
with gzip.open(OUT/'nfl-common.jsonl.gz','wt') as f:
 for r in nfl:
  row={k:r[k] for k in ['id','kind','events']};row.update(source='nfl',dt=.1,players=[{'side':s,'group':g} for s,g in zip(r['sides'],r['groups'])],carrier=r['ids'].index(meta[r['id']]) if r['id'] in meta else None,cell={'concept':r.get('concept')},xy=[[c for p in pts for c in (p if p is not None else [None,None])] for pts in zip(*r['tracks'])])
  f.write(json.dumps(row)+'\n')
(OUT/'common-conversion.json').write_text(json.dumps({'native_inputs':{k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in sel.items()},'operator_source':'bdadfedb77ed5d12c77cf8797ea342847a8a9700:scripts/diag/stretch/smooth.py','native_quantization':'.01yd,10Hz from raw World state; no interpolation','pitch_exchange_alias':'pitch_catch event admitted as handoff phase for carrier bin; preserve original native event','NFL_cache':'Prior20play cache,12runs, official carrier joined from existing player_play.csv; no new tracking query.'},indent=2)+'\n')
