import{contactFixture,contactCommands}from'../../scripts/diag/run-contact-technique.ts';
import{runContactObservers}from'../../src/sim/run-contact-observer.ts';
import{availability,supportParams}from'../../src/physics/support.ts';
import{traits}from'../../src/sim/engagement.ts';
const f=contactFixture({type:'run',runBlock:60,passBlock:60});f.engagement.surfaceAxis={x:-1,y:0};f.engagement.drive={x:1,y:0};f.engagement.nextMoveAt=Infinity;f.defender.runFit={gap:'B',side:1,kind:'interior',technique:'attack',pace:'stack'};f.defender.recog!.read='run';
let aim;runContactObservers.set(f.sim,(_rep,phase,data)=>{if(phase==='movement'){aim=data.defensiveAim;console.log('obs',JSON.stringify({aim,flow:data.heldFlow,declared:data.declared,read:data.reading}));}else console.log(phase)});
console.log('initial',contactCommands(f)[f.defender.idx], f.defender.body.support?.state,availability(f.defender.body.support!,supportParams(f.defender.profile),1),traits(f.defender).lateral,!!f.defender.engagement);
f.defender.body.pos.y=aim.y-.08;f.defender.body.vel={x:0,y:.4};f.sim.t+=.01;console.log('next',contactCommands(f)[f.defender.idx],!!f.defender.engagement,availability(f.defender.body.support!,supportParams(f.defender.profile),1));
