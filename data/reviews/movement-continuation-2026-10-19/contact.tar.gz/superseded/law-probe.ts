import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {World} from '../../src/physics/world.ts';
import {gaitLag,movingArrivalVelocity,fatigueFactor} from '../../src/physics/kinematics.ts';
import {availability,supportParams} from '../../src/physics/support.ts';
import {requestToCover} from '../../src/sim/motion-plan.ts';
import {PlaySim} from '../../src/sim/playsim.ts';
import {traits} from '../../src/sim/engagement.ts';
import {sourceVersion} from '../../scripts/source-version.ts';
const saved=JSON.parse(gunzipSync(readFileSync('/workspace/football-linebacker-run-flow/out/run-flow/enriched/TOSS.json.gz')).toString());
const sim=new PlaySim(saved.setup),d=sim.slot('DT_W')!,td=traits(d);const rows=[];
for(const kind of ['hold','flow','reverse'] as const)for(const law of ['deadline','arrival'] as const){
 const b=structuredClone(d.body);b.pos={x:0,y:0};b.vel={x:0,y:kind==='hold'?0:1.5};b.facing=Math.PI;delete b.support;const world=new World([b]);let aim=.3;const ticks=[];
 for(let k=0;k<100;k++){
  const t=k*.05,flow=kind==='hold'?0:kind==='reverse'&&t>=1.5?-1.5:1.5;
  if(k)aim+=flow*.05;
  const capacity=availability(b.support!,supportParams(b.profile),fatigueFactor(b.energy));
  const requested=law==='deadline'?Math.max(-td.lateral,Math.min(td.lateral,requestToCover(gaitLag(b.profile),aim+flow*2*d.mind.decisionInterval-b.pos.y,2*d.mind.decisionInterval,b.vel.y))):movingArrivalVelocity(b,{x:b.pos.x,y:aim},{x:0,y:flow},td.lateral,0,0,.8+.4*td.bend,capacity).y;
  const before={pos:{...b.pos},vel:{...b.vel}},r=world.step([{vel:{x:0,y:requested},facing:Math.PI,cutSkill:.8+.4*td.bend}],.05);
  ticks.push({t,aim,flow,requested,before,after:{pos:{...b.pos},vel:{...b.vel}},residual:r.work.residual});
 }
 rows.push({kind,law,ticks});
}
writeFileSync(process.argv[2]??'out/run-rep-arrival/law-probe.json',JSON.stringify({source:sourceVersion(),profile:d.profile,lateralCap:td.lateral,horizon:2*d.mind.decisionInterval,rows}));
for(const r of rows){const tail=r.ticks.filter(t=>t.t>2.5);console.log(JSON.stringify({kind:r.kind,law:r.law,lastError:tail.at(-1)!.aim-tail.at(-1)!.after.pos.y,requestFlips:tail.slice(1).filter((t,k)=>t.requested*tail[k].requested<0&&Math.min(Math.abs(t.requested),Math.abs(tail[k].requested))>.5).length,maxError:Math.max(...tail.map(t=>Math.abs(t.aim-t.after.pos.y))),lastVelocity:tail.at(-1)!.after.vel.y}));}
