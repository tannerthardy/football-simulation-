import gzip,json,math
from pathlib import Path

roots={
 'accepted':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response'),
 'yaw':Path('/workspace/football-movement-continuity/out/movement-continuity/pilot'),
 'gait':Path('/workspace/football-gait-achieved-pose/out/gait-achieved-pose/native'),
 'both':Path('/workspace/football-movement-physics-interaction/out/physics-interaction/native')}
def read(case,arm):
 root=roots[arm]
 if arm=='accepted':root=root/('baseline' if case=='TOSS' else 'fresh-baseline')
 return json.load(gzip.open(root/(case+'.json.gz'),'rt'))
def delta(a,b,key):
 return math.hypot(a[key]['x']-b[key]['x'],a[key]['y']-b[key]['y'])
def cmd_diff(a,b):
 if a is None or b is None:return a!=b
 if delta(a,b,'vel')>1e-6:return True
 return abs(a.get('facing',0)-b.get('facing',0))>1e-6
out={}
for case in ['TOSS','PASS13']:
 a=read(case,'accepted');rows={}
 slots={x['idx']:{'idx':x['idx'],'slot':x['slot'],'id':x['player']['id']} for x in a['initial']}
 for arm in ['yaw','gait','both']:
  b=read(case,arm);result={
   'sameInput':a['inputSha256']==b['inputSha256'],
   'sameCommonInitialFields':all(all(u[k]==v[k] for k in u.keys()&v.keys()) for u,v in zip(a['initial'],b['initial'])),
   'omittedInitialMetadata':sorted(set().union(*(u.keys()-v.keys() for u,v in zip(a['initial'],b['initial'])))),
   'sameInitialBodies':a['ticks'][0]['before']==b['ticks'][0]['before'],
   'source':b['source'],'elapsedSeconds':b['elapsedSeconds'],
   'outcome':b['outcome'],'gain':b['gain'],'end':b['ticks'][-1]['completed'],
   'events':[e for e in b['events'] if e['type'] in ['throw','catch','missed_tackle','carrier_contact','tackle_wrap','tackle']]}
  for x,y in zip(a['ticks'],b['ticks']):
   assert abs(x['t']-y['t'])<1e-9
   if 'rng' not in result and x['rng']!=y['rng']:
    result['rng']={'t':x['t'],'accepted':json.loads(x['rng']),'candidate':json.loads(y['rng'])}
   for key in ['requests','intents']:
    if key in result:continue
    for i,(u,v) in enumerate(zip(x[key],y[key])):
     if cmd_diff(u,v):
      result[key]={'t':x['t'],'actor':slots[i],'accepted':u,'candidate':v};break
   for key in ['pos','vel','facing']:
    if key in result:continue
    for i,(u,v) in enumerate(zip(x['after'],y['after'])):
     size=delta(u,v,key) if key!='facing' else abs(u[key]-v[key])
     if size>1e-6:
      result[key]={'t':x['t'],'completed':x['completed'],'actor':slots[i],
        'delta':size,'sameOwnRequest':x['requests'][i]==y['requests'][i],
        'sameOwnIntent':x['intents'][i]==y['intents'][i],
        'sameRng':x['rng']==y['rng'],'accepted':u[key],'candidate':v[key],
        'ownRequest':y['requests'][i],'ownIntent':y['intents'][i]};break
  rows[arm]=result
 out[case]=rows
Path('out/gait-achieved-pose/native-review.json').write_text(json.dumps(out,indent=2)+'\n')
for case,rows in out.items():
 print(case)
 for arm,r in rows.items():
  print(arm,json.dumps({k:v for k,v in r.items() if k not in ['events','rng']}))
  print('rngFirst',r.get('rng',{}).get('t'))
