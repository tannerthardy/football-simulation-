Requesting a turn currently lets `World.plan` and `stepBody` compute acceleration using a future facing that the body has not achieved. This grants forward gait before the finite yaw motor earns the turn. Compute gait from the attained pose while preserving the existing yaw request, motor, contact laws and physical capacities.

**Draft: Physics-owner review is required before integration.** This is independent of #162; the standalone candidate retains the accepted yaw motor. The yaw-plus-gait composition is diagnostic evidence only and is not a production candidate.

## Scope and pins

- Accepted base: `f4146275ce7539816bf57b4ed55a0d2be10e48c7`; canonical queue inspected at `9a6bb795179a4b2e61ed59d25bcf23ca5e40f423`.
- Runtime correction: `36a77d17444658675f886c3914572faa181bd5a4`; native review documentation: `1a9972ff47f2495ac774b8d8eaabe7c6352703a3`.
- Tested runtime SHA256: `ee292a6a4396e81a50112f62cf344c759f62402cb9e3eb0bae8a257d00a5c2d1`.
- Only runtime edits remove the temporary future-facing swaps in `World.plan` and `stepBody`. Controllers, acquired information, contact geometry, capacities, speed/braking, hands and release rules are unchanged.
- Baseline launcher pins all 44 flags, including `RUN_CONTACT_COMPONENTS=1`, `GAIT_STEP=0` and unset `CF_FLOW`; no flag/default activation.

## Evidence for and against

A standard sideways start requesting a 90° turn reaches 0.2596 yd/s in the first 0.05 s on accepted source, while the attained-pose sprint law allows 0.1904 yd/s. The correction achieves 0.1904 in both `World` and `stepBody`, with finite yaw still executing immediately. Forward sprint/rest and a traction-saturated zero-yaw control hold. The new mechanical contracts fail 3/5 on unchanged accepted source and pass 5/5 on the candidate.

Two exact frozen native inputs use the same initial physical bodies and input hashes as saved accepted baselines. Their first physical differences occur with identical requests, final intents and shared RNG; different requests and draws follow. Later contacts are not matched-execution grip experiments.

- **Adverse TOSS:** gain 3.84→4.49 yd; first wrap 3.60→3.70 s and completed tackle 4.20→4.40 s. The earlier DE miss/body contact remains. Keep the extra 0.65 yd and later wrap visible.
- **PASS13:** same actual Y catches at 3.80 s; both plays finish by tackle, 22.74→19.11 yd. Lower gain is not a realism acceptance condition.
- **Smoothness limit:** gait alone does not repair yaw rocking or globally improve paths. In 517 windows valid/clear in all four native arms, gait-only body-facing reversal is 1.270° versus accepted 1.202°; travel-heading reversal is 0.229° versus 0.210°. The diagnostic yaw+gait arm reduces facing reversal to 0.082° but path reversal rises to 0.245°.
- **Composition limit:** TOSS's first runner contact is delayed to 4.80 s despite lower final gain. Composed PASS13 has a catch and later wraps but remains live at the six-second recording budget; no completed outcome is claimed.

## Validation and next decision

49 focused TypeScript checks and typecheck pass on the exact runtime above. Original accepted failures and all 44 resolved settings remain in the receipts. Focused launcher: 2.147 s; typecheck: 11.451 s. The two standalone native prefixes cost 2.046 s; accepted/yaw traces and the existing NFL reference are reused. No new NFL query, downloads, games or full-suite repeat.

Physics should review the discrete attained-start-pose gait convention and finite movement constraints independently from #162's yaw motor. Integration owns exact combined verification. Request/controller path jitter remains open.

Report: `docs/reviews/gait-achieved-pose-2026-10-19.md`.

Immutable evidence: EVIDENCE_PIN_PENDING.
