import gzip, hashlib, json
from pathlib import Path

cases = [
 ("IZ", Path("/workspace/football-linebacker-run-flow/out/run-flow/enriched/IZ.json.gz"), {"LB_W": [2,2.05,2.15,2.2], "LB_M": [2.15,2.25,2.3,2.35]}),
 ("COUNTER2", Path("/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/COUNTER2.json.gz"), {"LB_W": [.9,.95,1.05,1.1]}),
 ("OZ24", Path("/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/OZ24.json.gz"), {"LB_W": [1.85,1.9,1.95,2.2]}),
 ("TOSS", Path("/workspace/football-linebacker-run-flow/out/run-flow/enriched/TOSS.json.gz"), {"LB_M": [1.5,1.6,1.65,1.8,2,2.2,2.4]})]
rows = []
for label, path, selected in cases:
 raw = path.read_bytes(); tape = json.loads(gzip.decompress(raw))
 identity = {p['slot']: p for p in tape['initial']}
 for slot, times in selected.items():
  player = identity[slot]; idx = player['idx']
  for t in times:
   tick = next(tick for tick in tape['ticks'] if abs(tick['t']-t)<1e-6)
   cues = [c for c in tape['cues'] if c['a']==idx and c['b']==next(p['idx'] for p in tape['initial'] if p['slot']=='RB') and abs(c['t']-t)<1e-6]
   rows.append(dict(case=label,inputSha256=tape['inputSha256'],tapeSource=tape['source'],tapePath=str(path),tapeSha256=hashlib.sha256(raw).hexdigest(),
    idx=idx,slot=slot,playerId=player['player']['id'],t=t,installedRunFit=player['runFit'],
    before={k:tick['before'][idx][k] for k in ['pos','vel','facing']},
    rawRequest=tick['requests'][idx],finalIntent=tick['intents'][idx],
    achieved={k:tick['after'][idx][k] for k in ['pos','vel','facing']},
    aims=[a for a in tape['aims'] if a['a']==idx and abs(a['t']-t)<1e-6],
    firstConsumedRB=cues[0] if cues else None,
    engaged=[r for r in tick['reps'] if idx in [r['b'],r['d']]],
    contacts=[c for c in tick['contacts'] if idx in [c['i'],c['j']]]))
Path('out/free-fit-continuity/accepted-witnesses.json').write_text(json.dumps(rows,indent=2)+'\n')
print(f'{len(rows)} selected native observations; no simulator calls')
