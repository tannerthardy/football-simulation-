import ast, gzip, hashlib, json, math
from pathlib import Path
from collections import defaultdict

reference=Path('out/free-fit-continuity/smooth-reference.py')
parsed=ast.parse(reference.read_text())
function=next(n for n in parsed.body if isinstance(n,ast.FunctionDef) and n.name=='measure')
namespace={'math':math}
exec(compile(ast.Module(body=[function],type_ignores=[]),str(reference),'exec'),namespace)
measure=namespace['measure']

pairs=[('IZ','/workspace/football-linebacker-run-flow/out/run-flow/enriched/IZ.json.gz'),('OZ24','/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/OZ24.json.gz')]
results=[]
for name,baseline in pairs:
 for arm,path in [('baseline',baseline),('candidate','out/fit-continuity/native/'+name+'.json.gz')]:
  tape=json.load(gzip.open(path,'rt')); ticks=tape['ticks'][:64]
  # Exact common-time grid, with only position measurements quantized like NFL.
  xy=[[round(c,2) for p in tape['initial'] for c in (p['pos']['x'],p['pos']['y'])]]
  xy += [[round(c,2) for b in tick['after'] for c in (b['pos']['x'],b['pos']['y'])] for tick in ticks if abs(tick['completed']/.1-round(tick['completed']/.1))<1e-7]
  assert len(xy)==33
  by_group=defaultdict(lambda:dict(sec=0.,pulses=0,wobble=0,lat=0,secc=0.,pc=0,wc=0,raw_wobble=0,raw_lat=0,raw_wc=0,raw_sec=0.,raw_secc=0.))
  for p in tape['initial']:
   i=p['idx']
   if i<11:continue
   group='LB' if p['slot'].startswith('LB') else 'S' if p['slot'] in ['FS','SS'] else 'CB' if p['slot'].startswith('CB') else 'DL'
   row=by_group[group];m=measure(xy,i,0,32,.1,list(range(11)))
   for k in ['sec','pulses','wobble','lat','secc','pc','wc']:row[k]+=m[k]
   # Same directional thresholds as smooth.py applied directly to raw own
   # behavior velocity requests. These are NOT NFL-position measurements.
   selected=[tick for tick in ticks if abs(tick['t']/.1-round(tick['t']/.1))<1e-7]
   vec=[t['requests'][i]['vel'] for t in selected]
   near=[any(math.hypot(t['before'][i]['pos']['x']-t['before'][j]['pos']['x'],t['before'][i]['pos']['y']-t['before'][j]['pos']['y'])<1.2 for j in range(11)) for t in selected]
   lastsign=0;latlast=0
   for k,(a,b) in enumerate(zip(vec,vec[1:])):
    sa=math.hypot(a['x'],a['y']);sb=math.hypot(b['x'],b['y'])
    if sa<2 or sb<2:continue
    d=math.degrees(math.atan2(a['x']*b['y']-a['y']*b['x'],a['x']*b['x']+a['y']*b['y']))
    sg=(d>5)-(d< -5)
    if sg and lastsign and sg!=lastsign:row['raw_wobble']+=1;row['raw_wc']+=near[k+1]
    if sg:lastsign=sg
   for v in vec:
    sg=(v['y']>.5)-(v['y']< -.5)
    if sg and latlast and sg!=latlast:row['raw_lat']+=1
    if sg:latlast=sg
   row['raw_sec']+=len(vec)*.1;row['raw_secc']+=sum(near)*.1
  for group,row in sorted(by_group.items()):
   row['free_sec']=row['sec']-row['secc'];row['raw_free_sec']=row['raw_sec']-row['raw_secc'];row['free_wobble']=row['wobble']-row['wc'];row['raw_free_wobble']=row['raw_wobble']-row['raw_wc']
   results.append(dict(case=name,arm=arm,group=group,**row))
out=dict(operator='Claude smooth.py unchanged measure() for10Hz/.01yd native positions; identical turning/lat threshold kernels on10Hz raw request velocities; requests are not NFL metrics',operatorSha256=hashlib.sha256(reference.read_bytes()).hexdigest(),horizon=3.2,phase='Both candidate prefixes live/censored; original OZ24 longer tape has terminal outcome not compared here',rows=results)
Path('out/free-fit-continuity/smooth-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
for row in results:
 print(row['case'],row['arm'],row['group'],'body wob/lat',row['wobble'],row['lat'],'bodyfree wob/sec',row['free_wobble'],round(row['free_sec'],2),'raw wob/lat',row['raw_wobble'],row['raw_lat'],'rawfree wob/sec',row['raw_free_wobble'],round(row['raw_free_sec'],2))
