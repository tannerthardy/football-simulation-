"""Read saved exact native prefixes; no simulation, sensing or random draws."""
import gzip,json,math,hashlib
from pathlib import Path
ROOT=Path('/workspace/football-continuous-track-objective')
BASE={'OZ24':Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline/OZ24.json.gz'),'PASS13':Path('/workspace/football-defensive-snap-response/out/defensive-snap-response/fresh-baseline/PASS13.json.gz')}
def load(p):return json.load(gzip.open(p,'rt'))
def at(r,t):return next(x for x in r['ticks'] if abs(x['t']-t)<1e-8)
def norm(v):return math.hypot(v['x'],v['y'])
def delta(a,b):return math.hypot(a['x']-b['x'],a['y']-b['y'])
def initialslot(r,s):return next(a['idx'] for a in r['initial'] if a['slot']==s)
def rec(r,t,s):return at(r,t)['before'][initialslot(r,s)]
def contacts(r,s):
 i=initialslot(r,s);return [{'t':z['t'],**v}for z in r['ticks'] if z['t']<3.2 for v in z['contacts'] if i in [v['i'],v['j']]]
def request_reversal(r,s,start,end):
 i=initialslot(r,s);ts=[z for z in r['ticks'] if start<=z['t']<=end]
 headings=[math.atan2(z['requests'][i]['vel']['y'],z['requests'][i]['vel']['x']) for z in ts]
 turn=[math.atan2(math.sin(q-p),math.cos(q-p)) for p,q in zip(headings,headings[1:])]
 reversal=[min(abs(p),abs(q))*180/math.pi for p,q in zip(turn,turn[1:]) if p*q<0]
 return {'samples':len(headings),'maxRequestStep':max(delta(p['requests'][i]['vel'],q['requests'][i]['vel']) for p,q in zip(ts,ts[1:])),'maxHeadingStepDeg':max(abs(x)*180/math.pi for x in turn),'alternatingCorrections':reversal,'sumAlternatingCorrectionDeg':sum(reversal)}
rows={}
for case,bp in BASE.items():
 cp=ROOT/'out/track-continuity/native'/f'{case}.json.gz';b,c=load(bp),load(cp)
 assert b['setup']==c['setup'];assert b['inputSha256']==c['inputSha256'];assert all(x['rng']==y['rng'] for x,y in zip(b['ticks'],c['ticks']))
 first={}
 for key in ['requests','intents','after']:
  first[key]={}
  for threshold in [1e-10,.01,.1]:
   for bt,ct in zip(b['ticks'],c['ticks']):
    chosen=next(({'t':ct['t'],'slot':c['initial'][i]['slot'],'delta':delta(bv['vel'],cv['vel'])} for i,(bv,cv) in enumerate(zip(bt[key],ct[key]))if bv is not None and cv is not None and delta(bv['vel'],cv['vel'])>threshold),None)
    if chosen:first[key][str(threshold)]=chosen;break
 rows[case]={'baselineFile':str(bp),'candidateFile':str(cp),'fileSha256':{'baseline':hashlib.sha256(bp.read_bytes()).hexdigest(),'candidate':hashlib.sha256(cp.read_bytes()).hexdigest()},'source':{'baseline':b['source'],'candidate':c['source']},'inputSha256':b['inputSha256'],'candidatePhase':c['phase'],'candidateOutcome':c['outcome'],'prefixEnd':c['ticks'][-1]['completed'],'sameInput':True,'sameRngStates':True,'firstDivergence':first,'contacts':{s:{'baseline':contacts(b,s),'candidate':contacts(c,s)} for s in ['FS','SS','LB_W','LB_S']}}
 if case=='OZ24':
  rows[case]['freeAlleyWindow']={arm:request_reversal(r,'FS',1.3,1.65) for arm,r in [('baseline',b),('candidate',c)]}
  rows[case]['alleySamples']=[]
  for t in [.4,1,1.5,1.9,2.5,3.15]:
   bb,cb=rec(b,t,'FS'),rec(c,t,'FS');q=at(c,t)['requestObjectives'][20]
   rows[case]['alleySamples'].append({'t':t,'baseline':{k:bb[k] for k in ['pos','vel']},'candidate':{k:cb[k] for k in ['pos','vel']},'candidateGoal':q,'positionDelta':delta(bb['pos'],cb['pos'])})
 else:
  rows[case]['coverageSamples']=[]
  for t in [1,1.5,2,2.5,2.8,3.15]:
   samples={'t':t}
   for ds,rs in [('LB_W','H'),('FS','H'),('CB_S','Z'),('CB_W','X')]:
    vals={}
    for arm,r in [('baseline',b),('candidate',c)]:
     d,rr=rec(r,t,ds),rec(r,t,rs)
     vals[arm]={'defenderPos':d['pos'],'defenderVel':d['vel'],'receiverPos':rr['pos'],'depthLeverage':d['pos']['x']-rr['pos']['x'],'lateralOffset':d['pos']['y']-rr['pos']['y'],'separation':delta(d['pos'],rr['pos'])}
    samples[ds+'-'+rs]=vals
   rows[case]['coverageSamples'].append(samples)
  rows[case]['sameThrow']={arm:[e for e in r['events'] if e['type']=='throw'] for arm,r in [('baseline',b),('candidate',c)]}
  rows[case]['outsideCornersIdentical']=all(bt['before'][i]==ct['before'][i] and bt['requests'][i]==ct['requests'][i] for bt,ct in zip(b['ticks'],c['ticks']) for i in [18,19])
  rows[case]['offensiveBodiesIdentical']=all(bt['before'][i]==ct['before'][i] for bt,ct in zip(b['ticks'],c['ticks'])for i in range(11))
(ROOT/'out/track-continuity/analysis.json').write_text(json.dumps({'qualification':'Same frozen inputs, 64 matched 20Hz ticks each. Both candidate prefixes live at3.2s, no completed outcome claim. Accepted baseline7d235.. versus first globallead extraction4e78... This is not #162 motor composition. No new native or NFL query by analysis. All paired World-boundary RNG states identical. Exact full44 flags in native-launch.json.','cases':rows},indent=2))
for case,r in rows.items():print(case,r.get('freeAlleyWindow',{}),r.get('sameThrow',{}),'corners identical',r.get('outsideCornersIdentical'))
