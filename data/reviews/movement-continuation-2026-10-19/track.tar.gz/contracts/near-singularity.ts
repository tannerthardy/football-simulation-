import {readFileSync,writeFileSync} from 'node:fs';
import {track as candidate} from '../../src/sim/behaviors/common.ts';
import {track as accepted} from '/workspace/football-linebacker-run-flow/out/run-flow/accepted-host/src/sim/behaviors/common.ts';
import {sourceVersion} from '../../scripts/source-version.ts';
const cwd=process.cwd(),candidateSource=sourceVersion();process.chdir('/workspace/football-linebacker-run-flow/out/run-flow/accepted-host');const acceptedSource=sourceVersion();process.chdir(cwd);
const actor={pos:{x:0,y:20},profile:{vmax:9,brake:6}},motion={x:-9,y:0},options={speed:.65,gain:2};
const rows=[2.5,2.599,2.59999999,2.6,2.60000001,2.601,2.7].map(d=>({distance:d,accepted:accepted(actor as any,{x:d,y:20},motion,options).vel,candidate:candidate(actor as any,{x:d,y:20},motion,options).vel}));
const result={acceptedSource,candidateSource,question:'Does extending distant pursuit lead into near stationkeeping create another discontinuity when the lead point passes through our own body?',inputs:{actor,motion,options},rows,conclusion:'Rejected. A fast acquired approaching receiver is legitimate. The proposed normalized future-bearing crosses the own COM at2.6yd; infinitesimal picture changes create another finite request jump, while accepted near stationkeeping is continuous. No third variant or native run.'};
writeFileSync('out/continuous-track/near-singularity.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
