"""Reduce saved tapes and receipts only; never starts the simulator.

Restore the old baseline archive at --baseline and this packet at --root.
"""
import argparse, gzip, hashlib, json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, default=Path('out/man-run-continuity'))
p.add_argument('--baseline', type=Path, default=Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff'))
p.add_argument('--fresh-baseline', type=Path, default=Path('/tmp/football-db-stalk-baseline/out/man-run-continuity/fresh-baseline'))
args = p.parse_args()
H = lambda raw: hashlib.sha256(raw).hexdigest()
def read(path):
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw)), H(raw)

final_source = '925eb44e637929e5031553c7a3d44dd8c20aa26d05c31a799929faef1b1a740b'
base_source = '4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571'
cases, fields = [], ['before','requests','intents','after','repBefore','reps','contacts','rng','ball']
for name in ['WZ7','OZ4','WZORD','F_OZ','F_COUNTER','PA13','F_Q_OZ']:
    bp = args.fresh_baseline / (name+'.json.gz') if name == 'F_Q_OZ' else args.baseline / ('baseline' if name in ['WZ7','OZ4','WZORD'] else 'transfer-baseline') / (name+'.json.gz')
    cp = args.root / ('reader-tail' if name in ['PA13','F_Q_OZ'] else 'reader-candidate') / (name+'.json.gz')
    b, bh = read(bp); c, ch = read(cp)
    assert b['source'] == base_source and c['source'] == final_source
    assert b['inputSha256'] == c['inputSha256'] and b['setup'] == c['setup']
    assert b['phase'] != 'live' and c['phase'] != 'live'
    first = {}
    for field in fields:
        first[field] = next(({'tick':x['t'],'achievedAt':x['completed']} for x,y in zip(b['ticks'],c['ticks']) if x[field] != y[field]), None)
        if first[field] is None and len(b['ticks']) != len(c['ticks']):
            first[field] = {'differentLength': [len(b['ticks']),len(c['ticks'])]}
    cases.append({'case':name,'inputSha256':b['inputSha256'],'baseline':{'path':str(bp),'sha256':bh,'source':b['source'],'gain':b['gain'],'outcome':b['outcome'],'terminal':True},
        'candidate':{'path':str(cp),'sha256':ch,'source':c['source'],'gain':c['gain'],'outcome':c['outcome'],'terminal':True},
        'firstCommonFieldDifferences':first,'allListedCommonFieldsIdentical':all(v is None for v in first.values()),
        'candidateCaseSeconds':c['elapsedSeconds'],'seed':c['setup']['seed'],'call':c['setup']['offCall']['label'],'defense':c['setup']['defCall']['label']})

receipts=[]
for path in sorted(args.root.glob('*.json')):
    r=json.loads(path.read_bytes())
    if 'commands' not in r: continue
    receipts.append({'path':str(path),'sha256':H(path.read_bytes()),'commit':r['commit'],'source':r['sourceSha256'],'exitCode':r['exitCode'],
        'inputsUnchanged':r['inputsUnchanged'],'commandSeconds':sum(x['elapsedSeconds'] for x in r['commands']),
        'native':any('capture.mjs' in str(x['command']) or 'capture-rules.mjs' in str(x['command']) for x in r['commands'])})
fresh = args.fresh_baseline.parent/'fresh-baseline-launch.json'
r=json.loads(fresh.read_bytes())
receipts.append({'path':str(fresh),'sha256':H(fresh.read_bytes()),'commit':r['commit'],'source':r['sourceSha256'],'exitCode':r['exitCode'],'inputsUnchanged':r['inputsUnchanged'],
    'commandSeconds':sum(x['elapsedSeconds'] for x in r['commands']),'native':True})
result={'inspectionOnly':True,'newSimulations':0,'cases':cases,'receipts':receipts,
    'cost':{'commandSeconds':sum(r['commandSeconds'] for r in receipts),'nativeCommandSeconds':sum(r['commandSeconds'] for r in receipts if r['native']),
        'focusedAndTypecheckCommandSeconds':sum(r['commandSeconds'] for r in receipts if not r['native']),
        'attemptedNativeCases':22,'savedTerminalCases':21,'reusedBaselineCases':6,'finalUniqueTerminalCases':7,
        'qualification':'Includes all developmental receipts and one failed aggregate recording attempt. Original PA attempt lacks a saved tape; tail retry completes the final seven-case evidence, without relabeling the failed batch as passing.'},
    'completion':{'firstFive':'reader-candidate: five terminal files survive failed aggregate reader-native-launch.json; no aggregate success claimed',
        'tail':'reader-tail: PA13 and F_Q_OZ completed under passing reader-tail-launch.json',
        'collector':'The first batch copied most evidence but retained cached coverage references, causing circular JSON on PA13. Corrected collector snapshots cached metadata; no new sensing, RNG or controller updates.'}}
(args.root/'completion-ledger.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':[(r['case'],r['baseline']['gain'],r['candidate']['gain'],r['allListedCommonFieldsIdentical']) for r in cases],'cost':result['cost']},indent=2))
