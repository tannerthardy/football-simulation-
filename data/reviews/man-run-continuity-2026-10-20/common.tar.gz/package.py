"""Package existing evidence and verify archive readback; zero simulations."""
from pathlib import Path
import gzip, hashlib, io, json, shutil, subprocess, tarfile

root=Path('out/man-run-continuity')
dest=Path('/tmp/football-man-run-evidence/data/reviews/man-run-continuity-2026-10-20')
dest.mkdir(parents=True,exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest()
base='2c98bed94adad8087c65f381d4090444ad283985'
code='11ef1703a59b1ab13bbebf2eeb51ed7a8eba8e05'
tests='0dca4f09ec876a65949242221ad712f493ec51bf'
files=['src/sim/behaviors/defense.ts','src/sim/coverage-cues.ts','src/sim/coverage/reads.ts','src/sim/run-fits.ts']
git=lambda *args:subprocess.check_output(['git',*args])
(root/'runtime.patch').write_bytes(git('diff','--binary',base,code,'--',*files))
(root/'contracts.patch').write_bytes(git('diff','--binary',base,tests,'--','test/man-run-continuity.test.ts'))
paths=git('ls-tree','-r','--name-only',base,'src').decode().splitlines()
def source(ref,overrides=False):
    h=hashlib.sha256()
    for path in paths:
        raw=git('show',f'{code if overrides and path in files else ref}:{path}')
        h.update(path.encode()+b'\0'+raw+b'\0')
    return h.hexdigest()
proof={'base':base,'runtime':code,'tests':tests,'files':files,'baselineSource':source(base),
       'candidateSource':source(code),'fourFileProjectionSource':source(base,True),
       'runtimePatchSha256':H((root/'runtime.patch').read_bytes()),'contractsPatchSha256':H((root/'contracts.patch').read_bytes()),
       'qualification':'Pure git-object reconstruction: only these four source files differ; no simulator/check execution.'}
assert proof['baselineSource']=='4273994fa50f0f11a54bff53b374ad87d80766be471ca727ce43f76fdef83571'
assert proof['candidateSource']==proof['fourFileProjectionSource']=='925eb44e637929e5031553c7a3d44dd8c20aa26d05c31a799929faef1b1a740b'
(root/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
fresh=Path('/tmp/football-db-stalk-baseline/out/man-run-continuity')
groups={
    'final-native.tar.gz':[(p,str(p.relative_to(root))) for folder in ['reader-candidate','reader-tail'] for p in sorted((root/folder).glob('*'))],
    'developmental-native.tar.gz':[(p,str(p.relative_to(root))) for folder in ['candidate','final-candidate','guarded-candidate','fresh-candidate'] for p in sorted((root/folder).glob('*'))],
    'fresh-baseline.tar.gz':[(p,str(p.relative_to(fresh))) for p in sorted((fresh/'fresh-baseline').glob('*'))]+[(fresh/'fresh-baseline-launch.json','fresh-baseline-launch.json')],
    'common.tar.gz':[(p,str(p.relative_to(root))) for p in sorted(root.iterdir()) if p.is_file()]+[(p,str(p.relative_to(root))) for p in sorted((root/'claude-evidence').glob('*')) if p.is_file()],
}
archives=[]
for name,members in groups.items():
    target=dest/name
    with target.open('wb') as raw:
        with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode='w') as tar:
                for path,arc in members:
                    info=tar.gettarinfo(str(path),arcname=arc)
                    info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
                    tar.addfile(info,io.BytesIO(path.read_bytes()))
    inventory=[]
    with tarfile.open(target) as tar:
        assert len(tar.getmembers())==len(members)
        for (path,arc),member in zip(members,tar.getmembers()):
            data=tar.extractfile(member).read();assert member.name==arc and data==path.read_bytes()
            inventory.append({'path':arc,'bytes':len(data),'sha256':H(data)})
    archives.append({'path':name,'bytes':target.stat().st_size,'sha256':H(target.read_bytes()),'members':inventory})
ledger=json.loads((root/'completion-ledger.json').read_text())
manifest={'acceptedDevelop':base,'queue':'4cc3337df24faa6d857b612ae62e3df3109a5296','claudeResearch':'bae3fe80d189a7d792aaafbc4eea1ae2baa79573',
          'runtime':code,'tests':tests,'baselineSource':proof['baselineSource'],'candidateSource':proof['candidateSource'],
          'reusedBaselineEvidence':{'commit':'32977c642075c94f1b4ea7f1f6bb5aacc6161385','path':'data/reviews/db-stalk-workoff-2026-10-20','manifestSha256':'53f30c6429a29e75bb0957ddca10d3808922a044e7feca77551694bb35d94a3b'},
          'flags':'All44 unchanged, RUN_CONTACT_COMPONENTS1, GAIT_STEP0, CF_FLOWunset; full resolved flags and physical defaults in every launcher receipt.',
          'cost':ledger['cost'],'focused':'129 distinct final-source checks and typecheck pass; earlier failures preserved, no full suite/games/NFL query.',
          'finalCases':ledger['cases'],'archives':archives}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
image=root/'claude-evidence/purpose-continuity.png'
if image.exists():shutil.copy2(image,dest/image.name)
print(json.dumps({'destination':str(dest),'manifestSha256':H((dest/'manifest.json').read_bytes()),'archives':[{k:v for k,v in a.items() if k!='members'}for a in archives],'proof':proof},indent=2))
