# Football intelligence: keep the purpose, reconsider the evidence and means

Read-only source audit; this note adds no implementation, test or simulation.
Accepted reference is `2c98bed94adad8087c65f381d4090444ad283985` (queue
`4cc3337df24faa6d857b612ae62e3df3109a5296`). Current Man/reader code was inspected
at `0dca4f09ec876a65949242221ad712f493ec51bf`; its last runtime addition is
`11ef1703a59b1ab13bbebf2eeb51ed7a8eba8e05`. Claude comparison is
`bae3fe80d189a7d792aaafbc4eea1ae2baa79573`, not accepted runtime.

The useful generalization is **evidence-backed continuity of responsibility**.
A player can know his installed duty, accept a developing interpretation from
acquired evidence, and pursue it while changing his technique. Contact, a
moving landmark or a temporary loss of a cue does not automatically constitute
a new football assignment. Conversely, an accepted decision must not survive
contradictory acquired evidence merely because persistence improved an ending.

## What the Man/reader correction establishes

`coverage-cues.ts` keeps shallow blocking admission in `showsBlock` while
factoring current acquired pads/contact evidence into `observedBlocking`
(`src/sim/coverage-cues.ts:6–30`). An accepted blocker crossing LOS+2 therefore
need not become a vertical threat solely because he crossed the admission
boundary. This does not classify a previously unaccepted deep route as a block.

`ManCoverage.coverMan` distinguishes the admitted support episode from its
continuing evidence (`behaviors/defense.ts:240–301`). Continuation still requires
current run belief and acquired blocking evidence. An upright release can
restore coverage while the receiver remains in front of the defender. Existing
ball recognition retains priority; unrecognized flight invokes the coverage
continuation, whereas recognized flight retires it (`defense.ts:223–235`). No
new private `throwAt` deadline or fixed persistence timer supplies that decision.

The explicit installed-backfield input matters as much as retaining the duty.
`blockingSupport` passes consumed back/QB pictures into the existing fit;
`executeRunFit` interprets those pictures and the installed expectation rather
than switching on the hidden live holder (`run-fits.ts:189–219`). A personally
acquired empty-back/carrying-QB contradiction can retire the mesh expectation.
The extension is bounded to an explicitly installed RB backfield input;
empty/split-back formations retain their pre-existing shallow policy. This is
not a claim that all engine possession, gaze or teammate information is repaired.

The owning release reader uses the deeper current blocking evidence only for
an already accepted block under run belief (`coverage/reads.ts:99–104`). Real
competing releases retain ordinary confirmation (`reads.ts:105–125`); its
pre-existing memory through ambiguous `none` pictures is not removed here.
This addresses a second ownership boundary: a Man instance alone cannot prevent
the match reader from falsely replacing its subcontroller. Installed `a.runFit`
and the existing `CoverageDefender` remain the support architecture; no global
play-phase or intention manager is introduced.

## Three analogous questions for later owners

1. **Contact setup versus already selected support.** Accepted
   `engagement.ts` starts a fresh move wait for each new contact and later
   replaces behavior movement with contact technique. Independent pending
   [#169](https://github.com/tannerthardy/football-simulation-/pull/169), code
   `e83b735fef5c947850f9b941722d13feee263b92`, removes one redundant initial wait
   after the acquired support contract qualifies. Its evidence also shows that
   earlier work-off does not guarantee useful arrival. Future question: does
   the held escape side still serve the acquired runner path? Preserve useful
   away-from-blocker escapes, earned sustained blocks and real physical limits.

2. **Pull admission versus continued fit/handoff.** Accepted
   `run-fits.ts` uses `PULL_REACH=6` as a fresh projected-target condition.
   Prior [#166](https://github.com/tannerthardy/football-simulation-/pull/166)
   report `0c6401e777871fedf676d4ac936a1effacad337e` records a continuing acquired
   pull losing its adjustment at that boundary. Literal clamping failed remote,
   cutback and declared-runner controls. Future question: when should this
   installed responsibility continue, hand off or yield to a runner override?
   This note proposes no fit change.

3. **Movement modification versus purpose.** Accepted `track` attaches an
   own objective, while `runThrough` emits velocity without it
   (`behaviors/common.ts:31–36,73–74`); contact and spacing then refine requests
   (`playsim.ts:569–597`). Prior #166 experiments remain held: a raw-forward-
   progress guard rejected a fresh player's better sideways arrival with more
   clearance. Future question: can the modifier preserve and assess the actual
   fixed/moving/interception objective? Neither higher speed nor greater
   persistence along the original velocity is a general answer.

The existing `Recognition` hysteresis (`recognition.ts:223–240`), held
`SnapMind.aim` (`mind.ts:72–78`) and coupled contact aim/mode/flow
(`engagement.ts:903–917` on accepted source) already provide local building
blocks. Lower awareness can produce late reads, stable mistakes and delayed
corrections. The engine need not manufacture indecision by repeatedly erasing a
supported job. These examples motivate owner-specific contracts and opposing
controls, not a universal commitment knob or permission for every defender to
abandon leverage and chase.
