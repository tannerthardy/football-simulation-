"""Read immutable saved controller captures/Claude receipts; simulate nothing."""
from pathlib import Path
import gzip,json,hashlib,subprocess,math
root=Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff')
out=Path('out/man-run-continuity/claude-evidence')
H=lambda b:hashlib.sha256(b).hexdigest()
records=[]
for case,slot,start,end in [('WZ7','CB_S',1.15,1.85),('WZ7','CB_W',1.20,1.80),('OZ4','CB_S',1.20,1.85),('OZ4','CB_W',1.20,1.85)]:
 path=root/'baseline'/(case+'.json.gz');raw=path.read_bytes();a=json.loads(gzip.decompress(raw));by={v['slot']:v for v in a['initial']};actor=by[slot];di=actor['idx'];receiver=by['Z'if slot=='CB_S'else'X'];ri=receiver['idx'];rb=by['RB']['idx'];qb=by['QB']['idx'];ticks={t['t']:t for t in a['ticks']};calls=[c for c in a['calls']if c['a']==di];rows=[]
 for tm in [.65,start,round(end-.05,2),end]:
  c=next(c for c in calls if c['t']==tm);t=ticks[tm];seen=[p for p in a['cues'][c['cues'][0]:c['cues'][1]]if p['a']==di]
  pics={}
  for label,i in [('receiver',ri),('RB',rb),('QB',qb)]:
   ps=[p['picture']for p in seen if p['b']==i]
   pics[label]=ps[0]if ps else None
  aims=[p for p in a['aims']if p['a']==di and p['t']==tm and not p['job'].startswith('run-contact')]
  rows.append({'t':tm,'kind':c['kind'],'read':c.get('read'),'consumedPictures':pics,'rawCommand':t['requests'][di],'deliveredCommand':t['intents'][di],'before':t['before'][di],'after':t['after'][di],'runnerReality':t['before'][rb]['pos'],'recordedSupportAims':aims,'engagements':[e for e in t['repBefore']if e['d']==di]})
 lapse=[c for c in calls if start<=c['t']<end];lo=ticks[start]['before'][di];hi=ticks[end]['before'][di]
 low=True;past=False
 for c in lapse:
  t=ticks[c['t']];cs=a['cues'][c['cues'][0]:c['cues'][1]];cue=next((p['picture']for p in cs if p['a']==di and p['b']==ri),None)
  if cue:
   low=low and cue['stance']=='low';past=past or(cue['pos']['x']-t['before'][di]['pos']['x']>1 and cue['vel']['x']>2)
 records.append({'case':case,'tape':str(path),'tapeSha256':H(raw),'inputSha256':a['inputSha256'],'source':a['source'],'defender':{'idx':di,'slot':slot,'id':actor['player']['id'],'runFit':actor['runFit']},'receiver':{'idx':ri,'slot':receiver['slot'],'id':receiver['player']['id']},'lapse':{'from':start,'to':end,'seconds':round(end-start,2),'allRunBelief':all(c.get('read')=='run'for c in lapse),'allAcquiredReceiverLowPads':low,'anyReceiverPastOwnDepthAndRunning':past,'achievedExtraDepth':hi['pos']['x']-lo['pos']['x'],'achievedVelocityAtStart':lo['vel'],'achievedVelocityAtEnd':hi['vel']},'rows':rows,'qualification':'Mode inferred from actual calls/aims and source. Raw command is meaningful before contact; later engagement laws may overwrite it. Return at end is dispatcher acquired-RB support (#75), not showsBlock regaining truth.'})
manifestPins=['docs/reviews/run-game-v3/part9/d0co.manifest.json','docs/reviews/run-game-v3/part10/q0co.manifest.json','docs/reviews/run-game-v3/part10/s1co.manifest.json','docs/reviews/run-game-v3/part10/s2co.manifest.json','docs/reviews/run-game-v3/part10/s1gap.manifest.json']
ref='bae3fe80d189a7d792aaafbc4eea1ae2baa79573';manifests=[]
for path in manifestPins:
 b=subprocess.check_output(['git','show',ref+':'+path]);m=json.loads(b);(out/Path(path).name).write_bytes(b)
 manifests.append({'publishedAt':ref,'path':path,'sha256':H(b),'commit':m['commit'],'source':m['sourceSha256'],'dirty':m['dirty'],'overrides':m['overrides'],'flags':m['flags'],'qualification':'Published research source/flags; not a pure accepted-develop source receipt. Manifest source drift checks are reported by original collector.'})
for name in ['part10/outcomes.txt','part10/pr169.txt','part11/structure.txt','part11/sim-internals.txt']:
 p='docs/reviews/run-game-v3/'+name;b=subprocess.check_output(['git','show',ref+':'+p]);(out/name.replace('/','-')).write_bytes(b)
result={'createdFromSavedDataOnly':True,'nativeSimulations':0,'NFLQueries':0,'sourceRef':ref,'witnesses':records,'researchManifests':manifests,'limits':['Four correlated defender histories across two installed plays/two rosters, not population rates.','WZORD and current PA13 are useful untouched opposite controls but do not directly prove MAN_RUN_COMMIT release behavior.','Consumer source must preserve acquired throw priority rather than private throwAt gate.','Research Part12/13 packages alter gait/mesh/front/spacing; their improved yardage does not attribute MAN_RUN_COMMIT alone.']}
(out/'saved-witnesses.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'witnesses':len(records),'nativeSimulations':0,'written':str(out/'saved-witnesses.json'),'lapsing':[{k:r[k]for k in ['case','defender','lapse']}for r in records]},indent=2))
