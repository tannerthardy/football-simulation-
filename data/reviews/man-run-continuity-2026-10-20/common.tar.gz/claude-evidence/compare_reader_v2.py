"""Read saved OZ4 arms; no simulator, controller or test execution."""
from pathlib import Path
import json,gzip,hashlib,math
out=Path('out/man-run-continuity/claude-evidence')
paths={'accepted':Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff/baseline/OZ4.json.gz'),'man299':Path('out/man-run-continuity/guarded-candidate/OZ4.json.gz'),'reader925':Path('out/man-run-continuity/reader-candidate/OZ4.json.gz')}
H=lambda b:hashlib.sha256(b).hexdigest();A={};pins={}
for arm,p in paths.items():
 raw=p.read_bytes();a=json.loads(gzip.decompress(raw));A[arm]=a;pins[arm]={'path':str(p),'sha256':H(raw),'source':a['source'],'inputSha256':a['inputSha256'],'gain':a['gain'],'terminal':a['phase']!='live'}
assert len({p['inputSha256']for p in pins.values()})==1
slots={p['idx']:p['slot']for p in A['accepted']['initial']}
fields=['before','requests','intents','after','repBefore','reps','contacts','rng','ball']
def first(a,b,f):
 for x,y in zip(a['ticks'],b['ticks']):
  if x[f]!=y[f]:return{'tick':x['t'],'completed':x['completed'],'actors':[slots[i]for i,(p,q)in enumerate(zip(x[f],y[f]))if p!=q]if f in ['before','requests','intents','after']else None}
 return None
comparisons={}
for left,right in [('accepted','reader925'),('man299','reader925')]:
 comparisons[left+'->'+right]={f:first(A[left],A[right],f)for f in fields}
records=[]
for tm in [1.75,1.8,1.85,1.95,2.0,2.1,2.5,2.8,2.95,3.,3.15,3.3,3.55,4.,4.05,4.1]:
 row={'tick':tm,'achievedAt':tm+.05,'arms':{}}
 for arm,a in A.items():
  t=next(t for t in a['ticks']if t['t']==tm);rb=t['after'][6];d={}
  for i in[18,20,21]:
   b=t['after'][i];r={'position':b['pos'],'velocity':b['vel'],'speed':math.hypot(*b['vel'].values()),'runnerDistance':math.dist(b['pos'].values(),rb['pos'].values()),'raw':t['requests'][i],'intent':t['intents'][i]}
   ep=next((e for e in t['reps']if e['d']==i),None)
   if ep:r['runRep']=ep
   if 'coverage'in t:r['cachedCoverage']=t['coverage'][i]
   d[slots[i]]=r
  row['arms'][arm]={'runnerPosition':rb['pos'],'runnerVelocity':rb['vel'],'defenders':d}
 records.append(row)
events={arm:[e for e in a['events']if e['type']in['carrier_contact','tackle_wrap','broken_tackle','tackle','block_contact']and(e['type']!='block_contact'or slots.get(e['a'])in['X','Z'])]for arm,a in A.items()}
eps={}
for arm,a in A.items():
 ps={}
 for c in a['contact']:
  if c['b']!=9 or c['d']!=18:continue
  r=c['rep'];q=ps.setdefault(r['id'],{'start':r['start'],'b':9,'d':18,'end':None})
  if c['phase']=='end':q['end']={'t':c['t'],**c['data']}
 eps[arm]=list(ps.values())
result={'scope':'Saved OZ4 reader-extension comparison; earlier FINAL-NATIVE-MEMO.md is historical source299 only.','inspectionOnly':True,'newSimulations':0,'pins':pins,'firstDifferences':comparisons,'selectedGeometry':records,'events':events,'Z_CB_SEpisodes':eps,'facts':['reader925 fixes the actual SS1.80 classification/assignment error; cached rule is zone quarter_s_in and judgment rule with Zreleaseblock first.65.','SS wraps3.05/slips3.35 like accepted baseline; man299 was3.20/3.45.','OZ4reader17.09 remains adverse to accepted15.59; real sameWR/CB recontact3.30-3.75 prevents corner contact.','Exact SS/FS grasp quality/draw was not captured; do not claim causal grip defect or complete physical correctness from this trace.'],'limits':['Existing reader-candidate wrapper failed later while serializing a live PA rule reference. This OZ4 tape completed before that failure, retains its own exactsource/input/tape identity, and is diagnostic evidence, not a passing aggregate launch receipt.','Parent owns final command/tail receipts and declares compatibility; this worker ran no test/native command.']}
(out/'reader-v2-native-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pins':pins,'firstDifferences':comparisons},indent=2))
