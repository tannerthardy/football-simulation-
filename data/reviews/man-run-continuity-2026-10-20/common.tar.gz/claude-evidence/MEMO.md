# Saved evidence: man run-support continuity

2026-10-20. Read-only worker; zero simulator constructors/ticks, NFL queries or
downloads. `inspect_saved.py` reads existing exact captures and published
research receipts. `saved-witnesses.json` retains stable players, tape/input
hashes, first cue/command changes, raw/delivered movement and achieved bodies.

## Repeated accepted-source witness

Accepted source4273994/2c98bed; prior #169 baseline tapes remain compatible
because #169 changes only engagement admission later, not these precontact reads.
There are four correlated corner histories across two plays/two generated
rosters. They are a mechanism witness, not a frequency estimate.

| Case / actor | Support accepted | Cue passes LOS+2, man resumes | Acquired back restores support | Extra achieved depth during lapse |
|---|---:|---:|---:|---:|
| WZ7 CB_S pair11D-CB3 marking Zpair11O-WR3 |.65|1.15|1.85|1.489yd|
| WZ7 CB_W pair11D-CB1 marking Xpair11O-WR1 |.65|1.20|1.80|1.111yd|
| OZ4 CB_S pair31D-CB1 marking Zpair31O-WR3 |.65|1.20|1.85|1.015yd|
| OZ4 CB_W pair31D-CB3 marking Xpair31O-WR4 |.65|1.20|1.85|1.329yd|

During each lapse, run belief remains stable, every consumed primary receiver
picture still has low pads, and the receiver has not passed the defender's own
depth by1yd while running downfield. No physical block exists at the initiating
failure. Thus a solver/grip defect cannot explain the first wrong request.

For WZ7 CB_S, at1.15 the acquired Z picture is x42.0925,y8.7831,vx4.1813,
low pads,facing.0876,age.40; CB is x46.2870,y9.5794. The raw request becomes
(+9.4733,−3.1486) rather than its accepted alley fit. Its body starts with
vx−.214 and is vx+4.285 at1.85 when support resumes. OZ4 CB_S similarly goes
vx−.466→+3.426. Motion is achieved, not merely a changed label.

**Important attribution:** support at1.85 does not mean `showsBlock` becomes
true again. The receiver remains beyond its hard2yd cutoff. The existing
CoverageDefender acquired-back override (#75) now sees RB carrying=true and
restores the same body's installed support, even though it still marks Z/X.
Before this, QB is seen carrying deep through the mesh and RB carrying=false.
Retaining the support read must preserve play-action uncertainty and respond to
an acquired release; it must not assume the hidden give has happened.

## Claude's isolated and combined evidence

Published at `bae3fe80d189a7d792aaafbc4eea1ae2baa79573`:

- Part10 `s2co`: source6fc13a639c1d6726d3ff74e941704b5d1830d8d6aa682e0984e7bdc851844312,
  host2e791b61 plus recorded dirty patch3b864694...; MAN_RUN_COMMIT=1 alone,
  1200 zone lab plays,40+8.42%.
- `s1co` same source with MAN_RUN_COMMIT/BLOCK_FRONT/TRACK_FACING:8.50%.
- `s1gap` same combined flags:6.25%; no isolated gap MAN_RUN_COMMIT arm is
  published in Part10.
- The prior `d0co`9.42% uses research source05c4d6ec..., not identical s2co
  source6fc13a6 nor pure accepted4273994. Other new branches are default off,
  but do not erase this provenance difference or call the receipts one source.
- #169 `q0co` is another scratch source8b8c60c8 at025e5505,1200 zone plays,
  40+9.67%; gap8.94%. Stalk sample:320 separation endings,8runner-passed,
  122terminal-active,2body-down;40/433 unique stalked DBs enter the script's
  geometric carrier-proximity threshold. That is not verified touch/held load.
  Earlier42/432 is likewise not432episodes; denominators are unique stalked
  DBs aggregated over plays, while episodes have different counts.
- Part11–13 packages add gait/mesh/front/depth/spacing changes. Their outcome
  gains do not attribute MAN_RUN_COMMIT alone, and tracking proximity cannot
  establish hand-force or gaze correctness.

## Useful controls and general lesson

WZORD's successful CB_W escape2.95/assist3.05 and opposite sustained stalk are
useful negative controls. PA13 on current accepted source completes14.51 yards;
prior #169 onset comparison is exactly identical across all native fields.
They do not directly exercise an accepted man-block read followed by a genuine
release/throw. Use an actual controller contract for acquired release, unknown
or contradictory picture, PA reclassification and recognized throw priority.

The general missing intelligence is continuity of purpose with a reason to
revise it: a cue should admit a responsibility, and new acquired evidence
should revise that responsibility. A start condition becoming false because
its receiver crossed a geometric threshold is not the same as contrary
football evidence. #169 separately demonstrated that renewed physical contact
should not reset an already justified response. This argues for clear existing
owner contracts at responsibility/action/contact boundaries, not one universal
commitment timer or global run/pass phase manager.
