"""Saved final candidate comparison; no simulator or controller invocation."""
from pathlib import Path
import gzip,json,hashlib,math
root=Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff/baseline');here=Path('out/man-run-continuity');out=here/'claude-evidence'
H=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b)),H(b)
def first(a,b,k):
 for x,y in zip(a['ticks'],b['ticks']):
  if x[k]!=y[k]:
   actors=[i for i,(p,q)in enumerate(zip(x[k],y[k]))if p!=q]if k in ['requests','intents','before','after']else None
   return {'tick':x['t'],'completed':x['completed'],'actors':actors}
 return None
records=[]
for key in ['WZ7','OZ4','WZORD','F_Q_OZ']:
 bp=root/(key+'.json.gz')if key!='F_Q_OZ'else Path('/tmp/football-db-stalk-baseline/out/man-run-continuity/fresh-baseline/F_Q_OZ.json.gz')
 cp=here/'guarded-candidate'/(key+'.json.gz')if key!='F_Q_OZ'else here/'fresh-candidate'/(key+'.json.gz')
 a,ha=read(bp);b,hb=read(cp);assert a['inputSha256']==b['inputSha256'];agents={p['idx']:{'slot':p['slot'],'id':p['player']['id'],'runFit':p.get('runFit')}for p in a['initial']};slots={p['slot']:p['idx']for p in a['initial']};rb=slots['RB']
 def event(A):return[e for e in A['events']if e['type']in ['carrier_contact','tackle_wrap','broken_tackle','tackle','shed','block_contact']and(e['type']!='block_contact'or agents[e['a']]['slot']in['X','Z'])]
 def eps(A):
  ps={}
  for e in A['contact']:
   if agents[e['b']]['slot']not in['X','Z']or agents[e['d']]['slot']not in['CB_S','CB_W']:continue
   r=e['rep'];q=ps.setdefault(r['id'],{'id':r['id'],'b':e['b'],'d':e['d'],'start':r['start'],'end':None})
   if e['phase']=='end':q['end']={'t':e['t'],**e['data']}
  return list(ps.values())
 selected=[]
 for tm in [1.15,1.2,1.5,1.75,1.8,2.,2.5,2.8,3.,3.15,3.3,3.6,4.]:
  row={'tick':tm}
  for arm,A in [('baseline',a),('candidate',b)]:
   t=next((t for t in A['ticks']if t['t']==tm),None)
   if not t:continue
   rp=t['after'][rb];d={}
   for slot in['CB_S','CB_W','SS','FS']:
    i=slots[slot];p=t['after'][i];outside=(rp['pos']['y']-p['pos']['y'])*(1 if slot.endswith('_S')else -1)
    d[slot]={'position':p['pos'],'velocity':p['vel'],'speed':math.hypot(*p['vel'].values()),'runnerDistance':math.dist(p['pos'].values(),rp['pos'].values()),'upfieldLead':p['pos']['x']-rp['pos']['x'],'rawCommand':t['requests'][i],'deliveredCommand':t['intents'][i]}
    if slot in ['CB_S','CB_W']:d[slot]['outsideMargin']=outside
   row[arm]={'achievedAt':t['completed'],'runnerPosition':rp['pos'],'runnerVelocity':rp['vel'],'defenders':d}
  selected.append(row)
 ss=[]
 if key=='OZ4':
  for arm,A in [('baseline',a),('candidate',b)]:
   tm=1.8;c=next(c for c in A['calls']if c['a']==slots['SS']and c['t']==tm);cs=A['cues'][c['cues'][0]:c['cues'][1]];ps={}
   for slot in['Z','CB_S','CB_W']:
    p=next((p['picture']for p in cs if p['a']==slots['SS']and p['b']==slots[slot]),None);ps[slot]=p
   t=next(t for t in A['ticks']if t['t']==tm);r=ps['Z'];d=ps['CB_S'];h=t['minds'][slots['SS']]['decisionInterval']+d['age'];depth=d['pos']['x']-r['pos']['x'];projection=depth-(r['vel']['x']-d['vel']['x'])*h
   ss.append({'arm':arm,'tick':tm,'controllerKind':c['kind'],'command':c['command'],'consumedPictures':ps,'rawPictureCapProjection':{'depth':depth,'horizon':h,'projectedDepth':projection},'qualification':'Pure diagnostic projection on recorded raw pictures; actual judgment uses ReleaseReader interpreted output. Exact judgment reason/cache was not passively recorded. Different subtechnique and raw request are recorded; protect-vertical inference is source-supported, not an emitted reason.'})
 records.append({'case':key,'inputSha256':a['inputSha256'],'baselineSource':a['source'],'candidateSource':b['source'],'tapeSha256':{'baseline':ha,'candidate':hb},'allTerminal':a['phase']!='live'and b['phase']!='live','gains':[a['gain'],b['gain']],'agents':agents,'firstDifferences':{k:first(a,b,k)for k in['requests','intents','after','rng','contacts']},'allCommonNumericFieldsEqual':all(x[k]==y[k]for x,y in zip(a['ticks'],b['ticks'])for k in['before','requests','intents','after','repBefore','reps','contacts','rng','ball']),'events':{'baseline':event(a),'candidate':event(b)},'episodes':{'baseline':eps(a),'candidate':eps(b)},'selectedGeometry':selected,'OZ4SafetyInteraction':ss})
(out/'final-native-comparison.json').write_text(json.dumps({'simulations':0,'inspectionOnly':True,'records':records},indent=2)+'\n')
print(json.dumps([{'case':r['case'],'gains':r['gains'],'first':r['firstDifferences']}for r in records],indent=2))
