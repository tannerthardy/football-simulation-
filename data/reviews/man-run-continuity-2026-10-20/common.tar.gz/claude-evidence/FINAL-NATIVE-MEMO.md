# Final man-support continuation: saved native interpretation

Inspection only; no new simulator/controller invocation, tests or NFL query.
`compare_final.py` reads accepted-source baseline tapes and final guarded
candidate source29977086, checking exact input hashes and every common numeric
field. Source1a79890 predecessor has compatible trajectories for these three
inputs; this report hashes and references the actual guarded299 tapes.

## First useful divergence precedes contact/randomness

WZ7 first changes CB_S at tick1.15 (achieved1.20); OZ4 changes both corners at
1.20 (achieved1.25). Previously, the unchanged run belief and acquired low-pad
receiver produced support until the receiver crossed LOS+2, then lost it.
Candidate preserves that admitted purpose. Initial RNG divergence is1.80 in
WZ7 /1.90 in OZ4 when changed physical blocking begins. Thus neither the first
corrected decision nor the earlier achieved support motion requires a new
execution draw.

WZ7 at achieved1.80: CB_S is x45.966,y10.951 versus baseline47.568,9.943;
runner position is exactly equal. Candidate is1.792yd nearer while retaining
9.108yd upfield lead and11.726yd outside margin. His movement remains an alley
fit before the runner declares, not a hidden-possessor chase.

## WZ7: actual useful return, with earned block still permitted

Zpair11O-WR3 / CB_Spair11D-CB3 still acquire a real block, now at1.80 with
loaded/contact event1.85 rather than2.20/2.25. Earlier position does not ban
stalk access. The new rep separates2.25; baseline first rep runs until3.80,
then the pair reacquires4.50–4.90. Candidate has no later re-block.

At achieved3.05 candidate CB distance3.985yd/upfield2.194/outside3.327 versus
baseline10.186/8.202/6.040. He gathers into a useful interception and wraps3.30,
then finishes4.30. Baseline has no corner contact; FS wraps5.55/finishes6.40.
Gain25.85→5.94 is consistent with an observed native return, but later paths and
RNG differ, so not every saved yard is attributed to the admission contract.

## OZ4 adverse: corner geometry improves, secondary interaction costs timing

Zpair31O-WR3 / CB_Spair31D-CB1 acquire earlier1.90 (contact1.95), then separate
2.55 versus baseline2.25/2.30 acquisition and3.20 separation. At achieved2.85
candidate CB distance6.510/upfield2.925/outside5.816 versus10.726/6.708/8.370.
This is an honest nearer approach, not simply a smaller final gain target.

The receiver earns new reachable contact3.25/contact3.30 (center separation
about.78yd), before the corner can reach the runner. Actual normal/tangent
loads at tick3.30 are338.3/−193.7 in native hand-force units; no forced release
or artificial block denial occurs. That rep ends3.75 when the runner has
passed; baseline also re-blocks this pair later3.80–4.25. Corner contact never
occurs in either arm. Existing engagement request ownership and startup wait
remain outside this candidate; #169's correction is independently pending.

**Recorded adverse sequence before RNG:** at1.80 the safety SS changes from
zone/alley-fit to man with a large downfield request(+8.799,−4.743), while
baseline remains its zone/alley request(−1.321,+3.455). Shared RNG has not yet
diverged. Its consumed Z picture is exactly equal: x45.5530,y9.8929,vx5.3482,
low pads,age.35. Its teammate corner picture differs because of the intended
support motion. Baseline CB_S isx47.3187,vx+2.9127; candidatex46.1478,vx−.4323.

Source-supported explanation: ReleaseReader still uses the depth-limited
`showsBlock` and can classify downfield stalk motion as a vertical. A safety's
CoverageJudgment then protects an uncapped vertical. Applying its cap-depth
formula to the recorded raw pictures gives baseline depth1.766/projected1.232
versus candidate.595/projected−.673 over decisionInterval+.05age. Candidate's
corner correctly stopped retreating with the receiver, so he no longer looks
like that receiver's roof. This explains why the safety can attempt a coverage
rescue on the same run. **The exact judgment reason and final interpreted
ReceiverRead were not recorded**; treat this as a source-supported interaction
hypothesis, not a directly emitted directive explanation or proof every safety
read was wrong. The actual SS mode/request divergence is recorded.

After acquired RB possession restores support1.85, the safety's held alley
and subsequent pursuit differ. Its first wrap is3.20 versus3.05; both holds
slip (3.45 versus3.35), and FS wraps4.15 versus4.05/finishes4.75 versus4.65.
Ending15.59→16.90 (+1.31yd) remains adverse. It is not evidence for a new grip
law defect, and the later slip/draws cannot by themselves explain the earlier
1.80 assignment divergence. Do not present a lower overall YAC or universal
containment success. Remaining multi-defender cue/assignment interaction is a
separate, bounded follow-up; do not stack a ReleaseReader rewrite here.

## Opposing successful finish and fresh transfer

WZORD is full common-field numeric/RNG/event identity, not merely the same2.89yd
ending. CB_W separates2.95 and assists3.05; opposite CB_S's legitimate sustained
block remains active at whistle. No forced escape or extra mid-level fitter.

Fresh generated51/52 Quarters weak OZ (F_Q_OZ) changes both corners at1.15,
RNG1.80. At achieved2.05, CB_W runner distance16.401→14.022yd; opposite CB_S
23.002→19.677. X still obtains loaded CB_W block1.85 versus2.25. Opposite Z no
longer reaches CB_S before play end as he flows with his legitimate support.
No corner records runner contact in either arm. FS finishes4.05 in both;
gain4.67→4.52. This demonstrates fresh purpose/geometry transfer, not a second
successful corner-tackle claim or a long-run-tail certification.

## Football disposition

The candidate repairs a repeated responsibility discontinuity that is wrong
before the selected endings: disappearing shallow admission geometry does not
contradict an acquired continuing blocking picture. It preserves a useful
support job and improves attained positioning in selected and fresh players.
Earlier real stalk contact and OZ4 re-block show the offense remains free to
win. WZORD preserves an ordinary defensive finish and sustained offensive work.

OZ4 exposes another instance of the broader missing intelligence: teammates
interpret related evidence through different responsibility contexts. A
corner's run-support movement can be interpreted as loss of pass help by the
safety while that receiver's downfield blocking is classified as vertical.
Retaining purpose is necessary; coordinated interpretation and attainable
handoff still need explicit contracts. This is not permission for global
commitment timers, perfect shared awareness or a package of depth/gait changes.
