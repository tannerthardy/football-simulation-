# Reader extension: OZ4 classification repaired, adverse ending retained

Saved inspection only. No new simulations, controller queries, tests or NFL
queries. `compare_reader_v2.py` reads accepted4273994, man-only29977086 and
reader925eb44e637929e5031553c7a3d44dd8c20aa26d05c31a799929faef1b1a740b tapes.
Input hashes match; `reader-v2-native-comparison.json` records every tape SHA256,
first common-field divergence, copied cached coverage snapshots, selected
achieved geometry, actual run-contact forces and event chronology.

**Historical qualification:** `FINAL-NATIVE-MEMO.md` and its original comparison
belong to the man-only299 candidate. Its safety-rescue inference is now directly
resolved by reader925's cached rule snapshots; it is not the final925 result.
Earlier source299 endings must not be relabeled as this source.

The first reader925-versus-man299 difference is exactly **SS at tick1.80**
(completed1.85), before any RNG divergence between those arms (2.95). At that
instant925's cached SS rule is `q_safety`, job`zone:quarter_s_in`, judgment`rule`,
and Z remains `release:block`, first block/since.65. The false vertical rescue
is removed. Corners retain the same previously justified support motion.

The delivered SS request changes from man299(+8.799,−4.743) back to the sensible
zone/support request matching the accepted baseline(−1.321,+3.455). At achieved
2.85, distance to the runner improves3.824→2.827yd, essentially accepted2.825.
This is attained support before RNG divergence, not a better ending chosen
post hoc. Its first wrap returns from3.20 to3.05 and slip from3.45 to3.35,
matching the accepted event times.

## Why OZ4 is still adverse

Reader925 gains17.09 versus accepted15.59/man29916.90. The early assignment
repair did not reduce the ending; keep that result visible.

- Zpair31O-WR3 legitimately reaches CB_Spair31D-CB1 at1.90 with loaded/contact
  event1.95, and they separate2.55. Earlier contact than accepted remains, so
  the information correction does not suppress useful WR blocking access.
- The same receiver reacquires reachable contact3.30 with event3.35. That rep
  lasts until3.75 when the runner passes. At tick3.30 the transmitted normal
  and tangent loads are258.44/−125.64 in the native force units. At achieved
  3.35 the corner is2.513yd from the runner and at3.60 is1.948yd away, but is
  actually occupied by the block. He records no runner contact. This is
  preserved physical offensive work, not continued reactivation of man coverage.
- At SS's achieved3.05 entry, accepted distance is1.745yd and reader1.735;
  SS positions differ by less than.001yd. Receiver/runner velocity and prior
  random stream differ slightly; both SS wraps then slip. Exact grasp
  quality/draws were not captured, so these tapes cannot assign the remaining
  adverse ending to a particular grip parameter or certify its physical law.
- At achieved4.05 FS is1.299yd from the runner versus accepted1.059. Runner
  speed is8.117 versus7.798yd/s. FS wraps4.10 versus4.05; terminal4.80 versus
  4.65. Later runner/support/contact execution explains where the extra gain
  occurs; the available evidence does not identify one additional incorrect
  controller decision that should be repaired in this candidate.

There is a concrete renewed-contact limitation already separated in #169 and
an uncertain later hold/approach contribution. Neither justifies restoring a
false vertical route interpretation or tuning hands/forcing an ending. Call
this a correct early reading/purpose repair with a retained adverse outcome,
real offensive re-block and incomplete late-execution attribution. Do not
claim all of17.09 is an earned win under a validated contact model.

The original reader-candidate batch later failed on a PA live-reference circular
serialization. OZ4 was already completed and is retained as source-qualified
diagnostic evidence, not a passing aggregate-launch receipt. Parent separately
owns the fixed passive-copy collector/tail passing receipt; no simulation was
repeated by this worker.
