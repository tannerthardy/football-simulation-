"""Standalone figure from saved native samples only. No simulator invocation.

Run at repository root:
MPLCONFIGDIR=/tmp/football-continuity-plot XDG_CACHE_HOME=/tmp/football-continuity-cache \
  python3 out/man-run-continuity/claude-evidence/plot_continuity.py
"""
from pathlib import Path
import gzip,json,hashlib,argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
out=Path('out/man-run-continuity/claude-evidence')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline-dir',type=Path,default=Path('/workspace/football-db-stalk-workoff/out/db-stalk-workoff/baseline'))
parser.add_argument('--man-dir',type=Path,default=Path('out/man-run-continuity/guarded-candidate'))
parser.add_argument('--reader-dir',type=Path,default=Path('out/man-run-continuity/reader-candidate'))
args=parser.parse_args();base=args.baseline_dir;man=args.man_dir;reader=args.reader_dir
colors={'accepted':'#666666','man299':'#b3710b','reader925':'#1464a0'}
loaded={}
def get(arm,key):
 p={'accepted':base,'man299':man,'reader925':reader}[arm]/(key+'.json.gz')
 raw=p.read_bytes();a=json.loads(gzip.decompress(raw));assert a['source'].startswith({'accepted':'4273994','man299':'29977086','reader925':'925eb44'}[arm]);loaded[arm+'/'+key]={'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'source':a['source'],'inputSha256':a['inputSha256'],'gain':a['gain']}
 return a
wz={arm:get(arm,'WZ7')for arm in['accepted','reader925']}
oz={arm:get(arm,'OZ4')for arm in['accepted','man299','reader925']}
assert len({a['inputSha256']for a in wz.values()})==1
assert len({a['inputSha256']for a in oz.values()})==1
fig,ax=plt.subplots(2,2,figsize=(12.5,9.5))
fig.subplots_adjust(left=.095,right=.98,bottom=.20,top=.82,hspace=.53,wspace=.26)
fig.suptitle('Continuity of football purpose: recorded requests and achieved movement',fontsize=15,y=.975)
fig.text(.5,.925,'WZ7: CB_S pair11D-CB3 marks Z pair11O-WR3  |  OZ4: SS pair31D-S1',ha='center',fontsize=10)
# Do not guess the safety identity: replace the label with recorded source player.
ss=next(p['player']['id']for p in oz['reader925']['initial']if p['slot']=='SS')
fig.texts[-1].set_text('WZ7: CB_S pair11D-CB3 marks Z pair11O-WR3  |  OZ4: SS '+ss)
for arm,a in wz.items():
 di=next(p['idx']for p in a['initial']if p['slot']=='CB_S')
 ts=[t for t in a['ticks']if .7<=t['t']<=2.25]
 ax[0,0].plot([t['t']for t in ts],[t['requests'][di]['vel']['x']for t in ts],color=colors[arm],lw=2)
 ax[0,1].plot([t['completed']for t in ts],[t['after'][di]['pos']['x']-a['setup']['los']for t in ts],color=colors[arm],lw=2)
ax[0,0].set_title('WZ7 corner: shallow cue lapses at 1.15s',loc='left',fontsize=11)
ax[0,0].set_ylabel('Requested downfield velocity (yd/s)')
ax[0,0].set_xlabel('Controller tick time (s)')
ax[0,0].axvline(1.15,color='#555',ls=':',lw=1)
ax[0,0].annotate('Old request retreats\nwith the blocker',(1.4,9.6),xytext=(.7,6),fontsize=9,arrowprops={'arrowstyle':'->','color':'#555'})
ax[0,0].set_ylim(-4,12)
ax[0,1].set_title('WZ7 corner: useful depth survives',loc='left',fontsize=11)
ax[0,1].set_ylabel('Achieved depth past LOS (yd)')
ax[0,1].set_xlabel('Completed physics time (s)')
ax[0,1].axvline(1.85,color='#555',ls=':',lw=1)
ax[0,1].annotate('RNG differs in step\n1.80–1.85s',(1.85,8.5),xytext=(1.22,9.0),fontsize=8,arrowprops={'arrowstyle':'->','color':'#777'})
ax[0,1].set_ylim(4,10)
for arm,a in oz.items():
 di=next(p['idx']for p in a['initial']if p['slot']=='SS');ri=next(p['idx']for p in a['initial']if p['slot']=='RB')
 ts=[t for t in a['ticks']if 1.65<=t['t']<=2.85]
 style='--'if arm=='accepted'else'-'
 ax[1,0].plot([t['t']for t in ts],[t['requests'][di]['vel']['x']for t in ts],color=colors[arm],lw=1.7,ls=style)
 ax[1,1].plot([t['completed']for t in ts],[((t['after'][di]['pos']['x']-t['after'][ri]['pos']['x'])**2+(t['after'][di]['pos']['y']-t['after'][ri]['pos']['y'])**2)**.5 for t in ts],color=colors[arm],lw=2,ls=style)
ax[1,0].set_title('OZ4 safety: false vertical rescue removed',loc='left',fontsize=11)
ax[1,0].set_ylabel('Requested downfield velocity (yd/s)')
ax[1,0].set_xlabel('Controller tick time (s)')
ax[1,0].axvline(1.8,color='#555',ls=':',lw=1)
ax[1,0].annotate('299 switches to man\n925 keeps block read',(1.8,8.8),xytext=(2.03,6),fontsize=9,arrowprops={'arrowstyle':'->','color':'#555'})
ax[1,0].set_ylim(-12,12)
ax[1,1].set_title('OZ4 safety: closer before new execution draws',loc='left',fontsize=11)
ax[1,1].set_ylabel('Achieved distance to runner (yd)')
ax[1,1].set_xlabel('Completed physics time (s)')
ax[1,1].annotate('Shown through 2.90s;\n299→925 RNG differs at tick 2.95',(.95,.95),xycoords='axes fraction',ha='right',va='top',fontsize=8)
for axes in ax.flat:
 axes.grid(alpha=.22);axes.axhline(0,color='#777',lw=.7,alpha=.5)
legend=[Line2D([0],[0],color=colors['accepted'],lw=2,label='Accepted 4273994'),Line2D([0],[0],color=colors['man299'],lw=2,label='Man-only 29977086'),Line2D([0],[0],color=colors['reader925'],lw=2,label='Reader continuation 925eb44')]
fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,.11),ncol=3,fontsize=9)
fig.text(.5,.065,'Final outcomes: WZ7 25.85 → 5.87 yd; OZ4 15.59 → 17.09 yd (ADVERSE).',ha='center',fontsize=10)
fig.text(.5,.025,'Same frozen inputs and stable player IDs; current physical laws unchanged.\nRestored purpose/read is supported; later contact execution and the long-run tail are not certified.',ha='center',fontsize=9)
fig.savefig(out/'purpose-continuity.png',dpi=160)
(out/'purpose-continuity-provenance.json').write_text(json.dumps({'savedInspectionOnly':True,'newSimulations':0,'samples':loaded,'figure':'purpose-continuity.png'},indent=2)+'\n')
print(out/'purpose-continuity.png')
