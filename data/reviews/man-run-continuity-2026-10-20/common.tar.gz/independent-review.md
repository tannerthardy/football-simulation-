# Independent acquired-support continuation review

Reviewer: `/root/man_commit_review` (source and saved-evidence review; no source
edits, tests or native simulations performed by this reviewer).

Reviewed runtime code `11ef1703a59b1ab13bbebf2eeb51ed7a8eba8e05`, full source
`925eb44e637929e5031553c7a3d44dd8c20aa26d05c31a799929faef1b1a740b`.
Final `0dca4f09ec876a65949242221ad712f493ec51bf` corrects only the outward-route
fixture; the runtime is unchanged.

**Disposition: approve the scoped information/continuation contract.** This is
not an approval of overall containment, block defeat or explosive-run realism.

- Shallow evidence still admits blocking. Continued personally acquired pads
  or reachable facing-contact evidence can sustain an accepted man-support
  duty beyond that admission boundary while run belief remains.
- Acquired upright/no-contact releases restore man responsibility before the
  receiver must run behind the defender. Changed pass/unsure belief cancels
  acceptance; the shared reader retains existing confirmation timing and its
  pass/unsure pressed-vertical behavior. Outward/wheel releases remain supported.
- Recognized flight wins through the existing ball controller and retires the
  marker. Unrecognized flight continues the same acquired/expected backfield
  interpretation; no new private release-time cue or fixed commitment timer.
- The explicit BackfieldRunFit distinguishes installed exchange expectation
  from an affirmative runner key. It reuses acquired failed-exchange
  contradiction/retirement and preserves ordinary versus keyed pursuit gates.
- Continuing episodes own that picture before the legacy live-holder pursuit
  gate. Without an installed backfield input, continuation is not extended;
  the previous shallow policy remains. Initial admission and other legacy
  pursuit paths are separate information debt.

The OZ4 native decision provides causal support for the shared-reader repair:
SS retains its quarter/run-fit responsibility at1.80 rather than inventing a
vertical rescue from Z's continuing low-pad picture. **Its final17.09-yard
ending remains adverse.** Earlier source decisions, earned receiver blocks,
re-contact and subsequent approach can still defeat the defense; fixing the
interpretation does not establish that every movement or ending improved.

Remaining limits: episode memory is instance-local; uncertain memory across
reassignment, physical hand defeat, held escape-side choice, attainable pursuit
and broader secondary replacement remain separate. No new speed, strength,
hands, release rule, global phase manager or experimental package is approved.
Do not add another selected-play policy variant to hide the adverse result.
Integration owns exact combined verification and acceptance.
