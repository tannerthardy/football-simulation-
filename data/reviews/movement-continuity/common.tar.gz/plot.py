import gzip,json,math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
out=Path(__file__).resolve().parent
selection=json.loads((out/'selection.json').read_text());baseline=json.load(gzip.open(out/selection['baseline'][0]));candidate=json.load(gzip.open(out/selection['candidate'][0]))
fig,axes=plt.subplots(2,2,figsize=(11,7),constrained_layout=True)
for label,color,r in [('Accepted','#b45436',baseline),('Candidate','#287b9d',candidate)]:
 ticks=[t for t in r['ticks'] if .7<=t['t']<=2.4]
 # QB carries out the fake after the pitch; raw intent has no facing override.
 want=[math.degrees(math.atan2(t['intents'][0]['vel']['y'],t['intents'][0]['vel']['x'])) for t in ticks]
 unwrap=lambda xs:[math.degrees(v) for v in __import__('numpy').unwrap([math.radians(v) for v in xs])]
 face=unwrap([math.degrees(t['before'][0]['facing']) for t in ticks]);want=unwrap(want)
 shift=360*round((face[0]-want[0])/360);want=[v+shift for v in want]
 axes[0,0].plot([t['t'] for t in ticks],face,label=label,color=color)
 axes[0,0].plot([t['t'] for t in ticks],want,ls='--',alpha=.7,color=color)
 ys=json.load(open(out/('yaw-baseline.json' if label=='Accepted' else 'yaw-candidate.json')))
 row=next(r for r in ys if r['substeps']==12 and r['speed']==0 and abs(r['target']-math.pi/2)<1e-9)
 axes[0,1].plot([t['t'] for t in row['ticks'][:20]],[math.degrees(t['facing']) for t in row['ticks'][:20]],label=label,color=color)
axes[0,0].set(title='Native Toss QB: requested versus achieved facing',xlabel='Seconds after snap',ylabel='Facing (degrees; unwrapped)');axes[0,0].legend();axes[0,0].text(.02,.03,'Dashed: actual movement request direction',transform=axes[0,0].transAxes,fontsize=8)
axes[0,1].axhline(90,color='gray',ls='--');axes[0,1].set(title='One body, constant 90° turn, no contact or randomness',xlabel='Seconds',ylabel='Achieved facing (degrees)')
r=json.load(open(out/'comparison.json'));x=[0,1,2]; labels=['Accepted','Candidate','NFL reference'];colors=['#b45436','#287b9d','#667e52']
for ax,metric,title in [(axes[1,0],'yaw_reversal_deg','Alternating body-facing correction'),(axes[1,1],'heading_reversal_deg','Alternating travel-heading correction')]:
 vals=[r['paired_clear_all']['bins']['ALL'][a][metric]['mean'] for a in ('baseline','candidate')]+[r['nfl']['bins']['ALL/clear_all'][metric]['mean']];ax.bar(x,vals,color=colors);ax.set(xticks=x,xticklabels=labels,title=title,ylabel='Mean reversal amplitude (degrees)')
 ax.set_ylim(0,max(vals)*1.25)
 for i,v in enumerate(vals):ax.text(i,v+max(vals)*.03,f'{v:.3f}',ha='center',fontsize=9)
fig.suptitle('Turning motor rings; fixing it removes body wobble, not all path jitter',fontsize=13)
fig.text(.02,-.035,'Sim: 1,399 matched actor/time samples from 6 snaps. NFL: first 12 runs + 8 dropbacks in existing week-1 order. 10 Hz, .01 yd, speed ≥2 yd/s, >1.5 yd from every player.\nNFL orientation is a provider estimate, not gaze. Unequal play/role mix; this is a bounded diagnostic reference, not league certification.',fontsize=8)
fig.savefig(out/'movement-continuity.png',dpi=160,bbox_inches='tight')
