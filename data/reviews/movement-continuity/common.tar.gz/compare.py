"""Same 10Hz/.01yd operator; no smoothing, interpolation or provider speed.

Position heading and body orientation are separate. Reversal is the smaller
absolute turn in two adjacent opposite-sign turns, zero for a purposeful
one-direction cut. It is a descriptive proxy, not a label of bad football.
"""
import gzip, json, math, hashlib, sys
from collections import defaultdict
from pathlib import Path

OUT=Path(__file__).resolve().parent
def delta(a,b): return math.atan2(math.sin(b-a),math.cos(b-a))
def quantile(xs,p):
 xs=sorted(xs);i=(len(xs)-1)*p;lo=int(i);return xs[lo]+(xs[min(lo+1,len(xs)-1)]-xs[lo])*(i-lo)
def stats(xs):
 return {'n':len(xs),'mean':sum(xs)/len(xs),'p50':quantile(xs,.5),'p90':quantile(xs,.9)} if xs else {'n':0}
def samples(row,min_speed=2,precision=2):
 tracks=row['tracks'];n=len(tracks);facings=row['facings'];out={};excluded=defaultdict(int)
 for i,track in enumerate(tracks):
  for k in range(3,len(track)):
   raw=track[k-3:k+1]
   if any(p is None for p in raw):excluded['missing_actor_position']+=1;continue
   points=[[round(c,precision) for c in p] for p in raw]
   v=[[(b[d]-a[d])*10 for d in (0,1)] for a,b in zip(points,points[1:])]
   speeds=[math.hypot(*p) for p in v]
   if min(speeds)<min_speed:excluded['below_speed_gate']+=1;continue
   turn=[delta(math.atan2(*a[::-1]),math.atan2(*b[::-1]))*180/math.pi for a,b in zip(v,v[1:])]
   value={'heading_turn_deg':abs(turn[1]),'heading_reversal_deg':min(map(abs,turn)) if turn[0]*turn[1]<0 else 0,
    'speed_pulse_ydps':abs(speeds[2]-2*speeds[1]+speeds[0]),'speed_ydps':speeds[1]}
   faces=facings[i][k-2:k+1]
   if all(f is not None for f in faces):
    yaw=[math.degrees(delta(a,b)) for a,b in zip(faces,faces[1:])]
    value.update(yaw_turn_deg=abs(yaw[1]),yaw_reversal_deg=min(map(abs,yaw)) if yaw[0]*yaw[1]<0 else 0)
   else:excluded['missing_orientation']+=1
   if any(any(tracks[j][f] is None for f in range(k-3,k+1)) for j in range(n)):
    zone='unknown_proximity';excluded[zone]+=1
   else:
    near={j for j in range(n) if j!=i and any(math.dist(track[f],tracks[j][f])<=1.5 for f in range(k-3,k+1))}
    zone='near_opponent' if any(row['sides'][j]!=row['sides'][i] for j in near) else 'near_teammate' if near else 'clear_all'
   out[(row['ids'][i],k)]={'group':row['groups'][i],'zone':zone,'values':value}
 return out,dict(excluded)
def aggregate(rows,min_speed=2,precision=2):
 bins=defaultdict(lambda:defaultdict(list));exclusions=defaultdict(int)
 for row in rows:
  values,exc=samples(row,min_speed,precision)
  for k,v in exc.items():exclusions[k]+=v
  for s in values.values():
   for key in (s['group']+'/'+s['zone'],'ALL/'+s['zone'],row['kind']+'/ALL/'+s['zone']):
    for m,v in s['values'].items():bins[key][m].append(v)
 return {'bins':{k:{m:stats(v) for m,v in ms.items()} for k,ms in bins.items()},'exclusions':dict(exclusions)}
def paired(before,after):
 # Same actor/time, both arms satisfy the speed and clear-all conditions;
 # truncate to common exposure, never pad a completed play.
 bins=defaultdict(lambda:defaultdict(lambda:defaultdict(list)));counts={}
 for a,b in zip(before,after):
  assert a['id']==b['id'] and a['ids']==b['ids']
  sa,_=samples(a);sb,_=samples(b);counts[a['id']]=0
  for key,x in sa.items():
   y=sb.get(key)
   if not y or x['zone']!='clear_all' or y['zone']!='clear_all':continue
   counts[a['id']]+=1
   for group in ('ALL',x['group']):
    for arm,s in [('baseline',x),('candidate',y)]:
     for m,v in s['values'].items():bins[group][arm][m].append(v)
 return {'bins':{k:{arm:{m:stats(v) for m,v in ms.items()} for arm,ms in arms.items()} for k,arms in bins.items()},'samples_by_play':counts}
def load(p):return json.load(gzip.open(p))
def read_native(p):
 r=load(p);initial=r['initial'];ids=[a['slot'] for a in initial]
 group=lambda p:'OL' if p in ('OT','OG','C','T','G') else 'DL' if p in ('DE','DT','NT','EDGE') else 'DB' if p in ('CB','FS','SS','S') else 'LB' if p in ('MLB','OLB','ILB') else 'RB' if p=='FB' else p
 frames=[r['ticks'][0]['before']]+[t['after'] for t in r['ticks'] if abs(t['completed']*10-round(t['completed']*10))<1e-6]
 return {'id':r['id'],'kind':r['setup']['offCall']['kind'],'groups':[group(a['player']['position']) for a in initial],
  'sides':['O' if i<11 else 'D' for i in range(len(ids))],'ids':ids,
  'tracks':[[[f[i]['pos']['x'],f[i]['pos']['y']] for f in frames] for i in range(len(ids))],
  'facings':[[f[i]['facing'] for f in frames] for i in range(len(ids))]}
def main():
 evidence=Path(sys.argv[1]) if len(sys.argv)>1 else OUT
 selection=json.loads((evidence/'selection.json').read_text())
 paths=[evidence/p for p in selection['baseline']]
 before=[read_native(p) for p in paths];candidate_paths=[evidence/p for p in selection['candidate']];after=[read_native(p) for p in candidate_paths]
 nfl=load(evidence/'nfl-selected.json.gz')
 result={'definition':__doc__,'native_inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths+candidate_paths],
  'baseline':aggregate(before),'candidate':aggregate(after),'nfl':aggregate(nfl),'paired_clear_all':paired(before,after),
  'low_speed_sensitivity':{name:aggregate(rows,.5) for name,rows in [('baseline',before),('candidate',after),('nfl',nfl)]}}
 (evidence/'comparison.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 for label in ('baseline','candidate','nfl'):
  print(label,{k:{m:round(s['mean'],4) for m,s in ms.items()} for k,ms in result[label]['bins'].items() if k in ('ALL/clear_all','ALL/near_teammate','ALL/near_opponent')})
 print('paired ALL',result['paired_clear_all']['bins']['ALL'])
if __name__=='__main__':main()
