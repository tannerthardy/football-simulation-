import importlib.util,math,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('jitter_operator',Path(__file__).with_name('compare.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def row(points,faces=None):
 return {'id':'test','kind':'run','ids':['1'],'groups':['LB'],'sides':['D'],'tracks':[points],'facings':[faces or [0]*len(points)]}
class Operator(unittest.TestCase):
 def test_straight_constant_speed_is_not_jitter(self):
  a,_=m.samples(row([[k*.4,0] for k in range(12)]))
  self.assertTrue(a)
  for s in a.values():
   self.assertEqual(s['zone'],'clear_all')
   for k in ('yaw_reversal_deg','heading_reversal_deg','speed_pulse_ydps'):self.assertAlmostEqual(s['values'][k],0)
 def test_purposeful_curve_does_not_count_as_alternating_heading(self):
  a,_=m.samples(row([[4*math.cos(k*.1),4*math.sin(k*.1)] for k in range(12)],[k*.1 for k in range(12)]))
  self.assertTrue(a)
  for s in a.values():self.assertEqual(s['values']['heading_reversal_deg'],0);self.assertEqual(s['values']['yaw_reversal_deg'],0)
 def test_opposite_turns_are_detected_and_wrap_is_shortest(self):
  a,_=m.samples(row([[0,0],[.4,0],[.8,.1],[1.2,0]],[math.radians(x) for x in (176,178,-179,178)]))
  s=a[('1',3)]['values'];self.assertGreater(s['heading_reversal_deg'],10);self.assertAlmostEqual(s['yaw_reversal_deg'],3)
 def test_missing_positions_are_never_filled_or_classified_clear(self):
  r=row([[k*.4,0] for k in range(5)]);r['tracks'][0][1]=None
  a,e=m.samples(r);self.assertEqual(a,{});self.assertEqual(e['missing_actor_position'],2)
  r=row([[k*.4,0] for k in range(5)]);r['ids']+=['2'];r['groups']+=['RB'];r['sides']+=['O'];r['tracks'] += [[None]*5];r['facings'] += [[None]*5]
  a,_=m.samples(r);self.assertTrue(a);self.assertTrue(all(s['zone']=='unknown_proximity' for s in a.values()))
 def test_low_speed_heading_is_excluded(self):
  a,e=m.samples(row([[k*.1,0] for k in range(8)]));self.assertFalse(a);self.assertEqual(e['below_speed_gate'],5)
 def test_teammates_and_opponents_have_distinct_proximity_labels(self):
  r=row([[k*.4,0] for k in range(5)]);r['ids']+=['2'];r['groups']+=['RB'];r['sides']+=['D'];r['tracks'] += [[[k*.4,1] for k in range(5)]];r['facings'] += [[0]*5]
  a,_=m.samples(r);self.assertTrue(all(s['zone']=='near_teammate' for s in a.values()))
  r['sides'][1]='O';a,_=m.samples(r);self.assertTrue(all(s['zone']=='near_opponent' for s in a.values()))
 def test_pairing_does_not_pad_a_completed_play(self):
  a=row([[k*.4,0] for k in range(10)]);b=row([[k*.4,0] for k in range(5)])
  p=m.paired([a],[b]);self.assertEqual(p['samples_by_play']['test'],2)
if __name__=='__main__':unittest.main()
