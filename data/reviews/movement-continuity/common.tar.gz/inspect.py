import csv, gzip, hashlib, importlib.util, itertools, json, math, sys, time
from pathlib import Path
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'out/movement-continuity'
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def summary(v):
 if not v:return {'n':0}
 v=sorted(v)
 return {'n':len(v),'mean':sum(v)/len(v),'p50':v[len(v)//2],'p90':v[int((len(v)-1)*.9)]}
def angle(a,b):return math.atan2(a[0]*b[1]-a[1]*b[0],a[0]*b[0]+a[1]*b[1])
def metrics(row):
 # Four consecutive 10Hz positions; no provider speed, no interpolation.
 tracks=row['tracks']; groups=row['groups']; sides=row['sides']; bins=defaultdict(lambda:defaultdict(list)); worst=[]
 for i,xy in enumerate(tracks):
  xy=[None if p is None else [round(c,2) for c in p] for p in xy]
  for k in range(3,len(xy)):
   pts=xy[k-3:k+1]
   if any(p is None for p in pts):continue
   v=[[(b[d]-a[d])*10 for d in (0,1)] for a,b in zip(pts,pts[1:])]
   s=[math.hypot(*p) for p in v]
   if min(s)<2:continue
   turns=[angle(a,b)*180/math.pi for a,b in zip(v,v[1:])]
   pulsing=abs(s[2]-2*s[1]+s[0])
   reversal=min(abs(turns[0]),abs(turns[1])) if turns[0]*turns[1]<0 else 0
   near=any(j!=i and sides[j]!=sides[i] and all(tracks[j][f] is not None and math.dist(tracks[i][f],tracks[j][f])<=1.5 for f in (k-1,k)) for j in range(len(tracks)))
   # Free requires all opponents >1.5yd throughout this short window.
   free=not any(j!=i and sides[j]!=sides[i] and any(tracks[j][f] is not None and math.dist(tracks[i][f],tracks[j][f])<=1.5 for f in range(k-3,k+1)) for j in range(len(tracks)))
   zone='free' if free else 'near' if near else 'transition'
   for key in (groups[i]+'/'+zone,'ALL/'+zone):
    facing=row.get('facings',[]); yaw=[math.degrees(math.atan2(math.sin(facing[i][j]-facing[i][j-1]),math.cos(facing[i][j]-facing[i][j-1]))) for j in (k-1,k)] if facing and all(facing[i][j] is not None for j in (k-2,k-1,k)) else None
    if yaw:
     bins[key]['yaw_turn_deg'].append(abs(yaw[1]));bins[key]['yaw_reversal_deg'].append(min(map(abs,yaw)) if yaw[0]*yaw[1]<0 else 0)
    bins[key]['turn_deg'].append(abs(turns[1]));bins[key]['pulse_ydps'].append(pulsing);bins[key]['reversal_deg'].append(reversal);bins[key]['speed_ydps'].append(s[1])
   if free:worst.append({'play':row['id'],'actor':row['ids'][i],'group':groups[i],'t':round(k*.1,2),'turns':turns,'speeds':s,'reversal':reversal,'pulse':pulsing})
 return {k:{m:summary(v) for m,v in d.items()} for k,d in bins.items()},worst
def native(path):
 r=json.load(gzip.open(path)); ids=[a['slot'] for a in r['initial']]; groups=[a['player']['position'] for a in r['initial']]
 group=lambda p:'OL' if p in ('OT','OG','C','T','G') else 'DL' if p in ('DE','DT','NT','EDGE') else 'DB' if p in ('CB','FS','SS','S') else 'LB' if p in ('MLB','OLB','ILB') else p
 groups=list(map(group,groups));snap=[a['pos'] for a in r['initial']]
 frames=[snap]+[[a['pos'] for a in t['after']] for t in r['ticks'] if abs(t['completed']*10-round(t['completed']*10))<1e-6]
 return {'id':r['id'],'kind':r['setup']['offCall']['kind'] if 'offCall' in r['setup'] else 'unknown','groups':groups,'sides':['O' if i<11 else 'D' for i in range(len(ids))],'ids':ids,'tracks':[[[f[i]['x'],f[i]['y']] for f in frames] for i in range(len(ids))],'facings':[[r['ticks'][0]['before'][i]['facing']]+[t['after'][i]['facing'] for t in r['ticks'] if abs(t['completed']*10-round(t['completed']*10))<1e-6] for i in range(len(ids))],'native':str(path),'source':r['source']}
def nfl():
 data=Path('/workspace/football-yac-angle/data/raw/bdb2025/big-data-bowl-data');start=time.perf_counter()
 sys.path.insert(0,str(ROOT/'scripts/mechanics'))
 import nfl_bdb2025 as adapter
 adapter.DATA=data;position,meta=adapter.load_meta()
 counts={'run':0,'pass':0};selected=[];file=data/'tracking_week_1.csv'
 with file.open(newline='') as f:
  reader=csv.reader(f);next(reader)
  for key,rows in itertools.groupby(reader,key=lambda r:(r[0],r[1])):
   rows=list(rows);m=meta.get(key)
   if not m or counts[m['kind']]>=({'run':12,'pass':8}[m['kind']]):continue
   snap=next((int(r[4]) for r in rows if r[5]=='SNAP'),None)
   if snap is None:continue
   # Same adapter meta/groups/events; raw valid samples, never forward filled.
   common=adapter.convert(key,rows,m,position)
   if common is None:continue
   end=min(6.,common['events'].get('end',6.)); n=int(end*10)+1
   records={}; facings={}
   for r in rows:
    k=int(r[4])-snap
    if r[2]=='NA' or not 0<=k<n:continue
    records.setdefault(r[2],[None]*n)[k]=[float(r[10]),float(r[11])]
    facings.setdefault(r[2],[None]*n)[k]=None if r[15] in ('NA','') else math.radians(90-float(r[15]))
   ids=sorted(records,key=lambda i:(next(r[8] for r in rows if r[2]==i)!=m['offense'],i))
   if len(ids)!=22:continue
   groups=[adapter.GROUP.get(position.get(i,'')) for i in ids]
   if None in groups:continue
   selected.append({'id':':'.join(key),'kind':m['kind'],'concept':m['concept'],'yards':m['yards'],'groups':groups,'sides':['O' if j<11 else 'D' for j in range(22)],'ids':ids,'tracks':[records[i] for i in ids],'facings':[facings[i] for i in ids],'events':common['events']})
   counts[m['kind']]+=1
   if counts=={'run':12,'pass':8}:break
   if time.perf_counter()-start>45:raise RuntimeError('45s budget')
 receipt={'source':str(data),'week1_sha256':sha(file),'files':{p.name:sha(p) for p in [data/'players.csv',data/'plays.csv',data/'player_play.csv']},'selection':'First eligible 12 designed runs and 8 dropbacks in existing week1 file order; outcomes not used. First six live seconds only. No imputation. NFL near/free is proximity, not measured contact.','counts':counts,'elapsed_s':time.perf_counter()-start}
 (OUT/'nfl-receipt.json').write_text(json.dumps(receipt,indent=2))
 with gzip.open(OUT/'nfl-selected.json.gz','wt') as f:json.dump(selected,f)
 return selected
def main():
 if sys.argv[1]=='nfl':nfl();return
 if sys.argv[1] in ('native','pilot'):
  base=Path('/workspace/football-defensive-snap-response/out/defensive-snap-response')
  paths=list((base/'baseline').glob('*.json.gz'))+list((base/'fresh-baseline').glob('*.json.gz'))+list(Path('/workspace/football-linebacker-run-flow/out/run-flow/extra-baseline').glob('*.json.gz'))
  if sys.argv[1]=='pilot':paths=list((OUT/'pilot').glob('*.json.gz'))
  rows=[native(p) for p in paths]
  with gzip.open(OUT/'native-selected.json.gz','wt') as f:json.dump(rows,f)
  print([(r['id'],r['groups']) for r in rows[:1]])
 else:rows=json.load(gzip.open(OUT/'nfl-selected.json.gz'))
 # Pool actual samples (not per-play percentiles) by retrieving per-play operator
 # values; expand summary-only aggregation below in the committed operator.
 totals=defaultdict(lambda:defaultdict(list));worst=[]
 for row in rows:
  bins,w=metrics(row);worst+=w
  for key,ms in bins.items():
   for metric,s in ms.items():totals[key][metric].append(s)
 out={k:{m:{'n':sum(s['n'] for s in v),'mean':sum(s['mean']*s['n'] for s in v)/sum(s['n'] for s in v)} for m,v in ms.items()} for k,ms in totals.items()}
 (OUT/(sys.argv[1]+'-metrics.json')).write_text(json.dumps({'bins':out,'worst_reversals':sorted(worst,key=lambda r:r['reversal'],reverse=True)[:24],'worst_pulses':sorted(worst,key=lambda r:r['pulse'],reverse=True)[:24]},indent=2))
 print(json.dumps(out,indent=2));print('WORST',json.dumps(sorted(worst,key=lambda r:r['reversal'],reverse=True)[:8]))
if __name__=='__main__':main()
