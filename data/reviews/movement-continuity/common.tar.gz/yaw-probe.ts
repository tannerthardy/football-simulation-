import {World} from '../../src/physics/world.ts';
import {angleDiff} from '../../src/core/vec.ts';
import {writeFileSync} from 'node:fs';
const profile={massKg:100,radius:.3,reach:1,heightYd:2.05,vmax:9,tau:1.3,brake:6,lateral:6,turnRate:8,backpedal:.6,shuffle:.55,maxCatchHeight:3,reactReach:2.6,reactionTime:.25,power:100,balance:.5};
const rows=[];
for(const target of [.2,Math.PI/2])for(const speed of [0,3,7])for(const substeps of [1,12,48]){
 const b={pos:{x:0,y:0},vel:{x:speed,y:0},facing:0,energy:1,profile:{...profile}};const world=new World([b],{substeps}); const ticks=[];
 // An explicit stationary facing with constant requested travel, no perception,
 // randomness, contact, spacing or decisions. Native World law only.
 for(let k=0;k<60;k++) {const r=world.step([{vel:{x:speed,y:0},facing:target}],.05);ticks.push({t:(k+1)*.05,facing:b.facing,error:angleDiff(b.facing,target),spin:b.spin,pos:{...b.pos},vel:{...b.vel},work:r.work.residual});}
 rows.push({target,speed,substeps,ticks});
}
writeFileSync(process.argv[2]??'out/movement-continuity/yaw-baseline.json',JSON.stringify(rows));
console.log(JSON.stringify(rows.filter(r=>r.substeps===12).map(r=>({target:r.target,speed:r.speed,lastError:r.ticks.at(-1).error,maxErrorAfterHalfSecond:Math.max(...r.ticks.slice(10).map(t=>Math.abs(t.error))),reversals:r.ticks.slice(11).filter((t,k)=>t.spin*r.ticks[k+10].spin<0).length,maxResidual:Math.max(...r.ticks.map(t=>Math.abs(t.work)))}))));
